/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include <tcl.h>

#include <sam9407.h>

#include "ctrlnames.h"

#ifndef MAP_FAILED
#define MAP_FAILED ((void *)-1)
#endif

#define NumberOf(vec) (sizeof(vec)/sizeof(*(vec)))

typedef struct SubCommand {
  char *name;
  int (*function)(struct SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
} SubCommand;

typedef struct {
  int inUse, fd, noEvents;
  int apiClass;
  Tcl_Interp *interp;
  Tcl_DString eventCmd;
} MixerContext;

typedef struct {
  SamCtrlNameAssoc *assocs;
  int nIds, nAddrs;
  SamCtrlNameAssoc **byId;
  Tcl_HashTable byName;
} Controls;

typedef struct {
  char *name;
  Controls mixerFWCtrls, audioCtrls;
} ApiInfo;

typedef struct {
  Controls mixerHWCtrls;
} DriverInfo;

static int nApiInfo;
static ApiInfo **apiInfoById;
static Tcl_HashTable apiInfoByName;
static DriverInfo driverInfo;

static MixerContext mixerContexts[64];

static void mixerEvent(ClientData clientData, int mask);
static int openCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int closeCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int fileCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int eventCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int apiInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int syncJoinCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int syncLeaveCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int syncInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int driverInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int hwHintsGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int hwHintsSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int firmwareLoadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerKnownCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerAudioKnownCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerAudioGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerAudioSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int mixerAudioInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int channelOwnerInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int bankLoadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int bankUnloadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int bankPrioChgCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int bankInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);
static int peakMeterInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv);

static SubCommand x9407SubCommands[]={
  {
    "open",
    openCmd
  },
  {
    "close",
    closeCmd
  },
  {
    "file",
    fileCmd
  },
  {
    "event",
    eventCmd
  },
  {
    "api_info",
    apiInfoCmd
  },
  {
    "sync_join",
    syncJoinCmd
  },
  {
    "sync_leave",
    syncLeaveCmd
  },
  {
    "sync_info",
    syncInfoCmd
  },
  {
    "driver_info",
    driverInfoCmd
  },
  {
    "hw_hints_get",
    hwHintsGetCmd
  },
  {
    "hw_hints_set",
    hwHintsSetCmd
  },
  {
    "firmware_load",
    firmwareLoadCmd
  },
  {
    "mixer_known",
    mixerKnownCmd
  },
  {
    "mixer_get",
    mixerGetCmd
  },
  {
    "mixer_set",
    mixerSetCmd
  },
  {
    "mixer_info",
    mixerInfoCmd
  },
  {
    "mixer_audio_known",
    mixerAudioKnownCmd
  },
  {
    "mixer_audio_get",
    mixerAudioGetCmd
  },
  {
    "mixer_audio_set",
    mixerAudioSetCmd
  },
  {
    "mixer_audio_info",
    mixerAudioInfoCmd
  },
  {
    "channel_owner_info",
    channelOwnerInfoCmd
  },
  {
    "bank_load",
    bankLoadCmd
  },
  {
    "bank_unload",
    bankUnloadCmd
  },
  {
    "bank_prio_chg",
    bankPrioChgCmd
  },
  {
    "bank_info",
    bankInfoCmd
  },
  {
    "peak_meter_info",
    peakMeterInfoCmd
  },
  {
    NULL			/* sentinel */
  }
};

static int commonCmd(SubCommand *subCommands, Tcl_Interp *interp, int argc, char **argv)
{
  char *opt;
  struct SubCommand *subCmd;
  if(argc<2) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " option ?arg?\"", NULL);
    return TCL_ERROR;
  }
  opt=argv[1];
  for(subCmd=subCommands;subCmd->name;subCmd++) {
    if(opt[0]==subCmd->name[0] && strcmp(opt,subCmd->name)==0)
      return (*subCmd->function)(subCmd, interp, argc, argv);
  }

  Tcl_AppendResult(interp, argv[0], ": bad option \"", opt, "\": must be ", NULL);
  for(subCmd=subCommands;subCmd->name;subCmd++) {
    Tcl_AppendResult(interp, subCmd->name, NULL);
    if(subCmd[1].name) {
      if(subCmd[2].name)
	Tcl_AppendResult(interp, ", ", NULL);
      else
	Tcl_AppendResult(interp, " or ", NULL);
    }
  }
  return TCL_ERROR;
}

/* Parse options in a unified way
 * all varargs parameter come in pairs, which is
 * char *optionName, int *destValue
 */
static int parseOptions(Tcl_Interp *interp, char *argv0, char *subCmd, int *argcP, char ***argvP, ...)
{
  va_list ap;
  char *optionName, **destValueWithArg=NULL;
  int *destValue=NULL,found,first,withArg;
  /* initialize all values */
  va_start(ap, argvP);
  for(;;) {
    optionName=va_arg(ap, char *);
    if(!optionName)
      break;
    withArg=*optionName==':';
    if(withArg) {
      destValueWithArg=va_arg(ap, char **);
      *destValueWithArg=NULL;
    } else {
      destValue=va_arg(ap, int *);
      *destValue=0;
    }
  }
  va_end(ap);
  /* now check for options */
  while(*argcP>0 && ***argvP=='-') {
    if(strcmp(**argvP,"--")==0) {
      (*argcP)--;
      (*argvP)++;
      break;
    }
    found=0;
    va_start(ap, argvP);
    for(;;) {
      optionName=va_arg(ap, char *);
      if(!optionName)
	break;
      withArg=*optionName==':';
      if(withArg){
	optionName++;
	destValueWithArg=va_arg(ap, char **);
      } else
	destValue=va_arg(ap, int *);
      if(strcmp(**argvP+1,optionName)==0) {
	if(withArg) {
	  (*argcP)--;
	  (*argvP)++;
	  *destValueWithArg=**argvP;
	} else
	  *destValue=1;
	found=1;
	break;
      }
    }
    va_end(ap);
    if(!found) {
      Tcl_AppendResult(interp, argv0, NULL);
      if(subCmd)
	Tcl_AppendResult(interp, " ", subCmd, NULL);
      Tcl_AppendResult(interp, ": bad option \"", **argvP, "\": should be ",NULL);
      first=1;
      va_start(ap, argvP);
      for(;;) {
	optionName=va_arg(ap, char *);
	if(!optionName)
	  break;
	withArg=*optionName==':';
	(void)va_arg(ap, int *);
	if(!first)
	  Tcl_AppendResult(interp, ", ", NULL);
	else
	  first=0;
	if(withArg)
	  Tcl_AppendResult(interp, "-", optionName+1, " arg", NULL);
	else
	  Tcl_AppendResult(interp, "-", optionName, NULL);
      }
      va_end(ap);
      Tcl_AppendResult(interp, " or --", NULL);
      return TCL_ERROR;
    }
    (*argcP)--;
    (*argvP)++;
  }
  return TCL_OK;
}

static int getChannelId(Tcl_Interp *interp, char *channelStr, MixerContext **dest)
{
  int channelId;

  if(channelStr) {
    if(strncmp(channelStr, "sam_", 4)==0)
      channelId=atoi(channelStr+4);
    else
      channelId=-1;
  } else
    channelId=0;

  if(channelId>=0 && channelId<NumberOf(mixerContexts) &&
     mixerContexts[channelId].inUse) {
    *dest=mixerContexts+channelId;
    return TCL_OK;
  }

  if(channelId)
    Tcl_AppendResult(interp, "wrong sam9407 channel id \"", channelStr, "\"", NULL);
  else
    Tcl_AppendResult(interp, "sam9407 channel not open", NULL);

  return TCL_ERROR;
}

static void appendAttr(Tcl_DString *dstr, char *name, char *value)
{
  Tcl_DStringStartSublist(dstr);
  Tcl_DStringAppendElement(dstr, name);
  Tcl_DStringAppendElement(dstr, value);
  Tcl_DStringEndSublist(dstr);
}

static void appendAttrInt(Tcl_DString *dstr, char *name, int value)
{
  char buf[32];
  sprintf(buf, "%d", value);
  appendAttr(dstr, name, buf);
}

static void mixerEvent(ClientData clientData, int mask)
{
  int channelId=(int)(long)clientData;
  MixerContext *context=mixerContexts+channelId;
  ApiInfo *apiInfo;
  SamCtrlNameAssoc *assoc;
  SamEvent events[256], *event;
  int n, i;
  char buf[32];
  Tcl_DString interpResult, cmd;
  Tcl_CmdInfo cmdInfo;

  if((n=read(context->fd, events, sizeof(events)))<0) {
    fprintf(stderr, "fatal: can't read sam9407 dirty flags.\n");
    exit(1);
  }

  n/=sizeof(SamEvent);

  if(!*Tcl_DStringValue(&context->eventCmd))
    return;

  if(!(apiInfo=apiInfoById[context->apiClass]))
    return;

  Tcl_DStringInit(&interpResult);
  Tcl_DStringAppend(&interpResult, context->interp->result, -1);

  Tcl_DStringInit(&cmd);
  Tcl_DStringAppendElement(&cmd, Tcl_DStringValue(&context->eventCmd));
  sprintf(buf, "sam_%d", channelId);
  Tcl_DStringAppendElement(&cmd, buf);
  Tcl_DStringStartSublist(&cmd);
  for(i=0; i<n; i++) {
    event=events+i;
    if(event->type>=0) {
      /* audio event */
      if(event->id<apiInfo->audioCtrls.nIds &&
	 apiInfo->audioCtrls.byId[event->id]) {
	Tcl_DStringStartSublist(&cmd);
	Tcl_DStringAppendElement(&cmd, "audio");
	sprintf(buf, "%d", event->type);
	Tcl_DStringAppendElement(&cmd, buf);
	Tcl_DStringAppendElement(&cmd, apiInfo->audioCtrls.byId[event->id]->name);
	sprintf(buf, "%d", event->addr);
	Tcl_DStringAppendElement(&cmd, buf);
	Tcl_DStringEndSublist(&cmd);
      }
    } else {
      switch(event->type) {
      case SAM_EVENT_TYPE_MIXER:
	assoc=NULL;
	if(event->id>=SAM_MIXER_HW_ID_FIRST) {
	  if(event->id-SAM_MIXER_HW_ID_FIRST<driverInfo.mixerHWCtrls.nIds)
	    assoc=driverInfo.mixerHWCtrls.byId[event->id-SAM_MIXER_HW_ID_FIRST];
	} else {
	  if(event->id<apiInfo->mixerFWCtrls.nIds)
	    assoc=apiInfo->mixerFWCtrls.byId[event->id];
	}
	if(assoc) {
	  Tcl_DStringStartSublist(&cmd);
	  Tcl_DStringAppendElement(&cmd, "mixer");
	  Tcl_DStringAppendElement(&cmd, assoc->name);
	  sprintf(buf, "%d", event->addr);
	  Tcl_DStringAppendElement(&cmd, buf);
	  Tcl_DStringEndSublist(&cmd);
	}
	break;
      case SAM_EVENT_TYPE_NOCTRL:
	switch(event->id) {
	case SAM_EVENT_FIRMWARE_CHANGED:
	  Tcl_DStringAppendElement(&cmd, "firmware");
	  break;
	case SAM_EVENT_SBANK_CHANGED:
	  Tcl_DStringAppendElement(&cmd, "sbank");
	  break;
	case SAM_EVENT_CHANNEL_OWNER_CHANGED:
	  Tcl_DStringAppendElement(&cmd, "channel_owner");
	  break;
	}
	break;
      }
    }
  }
  Tcl_DStringEndSublist(&cmd);
  if(Tcl_Eval(context->interp, Tcl_DStringValue(&cmd))!=TCL_OK) {
    if(Tcl_GetCommandInfo(context->interp, "bgerror", &cmdInfo)) {
      Tcl_DStringSetLength(&cmd, 0);
      Tcl_DStringAppendElement(&cmd, "bgerror");
      Tcl_DStringAppendElement(&cmd, Tcl_DStringValue(&context->eventCmd));
      Tcl_Eval(context->interp, Tcl_DStringValue(&cmd));
    } else
      fprintf(stderr, "warning: sam event command \"%s\" failed: %s\n", Tcl_DStringValue(&context->eventCmd), context->interp->result);
  }
  Tcl_DStringFree(&cmd);

  Tcl_DStringResult(context->interp, &interpResult);
  Tcl_DStringFree(&interpResult);
}

static int openCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionDevice, *optionCard;
  int optionNoEvents;
  char buf[256];
  MixerContext *context;
  int cardNr, channelId;
  SamApiInfo apiInfo;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":device", &optionDevice,
			":card", &optionCard,
			"noEvents", &optionNoEvents,
			NULL))!=TCL_OK)
    return code;

  context=NULL;
  for(channelId=0; channelId<NumberOf(mixerContexts); channelId++)
    if(!mixerContexts[channelId].inUse) {
      context=mixerContexts+channelId;
      break;
    }

  if(!context) {
    Tcl_AppendResult(interp, "too many open sam9407 channels", NULL);
    return TCL_ERROR;
  }

  memset(context, 0, sizeof(MixerContext));
  context->interp=interp;
  context->noEvents=optionNoEvents;
  Tcl_DStringInit(&context->eventCmd);

  if(optionDevice) {
    context->fd=open(optionDevice, O_RDWR);
  } else {
    if(optionCard)
      cardNr=strtol(optionCard, NULL, 0);
    else
      cardNr=0;

    sprintf(buf, "/dev/sam9407/card%d/mixer", cardNr);
    context->fd=open(buf, O_RDWR);
    if(context->fd<0) {
      sprintf(buf, "/dev/sam%d_mixer", cardNr);
      context->fd=open(buf, O_RDWR);
    }
    if(context->fd<0 && cardNr==0) {
      sprintf(buf, "/dev/mixer");
      context->fd=open(buf, O_RDWR);
    }
  }

  if(context->fd<0) {
    Tcl_AppendResult(interp, "can't open sam9407 device: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(ioctl(context->fd, SAM_IOC_API_INFO, &apiInfo)<0) {
    close(context->fd);
    Tcl_AppendResult(interp, "can't query sam9407 API information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(apiInfo.version!=SAM_MIXER_API_VERSION) {
    close(context->fd);
    Tcl_AppendResult(interp, "incompatible sam9407 API versions, please recompile the Tcl module", NULL);
    return TCL_ERROR;
  }

    
  if(apiInfo.apiClass>=0 && apiInfo.apiClass<nApiInfo)
    context->apiClass=apiInfo.apiClass;
  else
    context->apiClass=SAM_API_CLASS_NONE;

  if(!context->noEvents) {
#if TCL_MAJOR_VERSION<8
    Tcl_CreateFileHandler(Tcl_GetFile(context->fd, TCL_UNIX_FD), TCL_READABLE, mixerEvent, (ClientData)(long)channelId);
#else
    Tcl_CreateFileHandler(context->fd, TCL_READABLE, mixerEvent, (ClientData)(long)channelId);
#endif
  }

  context->inUse=1;
  sprintf(buf, "sam_%d", channelId);
  Tcl_AppendResult(interp, buf, NULL);

  return TCL_OK;
}

static int closeCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  MixerContext *context;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, localArgc>0 ? localArgv[0] : NULL, &context))!=TCL_OK)
    return code;

  if(!context->noEvents) {
#if TCL_MAJOR_VERSION<8
    Tcl_DeleteFileHandler(Tcl_GetFile(context->fd, TCL_UNIX_FD));
#else
    Tcl_DeleteFileHandler(context->fd);
#endif
  }

  close(context->fd);
  context->inUse=0;

  Tcl_DStringFree(&context->eventCmd);

  return TCL_OK;
}

static int fileCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  sprintf(buf, "%d", context->fd);
  Tcl_AppendResult(interp, buf, NULL);

  return TCL_OK;
}

static int eventCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  Tcl_DStringSetLength(&context->eventCmd, 0);
  if(localArgc>0)
    Tcl_DStringAppend(&context->eventCmd, localArgv[0], -1);

  return TCL_OK;
}

static int apiInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  SamApiInfo apiInfo;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_API_INFO, &apiInfo)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 API information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(apiInfo.version!=SAM_MIXER_API_VERSION) {
    context->apiClass=SAM_API_CLASS_NONE;
    Tcl_AppendResult(interp, "incompatible sam9407 API versions, please recompile the Tcl module", NULL);
    return TCL_ERROR;
  }

  if(apiInfo.apiClass<0 || apiInfo.apiClass>=nApiInfo ||
     (apiInfo.apiClass!=SAM_API_CLASS_NONE && !apiInfoById[apiInfo.apiClass])) {
    context->apiClass=SAM_API_CLASS_NONE;
    Tcl_AppendResult(interp, "unsupported sam9407 API class", NULL);
    return TCL_ERROR;
  }

  context->apiClass=apiInfo.apiClass;

  Tcl_DStringInit(&dstr);
  appendAttrInt(&dstr, "version", SAM_MIXER_API_VERSION);
  appendAttr(&dstr, "apiClass", apiInfoById[context->apiClass] ? apiInfoById[context->apiClass]->name : "NONE");
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int syncJoinCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  int syncGroup;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;
  
  if(localArgc>0)
    syncGroup=strtol(localArgv[0], NULL, 0);
  else
    syncGroup=-1;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_SYNC_JOIN, &syncGroup)<0) {
    Tcl_AppendResult(interp, "can't join sam9407 sync group: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  sprintf(buf, "%d", syncGroup);
  Tcl_AppendResult(interp, buf, NULL);

  return TCL_OK;
}

static int syncLeaveCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_SYNC_LEAVE)<0) {
    Tcl_AppendResult(interp, "can't leave sam9407 sync group: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  return TCL_OK;
}

static int syncInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  int syncGroup;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_SYNC_INFO, &syncGroup)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 sync group: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  sprintf(buf, "%d", syncGroup);
  Tcl_AppendResult(interp, buf, NULL);

  return TCL_OK;
}

static int driverInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  SamDriverInfo driverInfo;
  Tcl_DString dstr;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 driver information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  sprintf(buf, "%d.%d.%d",
	  driverInfo.driverVersion.major,
	  driverInfo.driverVersion.minor,
	  driverInfo.driverVersion.tiny);
  appendAttr(&dstr, "version", buf);
  appendAttr(&dstr, "hardware", driverInfo.hardware);
  appendAttr(&dstr, "firmware", driverInfo.firmware);
  appendAttrInt(&dstr, "haveAudio", !!driverInfo.haveAudio);
  appendAttrInt(&dstr, "haveMidi", !!driverInfo.haveMidi);
  appendAttrInt(&dstr, "memTotal", driverInfo.memTotal);
  appendAttrInt(&dstr, "memFree", driverInfo.memFree);
  appendAttrInt(&dstr, "memSBanks", driverInfo.memSBanks);
  appendAttrInt(&dstr, "memAudio", driverInfo.memAudio);
  appendAttrInt(&dstr, "playChannelsUsed", driverInfo.playChannelsUsed);
  appendAttrInt(&dstr, "playChannelsTotal", driverInfo.playChannelsTotal);
  appendAttrInt(&dstr, "recordChannelsUsed", driverInfo.recordChannelsUsed);
  appendAttrInt(&dstr, "recordChannelsTotal", driverInfo.recordChannelsTotal);
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int hwHintsGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  SamHardwareHints hardwareHints;
  Tcl_DString dstr;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_HW_HINTS_GET, &hardwareHints)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 hardware hints: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  appendAttrInt(&dstr, "cardMem", hardwareHints.cardMem);
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int hwHintsSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel, *optionCardMem;
  MixerContext *context;
  SamHardwareHints hardwareHints;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			":cardMem", &optionCardMem,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_HW_HINTS_GET, &hardwareHints)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 hardware hints: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(optionCardMem)
    hardwareHints.cardMem=strtol(optionCardMem, NULL, 0);

  if(optionCardMem) {
    if(ioctl(context->fd, SAM_IOC_HW_HINTS_SET, &hardwareHints)<0) {
      Tcl_AppendResult(interp, "can't set sam9407 hardware hints: ", strerror(errno), NULL);
      return TCL_ERROR;
    }
  }

  return TCL_OK;
}

static int firmwareLoadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  SamFirmware firmware;
  int fd;
  struct stat st;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(localArgc<1) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " firmware_load ?-channel channel? ?--? file_name\"", NULL);
    return TCL_ERROR;
  }

  memset(&firmware, 0, sizeof(SamFirmware));
  if((fd=open(localArgv[0], O_RDONLY))<0) {
    Tcl_AppendResult(interp, "can't open firmware file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(fstat(fd, &st)<0) {
    close(fd);
    Tcl_AppendResult(interp, "can't stat firmware file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if((firmware.data=(unsigned short *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    close(fd);
    Tcl_AppendResult(interp, "can't map firmware file \"", localArgv[0], "\" to memory: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  firmware.size=st.st_size>>1;
  if(ioctl(context->fd, SAM_IOC_FIRMWARE_LOAD, &firmware)<0) {
    munmap((void *)firmware.data, st.st_size);
    close(fd);
    Tcl_AppendResult(interp, "can't upload firmware file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  munmap((void *)firmware.data, st.st_size);
  close(fd);

  return TCL_OK;
}

static int mixerKnownCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  ApiInfo *apiInfo;
  int i;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  Tcl_DStringInit(&dstr);
  for(i=0; i<driverInfo.mixerHWCtrls.nIds; i++)
    if(driverInfo.mixerHWCtrls.byId[i])
      Tcl_DStringAppendElement(&dstr, driverInfo.mixerHWCtrls.byId[i]->name);
  apiInfo=apiInfoById[context->apiClass];
  if(apiInfo) {
    for(i=0; i<apiInfo->mixerFWCtrls.nIds; i++)
      if(apiInfo->mixerFWCtrls.byId[i])
	Tcl_DStringAppendElement(&dstr, apiInfo->mixerFWCtrls.byId[i]->name);
  }

  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int parseMixerAudioCtrls(Tcl_Interp *interp, MixerContext *context, char *kind,
				Controls *searchFirst, Controls *searchSecond,
				int setValue, int localArgc, char **localArgv, SamControl *controls)
{
  int code, valueArgc;
  char **valueArgv;
  Tcl_HashEntry *entry;
  SamCtrlNameAssoc *assoc;
  int i;

  for(i=0; i<localArgc; i++) {
    if((code=Tcl_SplitList(interp, localArgv[i], &valueArgc, &valueArgv))!=TCL_OK)
      return code;

    assoc=NULL;
    if(valueArgc>=1) {
      entry=Tcl_FindHashEntry(&searchFirst->byName, valueArgv[0]);
      if(!entry && searchSecond)
	entry=Tcl_FindHashEntry(&searchSecond->byName, valueArgv[0]);
      if(entry)
	assoc=(SamCtrlNameAssoc *)Tcl_GetHashValue(entry);
    }
    if(!assoc) {
      Tcl_Free((char *)valueArgv);
      Tcl_AppendResult(interp, "unknown ", kind, " control \"", localArgv[i], "\"", NULL);
      return TCL_ERROR;
    }
    controls[i].id=assoc->id;
    if(valueArgc>1)
      controls[i].addr=strtol(valueArgv[1], NULL, 0);
    else
      controls[i].addr=0;
    if(setValue && valueArgc>2)
      controls[i].value=strtol(valueArgv[2], NULL, 0);
    else
      controls[i].value=0;

    Tcl_Free((char *)valueArgv);
  }

  controls[i].id=SAM_MIXER_ID_SENTINEL;

  return TCL_OK;
}

static int mixerGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  Tcl_DString dstr;
  SamControl *controls;
  int i;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no mixer controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  if(!controls) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "mixer",
				&apiInfo->mixerFWCtrls, &driverInfo.mixerHWCtrls,
				0, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_MIXER_GET, controls)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 mixer settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; controls[i].id!=SAM_MIXER_ID_SENTINEL; i++) {
    Tcl_DStringStartSublist(&dstr);
    if(controls[i].id>=SAM_MIXER_HW_ID_FIRST)
      Tcl_DStringAppendElement(&dstr, driverInfo.mixerHWCtrls.byId[controls[i].id-SAM_MIXER_HW_ID_FIRST]->name);
    else
      Tcl_DStringAppendElement(&dstr, apiInfo->mixerFWCtrls.byId[controls[i].id]->name);
    sprintf(buf, "%d", controls[i].addr);
    Tcl_DStringAppendElement(&dstr, buf);
    sprintf(buf, "%d", controls[i].value);
    Tcl_DStringAppendElement(&dstr, buf);
    Tcl_DStringEndSublist(&dstr);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int mixerSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  SamControl *controls, *resetControls, *backup, *ctrlP;
  int i, addr, addrLimit, resetIdx, nonResetIdx;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no mixer controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  resetControls=alloca((localArgc+1)*sizeof(SamControl));
  backup=alloca((driverInfo.mixerHWCtrls.nAddrs+apiInfo->mixerFWCtrls.nAddrs+1)*sizeof(SamControl));
  if(!controls || !resetControls || !backup) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "mixer",
				&apiInfo->mixerFWCtrls, &driverInfo.mixerHWCtrls,
				1, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  /* take out resetControls, as we'll backup old
   * non-reset values and restore them after a reset
   */
  resetIdx=nonResetIdx=0;
  for(i=0; controls[i].id!=SAM_MIXER_ID_SENTINEL; i++) {
    if((controls[i].id>=SAM_MIXER_HW_ID_FIRST && driverInfo.mixerHWCtrls.byId[controls[i].id-SAM_MIXER_HW_ID_FIRST]->doesReset) ||
       (controls[i].id<SAM_MIXER_HW_ID_FIRST && apiInfo->mixerFWCtrls.byId[controls[i].id]->doesReset))
      memcpy(resetControls+resetIdx++, controls+i, sizeof(SamControl));
    else {
      if(nonResetIdx!=i)
	memcpy(controls+nonResetIdx, controls+i, sizeof(SamControl));
      nonResetIdx++;
    }
  }
  controls[nonResetIdx].id=SAM_MIXER_ID_SENTINEL;
  resetControls[resetIdx].id=SAM_MIXER_ID_SENTINEL;

  if(resetIdx) {
    /* backup non-reset values */
    ctrlP=backup;
    for(i=0; i<apiInfo->mixerFWCtrls.nIds; i++) {
      if(apiInfo->mixerFWCtrls.byId[i]) {
	addrLimit=apiInfo->mixerFWCtrls.byId[i]->addrLimit;
	for(addr=0; addr<=addrLimit; addr++) {
	  ctrlP->id=i;
	  ctrlP->addr=addr;
	  ctrlP++;
	}
      }
    }
    ctrlP->id=SAM_MIXER_ID_SENTINEL;

    if(ioctl(context->fd, SAM_IOC_MIXER_GET, backup)<0) {
      Tcl_AppendResult(interp, "can't query sam9407 mixer settings: ", strerror(errno), NULL);
      return TCL_ERROR;
    }

    /* send reset controls */
    if(ioctl(context->fd, SAM_IOC_MIXER_SET, resetControls)<0) {
      if(nonResetIdx)
	ioctl(context->fd, SAM_IOC_MIXER_SET, backup);
      Tcl_AppendResult(interp, "can't change sam9407 mixer settings: ", strerror(errno), NULL);
      return TCL_ERROR;
    }

    /* restore backup values */
    if(ioctl(context->fd, SAM_IOC_MIXER_SET, backup)<0) {
      Tcl_AppendResult(interp, "can't change sam9407 mixer settings: ", strerror(errno), NULL);
      return TCL_ERROR;
    }
  }

  /* send non-reset controls */
  if(nonResetIdx && ioctl(context->fd, SAM_IOC_MIXER_SET, controls)<0) {
    Tcl_AppendResult(interp, "can't change sam9407 mixer settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  return TCL_OK;
}

static int mixerInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  Tcl_DString dstr;
  SamControl *controls;
  int i;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no mixer controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  if(!controls) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "mixer",
				&apiInfo->mixerFWCtrls, &driverInfo.mixerHWCtrls,
				0, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_MIXER_INFO, controls)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 mixer settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; controls[i].id!=SAM_MIXER_ID_SENTINEL; i++) {
    Tcl_DStringStartSublist(&dstr);
    if(controls[i].id>=SAM_MIXER_HW_ID_FIRST)
      Tcl_DStringAppendElement(&dstr, driverInfo.mixerHWCtrls.byId[controls[i].id-SAM_MIXER_HW_ID_FIRST]->name);
    else
      Tcl_DStringAppendElement(&dstr, apiInfo->mixerFWCtrls.byId[controls[i].id]->name);
    sprintf(buf, "%d", !!controls[i].value);
    Tcl_DStringAppendElement(&dstr, buf);
    Tcl_DStringEndSublist(&dstr);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int mixerAudioKnownCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  ApiInfo *apiInfo;
  int i;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  Tcl_DStringInit(&dstr);
  apiInfo=apiInfoById[context->apiClass];
  if(apiInfo)
    for(i=0; i<apiInfo->audioCtrls.nIds; i++)
      if(apiInfo->audioCtrls.byId[i])
	Tcl_DStringAppendElement(&dstr, apiInfo->audioCtrls.byId[i]->name);

  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int mixerAudioGetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel, *optionAudioChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  Tcl_DString dstr;
  SamRedirectedAudioControl redirectedControls;
  SamControl *controls;
  int i;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			":audio_channel", &optionAudioChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(!optionAudioChannel) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " mixer_audio_get ?-channel channel? -audio_channel audio_channel ?--? ?audio_controls?\"", NULL);
    return TCL_ERROR;
  }

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no audio controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  if(!controls) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "audio",
				&apiInfo->audioCtrls, NULL,
				0, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  redirectedControls.channel=strtol(optionAudioChannel, NULL, 0);
  redirectedControls.controls=controls;

  if(ioctl(context->fd, SAM_IOC_MIXER_AUDIO_GET, &redirectedControls)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 audio settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; controls[i].id!=SAM_AUDIO_ID_SENTINEL; i++) {
    Tcl_DStringStartSublist(&dstr);
    Tcl_DStringAppendElement(&dstr, apiInfo->audioCtrls.byId[controls[i].id]->name);
    sprintf(buf, "%d", controls[i].addr);
    Tcl_DStringAppendElement(&dstr, buf);
    sprintf(buf, "%d", controls[i].isConfigured);
    Tcl_DStringAppendElement(&dstr, buf);
    sprintf(buf, "%d", controls[i].value);
    Tcl_DStringAppendElement(&dstr, buf);
    Tcl_DStringEndSublist(&dstr);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int mixerAudioSetCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel, *optionAudioChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  SamRedirectedAudioControl redirectedControls;
  SamControl *controls;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			":audio_channel", &optionAudioChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(!optionAudioChannel) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " mixer_audio_set ?-channel channel? -audio_channel audio_channel ?--? ?audio_controls?\"", NULL);
    return TCL_ERROR;
  }

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no audio controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  if(!controls) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "audio",
				&apiInfo->audioCtrls, NULL,
				1, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  redirectedControls.channel=strtol(optionAudioChannel, NULL, 0);
  redirectedControls.controls=controls;

  if(ioctl(context->fd, SAM_IOC_MIXER_AUDIO_SET, &redirectedControls)<0) {
    Tcl_AppendResult(interp, "can't change sam9407 audio settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  return TCL_OK;
}

static int mixerAudioInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel, *optionAudioChannel;
  ApiInfo *apiInfo;
  MixerContext *context;
  Tcl_DString dstr;
  SamRedirectedAudioControl redirectedControls;
  SamControl *controls;
  int i;
  char buf[32];

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			":audio_channel", &optionAudioChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(!optionAudioChannel) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " mixer_audio_info ?-channel channel? -audio_channel audio_channel ?--? ?audio_controls?\"", NULL);
    return TCL_ERROR;
  }

  apiInfo=apiInfoById[context->apiClass];
  if(!apiInfo) {
    Tcl_AppendResult(interp, "no audio controls supported for this API", NULL);
    return TCL_ERROR;
  }

  controls=alloca((localArgc+1)*sizeof(SamControl));
  if(!controls) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  if((code=parseMixerAudioCtrls(interp, context, "audio",
				&apiInfo->audioCtrls, NULL,
				0, localArgc, localArgv, controls))!=TCL_OK)
    return code;

  redirectedControls.channel=strtol(optionAudioChannel, NULL, 0);
  redirectedControls.controls=controls;

  if(ioctl(context->fd, SAM_IOC_MIXER_AUDIO_INFO, &redirectedControls)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 audio settings: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; controls[i].id!=SAM_AUDIO_ID_SENTINEL; i++) {
    Tcl_DStringStartSublist(&dstr);
    Tcl_DStringAppendElement(&dstr, apiInfo->audioCtrls.byId[controls[i].id]->name);
    sprintf(buf, "%d", !!controls[i].value);
    Tcl_DStringAppendElement(&dstr, buf);
    Tcl_DStringEndSublist(&dstr);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int channelOwnerInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  int pids[256];
  SamChannelOwnerInfo ownerInfo;
  char buf[256];
  int i;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  ownerInfo.pids=pids;
  ownerInfo.size=NumberOf(pids);
  if(ioctl(context->fd, SAM_IOC_CHANNEL_OWNER_INFO, &ownerInfo)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 channel owner information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; i<ownerInfo.size; i++) {
    sprintf(buf, "%d", pids[i]);
    Tcl_DStringAppendElement(&dstr, buf);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int bankLoadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  SamSoundBank soundBank;
  int fd;
  struct stat st;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(localArgc<2) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " bank_load ?-channel channel? ?--? id file_name\"", NULL);
    return TCL_ERROR;
  }

  memset(&soundBank, 0, sizeof(SamSoundBank));
  soundBank.id=strtol(localArgv[0], NULL, 0);
  if((fd=open(localArgv[1], O_RDONLY))<0) {
    Tcl_AppendResult(interp, "can't open soundbank file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if(fstat(fd, &st)<0) {
    close(fd);
    Tcl_AppendResult(interp, "can't stat soundbank file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  if((soundBank.data=(char *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    close(fd);
    Tcl_AppendResult(interp, "can't map soundbank file \"", localArgv[0], "\" to memory: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  soundBank.size=st.st_size;
  if(ioctl(context->fd, SAM_IOC_BANK_LOAD, &soundBank)<0) {
    munmap((void *)soundBank.data, st.st_size);
    close(fd);
    Tcl_AppendResult(interp, "can't upload soundbank file \"", localArgv[0], "\": ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  munmap((void *)soundBank.data, st.st_size);
  close(fd);

  return TCL_OK;
}

static int bankUnloadCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  unsigned char id;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(localArgc<1) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " bank_unload ?-channel channel? ?--? id\"", NULL);
    return TCL_ERROR;
  }

  id=strtol(localArgv[0], NULL, 0);
  if(ioctl(context->fd, SAM_IOC_BANK_UNLOAD, &id)<0) {
    Tcl_AppendResult(interp, "can't unload soundbank: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  return TCL_OK;
}

static int bankPrioChgCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  SamSoundBankPrio prio;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(localArgc<2) {
    Tcl_AppendResult(interp, "wrong # args: should be \"", argv[0], " bank_prio_chg ?-channel channel? ?--? id priority\"", NULL);
    return TCL_ERROR;
  }

  prio.id=strtol(localArgv[0], NULL, 0);
  prio.priority=strtol(localArgv[1], NULL, 0);
  if(ioctl(context->fd, SAM_IOC_BANK_PRIO_CHG, &prio)<0) {
    Tcl_AppendResult(interp, "can't change soundbank priority: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  return TCL_OK;
}

static int bankInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  SamSoundBankInfo bankInfo[SAM_NROF_SBANKS];
  int i;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  if(ioctl(context->fd, SAM_IOC_BANK_INFO, &bankInfo)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 soundbank information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; i<SAM_NROF_SBANKS; i++) {
    Tcl_DStringStartSublist(&dstr);
    appendAttr(&dstr, "name", bankInfo[i].name);
    appendAttrInt(&dstr, "priority", bankInfo[i].priority);
    Tcl_DStringEndSublist(&dstr);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int peakMeterInfoCmd(SubCommand *subCommand, Tcl_Interp *interp, int argc, char **argv)
{
  int code, localArgc;
  char **localArgv;
  char *optionChannel;
  MixerContext *context;
  Tcl_DString dstr;
  unsigned short peakMeter[256];
  SamPeakMeterInfo peakMeterInfo;
  char buf[256];
  int i;

  localArgc=argc-2;
  localArgv=argv+2;
  if((code=parseOptions(interp, argv[0], argv[1], &localArgc, &localArgv,
			":channel", &optionChannel,
			NULL))!=TCL_OK)
    return code;

  if((code=getChannelId(interp, optionChannel, &context))!=TCL_OK)
    return code;

  peakMeterInfo.data=peakMeter;
  peakMeterInfo.size=NumberOf(peakMeter);
  if(ioctl(context->fd, SAM_IOC_PEAK_METER_INFO, &peakMeterInfo)<0) {
    Tcl_AppendResult(interp, "can't query sam9407 peak meter information: ", strerror(errno), NULL);
    return TCL_ERROR;
  }

  Tcl_DStringInit(&dstr);
  for(i=0; i<peakMeterInfo.size; i++) {
    sprintf(buf, "%d", peakMeter[i]);
    Tcl_DStringAppendElement(&dstr, buf);
  }
  Tcl_DStringResult(interp, &dstr);
  Tcl_DStringFree(&dstr);

  return TCL_OK;
}

static int buildCtrls(SamCtrlNameAssoc *assocs, int offset, Controls *ctrls)
{
  int newEntry;
  SamCtrlNameAssoc *assoc;
  Tcl_HashEntry *entry;

  Tcl_InitHashTable(&ctrls->byName, TCL_STRING_KEYS);

  /* search for the maximum mixer control value */
  ctrls->nIds=ctrls->nAddrs=0;
  for(assoc=assocs; assoc->name; assoc++) {
    if(assoc->id-offset>=ctrls->nIds)
      ctrls->nIds=assoc->id-offset+1;
    ctrls->nAddrs+=assoc->addrLimit+1;
  }
  ctrls->byId=(SamCtrlNameAssoc **)Tcl_Alloc(ctrls->nIds*sizeof(SamCtrlNameAssoc *));
  if(!ctrls->byId)
    return TCL_ERROR;
  memset(ctrls->byId, 0, ctrls->nIds*sizeof(SamCtrlNameAssoc *));

  for(assoc=assocs; assoc->name; assoc++) {
    entry=Tcl_CreateHashEntry(&ctrls->byName, assoc->name, &newEntry);
    if(!entry)
      return TCL_ERROR;
    Tcl_SetHashValue(entry, assoc);
    ctrls->byId[assoc->id-offset]=assoc;
  }

  return TCL_OK;
}

int buildApiInfo(void)
{
  int newEntry, i;
  ApiInfo *apiInfo;
  Tcl_HashEntry *entry;
  
  if(buildCtrls(samMixerAssocHW, SAM_MIXER_HW_ID_FIRST, &driverInfo.mixerHWCtrls)!=TCL_OK)
    return TCL_ERROR;

  Tcl_InitHashTable(&apiInfoByName, TCL_STRING_KEYS);
  
  /* count the maximum API value */
  for(i=0; samApiAssocs[i].name; i++)
    if(samApiAssocs[i].apiClass>=nApiInfo)
      nApiInfo=samApiAssocs[i].apiClass+1;
  
  apiInfoById=(ApiInfo **)Tcl_Alloc(nApiInfo*sizeof(ApiInfo *));
  if(!apiInfoById)
    return TCL_ERROR;
  memset(apiInfoById, 0, nApiInfo*sizeof(ApiInfo *));

  for(i=0; samApiAssocs[i].name; i++) {
    apiInfo=(ApiInfo *)Tcl_Alloc(sizeof(ApiInfo));
    if(!apiInfo)
      return TCL_ERROR;
    memset(apiInfo, 0, sizeof(ApiInfo));

    /* create id -> name and name -> id mappings */
    entry=Tcl_CreateHashEntry(&apiInfoByName, samApiAssocs[i].name, &newEntry);
    if(!entry)
      return TCL_ERROR;
    Tcl_SetHashValue(entry, apiInfo);
    apiInfoById[samApiAssocs[i].apiClass]=apiInfo;

    apiInfo->name=samApiAssocs[i].name;

    if(buildCtrls(samApiAssocs[i].mixer, 0, &apiInfo->mixerFWCtrls)!=TCL_OK)
      return TCL_ERROR;

    if(buildCtrls(samApiAssocs[i].audio, 0, &apiInfo->audioCtrls)!=TCL_OK)
      return TCL_ERROR;
  }

  return TCL_OK;
}

int Sam_Init(Tcl_Interp *interp)
{
  if(buildApiInfo()!=TCL_OK) {
    Tcl_AppendResult(interp, "virtual memory exhausted", NULL);
    return TCL_ERROR;
  }

  Tcl_CreateCommand(interp, "sam", (Tcl_CmdProc *)commonCmd, x9407SubCommands, NULL);

  return TCL_OK;
}
