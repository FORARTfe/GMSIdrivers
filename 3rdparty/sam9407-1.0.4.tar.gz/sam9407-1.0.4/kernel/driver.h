#ifndef _DRIVER_H
#define _DRIVER_H

#include <linux/version.h>
#include <linux/sched.h>
#include <linux/time.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/poll.h>
#endif
#include <asm/byteorder.h>
#include <asm/atomic.h>
#include <asm/segment.h>

#include "kconfig.h"
#include "firmware.h"
#include "vendor.h"

#define SAM_MODE_READ_MASK		0x01
#define SAM_MODE_WRITE_MASK		0x02

#define SAM_RT_PRIORITY			20
#define SAM_IO_TIMEOUT			(2*HZ)

#define SAM_MAX_CARDS_COUNT		4

#define SAM_NUMBER_OF(vec)		(sizeof(vec)/sizeof(*(vec)))
#define SAM_OFFSET_OF(type,attr)	((char *)(&((type *)0)->attr)-(char *)0)
#define SAM_MIN(a,b)			((a)<(b) ? (a) : (b))
#define SAM_MAX(a,b)			((a)>(b) ? (a) : (b))

#define SAM_CARD_IDX(inode)		(MINOR((inode)->i_rdev)>>6)
#define SAM_CARD(inode)			(samCards[SAM_CARD_IDX(inode)])
#define SAM_MINOR_DEVICE(inode)		((SoundMinorDevice)(MINOR((inode)->i_rdev)&0xF))
#define SAM_PORT_IDX(inode)		((MINOR((inode)->i_rdev)>>4)&3)

#if LINUX_VERSION_CODE>=0x20200
#if LINUX_VERSION_CODE>=0x20400
typedef wait_queue_head_t		SamWaitQueueHead;
typedef wait_queue_t			SamWaitQueue;
#define SAM_DECLARE_MUTEX(name)		DECLARE_MUTEX(name)
#define SAM_INIT_MUTEX(sem)		init_MUTEX(sem)
#define SAM_INIT_WAITQUEUE_HEAD(p)	init_waitqueue_head(p)
#define SAM_TIMER_INIT(func)		{ { NULL, NULL }, 0, 0, func }
#else /* Linux 2.2 */
typedef struct wait_queue		*SamWaitQueueHead;
typedef struct wait_queue		SamWaitQueue;
#define SAM_DECLARE_MUTEX(name)		struct semaphore name=MUTEX
#define SAM_INIT_MUTEX(sem)		(*sem=MUTEX)
#define SAM_INIT_WAITQUEUE_HEAD(p)	(*p=NULL)
#define SAM_TIMER_INIT(func)		{ NULL, NULL, 0, 0, func }
#endif
#define SAM_BEGIN_CRITICAL(lock,flags)	spin_lock_irqsave(lock, flags)
#define SAM_END_CRITICAL(lock,flags)	spin_unlock_irqrestore(lock, flags)
#define SAM_GET_USER(v, ptr)		get_user(v, ptr)
#define SAM_PUT_USER(v, ptr)		put_user(v, ptr)
#define SAM_MEMCPY_FROMFS(d, s, n)	copy_from_user(d, s, n)
#define SAM_MEMCPY_TOFS(d, s, n)	copy_to_user(d, s, n)
#define SAM_ATOMIC_READ(v)		atomic_read(v)
#define SAM_ATOMIC_SET(v,i)		atomic_set(v,i)
#define SAM_CAP_SYS_ADMIN()		capable(CAP_SYS_ADMIN)
#define SAM_CPU_TO_LE16(v)		cpu_to_le16(v)
#define SAM_LE16_TO_CPU(v)		le16_to_cpu(v)
#define SAM_CPU_TO_LE32(v)		cpu_to_le32(v)
#define SAM_LE32_TO_CPU(v)		le32_to_cpu(v)
#define SAM_CPU_TO_BE16(v)		cpu_to_be16(v)
#define SAM_BE16_TO_CPU(v)		be16_to_cpu(v)
#else /* Linux 2.0 */
typedef struct wait_queue		*SamWaitQueueHead;
typedef struct wait_queue		SamWaitQueue;
#define SAM_DECLARE_MUTEX(name)		struct semaphore name=MUTEX
#define SAM_INIT_MUTEX(sem)		(*sem=MUTEX)
#define SAM_INIT_WAITQUEUE_HEAD(p)	(*p=NULL)
#define SAM_TIMER_INIT(func)		{ NULL, NULL, 0, 0, func }
#define SAM_BEGIN_CRITICAL(lock,flags)	{save_flags(flags); cli();}
#define SAM_END_CRITICAL(lock,flags)	restore_flags(flags)
#define SAM_GET_USER(v, ptr)		(v=get_user(ptr), 0)
#define SAM_PUT_USER(v, ptr)		(put_user(v, ptr), 0)
#define SAM_MEMCPY_FROMFS(d, s, n)	(memcpy_fromfs(d, s, n), 0)
#define SAM_MEMCPY_TOFS(d, s, n)	(memcpy_tofs(d, s, n), 0)
#define SAM_ATOMIC_READ(v)		(*(v))
#define SAM_ATOMIC_SET(v,i)		(*(v)=i)
#define SAM_CAP_SYS_ADMIN()		suser()
#if defined(__LITTLE_ENDIAN)
#define SAM_CPU_TO_LE16(v)		(v)
#define SAM_LE16_TO_CPU(v)		(v)
#define SAM_CPU_TO_LE32(v)		(v)
#define SAM_LE32_TO_CPU(v)		(v)
#define SAM_CPU_TO_BE16(v)		(((unsigned short)(v)&0xFF00)>>8 |\
					 ((unsigned short)(v)&0x00FF)<<8)
#define SAM_BE16_TO_CPU(v)		SAM_CPU_TO_BE16(v)
#elif defined(__BIG_ENDIAN)
#define SAM_CPU_TO_LE16(v)		(((unsigned short)(v)&0xFF00)>>8 |\
					 ((unsigned short)(v)&0x00FF)<<8)
#define SAM_LE16_TO_CPU(v)		SAM_CPU_TO_LE16(v)
#define SAM_CPU_TO_LE32(v)		(((unsigned)(v)&0xFF000000)>>24 |\
					 ((unsigned)(v)&0x00FF0000)>>8 |\
					 ((unsigned)(v)&0x0000FF00)<<8 |\
					 ((unsigned)(v)&0x000000FF)<<24)
#define SAM_LE32_TO_CPU(v)		SAM_CPU_TO_LE32(v)
#define SAM_CPU_TO_BE16(v)		(v)
#define SAM_BE16_TO_CPU(v)		(v)
#else
#error "Unsupported host byte order"
#endif
#endif /* Linux 2.0 */

/* as the sleep_on function doesn't provide a hook
 * between adding our process to the wait queue
 * and scheduling, we have to write our own
 * in order to have fully race condition free
 * scheduling.
 * samPrepareSleepOn must be called first, to ensure
 * the process ends up on the wait_queue before checking
 * the wait-condition or releasing a semaphore,
 * so we won't miss any wake_up's.
 * Depending on the wait-condition's result either
 * samCancelSleepOn or samSleepOn should be called afterwards.
 */
static __inline__ void samPrepareSleepOn(long state, SamWaitQueueHead *p, SamWaitQueue *wait)
{
  current->state=state;
#if LINUX_VERSION_CODE>=0x20400
  init_waitqueue_entry(wait, current);
#else
  wait->task=current;
#endif
  add_wait_queue(p, wait);
}

static __inline__ void samCancelSleepOn(SamWaitQueueHead *p, SamWaitQueue *wait)
{
  remove_wait_queue(p, wait);
  current->state=TASK_RUNNING;
}

static __inline__ void samSleepOn(SamWaitQueueHead *p, SamWaitQueue *wait)
{
  schedule();
  remove_wait_queue(p, wait);
}

typedef unsigned long SamDirtyFlag;
typedef unsigned SamRingBufferWord;

typedef enum {
  SoundMinorCtl,
  SoundMinorSeq,
  SoundMinorMidi,
  SoundMinorDsp,
  SoundMinorAudio,
  SoundMinorDsp16,
  SoundMinorStatus,
  SoundMinorAwfm,
  SoundMinorSeq2,
  SoundMinorSndproc,
  SoundMinorPss=SoundMinorSndproc,
  SoundMinorMod,
} SoundMinorDevice;

extern int samMajor;
extern int samCardsMap[];

/* audio feed thread (aka sam9407d) */

typedef struct {
  int haveJobs;
  SamWaitQueueHead feedSam;
  int shutdown;
} SamAudioFeedThreadInfo;

extern SamAudioFeedThreadInfo samFeedThreadInfo;

/* I/O */

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t statusRegSpinLock;
#endif
  struct semaphore ioLock, stillTryingLock;
  SamWaitQueueHead somethingHappened;
  SamWaitQueueHead pickLockScreaming;
  SamWaitQueueHead pickLockHappy;
  int ioTimeout;		/* timeout for I/O operations */
  int ioExpired;		/* ioTimeout exceeded */
  int pickLock;			/* audioFeedThread wants to talk */
  int waitForUARTAck;
} SamIOInfo;

/* MMT */

typedef struct {
  struct semaphore accessLock;
  unsigned mmtSize;
  SamMMTEntry *mmt, *tmpMMT;
  SamMMTSBank *sbank, *tmpSBank;
} SamMemInfo;

/* /dev/mixer */

typedef struct {
  struct semaphore accessLock;
  SamWaitQueueHead waitDirty;

  int syncGroup, syncStarted;

  /* each process that opens /dev/mixer
   * gets an index into usedMask
   * which is used to mark controls that
   * have been modified in hwDirtyFlags and fwDirtyFlags
   *
   * firmwareDirty, sbankDirty will be triggered, whenever
   * changes have been made to the firmware or soundbank.
   */
  SamDirtyFlag usedMask;
  SamDirtyFlag *hwDirtyFlags, *fwDirtyFlags;
  SamDirtyFlag firmwareDirty, sbankDirty, channelOwnerDirty;
} SamMixerInfo;

/* /dev/dsp & /dev/audio */

/* As all channel operations are handled
 * asynchronously, we keep some states here
 */
typedef enum {
  SamChannelStateClosed,
  SamChannelStateNotStarted,
  SamChannelStateSendStart,
  SamChannelStateOpen,
  SamChannelStateUnderflow,
  SamChannelStateOverflow,
  SamChannelStateClosing,
} SamChannelState;

typedef struct {
  char used, first;
  unsigned long startJiffies;
  unsigned bytes;
} SamAudioFrameCounter;

typedef struct {
  int frameIdx, transitions; /* points to the frame, we filled last */
  SamAudioFrameCounter frames[2];
  unsigned finishedBytes;
} SamAudioCounter;

typedef struct SamChannelInfo {
  struct semaphore accessLock;
  atomic_t keepBuffersUsageCount;
  char inUse, justOpened, closing;
#ifndef SAM_IGNORE_REC_OVERFLOW
  char recOverflow;
#endif
  SamChannelState state;
  int owner;
  int waitForTrigger;
  int syncGroup, syncStarted;
  unsigned syncSkipCount;
  unsigned format;
  unsigned short rate;
  char stereo;
  unsigned frameSizeWantedBytes;
  unsigned frameSize, frameCount;
  unsigned head, count, size;
  short *data;
  union {
    SamGenuineAudioCtrlValues genuine;
#ifdef SAM_ENABLE_FW_EWS64
    SamEWS64AudioCtrlValues ews64;
#endif
#ifdef SAM_ENABLE_FW_HOMSTDR
    SamHomstdrAudioCtrlValues homstdr;
#endif
  } ctrlValues;
  SamAudioCounter counter;
  SamWaitQueueHead feedMe, waitClosed;
  SamDirtyFlag *dirtyFlags;
} SamChannelInfo;

/* /dev/midi  */
typedef enum {
  SamMidiPortInternal,
  SamMidiPortExternal,
  SamMidiPortSentinel /* == last_port + 1 */
} SamMidiPortType;

typedef enum {
  SamMidiPortOwnerNone,
  SamMidiPortOwnerMidi,
  SamMidiPortOwnerSeq
} SamMidiPortOwner;

typedef struct {
  unsigned char *ringBuffer;
  int usedIdx, usedCount;
} SamMidiBuffer;

typedef struct {
  SamMidiPortOwner ownerRead, ownerWrite;
} SamMidiPort;

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t recSpinLock;
#endif
  struct semaphore accessLock;
  SamMidiPort ports[SamMidiPortSentinel]; /* indexed by SamMidiPortType */
  SamWaitQueueHead dataAvail;
#ifndef SAM_IGNORE_REC_OVERFLOW
  int recOverflow;
#endif
  int timerRunning;
  atomic_t recSuspendTicks;
  SamMidiBuffer rec;
} SamMidiInfo;

/* /dev/sequencer */

typedef struct {
  unsigned char *ringBuffer;
  int usedIdx, usedCount;
  int timerRunning, timerOverflow;
  atomic_t timerTicks;
} SamSeqBuffer;

typedef struct {
  int syncGroup, syncStarted, syncStartTimer;
  int checkPlayback;
  SamSeqBuffer play, rec;
  unsigned timeBase, tempo;
  SamWaitQueueHead moreSpace, dataAvail;
#ifndef SAM_IGNORE_REC_OVERFLOW
  int recOverflow;
#endif
  atomic_t recSuspendTicks;
  int followupRecEvent;
  unsigned lastRecTimer;
  int playing, sleeping;
  unsigned wakeupTicks;
  unsigned lastWaitTimerTicks, lastWaitTimerDrift;
  unsigned char pendingWriteBuf[4];
  int pendingWriteBufFilled;
} SamSeqInfo;

/* /dev/mod */

typedef struct {
  SamRingBufferWord *ringBuffer;
  int idx, count;
} SamModBuffer;

typedef struct {
  int syncGroup, syncStarted, syncStartTimer;
  int checkPlayback;
  struct semaphore accessLock;
  /* as most of the firmwares can't use the static
   * and recording from streaming device simultaneously
   * we count the number of open recording channels here
   */
  atomic_t recChannelsUsageCount;
  int inUse;
  unsigned voicesInUse;
  SamModBuffer play, rec;
  SamWaitQueueHead moreSpace, dataAvail;
#ifndef SAM_IGNORE_REC_OVERFLOW
  int recOverflow;
#endif
  int timerRunning, timerOverflow;
  int playing, sleeping;
  atomic_t timerTicks;
  unsigned wakeupTicks;
  struct timeval lastWaitTime;
} SamModInfo;

/* /dev/sndstat */

typedef struct {
  int n, i;
  char s[0];
} SamSndStatMsg;

typedef struct {
  struct semaphore accessLock;
} SamSndStatInfo;

/* Soundcard */
typedef struct SamCard {
  int cardIdx;
  struct SamCard *master, *slave;

  int port, auxPort0, auxPort1;
  int auxPort0Extent, auxPort1Extent;
#ifdef SAM_ENABLE_IRQ
  int irq;
#endif

  SamHardwareHints hints;

  SamHardwareInfo *hardwareInfo;
  SamFirmwareInfo *firmwareInfo;

  /* keep usageCountLock down while
   * checking for usageCount==0
   * in vsamTalkScheduled, when uploading
   * new firmware, or whenever
   * incrementing usageCount
   */
  struct semaphore usageCountLock;
  atomic_t usageCount;
  int firmwareLoaded;
  /* we keep an extra spinlock for SMP systems,
   * which will be held down in IRQ's accessing the loaded firmware
   * and whenever the firmware get's unloaded
   */
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t firmwareAccessSpinLock;
#endif

  atomic_t fastPollRequests;

  int checkChannelStates;

  SamIOInfo io;
  SamMemInfo mem;
  SamMixerInfo mixer;
  SamChannelInfo *channels;
  SamMidiInfo midi;
  SamSeqInfo seq;
  SamModInfo mod;
  SamSndStatInfo sndStat;

  union {
#ifdef SAM_ENABLE_FW_EWS64
    SamEWS64CtrlValues ews64;
#endif
  } ctrlValues;

  union {
#ifdef SAM_ENABLE_HW_EWS64S
    SamEWS64SHardwareCache ews64s;
#endif
#ifdef SAM_ENABLE_HW_EWS64XL
    SamEWS64XLHardwareCache ews64xl;
#endif
#if defined(SAM_ENABLE_HW_ST128RUBY) || defined(SAM_ENABLE_HW_ST128PCI)
    SamST128HardwareCache st128;
#endif
#ifdef SAM_ENABLE_HW_STDA
    SamSTDAHardwareCache stda;
#endif
#ifdef SAM_ENABLE_HW_MAXI64
    SamMaxi64HardwareCache maxi64;
#endif
  } hardwareCache;
} SamCard;

extern int samCardsCount;
extern SamCard *samCards[SAM_MAX_CARDS_COUNT];

SamCard *samRegisterCard(SamHardwareInfo *hardwareInfo, SamHardwareResource *res, SamCard *master);

#endif /* _DRIVER_H */
