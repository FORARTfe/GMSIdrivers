/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif

#include "driver.h"
#include "longlong.h"
#include "io.h"
#include "alloc.h"
#include "mixer.h"
#include "sync.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif
#include "mod.h"

#define SAM_MOD_RINGBUFFER_SIZE		256
#define SAM_MAX_VOICES			32
#define SAM_MAX_SAMPLE_BITS		18
#define SAM_MAX_SAMPLE_SIZE		(1<<SAM_MAX_SAMPLE_BITS)
#define SAM_MAX_SAMPLE_MASK		(SAM_MAX_SAMPLE_SIZE-1)

#define SAM_MOD_SYSTEM_POLL_INTERVAL	1
#ifdef SAM_ENABLE_RTC
#define SAM_MOD_TICKER_FREQ		(samUsingRTC ? SAM_RTC_FREQ : HZ)
#else
#define SAM_MOD_TICKER_FREQ		HZ
#endif

#define SAM_MOD_PITCH_VALUE(freq)	((freq)*0x400/44100)

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t accessSpinLock;
#endif
  struct timer_list timer;
  unsigned references;
  unsigned long lastTickerJiffies;
} ModTimerInfo;

#ifdef SAM_ENABLE_RTC
static void modRTCTicker(void);
#endif
static void modTicker(unsigned long data);

static int eventSizes[]={
  sizeof(SamModEchoEvent),		/* SAM_MOD_EVENT_ECHO */
  sizeof(SamModTimerEvent),		/* SAM_MOD_EVENT_WAIT_ABS */
  sizeof(SamModTimerEvent),		/* SAM_MOD_EVENT_WAIT_REL */
  sizeof(SamModMemEvent),		/* SAM_MOD_EVENT_MEM */
  sizeof(SamModTriggerEvent),		/* SAM_MOD_EVENT_OPEN */
  sizeof(SamModTriggerEvent),		/* SAM_MOD_EVENT_CLOSE */
  sizeof(SamModTriggerEvent),		/* SAM_MOD_EVENT_START */
  sizeof(SamModTriggerEvent),		/* SAM_MOD_EVENT_STOP */
  sizeof(SamModVolOutEvent),		/* SAM_MOD_EVENT_VOL */
  sizeof(SamModVolSendEvent),		/* SAM_MOD_EVENT_MAIN */
  sizeof(SamModVolSendEvent),		/* SAM_MOD_EVENT_AUX */
  sizeof(SamModPitchEvent),		/* SAM_MOD_EVENT_PITCH */
  sizeof(SamModFilterEvent),		/* SAM_MOD_EVENT_FILT */
};

#ifdef SAM_ENABLE_RTC
static SamRTCCallbackNode rtcCallbackInfo={
  modRTCTicker
};
#endif
static ModTimerInfo timerInfo={
#if LINUX_VERSION_CODE>=0x20200
  SPIN_LOCK_UNLOCKED,
#endif
  SAM_TIMER_INIT(modTicker)
};

static void checkWakeup(int deltaTicks)
{
  int i;
  SamCard *card;

  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    if(card->mod.timerRunning) {
      atomic_add(deltaTicks, &card->mod.timerTicks);
      if((unsigned)SAM_ATOMIC_READ(&card->mod.timerTicks)<deltaTicks &&
	 !card->mod.timerOverflow) {
	card->mod.timerOverflow=1;
	printk(KERN_WARNING "sam9407[#%d:%s]: mod timer overflow\n",
	       card->cardIdx, card->hardwareInfo->name);
      }
      if(card->mod.sleeping &&
	 (unsigned)SAM_ATOMIC_READ(&card->mod.timerTicks)>=card->mod.wakeupTicks) {
	card->mod.checkPlayback=1;
	samFeedThreadInfo.haveJobs=1;
	wake_up(&samFeedThreadInfo.feedSam);
      }
    }
  }
}

#ifdef SAM_ENABLE_RTC
static void modRTCTicker(void)
{
  checkWakeup(1);
}
#endif

static void modTicker(unsigned long data)
{
  unsigned flags;
  int deltaTicks;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  deltaTicks=jiffies-timerInfo.lastTickerJiffies;
  timerInfo.lastTickerJiffies=jiffies;
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);

  checkWakeup(deltaTicks);

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references) {
    timerInfo.timer.expires=jiffies+SAM_MOD_SYSTEM_POLL_INTERVAL;
    add_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStop(SamCard *card)
{
  unsigned flags;

  if(!card->mod.timerRunning)
    return;

  card->mod.timerRunning=0;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(--timerInfo.references==0) {
#ifdef SAM_ENABLE_RTC
    samRTCDisableCallback(&rtcCallbackInfo);
#endif
    del_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStart(SamCard *card)
{
  unsigned flags;

  if(card->mod.timerRunning)
    return;

  timerStop(card);

  card->mod.timerRunning=1;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references++==0) {
#ifdef SAM_ENABLE_RTC
    if(samUsingRTC) {
      samRTCEnableCallback(&rtcCallbackInfo);
    } else {
#endif
      timerInfo.lastTickerJiffies=jiffies;
      timerInfo.timer.expires=timerInfo.lastTickerJiffies+SAM_MOD_SYSTEM_POLL_INTERVAL;
      add_timer(&timerInfo.timer);
#ifdef SAM_ENABLE_RTC
    }
#endif
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void playTimerStop(SamCard *card)
{
  if(card->mod.syncGroup<0 || card->mod.playing) {
    timerStop(card);
  } else
    card->mod.syncStartTimer=0;
}

static void playTimerStart(SamCard *card)
{
  if(card->mod.syncGroup<0 || card->mod.playing) {
    timerStart(card);
  } else {
    card->mod.syncStartTimer=1;
    card->mod.checkPlayback=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  }
}

static __inline__ void syncLeave(SamCard *card)
{
  if(card->mod.syncGroup>=0) {
    samSyncLeave(card->mod.syncGroup, card->cardIdx, SamSyncDeviceMod, card->mod.syncStarted);
    card->mod.syncGroup=-1;
  }
}

static __inline__ int putInt(unsigned long arg, int value)
{
  int error;

  if((error=verify_area(VERIFY_WRITE, (void *)arg, sizeof(int)))<0)
    return error;
  if(SAM_PUT_USER(value, (int *)arg))
    return -EFAULT;

  return 0;
}

static int peekEventSize(SamModBuffer *modBuffer)
{
  if(modBuffer->count>0)
    return eventSizes[((SamModEvent *)(modBuffer->ringBuffer+modBuffer->idx))->type];

  return 0;
}

static int getEvent(SamModBuffer *modBuffer, SamModEvent *dest)
{
  unsigned idx, copied, bytes;
  union {
    SamRingBufferWord *u;
    char *b;
  } sp, dp;

  if(modBuffer->count>0) {
    idx=modBuffer->idx;
    copied=0;
    sp.u=modBuffer->ringBuffer+idx;
    dp.u=(SamRingBufferWord *)dest;
    bytes=eventSizes[((SamModEvent *)sp.u)->type];
    while(bytes>=sizeof(SamRingBufferWord)) {
      *dp.u++=*sp.u++;
      if(++idx>=SAM_MOD_RINGBUFFER_SIZE) {
	idx=0;
	sp.u=modBuffer->ringBuffer;
      }
      bytes-=sizeof(SamRingBufferWord);
      copied++;
    }
    if(bytes>0) {
      while(bytes>0) {
	*dp.b++=*sp.b++;
	bytes--;
      }
      if(++idx>=SAM_MOD_RINGBUFFER_SIZE)
	idx=0;
      copied++;
    }
    modBuffer->idx=idx;
    modBuffer->count-=copied;
    return 1;
  }

  return 0;
}

static int putEvent(SamModBuffer *modBuffer, SamModEvent *source)
{
  unsigned idx, copied, bytes;
  union {
    SamRingBufferWord *u;
    char *b;
  } sp, dp;

  bytes=eventSizes[source->type];
  if(bytes<=(SAM_MOD_RINGBUFFER_SIZE-modBuffer->count)*sizeof(SamRingBufferWord)) {
    idx=(modBuffer->idx+modBuffer->count)%SAM_MOD_RINGBUFFER_SIZE;
    copied=0;
    sp.u=(SamRingBufferWord *)source;
    dp.u=modBuffer->ringBuffer+idx;
    while(bytes>=sizeof(SamRingBufferWord)) {
      *dp.u++=*sp.u++;
      if(++idx>=SAM_MOD_RINGBUFFER_SIZE) {
	idx=0;
	dp.u=modBuffer->ringBuffer;
      }
      bytes-=sizeof(SamRingBufferWord);
      copied++;
    }
    if(bytes>0) {
      while(bytes>0) {
	*dp.b++=*sp.b++;
	bytes--;
      }
      copied++;
    }
    modBuffer->count+=copied;
    return 1;
  }

  return 0;
}

static int resetMod(SamCard *card)
{
  int error=0, tmpError, i;

  playTimerStop(card);

  SAM_ATOMIC_SET(&card->mod.timerTicks, 0);
  card->mod.timerOverflow=0;

  card->mod.playing=0;
  card->mod.sleeping=0;

  memset(&card->mod.lastWaitTime, 0, sizeof(card->mod.lastWaitTime));

#ifndef SAM_IGNORE_REC_OVERFLOW
  card->mod.recOverflow=0;
#endif
  card->mod.rec.idx=card->mod.rec.count=0;
  card->mod.play.idx=card->mod.play.count=0;

  for(i=0; i<SAM_MAX_VOICES; i++) {
    if((card->mod.voicesInUse>>i)&1) {
      if((tmpError=samTalk(card,
			   SamSendCtrl, 2, SAM_CMD_VOI_CLOSE, i,
			   SamEndOfScript))<0 && !error)
	error=tmpError;
    }
  }

  card->mod.voicesInUse=0;

  if((tmpError=samFree(card, SAM_MMT_ID_STAT_WAVE, SAM_MMT_ID_MASK))<0 && !error)
    error=tmpError;

  return error;
}

/* asynchronous playback of
 * events stored at card->mod.ringBuffer
 */
void samCheckPlaybackMod(SamCard *card)
{
  SamModEvent event;
  int error;
  unsigned vl, vh, q, r;

  down(&card->mod.accessLock);
  if(card->mod.syncGroup>=0 && !card->mod.playing) {
    if(card->mod.play.count<=0 && !card->mod.syncStartTimer) {
      up(&card->mod.accessLock);
      return;
    }
    if(!card->mod.syncStarted) {
      samSyncStart(card->mod.syncGroup);
      card->mod.syncStarted=1;
    }
    if(!samSyncReady(card->mod.syncGroup)) {
      up(&card->mod.accessLock);
      return;
    }
    if(card->mod.syncStartTimer)
      timerStart(card);
  }

  card->mod.playing=1;

  if(!card->mod.play.ringBuffer) {
    up(&card->mod.accessLock);
    return;
  }

  if(card->mod.sleeping) {
    if((unsigned)SAM_ATOMIC_READ(&card->mod.timerTicks)<card->mod.wakeupTicks) {
      up(&card->mod.accessLock);
      return;
    }
    card->mod.sleeping=0;
  }
  while(!card->mod.sleeping &&
	getEvent(&card->mod.play, &event)) {
    error=0;
    switch(event.type) {
    case SAM_MOD_EVENT_ECHO:
      if(card->mod.rec.ringBuffer) {
	if(!putEvent(&card->mod.rec, &event)) {
#ifndef SAM_IGNORE_REC_OVERFLOW
	  card->mod.recOverflow=1;
	  wake_up(&card->mod.dataAvail);
#endif
	} else
	  wake_up(&card->mod.dataAvail);
      }
      break;
    case SAM_MOD_EVENT_WAIT_ABS:
      memset(&card->mod.lastWaitTime, 0, sizeof(card->mod.lastWaitTime));
      /* flow into next case */
    case SAM_MOD_EVENT_WAIT_REL:
      card->mod.lastWaitTime.tv_sec+=event.timer.time.tv_sec;
      card->mod.lastWaitTime.tv_usec+=event.timer.time.tv_usec;
      if(card->mod.lastWaitTime.tv_usec>=1000000) {
	card->mod.lastWaitTime.tv_sec+=card->mod.lastWaitTime.tv_usec/1000000;
	card->mod.lastWaitTime.tv_usec%=1000000;
      }
      samLLMul32(&vl, &vh, card->mod.lastWaitTime.tv_usec, SAM_MOD_TICKER_FREQ);
      samLLDivMod24(vl, vh, 1000000, &q, &r);
      samLLMul32(&vl, &vh, card->mod.lastWaitTime.tv_sec, SAM_MOD_TICKER_FREQ);
      samLLAdd64(&vl, &vh, q, 0);
      if(!vh) {
	if(vl>(unsigned)SAM_ATOMIC_READ(&card->mod.timerTicks)) {
	  card->mod.wakeupTicks=vl;
	  card->mod.sleeping=1;
	}
      } else
	if(!card->mod.timerOverflow) {
	  card->mod.timerOverflow=1;
	  printk(KERN_WARNING "sam9407[#%d:%s]: mod timer overflow\n",
		 card->cardIdx, card->hardwareInfo->name);
	}
      break;
    case SAM_MOD_EVENT_MEM:
      {
	unsigned base, start, loop, end;
	unsigned char bank, format;

	if((error=samFindMMT(card, SAM_MMT_ID_STAT_WAVE|event.mem.handle<<8, ~SAM_MMT_ROM_MASK, &base, NULL))>0) {
	  bank=base>>SAM_MAX_SAMPLE_BITS;
	  base&=SAM_MAX_SAMPLE_MASK;
	  start=base+event.mem.start;
	  loop=base+event.mem.loop;
	  end=base+event.mem.end;

	  switch(event.mem.sampleType) {
	  case SamModSample8BitLow:
	    format=0x80;
	    break;
	  case SamModSample8BitHigh:
	    format=0xC0;
	    break;
	  default: /* SamModSample16Bit */
	    format=0x00;
	  }

	  switch(event.mem.loopType) {
	  case SamModLoopReverse:
	    format|=0x01;
	    break;
	  case SamModLoopReverseSignInvert:
	    format|=0x02;
	    break;
	  default: /* SamModLoopForward */
	  }

	  error=samTalk(card,
			SamSendCtrl, 15,
			SAM_CMD_VOI_MEM, event.mem.voice, format,
			bank, start, start>>8, start>>16,
			bank, loop, loop>>8, loop>>16,
			bank, end, end>>8, end>>16,
			SamEndOfScript);
	}
      }
      break;
    case SAM_MOD_EVENT_OPEN:
      card->mod.voicesInUse|=1<<event.trigger.voice;
      error=samTalk(card,
		    SamSendCtrl, 2, SAM_CMD_VOI_OPEN, event.trigger.voice,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_CLOSE:
      error=samTalk(card,
		    SamSendCtrl, 2, SAM_CMD_VOI_CLOSE, event.trigger.voice,
		    SamEndOfScript);
      card->mod.voicesInUse&=~(1<<event.trigger.voice);
      break;
    case SAM_MOD_EVENT_START:
      error=samTalk(card,
		    SamSendCtrl, 2, SAM_CMD_VOI_START, event.trigger.voice,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_STOP:
      error=samTalk(card,
		    SamSendCtrl, 2, SAM_CMD_VOI_STOP, event.trigger.voice,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_VOL:
      error=samTalk(card,
		    SamSendCtrl, 3, SAM_CMD_VOI_VOL, event.volOut.voice, event.volOut.volume,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_MAIN:
      error=samTalk(card,
		    SamSendCtrl, 4, SAM_CMD_VOI_MAIN, event.volSend.voice, event.volSend.right, event.volSend.left,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_AUX:
      error=samTalk(card,
		    SamSendCtrl, 4, SAM_CMD_VOI_AUX, event.volSend.voice, event.volSend.right, event.volSend.left,
		    SamEndOfScript);
      break;
    case SAM_MOD_EVENT_PITCH:
      {
	unsigned pitch;

	pitch=SAM_MOD_PITCH_VALUE(event.pitch.freq);

	error=samTalk(card,
		      SamSendCtrl, 4, SAM_CMD_VOI_PITCH, event.pitch.voice, pitch, pitch>>8,
		      SamEndOfScript);
      }
      break;
    case SAM_MOD_EVENT_FILT:
      error=samTalk(card,
		    SamSendCtrl, 4, SAM_CMD_VOI_FILT, event.filter.voice, event.filter.q, event.filter.fc,
		    SamEndOfScript);
      break;
    default:
      /* make compiler happy */
    }
    if(error<0)
      printk(KERN_ERR "sam9407[#%d:%s]: error writing to mod player\n",
	     card->cardIdx, card->hardwareInfo->name);
    wake_up(&card->mod.moreSpace);
  }
  up(&card->mod.accessLock);
}

int samOpenMod(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  int error;

  if(!card->firmwareInfo->haveMod)
    return -ENOPKG;

  down(&card->mod.accessLock);
  if(card->mod.inUse ||
     (card->firmwareInfo->mutexModRecAudio && SAM_ATOMIC_READ(&card->mod.recChannelsUsageCount))) {
    up(&card->mod.accessLock);
    return -EBUSY;
  }

  card->mod.inUse=1;

  error=0;

  if(file->f_mode & SAM_MODE_READ_MASK) {
    card->mod.rec.ringBuffer=kmalloc(SAM_MOD_RINGBUFFER_SIZE*sizeof(SamRingBufferWord), GFP_KERNEL);
    if(!card->mod.rec.ringBuffer)
      error=-ENOMEM;
  }

  if(error>=0 && (file->f_mode & SAM_MODE_WRITE_MASK)) {
    card->mod.play.ringBuffer=kmalloc(SAM_MOD_RINGBUFFER_SIZE*sizeof(SamRingBufferWord), GFP_KERNEL);
    if(!card->mod.play.ringBuffer)
      error=-ENOMEM;
  }

  if(error>=0)
    error=resetMod(card);

  if(error<0) {
    if(card->mod.rec.ringBuffer) {
      kfree(card->mod.rec.ringBuffer);
      card->mod.rec.ringBuffer=NULL;
    }
    if(card->mod.play.ringBuffer) {
      kfree(card->mod.play.ringBuffer);
      card->mod.play.ringBuffer=NULL;
    }
    card->mod.inUse=0;
    up(&card->mod.accessLock);
    return error;
  }

  up(&card->mod.accessLock);

  atomic_inc(&card->fastPollRequests);

  return 0;
}

void samReleaseMod(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  SamWaitQueue wait;

  down(&card->mod.accessLock);

  while(card->mod.play.count>0 &&
	(!card->mod.sleeping || card->mod.timerRunning ||
	 (card->mod.syncGroup>=0 && !card->mod.playing))) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->mod.moreSpace, &wait);
    up(&card->mod.accessLock);
    samSleepOn(&card->mod.moreSpace, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      break;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      break;
#endif /* Linux 2.0 */
    down(&card->mod.accessLock);
  }

  atomic_dec(&card->fastPollRequests);

  syncLeave(card);

  if(card->mod.rec.ringBuffer) {
    kfree(card->mod.rec.ringBuffer);
    card->mod.rec.ringBuffer=NULL;
  }
  if(card->mod.play.ringBuffer) {
    kfree(card->mod.play.ringBuffer);
    card->mod.play.ringBuffer=NULL;
  }

  if(resetMod(card)<0)
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't reset mod player\n",
	   card->cardIdx, card->hardwareInfo->name);

  card->mod.inUse=0;

  up(&card->mod.accessLock);
}

int samReadMod(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  SamWaitQueue wait;
  int error, n, size;
  char *cp;
  SamModEvent event;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  cp=buf;
  n=count;

  down(&card->mod.accessLock);

  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     !card->mod.recOverflow &&
#endif
     card->mod.rec.count<=0 && (file->f_flags & O_NONBLOCK)) {
    up(&card->mod.accessLock);
    return -EAGAIN;
  }

  /* wait for incoming data */
  for(;;) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->mod.dataAvail, &wait);
    if(
#ifndef SAM_IGNORE_REC_OVERFLOW
       card->mod.recOverflow ||
#endif
       card->mod.rec.count>0) {
      samCancelSleepOn(&card->mod.dataAvail, &wait);
      break;
    }
    up(&card->mod.accessLock);
    samSleepOn(&card->mod.dataAvail, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      return -ERESTARTSYS;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      return -ERESTARTSYS;
#endif /* Linux 2.0 */
    down(&card->mod.accessLock);
  }

#ifndef SAM_IGNORE_REC_OVERFLOW
  if(card->mod.recOverflow) {
    card->mod.recOverflow=0;
    card->mod.rec.idx=card->mod.rec.count=0;
    up(&card->mod.accessLock);
    return -EIO;
  }
#endif

  while((size=peekEventSize(&card->mod.rec))>0) {
    if(n<size) {
      if(cp==buf) {
	up(&card->mod.accessLock);
	return -EINVAL;
      }
      break;
    }

    getEvent(&card->mod.rec, &event);
    if(SAM_MEMCPY_TOFS(cp, &event, size)) {
      up(&card->mod.accessLock);
      return -EFAULT;
    }

    cp+=size;
    n-=size;
  }

  up(&card->mod.accessLock);

  return cp-buf;
}

int samWriteMod(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure)
{
  SamWaitQueue wait;
  int error, sigPending, n, size, voice;
  const char *cp;
  SamModEventType eventType;
  SamModEvent event;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_READ, buf, count))<0)
    return error;

  cp=buf;
  n=count;

  down(&card->mod.accessLock);

  while(n>0) {
    if(card->mod.play.count>SAM_MOD_RINGBUFFER_SIZE/2 &&
       (file->f_flags & O_NONBLOCK)) {
      error=-EAGAIN;
      break;
    }

    /* wait until at least half SAM_MOD_RINGBUFFER_SIZE
     * buffer is free
     * to avoid writing small chunks only
     */
    while(card->mod.play.count>SAM_MOD_RINGBUFFER_SIZE/2) {
      card->mod.checkPlayback=1;
      samFeedThreadInfo.haveJobs=1;
      wake_up(&samFeedThreadInfo.feedSam);
      samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->mod.moreSpace, &wait);
      up(&card->mod.accessLock);
      samSleepOn(&card->mod.moreSpace, &wait);
#if LINUX_VERSION_CODE>=0x20200
      sigPending=signal_pending(current);
#else /* Linux 2.0 */
      sigPending=current->signal & ~current->blocked;
#endif /* Linux 2.0 */
      down(&card->mod.accessLock);
      if(sigPending) {
	error=-ERESTARTSYS;
	break;
      }
    }
    if(error<0)
      break;

    while(n>0) {
      if(n<sizeof(SamModEventType)) {
	error=-EINVAL;
	break;
      }
      if(SAM_GET_USER(eventType, (SamModEventType *)cp)) {
	error=-EFAULT;
	break;
      }
      if(eventType<0 || eventType>=SAM_MOD_EVENT_LAST ||
	 n<(size=eventSizes[eventType])) {
	error=-EINVAL;
	break;
      }

      if(SAM_MEMCPY_FROMFS(&event, cp, size)) {
	error=-EFAULT;
	break;
      }

      switch(eventType) {
      case SAM_MOD_EVENT_MEM:
	voice=event.mem.voice;
	break;
      case SAM_MOD_EVENT_OPEN:
      case SAM_MOD_EVENT_CLOSE:
      case SAM_MOD_EVENT_START:
      case SAM_MOD_EVENT_STOP:
	voice=event.trigger.voice;
	break;
      case SAM_MOD_EVENT_VOL:
	voice=event.volOut.voice;
	break;
      case SAM_MOD_EVENT_MAIN:
      case SAM_MOD_EVENT_AUX:
	voice=event.volSend.voice;
	break;
      case SAM_MOD_EVENT_PITCH:
	voice=event.pitch.voice;
	break;
      case SAM_MOD_EVENT_FILT:
	voice=event.filter.voice;
	break;
      default:
	voice=0;
      }
      if(voice>SAM_MAX_VOICES) {
	error=-EINVAL;
	break;
      }

      if(!putEvent(&card->mod.play, &event))
	break;

      cp+=size;
      n-=size;
    }
    if(error<0)
      break;
  }

  up(&card->mod.accessLock);
  card->mod.checkPlayback=1;
  samFeedThreadInfo.haveJobs=1;
  wake_up(&samFeedThreadInfo.feedSam);

  if(error>=0 ||
     ((error==-EAGAIN || error==-ERESTARTSYS) && cp>buf))
    return cp-buf;
  else
    return error;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMod(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  unsigned mask;

  down(&card->mod.accessLock);

  mask=0;
  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     card->mod.recOverflow ||
#endif
     card->mod.rec.count>0)
    mask|= POLLIN | POLLRDNORM;

  if(card->mod.play.count<=SAM_MOD_RINGBUFFER_SIZE/2)
    mask|= POLLOUT | POLLWRNORM;

  poll_wait(file, &card->mod.dataAvail, wait);
  poll_wait(file, &card->mod.moreSpace, wait);

  up(&card->mod.accessLock);

  return mask;
}
#else /* Linux 2.0 */
int samSelectMod(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  int avail=0;

  down(&card->mod.accessLock);
  switch(type) {
  case SEL_IN:
    avail=
#ifndef SAM_IGNORE_REC_OVERFLOW
      card->mod.recOverflow ||
#endif
      card->mod.rec.count>0;
    if(!avail)
      select_wait(&card->mod.dataAvail, wait);
    break;
  case SEL_OUT:
    avail=(card->mod.play.count<=SAM_MOD_RINGBUFFER_SIZE/2);
    if(!avail)
      select_wait(&card->mod.moreSpace, wait);
    break;
  }
  up(&card->mod.accessLock);

  return avail;
}
#endif /* Linux 2.0 */

static int syncJoin(SamCard *card, int *syncGroupP)
{
  int error, syncGroup;

  if((error=verify_area(VERIFY_WRITE, syncGroupP, sizeof(int)))<0)
    return error;
  if(SAM_GET_USER(syncGroup, syncGroupP))
    return -EFAULT;

  if(card->mod.playing)
    return -EBUSY;

  syncLeave(card);
  if((error=samSyncJoin(&syncGroup, card->cardIdx, SamSyncDeviceMod))>=0) {
    card->mod.syncGroup=syncGroup;
    card->mod.syncStarted=0;
    card->mod.syncStartTimer=0;
    if(SAM_PUT_USER(syncGroup, syncGroupP))
      error=-EFAULT;
  }

  return error;
}

static int memInfo(SamCard *card, SamModMemInfo *memInfoP)
{
  SamModMemInfo memInfo;
  int error;
  SamDriverInfo tmpInfo;

  if((error=verify_area(VERIFY_READ, memInfoP, sizeof(SamModMemInfo)))<0)
    return error;

  memset(&tmpInfo, 0, sizeof(tmpInfo));
  samGetMemInfo(card, &tmpInfo);

  memInfo.memMod=tmpInfo.memMod;
  memInfo.memFree=tmpInfo.memFree;

  if(SAM_MEMCPY_TOFS(memInfoP, &memInfo, sizeof(SamModMemInfo)))
    return -EFAULT;

  return 0;
}

static int loadSamples(SamCard *card, SamModSamples *samplesP)
{
  SamModSamples samples;
  int error;
  unsigned addr;

  if((error=verify_area(VERIFY_READ, samplesP, sizeof(SamModSamples)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&samples, samplesP, sizeof(SamModSamples)))
    return -EFAULT;

  if(samples.size>SAM_MAX_SAMPLE_SIZE)
    return -EINVAL;
  
  if((error=verify_area(VERIFY_READ, samples.data, samples.size<<1))<0)
    return error;

  if((error=samFree(card, SAM_MMT_ID_STAT_WAVE|samples.handle<<8, ~SAM_MMT_ROM_MASK))<0 ||
     (error=samAlloc(card, SAM_MMT_ID_STAT_WAVE|samples.handle<<8,
		     samples.size, &addr,
		     SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_256K, NULL, NULL))<0)
    return error;

  if((error=samTalk(card, SamWriteMemFS, addr,
		    samples.data, samples.size,
		    SamEndOfScript))<0) {
    samFree(card, SAM_MMT_ID_STAT_WAVE|samples.handle<<8, ~SAM_MMT_ROM_MASK);
    return error;
  }

  return 0;
}

static int unloadSamples(SamCard *card, unsigned char *handleP)
{
  unsigned char handle;
  int error;

  if((error=verify_area(VERIFY_READ, handleP, sizeof(unsigned char)))<0)
    return error;
  if(SAM_GET_USER(handle, handleP))
    return -EFAULT;

  return samFree(card, SAM_MMT_ID_STAT_WAVE|handle<<8, ~SAM_MMT_ROM_MASK);
}

static int getVoices(SamCard *card, unsigned char *voices)
{
  int error;
  unsigned char dummy, response;

  if((error=verify_area(VERIFY_WRITE, voices, sizeof(unsigned char)))<0)
    return error;

  if(card->firmwareInfo->getVoicesReadDummy)
    error=samTalk(card,
		  SamSendCtrl, 2, SAM_CMD_GET_VOI, 0,
		  SamGetByte, &dummy,
		  SamGetByte, &response,
		  SamEndOfScript);
  else
    error=samTalk(card,
		  SamSendCtrl, 2, SAM_CMD_GET_VOI, 0,
		  SamGetByte, &response,
		  SamEndOfScript);
  if(error<0)
    return error;

  if(SAM_PUT_USER(response, voices))
    return -EFAULT;

  return 0;
}

static int getPos(SamCard *card, SamModPosition *position)
{
  int error;
  unsigned char voice, dummy;
  unsigned response;

  if((error=verify_area(VERIFY_WRITE, position, sizeof(SamModPosition)))<0)
    return error;
  if(SAM_GET_USER(voice, &position->voice))
    return -EFAULT;

  if(card->firmwareInfo->getPosReturnsVoice)
    error=samTalk(card,
		  SamSendCtrl, 2, SAM_CMD_GET_POS, voice,
		  SamGetByte, &dummy,
		  SamGetDWord, &response,
		  SamEndOfScript);
  else
    error=samTalk(card,
		  SamSendCtrl, 2, SAM_CMD_GET_POS, voice,
		  SamGetDWord, &response,
		  SamEndOfScript);
  if(error<0)
    return error;

  if(SAM_PUT_USER(response>>8, &position->offset))
    return -EFAULT;

  return 0;
}

static int addPos(SamCard *card, SamModPosition *positionP)
{
  SamModPosition position;
  int error;

  if((error=verify_area(VERIFY_READ, positionP, sizeof(SamModPosition)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&position, positionP, sizeof(SamModPosition)))
    return -EFAULT;

  return samTalk(card,
		 SamSendCtrl, 6, SAM_CMD_ADD_POS,
		 position.voice, 0,
		 position.offset, position.offset>>8, position.offset>>16,
		 SamEndOfScript);
}

int samIoctlMod(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr)
{
  SamWaitQueue wait;
  int error;

  error=0;
  switch(cmd) {
  case SAM_IOC_API_INFO:
    error=samApiInfo(card, (SamApiInfo *)arg, SAM_MOD_API_VERSION);
    break;
  case SAM_IOC_SYNC_JOIN:
    down(&card->mod.accessLock);
    error=syncJoin(card, (int *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_SYNC_LEAVE:
    down(&card->mod.accessLock);
    syncLeave(card);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_SYNC_INFO:
    down(&card->mod.accessLock);
    error=putInt(arg, card->mod.syncGroup);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_MEM_INFO:
    error=memInfo(card, (SamModMemInfo *)arg);
    break;
  case SAM_IOC_MOD_RESET:
    down(&card->mod.accessLock);
    error=resetMod(card);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_POST:
    down(&card->mod.accessLock);
    while(card->mod.play.count>0) {
      card->mod.checkPlayback=1;
      samFeedThreadInfo.haveJobs=1;
      wake_up(&samFeedThreadInfo.feedSam);
      samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->mod.moreSpace, &wait);
      up(&card->mod.accessLock);
      samSleepOn(&card->mod.moreSpace, &wait);
#if LINUX_VERSION_CODE>=0x20200
      if(signal_pending(current))
	return -ERESTARTSYS;
#else /* Linux 2.0 */
      if(current->signal & ~current->blocked)
	return -ERESTARTSYS;
#endif /* Linux 2.0 */
      down(&card->mod.accessLock);
    }
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_TIMER_START:
    playTimerStart(card);
    break;
  case SAM_IOC_MOD_TIMER_STOP:
    playTimerStop(card);
    break;
  case SAM_IOC_MOD_SAMPLES_LOAD:
    down(&card->mod.accessLock);
    error=loadSamples(card, (SamModSamples *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_SAMPLES_UNLOAD:
    down(&card->mod.accessLock);
    error=unloadSamples(card, (unsigned char *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_GET_VOICES:
    down(&card->mod.accessLock);
    error=getVoices(card, (unsigned char *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_GET_POS:
    down(&card->mod.accessLock);
    error=getPos(card, (SamModPosition *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_ADD_POS:
    down(&card->mod.accessLock);
    error=addPos(card, (SamModPosition *)arg);
    up(&card->mod.accessLock);
    break;
  case SAM_IOC_MOD_CTRLRATE_INFO:
    return putInt(arg, SAM_MOD_TICKER_FREQ);
  default:
    return -ENOSYS;
  }

  return error;
}

void samInitializeMod(void)
{
#ifdef SAM_ENABLE_RTC
  samRTCRegisterCallback(&rtcCallbackInfo);
#endif
}
