/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdarg.h>
#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <asm/io.h>

#include "driver.h"
#include "audio.h"
#include "midi.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif
#include "io.h"

#define SAM_CONTROL		(card->port+1)
#define SAM_STATUS		(card->port+1)
#define SAM_DATA8		(card->port)
#define SAM_DATA16		(card->port+2)

#define SAM_IO_DETECT_TIMEOUT	(HZ/10)
#define SAM_POLL_INTERVAL_IRQ	(2*HZ)
#define SAM_POLL_INTERVAL_SLOW	(HZ/20)
#define SAM_POLL_INTERVAL_FAST	1
#define SAM_EAGAIN_TIMEOUT	(HZ/100)
#define SAM_MAX_ASYNCS_INAROW	16
#define SAM_MAX_TALK_RETRIES	16
#define SAM_MAX_DISCARD_BYTES	0x1000

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t accessSpinLock;
#endif
  struct timer_list pollTimer;
  int pollAsync;		/* poll for asynchronous notifications */
} IOPollInfo;

#ifdef SAM_ENABLE_RTC
static void rtcPollNotification(void);
#endif
static void pollNotification(unsigned long data);
static int samTalkNoLock(SamCard *card, SamTalkCmd cmd, ...);

#ifdef SAM_ENABLE_RTC
static SamRTCCallbackNode rtcCallbackInfo={
  rtcPollNotification
};
#endif

static IOPollInfo pollInfo={
#if LINUX_VERSION_CODE>=0x20200
  SPIN_LOCK_UNLOCKED,
#endif
  SAM_TIMER_INIT(pollNotification)
};

#ifdef __i386__
#if LINUX_VERSION_CODE>=0x20200
static __inline__ int outswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  int error;
  __asm__ __volatile__
    ("cld\n"
     "0: rep; outsw\n"
     "   mov $0, %0\n"
     "1:\n"
     ".section .fixup,\"ax\"\n"
     "2: pushl %%eax\n"
     "   xorl %%eax, %%eax\n"
     "3: jecxz 4f\n"
     "   outw %%ax, %%dx\n"
     "   decl %%ecx\n"
     "   jmp 3b\n"
     "4: popl %%eax\n"
     "   mov %1, %0\n"
     "   jmp 1b\n"
     ".previous\n"
     ".section __ex_table,\"a\"\n"
     "	.align 4\n"
     "	.long 0b,2b\n"
     ".previous"
     : "=r" (error)
     : "i" (-EFAULT), "d" (port), "S" (sp), "c" (count));

  return error;
}
static __inline__ int inswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  int error;
  __asm__ __volatile__
    ("cld\n"
     "0: rep; insw\n"
     "   mov $0, %0\n"
     "1:\n"
     ".section .fixup,\"ax\"\n"
     "2: pushl %%eax\n"
     "3: decl %%ecx\n"
     "   jecxz 4f\n"
     "   inw %%dx, %%ax\n"
     "   jmp 3b\n"
     "4: popl %%eax\n"
     "   mov %1, %0\n"
     "   jmp 1b\n"
     ".previous\n"
     ".section __ex_table,\"a\"\n"
     "	.align 4\n"
     "	.long 0b,2b\n"
     ".previous"
     : "=r" (error)
     : "i" (-EFAULT), "d" (port), "D" (sp), "c" (count));

  return error;
}
#else /* Linux 2.0 */
static __inline__ int outswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  __asm__ __volatile__
    ("push %%ds\n"
     "push %%fs\n"
     "pop %%ds\n"
     "cld\n"
     "rep\n"
     "outsw\n"
     "pop %%ds": : "d" (port), "S" (sp), "c" (count));

  return 0;
}
static __inline__ int inswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  __asm__ __volatile__
    ("push %%es\n"
     "push %%fs\n"
     "pop %%es\n"
     "cld\n"
     "rep\n"
     "insw\n"
     "pop %%es": : "d" (port), "D" (sp), "c" (count));

  return 0;
}
#endif /* Linux 2.0 */
#else /* !i386 */
static __inline__ int outswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  int i;
  unsigned short v;

  for(i=0; i<count; i++) {
    if(SAM_GET_USER(v, sp+i)) {
      while(i++<count)
	outw(0, port);
      return -EFAULT;
    }
    outw(v, port);
  }

  return 0;
}
static __inline__ int inswFS(unsigned short port, unsigned short *sp, unsigned count)
{
  int i;

  for(i=0; i<count; i++)
    if(SAM_PUT_USER(inw(port), sp+i)) {
      while(++i<count)
	inw(port);
      return -EFAULT;
    }

  return 0;
}
#endif /* !i386 */

static void checkAsync(SamCard *card)
{
  unsigned flags;
  int loops, status, v;

  for(loops=0;
      (inb(SAM_STATUS)&(SAM_STATUS_TE|SAM_STATUS_ID_SYNC))==0 &&
	loops<SAM_MAX_ASYNCS_INAROW;
      loops++) {
    /* received a notification outside a samTalk script
     * check if condition is still valid after disabling IRQ's
     */
    SAM_BEGIN_CRITICAL(&card->io.statusRegSpinLock, flags);
    if(((status=inb(SAM_STATUS))&(SAM_STATUS_TE|SAM_STATUS_ID_SYNC))==0) {
      v=inb(SAM_DATA8);
      SAM_END_CRITICAL(&card->io.statusRegSpinLock, flags);
      switch(status&SAM_STATUS_ID_MASK) {
      case SAM_STATUS_ID_AUDIO:
	samAudioNotification(card, v);
	break;
      case SAM_STATUS_ID_MIDI:
	if(v==SAM_ACK_UART_MOD) {
	  card->io.waitForUARTAck=0;
	  wake_up(&card->io.somethingHappened);
	} else
	  samMidiInput(card, v);
	break;
      }
    } else
      SAM_END_CRITICAL(&card->io.statusRegSpinLock, flags);
  }
}

#ifdef SAM_ENABLE_IRQ
void samInterrupt(int irq, void *devId, struct pt_regs *regs)
{
  SamCard *card=(SamCard *)devId;

  checkAsync(card);
  wake_up(&card->io.somethingHappened);
}
#endif

static void ioTimedOut(unsigned long data)
{
  SamCard *card=(SamCard *)data;

  card->io.ioExpired=1;
  wake_up(&card->io.somethingHappened);
}

#ifdef SAM_ENABLE_RTC
static void rtcPollNotification(void)
{
  SamCard *card;
  int i;

  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    checkAsync(card);
  }
}
#endif

static void pollNotification(unsigned long data)
{
  unsigned flags;
  SamCard *card;
  int needsPolling, fastPolling, i;

  needsPolling=fastPolling=0;
  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

#ifdef SAM_ENABLE_IRQ
    if(!card->irq) {
#endif
      needsPolling=1;
      if(SAM_ATOMIC_READ(&card->fastPollRequests))
	fastPolling=1;
#ifdef SAM_ENABLE_IRQ
    }
#endif
    checkAsync(card);
  }

  SAM_BEGIN_CRITICAL(&pollInfo.accessSpinLock, flags);
  if(pollInfo.pollAsync) {
    if(needsPolling) {
#ifdef SAM_ENABLE_RTC
      if(samUsingRTC) {
	if(fastPolling) {
	  if(!rtcCallbackInfo.enabled)
	    samRTCEnableCallback(&rtcCallbackInfo);
	  fastPolling=0;
	} else
	  if(rtcCallbackInfo.enabled)
	    samRTCDisableCallback(&rtcCallbackInfo);
      }
#endif
      if(fastPolling)
	pollInfo.pollTimer.expires=jiffies + SAM_POLL_INTERVAL_FAST;
      else
	pollInfo.pollTimer.expires=jiffies + SAM_POLL_INTERVAL_SLOW;
    } else
      pollInfo.pollTimer.expires=jiffies + SAM_POLL_INTERVAL_IRQ;
    add_timer(&pollInfo.pollTimer);
  }
  SAM_END_CRITICAL(&pollInfo.accessSpinLock, flags);
}

void samStartPollNotifications(void)
{
#ifdef SAM_ENABLE_RTC
  samRTCRegisterCallback(&rtcCallbackInfo);
#endif
  pollInfo.pollAsync=1;
  pollInfo.pollTimer.expires=jiffies+SAM_POLL_INTERVAL_SLOW;
  add_timer(&pollInfo.pollTimer);
}

void samStopPollNotifications(void)
{
  unsigned flags;

  SAM_BEGIN_CRITICAL(&pollInfo.accessSpinLock, flags);
  pollInfo.pollAsync=0;
  del_timer(&pollInfo.pollTimer);
  SAM_END_CRITICAL(&pollInfo.accessSpinLock, flags);
}

static int samWaitReady(SamCard *card, int forcePolling, int (*condition)(SamCard *))
{
#ifdef SAM_ENABLE_IRQ
  SamWaitQueue wait;
#endif
  struct timer_list ioTimer;

  card->io.ioExpired=0;
  init_timer(&ioTimer);
  ioTimer.expires=jiffies+card->io.ioTimeout;
  ioTimer.data=(unsigned long)card;
  ioTimer.function=ioTimedOut;
  add_timer(&ioTimer);

  while((*condition)(card)) {
#ifdef SAM_ENABLE_IRQ
    if(!forcePolling && card->irq) {
      /* using IRQ handler */
      samPrepareSleepOn(TASK_UNINTERRUPTIBLE, &card->io.somethingHappened, &wait);
      if((*condition)(card) && !card->io.ioExpired)
	samSleepOn(&card->io.somethingHappened, &wait);
      else
	samCancelSleepOn(&card->io.somethingHappened, &wait);
    } else {
#endif /* SAM_ENABLE_IRQ */
      /* polling mode */
      checkAsync(card);
#if LINUX_VERSION_CODE>=0x20200
      if(current->need_resched)
	schedule();
#else /* Linux 2.0 */
      if(need_resched)
	schedule();
#endif /* Linux 2.0 */
#ifdef SAM_ENABLE_IRQ
    }
#endif
    if(card->io.ioExpired) {
      del_timer(&ioTimer);
#ifdef SAM_ENABLE_IRQ
      if(!forcePolling && card->irq) {
	printk(KERN_WARNING "sam9407[#%d:%s]: IRQ %d not working properly, using poll mode.\n",
	       card->cardIdx, card->hardwareInfo->name, card->irq);
	free_irq(card->irq, card);
	card->irq=0;
	/* reschedule timer for polling mode */
	card->io.ioExpired=0;
	ioTimer.expires=jiffies+card->io.ioTimeout;
	add_timer(&ioTimer);
      } else
#endif /* SAM_ENABLE_IRQ */
	/* not much to do, if we're already in polling mode */
	return -EIO;
    }
  }
  del_timer(&ioTimer);
  return 0;
}

static int samWritableCondition(SamCard *card)
{
  return inb(SAM_STATUS)&SAM_STATUS_RF;
}

static __inline__ int samOutb(SamCard *card, int value, int port)
{
  int error;
  if(inb(SAM_STATUS)&SAM_STATUS_RF)
    if((error=samWaitReady(card, 1, samWritableCondition))<0)
      return error;
  outb(value, port);
  return 0;
}

static int samReadableCondition(SamCard *card)
{
  return (inb(SAM_STATUS)&(SAM_STATUS_TE|SAM_STATUS_ID_SYNC))!=SAM_STATUS_ID_SYNC;
}

static __inline__ int samInb(SamCard *card)
{
  unsigned flags;
  int error, v;

  SAM_BEGIN_CRITICAL(&card->io.statusRegSpinLock, flags);
  while((inb(SAM_STATUS)&(SAM_STATUS_TE|SAM_STATUS_ID_SYNC))!=SAM_STATUS_ID_SYNC) {
    SAM_END_CRITICAL(&card->io.statusRegSpinLock, flags);
    if((error=samWaitReady(card, !card->firmwareLoaded, samReadableCondition))<0)
      return error;
    SAM_BEGIN_CRITICAL(&card->io.statusRegSpinLock, flags);
  }
  v=inb(SAM_DATA8);
  SAM_END_CRITICAL(&card->io.statusRegSpinLock, flags);

  return v;
}

static void discardInput(SamCard *card)
{
  unsigned flags;
  int n;

  SAM_BEGIN_CRITICAL(&card->io.statusRegSpinLock, flags);
  for(n=0; n<SAM_MAX_DISCARD_BYTES && (inb(SAM_STATUS)&(SAM_STATUS_TE|SAM_STATUS_ID_SYNC))==SAM_STATUS_ID_SYNC; n++)
    inb(SAM_DATA8);
  SAM_END_CRITICAL(&card->io.statusRegSpinLock, flags);
}

static int samUARTAckCondition(SamCard *card)
{
  return card->io.waitForUARTAck;
}

static int switchUARTMode(SamCard *card)
{
  int error;
  
  card->io.waitForUARTAck=1;
  if((error=samOutb(card, SAM_CMD_UART_MOD, SAM_CONTROL))<0)
    return error;

  while(card->io.waitForUARTAck) {
    if((error=samWaitReady(card, !card->firmwareLoaded, samUARTAckCondition))<0)
      return error;
  }
  return 0;
}

static int memOp(SamCard *card, int ctrl, SamTalkCmd burstOp, unsigned aAddr, unsigned short *aSp, int words)
{
  int result, chunk, max, i;
  unsigned addr;
  unsigned short *sp;

  addr=aAddr;
  sp=aSp;
  result=0;

  for(i=0; result>=0 && i<words; i+=chunk) {
    chunk=words-i<SAM_MAX_TRANSFER_SIZE ? words-i : SAM_MAX_TRANSFER_SIZE;
    /* if chunk would exceed page boundary, limit it */
    max=((~addr)&0xFFFF)+1;
    if(chunk>max)
      chunk=max;
    
    result=samTalkNoLock(card,
			 SamSendCtrl, 7, ctrl,
			 addr, addr>>8, addr>>16, addr>>24,
			 chunk, chunk>>8,
			 SamExpectRedo, SAM_ACK_OP, SAM_NAK_OP,
			 burstOp, sp, chunk,
			 SamEndOfScript);
    addr+=chunk;
    sp+=chunk;
  }

  return result;
}

static int vsamTalk(SamCard *card, SamTalkCmd aCmd, va_list *app, int restart)
{
  va_list ap;
  SamTalkCmd cmd;
  int done, result, n, i, cond;
  unsigned addr, *addrP, v, v2;
  unsigned short *sp;
  unsigned char *cp;

  memcpy(&ap, app, sizeof(va_list));
  cmd=aCmd;
  done=result=0;

  while(!done && result>=0) {
    switch(cmd) {
    case SamDiscardInput:
      /* if we're being picklocked by audio streaming
       * this is a good place to restart
       */
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      udelay(1000);
      discardInput(card);
      break;
    case SamUARTMode:
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      result=switchUARTMode(card);
      break;
    case SamSendCtrlInit:
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      n=va_arg(ap, int);
      for(i=0; i<n && result>=0; i++) {
	udelay(200);
	result=samOutb(card, va_arg(ap, int), SAM_CONTROL);
      }
      break;
    case SamSendCtrl:
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      n=va_arg(ap, int);
      if(n>0)
	result=samOutb(card, va_arg(ap, int), SAM_CONTROL);
      for(i=1; i<n && result>=0; i++)
	result=samOutb(card, va_arg(ap, int), SAM_DATA8);
      break;
    case SamSendCtrlIf:
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      cond=va_arg(ap, int);
      n=va_arg(ap, int);
      if(cond) {
	if(n>0)
	  result=samOutb(card, va_arg(ap, int), SAM_CONTROL);
	for(i=1; i<n && result>=0; i++)
	  result=samOutb(card, va_arg(ap, int), SAM_DATA8);
      } else
	for(i=0; i<n && result>=0; i++)
	  (void)va_arg(ap, int);
      break;
    case SamSendCtrlP:
      if(restart)
	memcpy(app, &ap, sizeof(va_list));

      n=va_arg(ap, int);
      cp=va_arg(ap, unsigned char *);
      if(n>0)
	result=samOutb(card, cp[0], SAM_CONTROL);
      for(i=1; i<n && result>=0; i++)
	result=samOutb(card, cp[i], SAM_DATA8);
      break;
    case SamSendMidi:
      n=va_arg(ap, int);
      result=samOutb(card, SAM_CMD_EN_MIDOUT, SAM_CONTROL);
      for(i=0; i<n && result>=0; i++)
	result=samOutb(card, va_arg(ap, int), SAM_DATA8);
      break;
    case SamSendMidiP:
      n=va_arg(ap, int);
      cp=va_arg(ap, unsigned char *);
      result=samOutb(card, SAM_CMD_EN_MIDOUT, SAM_CONTROL);
      for(i=0; i<n && result>=0; i++)
	result=samOutb(card, cp[i], SAM_DATA8);
      break;
    case SamSendMidiFS:
      n=va_arg(ap, int);
      cp=va_arg(ap, unsigned char *);
      result=samOutb(card, SAM_CMD_EN_MIDOUT, SAM_CONTROL);
      for(i=0; i<n && result>=0; i++) {
	if(SAM_GET_USER(v, cp+i))
	  result=-EFAULT;
	else
	  result=samOutb(card, v, SAM_DATA8);
      }
      break;
    case SamExpect:
      if((result=samInb(card))>=0)
	if(result!=(v=va_arg(ap, int))) {
	  if(card->firmwareLoaded)
	    printk(KERN_ERR "sam9407[#%d:%s]: invalid response, expected=0x%02x, received=0x%02x\n",
		   card->cardIdx, card->hardwareInfo->name, v, result);
	  result=-EIO;
	}
      break;
    case SamExpectRedo:
      v=va_arg(ap, int);
      v2=va_arg(ap, int);
      if((result=samInb(card))>=0) {
	if(result!=v) {
	  if(result!=v2) {
	    if(card->firmwareLoaded)
	      printk(KERN_ERR "sam9407[#%d:%s]: invalid response, expected=0x%02x or 0x%02x, received=0x%02x\n",
		     card->cardIdx, card->hardwareInfo->name, v, v2, result);
	    result=-EIO;
	  } else
	    result=-EAGAIN;
	}
      }
      break;
    case SamGetByte:
      if((result=samInb(card))>=0)
	*va_arg(ap, unsigned char *)=result;
      break;
    case SamGetWord:
      v=0;
      for(i=0; i<2 && (result=samInb(card))>=0; i++)
	v|=result<<(i<<3);
      if(result>=0)
	*va_arg(ap, unsigned short *)=v;
      break;
    case SamGetDWord:
      v=0;
      for(i=0; i<4 && (result=samInb(card))>=0; i++)
	v|=result<<(i<<3);
      if(result>=0)
	*va_arg(ap, unsigned *)=v;
      break;
    case SamBurstRead:
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      insw(SAM_DATA16, sp, n);
      break;
    case SamBurstReadFS:
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=inswFS(SAM_DATA16, sp, n);
      break;
    case SamBurstWrite:
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      outsw(SAM_DATA16, sp, n);
      break;
    case SamBurstWriteFS:
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=outswFS(SAM_DATA16, sp, n);
      break;
    case SamBurstWriteConst:
      v=SAM_CPU_TO_LE16(va_arg(ap, int));
      n=va_arg(ap, int);
      for(i=0; i<n; i++)
	outw(v, SAM_DATA16);
      break;
    case SamReadMem:
      addr=va_arg(ap, unsigned);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_RD_MEM, SamBurstRead, addr, sp, n);
      break;
    case SamReadMemP:
      addrP=va_arg(ap, unsigned *);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_RD_MEM, SamBurstRead, *addrP, sp, n);
      break;
    case SamReadMemFS:
      addr=va_arg(ap, unsigned);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_RD_MEM, SamBurstReadFS, addr, sp, n);
      break;
    case SamWriteMem:
      addr=va_arg(ap, unsigned);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_WRT_MEM, SamBurstWrite, addr, sp, n);
      break;
    case SamWriteMemP:
      addrP=va_arg(ap, unsigned *);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_WRT_MEM, SamBurstWrite, *addrP, sp, n);
      break;
    case SamWriteMemFS:
      addr=va_arg(ap, unsigned);
      sp=va_arg(ap, unsigned short *);
      n=va_arg(ap, int);
      result=memOp(card, SAM_CMD_WRT_MEM, SamBurstWriteFS, addr, sp, n);
      break;
    case SamGetMMT:
      addrP=va_arg(ap, unsigned *);
      if(card->firmwareInfo->getMMTAck)
	result=samTalkNoLock(card,
			     SamSendCtrl, 2, SAM_CMD_GET_MMT, 0x00,
			     SamExpect, card->firmwareInfo->getMMTAck,
			     SamGetDWord, addrP,
			     SamEndOfScript);
      else
	result=samTalkNoLock(card,
			     SamSendCtrl, 2, SAM_CMD_GET_MMT, 0x00,
			     SamGetDWord, addrP,
			     SamEndOfScript);
      break;
    case SamSetMMT:
      addr=va_arg(ap, unsigned);
      result=samTalkNoLock(card,
			   SamSendCtrl, 5, SAM_CMD_SET_MMT,
			   addr, addr>>8, addr>>16, addr>>24,
			   SamEndOfScript);
      break;
    case SamEndOfScript:
      result=0;
      done=1;
      break;
    default:
      result=-EINVAL;
    }
    if(!done && result>=0)
      cmd=va_arg(ap, SamTalkCmd);
  }

  return result;
}

static int samTalkNoLock(SamCard *card, SamTalkCmd cmd, ...)
{
  va_list ap;
  int result;

  va_start(ap, cmd);
  result=vsamTalk(card, cmd, &ap, 0);
  va_end(ap);

  return result;
}

static void eagainTimedOut(unsigned long data)
{
  SamCard *card=(SamCard *)data;

  wake_up(&card->io.pickLockScreaming);
}

static int vsamTalkScheduled(SamCard *card, int checkBusy, SamTalkCmd cmd, va_list *app)
{
  SamWaitQueue wait;
  int result, tries;
  struct timer_list eagainTimer;

  down(&card->io.stillTryingLock);
  down(&card->io.ioLock);
  tries=0;
  do {
    if(tries>0 && !card->io.pickLock) {
      /* if we've received an -EAGAIN,
       * wait until samTalkPickLock started
       * or SAM_EAGAIN_TIMEOUT timed out
       */
      init_timer(&eagainTimer);
      eagainTimer.expires=jiffies+SAM_EAGAIN_TIMEOUT;
      eagainTimer.data=(unsigned long)card;
      eagainTimer.function=eagainTimedOut;
      samPrepareSleepOn(TASK_UNINTERRUPTIBLE, &card->io.pickLockScreaming, &wait);
      if(!card->io.pickLock) {
	add_timer(&eagainTimer);
	samSleepOn(&card->io.pickLockScreaming, &wait);
      } else
	samCancelSleepOn(&card->io.pickLockScreaming, &wait);
    }

    while(card->io.pickLock) {
      /* samTalkPickLock is trying to get access */
      samPrepareSleepOn(TASK_UNINTERRUPTIBLE, &card->io.pickLockHappy, &wait);
      up(&card->io.ioLock);
      samSleepOn(&card->io.pickLockHappy, &wait);
      down(&card->io.ioLock);
    }

    if(checkBusy) {
      down(&card->usageCountLock);
      if(SAM_ATOMIC_READ(&card->usageCount)) {
	up(&card->usageCountLock);
	up(&card->io.ioLock);
	up(&card->io.stillTryingLock);
	return -EBUSY;
      }
    }
    
    result=vsamTalk(card, cmd, app, 1);

    if(checkBusy)
      up(&card->usageCountLock);

  } while(result==-EAGAIN && ++tries<SAM_MAX_TALK_RETRIES);
  up(&card->io.ioLock);
  up(&card->io.stillTryingLock);

  if(result==-EAGAIN) {
    if(card->firmwareLoaded)
      printk(KERN_ERR "sam9407[#%d:%s]: script failed after %d retries.\n",
	     card->cardIdx, card->hardwareInfo->name, tries);
    result=-EIO;
  }

  return result;
}

/* public functions */
int samFirmwareDetect(SamCard *card)
{
  unsigned long savedPolicy;
  long savedPriority;
  int result, oldTimeout;

  down(&card->io.ioLock);

  /* give the firmware detection realtime priority
   * so we don't miss a proper reply when the machine
   * is badly loaded
   */
  savedPolicy=current->policy;
  savedPriority=current->rt_priority;
  current->policy=SCHED_RR;
  current->rt_priority=SAM_RT_PRIORITY;

  oldTimeout=card->io.ioTimeout;
  card->io.ioTimeout=SAM_IO_DETECT_TIMEOUT;
  result=samTalkNoLock(card,
		       SamDiscardInput,
		       SamSendCtrl, 1, SAM_CMD_RESET,
		       SamUARTMode,
		       SamDiscardInput,
		       SamEndOfScript)>=0;
  card->io.ioTimeout=oldTimeout;

  current->policy=savedPolicy;
  current->rt_priority=savedPriority;

  up(&card->io.ioLock);

  return result;
}

int samTalkPickLock(SamCard *card, SamTalkCmd cmd, ...)
{
  va_list ap;
  int result;

  card->io.pickLock=1;
  wake_up(&card->io.pickLockScreaming);

  down(&card->io.ioLock);
  card->io.pickLock=0;
  wake_up(&card->io.pickLockHappy);

  va_start(ap, cmd);
  result=vsamTalk(card, cmd, &ap, 0);
  va_end(ap);

  up(&card->io.ioLock);

  return result;
}

int samTalk(SamCard *card, SamTalkCmd cmd, ...)
{
  int result;
  va_list ap;

  va_start(ap, cmd);
  result=vsamTalkScheduled(card, 0, cmd, &ap);
  va_end(ap);

  return result;
}

int samTalkNotBusy(SamCard *card, SamTalkCmd cmd, ...)
{
  int result;
  va_list ap;

  va_start(ap, cmd);
  result=vsamTalkScheduled(card, 1, cmd, &ap);
  va_end(ap);

  return result;
}
