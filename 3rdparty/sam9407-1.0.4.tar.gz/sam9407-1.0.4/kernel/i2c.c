/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <asm/errno.h>

#include "driver.h"
#include "i2c.h"

static int sendStart(SamCard *card, int (*output)(SamCard *card, int sda, int scl))
{
  int result;

  if((result=(*output)(card, 1, 1))<0 ||
     (result=(*output)(card, 0, 1))<0 ||
     (result=(*output)(card, 0, 0))<0) {
    (*output)(card, 1, 1);
    return result;
  }

  return 0;
}

static int sendStop(SamCard *card, int (*output)(SamCard *card, int sda, int scl))
{
  int result;

  if((result=(*output)(card, 0, 1))<0 ||
     (result=(*output)(card, 1, 1))<0) {
    (*output)(card, 1, 1);
    return result;
  }

  return 0;
}

static int receiveAck(SamCard *card,
		      int (*output)(SamCard *card, int sda, int scl),
		      int (*input)(SamCard *card))
{
  int error, sda;

  if((error=(*output)(card, 1, 0))<0 ||
     (error=(*output)(card, 1, 1))<0)
    return error;

  if((sda=(*input)(card))<0)
    return sda;

  if(sda>0)
    return -EIO;

  if((error=(*output)(card, 1, 0))<0)
    return error;

  return 0;
}

static int sendByte(SamCard *card,
		    int (*output)(SamCard *card, int sda, int scl),
		    int v)
{
  int result, sda, i;

  for(i=7; i>=0; i--) {
    sda=!!(v&(1<<i));
    if((result=(*output)(card, sda, 0))<0 ||
       (result=(*output)(card, sda, 1))<0 ||
       (result=(*output)(card, sda, 0))<0)
      break;
  }

  return result;
}
		    
static int receiveByte(SamCard *card,
		       int (*output)(SamCard *card, int sda, int scl),
		       int (*input)(SamCard *card))
{
  int error, result, sda, i;

  result=0;
  for(i=7; i>=0; i--) {
    if((error=(*output)(card, 1, 1))<0)
      return error;
    if((sda=(*input)(card))<0)
      return sda;
    if((error=(*output)(card, 1, 0))<0)
      return error;
    result=(result<<1)|!!sda;
  }

  return result;
}
		    
int samI2CWrite(SamCard *card,
		int (*output)(SamCard *card, int sda, int scl),
		int (*input)(SamCard *card),
		int addr, char *buf, int count)
{
  int result, i;

  if((result=sendStart(card, output))<0)
    return result;

  if((result=sendByte(card, output, addr<<1))<0 ||
     (result=receiveAck(card, output, input))<0) {
    sendStop(card, output);
    return result;
  }

  for(i=0; i<count; i++) {
    if((result=sendByte(card, output, buf[i]))<0 ||
       (result=receiveAck(card, output, input))<0) {
      sendStop(card, output);
      return result;
    }
  }

  return sendStop(card, output);
}

int samI2CRead(SamCard *card,
	       int (*output)(SamCard *card, int sda, int scl),
	       int (*input)(SamCard *card),
	       int addr, char *buf, int count)
{
  int result, last, i;

  if((result=sendStart(card, output))<0)
    return result;

  if((result=sendByte(card, output, (addr<<1)|1))<0 ||
     (result=receiveAck(card, output, input))<0) {
    sendStop(card, output);
    return result;
  }

  for(i=0; i<count; i++) {
    if((result=receiveByte(card, output, input))<0) {
      sendStop(card, output);
      return result;
    }
    buf[i]=result;

    last=i==count-1;
    if((result=(*output)(card, last, 0))<0 ||
       (result=(*output)(card, last, 1))<0 ||
       (result=(*output)(card, last, 0))<0) {
      sendStop(card, output);
      return result;
    }
  }

  return sendStop(card, output);
}
