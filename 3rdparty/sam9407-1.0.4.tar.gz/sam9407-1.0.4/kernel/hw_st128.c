/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/delay.h>
#if LINUX_VERSION_CODE<0x20200
#include <linux/bios32.h>
#endif
#include <linux/pci.h>
#include <asm/io.h>

#include "driver.h"
#include "io.h"

#define SAM_PCI_VENDOR_ID_HOONTECH		0x128E
#define SAM_PCI_DEVICE_ID_SAM9407		9
#define SAM_ELCR_PORT(irq)			(0x4D0+((irq)>=8))

#if defined(SAM_ENABLE_HW_ST128RUBY) || defined(SAM_ENABLE_HW_ST128PCI)
static int st128FillCache(SamCard *card);
static int st128RestoreCache(SamCard *card);
static int st128AudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input);
static int st128MidiRouteHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *route);
static int st128MuteHook(SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *mute);
#endif

#if defined(SAM_ENABLE_HW_ST128PCI) || defined(SAM_ENABLE_HW_STDA)
static int st128PCIConfigure(SamHardwareInfo **hardwareInfoMasterP, SamHardwareResource *resMaster,
			     SamHardwareInfo **hardwareInfoSlaveP, SamHardwareResource *resSlave,
			     unsigned bus, unsigned devFn);
#endif

#if defined(SAM_ENABLE_HW_ST128RUBY) || defined(SAM_ENABLE_HW_ST128PCI)
static SamHWCtrlVendorInfo st128CtrlInfo[]={
  {					/* SAM_MIXER_HW_ID_AUDIO_INPUT */
    st128AudioInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_AUDIO_OUTPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_MIDI_ROUTE */
    st128MidiRouteHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_EXTERNAL_CLOCK */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_INPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_IN_RATE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_ANALOG_OUT_VOL */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_MIDI_IN */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_CHANNEL */
    NULL,				/* vendorHandler */
  },
};

static SamHWHook st128Hooks[]={
  NULL,					/* SamHWHookIdSampleRate */
  st128MuteHook,			/* SamHWHookIdMasterMute */
  NULL,					/* SamHWHookIdMinus6dB */
};
#endif /* SAM_ENABLE_HW_ST128RUBY || SAM_ENABLE_HW_ST128PCI */

#ifdef SAM_ENABLE_HW_ST128RUBY
SamHardwareInfo samST128RubyHardwareInfo={
  "st128ruby",			/* name */
  NULL,				/* processHints */
  NULL,				/* reset */
  NULL,				/* firmwareDetected */
  NULL,				/* probeMem */
  st128FillCache,		/* fillCache */
  sizeof(SamST128HardwareCache),/* backupCacheSize */
  st128RestoreCache,		/* restoreCache */
  NULL,				/* ctrlIsAvail */
  st128CtrlInfo,		/* ctrlInfo */
  NULL,				/* hookIsAvail */
  st128Hooks,			/* hooks */
};

static SamPnpResource st128RubyPnPResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (ST128Ruby)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (ST128Ruby)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResAuxPort0 */
    0,				/* isOptional */
    "sam9407 (ST128Ruby Ctrl)",
    4, 0,			/* ldn, idx */
    2, 7,			/* extent, ofs */
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    NULL,
  },
};

SamPnPInfo samST128RubyPnPInfo={
  0x3746630E,
  &samST128RubyHardwareInfo,
  st128RubyPnPResources,
};
#endif /* SAM_ENABLE_HW_ST128RUBY */

#ifdef SAM_ENABLE_HW_ST128PCI
SamHardwareInfo samST128PCIHardwareInfo={
  "st128pci",			/* name */
  NULL,				/* processHints */
  NULL,				/* reset */
  NULL,				/* firmwareDetected */
  NULL,				/* probeMem */
  st128FillCache,		/* fillCache */
  sizeof(SamST128HardwareCache),/* backupCacheSize */
  st128RestoreCache,		/* restoreCache */
  NULL,				/* ctrlIsAvail */
  st128CtrlInfo,		/* ctrlInfo */
  NULL,				/* hookIsAvail */
  st128Hooks,			/* hooks */
};
#endif /* SAM_ENABLE_HW_ST128PCI */

#if defined(SAM_ENABLE_HW_ST128PCI) || defined(SAM_ENABLE_HW_STDA)
static SamPCIResource st128PCIResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (ST128PCI)",
    PCI_BASE_ADDRESS_0,		/* where */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (ST128PCI)",
    PCI_INTERRUPT_LINE,
  },
  {				/* SamHardwareResAuxPort0 */
    0,				/* isOptional */
    "sam9407 (ST128PCI Ctrl)",
    PCI_BASE_ADDRESS_0,		/* where */
    2, 8,			/* extent, ofs */
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    NULL
  },
};

SamPCIInfo samST128PCIInfo={
  SAM_PCI_VENDOR_ID_HOONTECH,
  SAM_PCI_DEVICE_ID_SAM9407,
#ifdef SAM_ENABLE_HW_ST128PCI
  &samST128PCIHardwareInfo,
#else
  NULL,
#endif
  st128PCIResources,
  st128PCIConfigure,
};
#endif /* SAM_ENABLE_HW_ST128PCI || SAM_ENABLE_HW_STDA */

#if defined(SAM_ENABLE_HW_ST128RUBY) || defined(SAM_ENABLE_HW_ST128PCI)
/* Structure of the ST128 control byte
 * located at MPUBASE+7 for ISA
 * and MPUBASE+10 for PCI cards
 *
 * Bit 0  : unmute
 * Bit 1  : wasel     0 for 2,4,8 MB   1 for 16,32 MB
 * Bit 2  : midisel
 * Bit 3  : daadsel
 * Bit 4  : echo_vol
 * Bit 5  : echo_on
 * Bit 6,7: dacsel
 *
 */

static int st128FillCache(SamCard *card)
{
  /* Unfortunately the control register
   * can't be retrieved
   * So we need to brute-force reset
   * the settings when the module gets loaded
   */
  card->hardwareCache.st128.dac=0x0F;
  outb(0x01, card->auxPort0+1);
  outb(card->hardwareCache.st128.dac, card->auxPort0);
  return 0;
}

/* restore the hardware cache from saved values */
static int st128RestoreCache(SamCard *card)
{
  outb(card->hardwareCache.st128.dac, card->auxPort0);
  return 0;
}

static int st128AudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input)
{
  unsigned char dac=card->hardwareCache.st128.dac;

  if(set) {
    dac&=~0xC8;
    switch(*input) {
    case SAM_MIXER_AUDIO_INPUT_CODEC:
      break;
    case SAM_MIXER_AUDIO_INPUT_MIC:
      dac|=0x40;
      break;
    case SAM_MIXER_AUDIO_INPUT_LINE1:
      dac|=0x80;
      break;
    case SAM_MIXER_AUDIO_INPUT_LINE2:
      dac|=0xC0;
      break;
    default: /* SAM_MIXER_AUDIO_INPUT_DIGITAL */
      dac|=0x08;
    }
  }

  switch(dac&0xC8) {
  case 0x00:
    *input=SAM_MIXER_AUDIO_INPUT_CODEC;
    break;
  case 0x40:
    *input=SAM_MIXER_AUDIO_INPUT_MIC;
    break;
  case 0x80:
    *input=SAM_MIXER_AUDIO_INPUT_LINE1;
    break;
  case 0xC0:
    *input=SAM_MIXER_AUDIO_INPUT_LINE2;
    break;
  default:
    *input=SAM_MIXER_AUDIO_INPUT_DIGITAL;
  }

  if(set) {
    outb(dac, card->auxPort0);
    card->hardwareCache.st128.dac=dac;
  }

  return 0;
}

static int st128MidiRouteHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *route)
{
  unsigned char dac=card->hardwareCache.st128.dac;

  if(set) {
    dac&=~0x04;
    dac|=(*route==SAM_MIXER_MIDI_ROUTE_DREAM)<<2;
  }

  *route=dac&0x04 ? SAM_MIXER_MIDI_ROUTE_DREAM : SAM_MIXER_MIDI_ROUTE_CODEC;

  if(set) {
    outb(dac, card->auxPort0);
    card->hardwareCache.st128.dac=dac;
  }

  return 0;
}

static int st128MuteHook(SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *mute)
{
  unsigned char dac=card->hardwareCache.st128.dac;
  if(set) {
    dac&=~1;
    dac|=!*mute;
  }
  *mute=!(dac&1);
  if(set) {
    outb(dac, card->auxPort0);
    card->hardwareCache.st128.dac=dac;
  }
  return 0;
}
#endif /* SAM_ENABLE_HW_ST128RUBY || SAM_ENABLE_HW_ST128PCI */

#if defined(SAM_ENABLE_HW_ST128PCI) || defined(SAM_ENABLE_HW_STDA)

#if LINUX_VERSION_CODE>=0x20400
/* This is ugly !
 * from Linux-2.3 onwards only existing PCI devices can
 * be accessed through the interface.
 * Unfortunately Hoontech chose to implement a K128 access hack
 * by using the non existing PCI function #7
 * So we temporarily reassign the function number of our Hoontech
 * sam9407 device to #7
 */

static void hackPCIFunc(unsigned bus, unsigned devFnFrom, unsigned devFnTo)
{
  struct pci_dev *dev;

  if((dev=pci_find_slot(bus, devFnFrom)))
    dev->devfn=devFnTo;
}
#endif


static int st128PCIConfigure(SamHardwareInfo **hardwareInfoMasterP, SamHardwareResource *resMaster,
			     SamHardwareInfo **hardwareInfoSlaveP, SamHardwareResource *resSlave,
			     unsigned bus, unsigned devFn)
{
#ifdef SAM_ENABLE_IRQ
  static struct {
    unsigned short vendor, devId;
  } chipsetsWithELCR[]={
    { PCI_VENDOR_ID_INTEL, PCI_DEVICE_ID_INTEL_82371AB_0 },
  };
#endif

  unsigned char devFn7=PCI_DEVFN(PCI_SLOT(devFn), 7);
  int success;
#ifdef SAM_ENABLE_IRQ
  unsigned char irq;
  int port, mask, value, i;
#if LINUX_VERSION_CODE<0x20200
  unsigned char dummyBus, dummyDevFn;
#endif
#endif

  /* Soundtrack Digital Audio cards share the same
   * vendor and device ID's with ST128 cards
   * However on the STDA the sam9407 is always first
   * whereas it's second on the ST128
   */
  if(PCI_FUNC(devFn)==0) {
#ifdef SAM_ENABLE_HW_STDA
    *hardwareInfoMasterP=&samSTDAMasterHardwareInfo;
    resMaster[SamHardwareResPort].id="sam9407 (STDA/M)";
#ifdef SAM_ENABLE_IRQ
    resMaster[SamHardwareResIrq].id="sam9407 (STDA/M)";
#endif
    resMaster[SamHardwareResAuxPort0].id="sam9407 (STDA Ctrl)";
    resMaster[SamHardwareResAuxPort0].value+=8;

    *hardwareInfoSlaveP=&samSTDASlaveHardwareInfo;
    resSlave[SamHardwareResPort].id="sam9407 (STDA/S)";
    resSlave[SamHardwareResPort].value=resMaster[SamHardwareResPort].value+8;
#ifdef SAM_ENABLE_IRQ
    resSlave[SamHardwareResIrq].id="sam9407 (STDA/S)";
    resSlave[SamHardwareResIrq].value=resMaster[SamHardwareResIrq].value;
#endif /* SAM_ENABLE_IRQ */
#else /* !SAM_ENABLE_HW_STDA */
    *hardwareInfoMasterP=NULL;
#endif /* !SAM_ENABLE_HW_STDA */
  }

  /* adjust the address of the control register */
#if LINUX_VERSION_CODE>=0x20400
  hackPCIFunc(bus, devFn, devFn7);
#endif
  success=pcibios_write_config_dword(bus, devFn7, 0x4C, resMaster[SamHardwareResAuxPort0].value|PCI_BASE_ADDRESS_SPACE_IO)==PCIBIOS_SUCCESSFUL;
#if LINUX_VERSION_CODE>=0x20400
  hackPCIFunc(bus, devFn7, devFn);
#endif
  if(!success)
    return -EIO;
  resMaster[SamHardwareResAuxPort0].value+=2;

#ifdef SAM_ENABLE_IRQ
  if(pcibios_read_config_byte(bus, PCI_DEVFN(PCI_SLOT(devFn), !PCI_FUNC(devFn)), PCI_INTERRUPT_LINE, &irq)!=PCIBIOS_SUCCESSFUL)
    return -EIO;

  /* enable shared IRQ handling */
  if(!resMaster[SamHardwareResIrq].value && irq!=0xFF) {
    /* check if this chipset supports
     * the edge/level trigger control register
     */
    for(i=0; i<SAM_NUMBER_OF(chipsetsWithELCR); i++) {
#if LINUX_VERSION_CODE>=0x20200
      if(pci_find_device(chipsetsWithELCR[i].vendor, chipsetsWithELCR[i].devId, NULL))
	break;
#else /* Linux 2.0 */
      if(pcibios_find_device(chipsetsWithELCR[i].vendor, chipsetsWithELCR[i].devId, 0, &dummyBus, &dummyDevFn)==PCIBIOS_SUCCESSFUL)
	break;
#endif /* Linux 2.0 */
    }
    if(i<SAM_NUMBER_OF(chipsetsWithELCR)) {
      /* adjust the EISA edge/level trigger control register */
      port=SAM_ELCR_PORT(irq);
      mask=1<<(irq&7);
      value=inb(port);
      if(value&mask)
	outb(value&~mask, port);

      /* adjust the K128 IRQ control and the PCI IRQ level register */
#if LINUX_VERSION_CODE>=0x20400
      hackPCIFunc(bus, devFn, devFn7);
#endif
      success=pcibios_write_config_dword(bus, devFn7, 0x48, 0xE400CC)==PCIBIOS_SUCCESSFUL;
#if LINUX_VERSION_CODE>=0x20400
      hackPCIFunc(bus, devFn7, devFn);
#endif
      if(!success ||
	 pcibios_write_config_byte(bus, devFn, PCI_INTERRUPT_LINE, irq)!=PCIBIOS_SUCCESSFUL)
	return -EIO;

      resMaster[SamHardwareResIrq].value=irq;
      resSlave[SamHardwareResIrq].value=irq;
    }
  }
#endif /* SAM_ENABLE_IRQ */

  return 0;
}
#endif /* SAM_ENABLE_HW_ST128PCI || SAM_ENABLE_HW_STDA */
