#ifndef _RTC_H
#define _RTC_H

#define SAM_RTC_FREQ		4096

typedef struct SamRTCCallbackNode {
  void (*callback)(void);
  int enabled;
  struct SamRTCCallbackNode *next;
} SamRTCCallbackNode;

extern int samUsingRTC;

void samRTCRegisterCallback(SamRTCCallbackNode *node);
void samRTCEnableCallback(SamRTCCallbackNode *node);
void samRTCDisableCallback(SamRTCCallbackNode *node);

void samInitializeRTC(void);
void samReleaseRTC(void);

#endif /* _RTC_H */
