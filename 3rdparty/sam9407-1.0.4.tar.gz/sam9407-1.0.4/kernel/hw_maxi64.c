/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <asm/io.h>

#include "driver.h"
#include "io.h"

#ifdef SAM_ENABLE_HW_MAXI64

static int maxi64FillCache(SamCard *card);
static int maxi64RestoreCache(SamCard *card);
static int maxi64CtrlIsAvail(struct SamCard *card, SamMixerHWId mixerId);
static int maxi64AudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input);

static SamHWCtrlVendorInfo maxi64CtrlInfo[]={
  {					/* SAM_MIXER_HW_ID_AUDIO_INPUT */
    maxi64AudioInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_AUDIO_OUTPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_MIDI_ROUTE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_EXTERNAL_CLOCK */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_INPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_IN_RATE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_ANALOG_OUT_VOL */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_MIDI_IN */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_CHANNEL */
    NULL,				/* vendorHandler */
  },
};

SamHardwareInfo samMaxi64HardwareInfo={
  "maxi64",			/* name */
  NULL,				/* processHints */
  NULL,				/* reset */
  maxi64RestoreCache,		/* firmwareDetected */
  NULL,				/* probeMem */
  maxi64FillCache,		/* fillCache */
  sizeof(SamMaxi64HardwareCache),/* backupCacheSize */
  maxi64RestoreCache,		/* restoreCache */
  maxi64CtrlIsAvail,		/* ctrlIsAvail */
  maxi64CtrlInfo,		/* ctrlInfo */
  NULL,				/* hookIsAvail */
  NULL,				/* hooks */
};

static SamPnpResource maxi64PnPResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (Maxi Sound 64)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (Maxi Sound 64)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResAuxPort0 */
    1,				/* isOptional */
    NULL,
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    NULL,
  },
};

static SamPnpResource maxi64ProPnPResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (Maxi Sound 64)",
    3, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (Maxi Sound 64)",
    3, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResAuxPort0 */
    1,				/* isOptional */
    NULL,
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    NULL,
  },
};

SamPnPInfo samMaxi64PnPInfo={
  0x3698630E,
  &samMaxi64HardwareInfo,
  maxi64PnPResources,
};

SamPnPInfo samMaxi64ProPnPInfo={
  0x68187316,
  &samMaxi64HardwareInfo,
  maxi64ProPnPResources,
};

static int maxi64CtrlIsAvail(struct SamCard *card, SamMixerHWId mixerId)
{
  return card->firmwareInfo->supportsMaxi64Controls;
}

static __inline__ int sendAudioInputControl(SamCard *card, int audioInput)
{
  return samTalk(card,
		 SamSendCtrl, 2, 0x2C, audioInput,
		 SamEndOfScript);
}

static int maxi64FillCache(SamCard *card)
{
  /* Unfortunately the control settings
   * can't be retrieved
   * So we need to brute-force reset
   * the settings when the module gets loaded
   */
  card->hardwareCache.maxi64.audioInput=0;

  return maxi64RestoreCache(card);
}

static int maxi64RestoreCache(SamCard *card)
{
  if(card->firmwareInfo->supportsMaxi64Controls)
    return sendAudioInputControl(card, card->hardwareCache.maxi64.audioInput);
  else
    return 0;
}

static int maxi64AudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input)
{
  int error, audioInput;

  audioInput=card->hardwareCache.maxi64.audioInput;

  if(set) {
    switch(*input) {
    case SAM_MIXER_AUDIO_INPUT_CODEC:
      audioInput=0;
      break;
    case SAM_MIXER_AUDIO_INPUT_LINE1:
      audioInput=1;
      break;
    case SAM_MIXER_AUDIO_INPUT_DIGITAL:
      audioInput=3;
    default: /* make compiler happy */
    }
  }

  switch(audioInput) {
  case 0:
    *input=SAM_MIXER_AUDIO_INPUT_CODEC;
    break;
  case 1:
    *input=SAM_MIXER_AUDIO_INPUT_LINE1;
    break;
  default:
    *input=SAM_MIXER_AUDIO_INPUT_DIGITAL;
  }

  if(set) {
    if((error=sendAudioInputControl(card, audioInput))<0)
      return error;
    card->hardwareCache.maxi64.audioInput=audioInput;
  }

  return 0;
}

#endif /* SAM_ENABLE_HW_MAXI64 */
