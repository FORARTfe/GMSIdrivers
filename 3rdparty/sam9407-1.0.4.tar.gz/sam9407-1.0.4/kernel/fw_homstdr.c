/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/stddef.h>
#include <linux/kernel.h>

#include "driver.h"

#ifdef SAM_ENABLE_FW_HOMSTDR

/* indexed by SamMixerId */
static SamFWCtrlVendorInfo homstdrMixerCtrlInfo[]={
  {								/* SAM_MIXER_HOMSTDR_ID_SENTINEL */
  },
  {								/* SAM_MIXER_HOMSTDR_ID_MASTER_VOL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x07,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x00,				/* storeAt */
  },
  {								/* SAM_MIXER_HOMSTDR_ID_MASTER_MUTE */
    SamCtrlTypeVendorHandler,					/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0,								/* valueLimit */
    0x00,							/* ctrl */
    SamHWHookTypeMandatory,					/* hwHookType */
    SamHWHookIdMasterMute,					/* hwHookId */
  },
};

static SamFWCtrlVendorInfo homstdrAudioCtrlInfo[]={
  {								/* SAM_AUDIO_HOMSTDR_ID_SENTINEL */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_CFG */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    1,								/* valueLimit */
    0x18,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x50,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_FRONTL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    0,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_FRONTR */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    1,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_REARL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    2,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_REARR */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    3,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_REV */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    4,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_SRC_VOL_CHR */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x19,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x54,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    5,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_CFG */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    3,								/* valueLimit */
    0x10,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    0,								/* storeAt */
    SamCtrlResponseVoicesFree,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_LB */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    0,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_MB1 */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    1,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_MB2 */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    2,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_MB3 */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    3,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_MB4 */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    4,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_EQ_LEV_HB */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x11,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x18,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
    5,								/* valueBytesOfs */
    5,								/* valueBytesLimit */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_EFF_CFG */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypePlayChannelLSB,				/* addrTagType */
    1,								/* addrTagLimit */
    1,								/* valueLimit */
    0x20,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x88,				/* storeAt */
    SamCtrlResponseVoicesFree,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REV_TYPE */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x0D,							/* valueLimit */
    0x21,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x90,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REV_TIME */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x22,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x94,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REV_FEED */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x23,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x98,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REV_VOLF */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x24,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x9C,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REV_VOLR */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x25,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xA0,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_TYPE */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x09,							/* valueLimit */
    0x28,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xB0,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_DEL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x29,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xB4,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_FEED */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x2A,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xB8,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_RATE */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x2B,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xBC,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_DEPTH */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x2C,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xC0,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_VOLF */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x2D,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xC4,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_CHR_VOLR */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x2E,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xC8,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_FILT_FC */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x4A,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamHomstdrAudioCtrlValues, filt_fc),
  },
  {								/* SAM_AUDIO_HOMSTDR_FILT_Q */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x4B,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamHomstdrAudioCtrlValues, filt_q),
  },
  {								/* SAM_AUDIO_HOMSTDR_FILTER_ON */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    1,								/* valueLimit */
    0x50,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0xD0,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REC_MODE */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x09,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x04,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionRecordOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_ID_REC_VOL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x0A,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x05,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionRecordOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_HOMSTDR_DINREC_VOL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannelMSB,					/* addrTagType */
    1,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x0B,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_ADDR|0x06,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
};

SamFirmwareInfo samHomstdrFirmwareInfo={
  "homstdr",			/* name */
  0x420,			/* probeAddr */
  "Home Studio Recording",	/* probeStr */
  SAM_API_CLASS_HOMSTDR,	/* apiClass */
  HZ/2,				/* initNapTimeout */
  0,				/* verifyChecksum */
  NULL,				/* setup */
  64,				/* mmtSlots */
  1,				/* largeCtrlTable */
  0x44,				/* peakMeterWords */
  1,				/* haveAudio */
  0,				/* haveMidi */
  0,				/* haveMod */
  0,				/* mutexModRecAudio */
  0,				/* supportsMaxi64Controls */
  4,				/* playBackChannels */
  1,				/* recordChannels */
  0x00,				/* getMMTAck */
  0x00,				/* openAck */
  0xC0,				/* closeAck */
  0,				/* closeAckRecChannel */
  0,				/* midiResetFixup */
  0,				/* getVoicesReadDummy */
  0,				/* getPosReturnsVoice */
  homstdrMixerCtrlInfo,		/* mixerCtrlInfo */
  homstdrAudioCtrlInfo,		/* audioCtrlInfo */
  0x00,				/* resetRestoreCtrl */
  0,				/* nResetReadjust */
  NULL,				/* resetReadjust */
  0,				/* nSBankRehash */
  NULL,				/* sbankRehash */
  NULL,				/* midiSelCtrls */
  0,				/* ctrlValuesSize */
  NULL,				/* initAudioCtrlValues */
};

#endif /* SAM_ENABLE_FW_HOMSTDR */
