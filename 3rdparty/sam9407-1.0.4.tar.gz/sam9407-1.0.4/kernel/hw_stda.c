/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <asm/io.h>

#include "driver.h"
#include "io.h"

#ifdef SAM_ENABLE_HW_STDA

/* Soundtrack Digital Audio routing register layout:
 *
 * Register #0
 *
 * Bit 0-2 : box #
 * Bit 3   : master DSP
 * Bit 4   : channel #0
 * Bit 5   : channel #1
 * Bit 6   : 0
 * Bit 7   : 0
 *
 *
 * Register #1
 *
 * Bit 0   : channel #2
 * Bit 1   : channel #3
 * Bit 2   : midi in
 * Bit 3   : slave DSP
 * Bit 4   : a0 (outin, selects analog source)
 * Bit 5   : a1 (selects slave dsp output -> master dsp)
 * Bit 6   : 1
 * Bit 7   : 0
 *
 *
 * Register #2
 *
 * Bit 0   : midi select
 * Bit 1   : 48kHz select
 * Bit 2-3 : user select (selects master dsp input from:
 *                        0 - slave DSP, 1 - ASS, 2 - external box)
 * Bit 4   : md
 * Bit 5   : cs
 * Bit 6   : 0
 * Bit 7   : 1
 *
 *
 * Register #3
 *
 * Bit 0   : mute
 * Bit 1   : cntl0 (selects aux input)
 * Bit 2   : cntl1 (selects mic input)
 * Bit 3   : daad (selects digital daughter board input)
 * Bit 4   : reset
 * Bit 5   : reverse
 * Bit 6   : 1
 * Bit 7   : 1
 *
 * Midi input and channel #0-3 routings are adjusted by
 * assigning the wanted box number and the master/slave DSP's
 * that shall be affected, while pulling the routing index
 * bit (exactly one of either midi input or channel #0-3)
 * to zero and switching it back to one.
 * All the other routing registers are static.
 */

#define SAM_STDA_PER_BOX_DSP_MASK	(1<<3)

#define SAM_STDA_PER_BOX_CH0_MASK	(1<<4)
#define SAM_STDA_PER_BOX_CH1_MASK	(1<<5)
#define SAM_STDA_PER_BOX_B0_MASK	(SAM_STDA_PER_BOX_CH0_MASK |\
					SAM_STDA_PER_BOX_CH1_MASK)

#define SAM_STDA_PER_BOX_CH2_MASK	(1<<0)
#define SAM_STDA_PER_BOX_CH3_MASK	(1<<1)
#define SAM_STDA_PER_BOX_MIDI_IN_MASK	(1<<2)
#define SAM_STDA_PER_BOX_B1_MASK	(SAM_STDA_PER_BOX_CH2_MASK |\
					SAM_STDA_PER_BOX_CH3_MASK |\
					SAM_STDA_PER_BOX_MIDI_IN_MASK)

static int stdaReset(SamCard *card);
static int stdaFillCache(SamCard *card);
static int stdaRestoreCache(SamCard *card);
static int stdaAudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input);
static int stdaAudioOutputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *output);
static int stdaPerBoxHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *box);

static SamHWCtrlVendorInfo stdaMasterCtrlInfo[]={
  {					/* SAM_MIXER_HW_ID_AUDIO_INPUT */
    stdaAudioInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_AUDIO_OUTPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_MIDI_ROUTE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_EXTERNAL_CLOCK */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_INPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_IN_RATE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_ANALOG_OUT_VOL */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_MIDI_IN */
    stdaPerBoxHandler,			/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_CHANNEL */
    stdaPerBoxHandler,			/* vendorHandler */
    3,					/* addrTagLimit */
  },
};

SamHardwareInfo samSTDAMasterHardwareInfo={
  "stda/m",				/* name */
  NULL,					/* processHints */
  stdaReset,				/* reset */
  NULL,					/* firmwareDetected */
  NULL,					/* probeMem */
  stdaFillCache,			/* fillCache */
  sizeof(SamSTDAHardwareCache),		/* backupCacheSize */
  stdaRestoreCache,			/* restoreCache */
  NULL,					/* ctrlIsAvail */
  stdaMasterCtrlInfo,			/* ctrlInfo */
  NULL,					/* hookIsAvail */
  NULL,					/* hooks */
};

static SamHWCtrlVendorInfo stdaSlaveCtrlInfo[]={
  {					/* SAM_MIXER_HW_ID_AUDIO_INPUT */
    stdaAudioInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_AUDIO_OUTPUT */
    stdaAudioOutputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_MIDI_ROUTE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_EXTERNAL_CLOCK */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_INPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_IN_RATE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_ANALOG_OUT_VOL */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_MIDI_IN */
    stdaPerBoxHandler,			/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_CHANNEL */
    stdaPerBoxHandler,			/* vendorHandler */
    3,					/* addrTagLimit */
  },
};

SamHardwareInfo samSTDASlaveHardwareInfo={
  "stda/s",				/* name */
  NULL,					/* processHints */
  NULL,					/* reset */
  NULL,					/* firmwareDetected */
  NULL,					/* probeMem */
  NULL,					/* fillCache */
  0,					/* backupCacheSize */
  NULL,					/* restoreCache */
  NULL,					/* ctrlIsAvail */
  stdaSlaveCtrlInfo,			/* ctrlInfo */
  NULL,					/* hookIsAvail */
  NULL,					/* hooks */
};

static int stdaReset(SamCard *card)
{
  outb(card->hardwareCache.stda.adda[3] | 0x10, card->auxPort0);
  udelay(1000);
  outb(card->hardwareCache.stda.adda[3], card->auxPort0);
  udelay(1000);

  return 0;
}

static int stdaFillCache(SamCard *card)
{
  static unsigned char initialADDA[]={
    0x30, 0x47, 0xB9, 0xC1
  };

  memset(&card->hardwareCache.stda, 0, sizeof(card->hardwareCache.stda));
  memcpy(card->hardwareCache.stda.adda, initialADDA, sizeof(card->hardwareCache.stda.adda));

  return stdaRestoreCache(card);
}

static void adjustBoxRoute(SamCard *card, SamSTDABoxRouteIdx boxRouteIdx, int clearBoxIdx)
{
  static unsigned char routeIdxMasks[]={
    SAM_STDA_PER_BOX_MIDI_IN_MASK,	/* SamSTDABoxRouteIdxMidi */
    SAM_STDA_PER_BOX_CH0_MASK,		/* SamSTDABoxRouteIdxCH0 */
    SAM_STDA_PER_BOX_CH1_MASK,		/* SamSTDABoxRouteIdxCH1 */
    SAM_STDA_PER_BOX_CH2_MASK,		/* SamSTDABoxRouteIdxCH2 */
    SAM_STDA_PER_BOX_CH3_MASK,		/* SamSTDABoxRouteIdxCH3 */
  };

  int mask, b0, b1;

  mask=routeIdxMasks[boxRouteIdx];

  b0=card->hardwareCache.stda.adda[0] | SAM_STDA_PER_BOX_B0_MASK;
  b1=card->hardwareCache.stda.adda[1] | SAM_STDA_PER_BOX_B1_MASK;

  if(clearBoxIdx>=0)
    b0|=clearBoxIdx;
  else
    b0|=card->hardwareCache.stda.boxRoutes[boxRouteIdx]&SAM_STDA_ROUTE_BOX_MASK;

  /* indicate which DSP shall be used for this channel mask */
  if(clearBoxIdx<0 && (card->hardwareCache.stda.boxRoutes[boxRouteIdx]&SAM_STDA_ROUTE_MASTER_MASK))
    b0|=SAM_STDA_PER_BOX_DSP_MASK;
  else
    b0&=~SAM_STDA_PER_BOX_DSP_MASK;

  if(clearBoxIdx<0 && (card->hardwareCache.stda.boxRoutes[boxRouteIdx]&SAM_STDA_ROUTE_SLAVE_MASK))
    b1|=SAM_STDA_PER_BOX_DSP_MASK;
  else
    b1&=~SAM_STDA_PER_BOX_DSP_MASK;

  outb(b0, card->auxPort0);
  outb(b1, card->auxPort0);

  /* lower the channel information mask
   * b0 carries channel information in the high nibble
   * b1 carries channel information in the low nibble
   */
  if(mask & 0x0F)
    b1&=~mask;
  else
    b0&=~mask;

  outb(b0, card->auxPort0);
  outb(b1, card->auxPort0);

  /* raise the channel information mask again */
  if(mask & 0x0F)
    b1|=mask;
  else
    b0|=mask;

  outb(b0, card->auxPort0);
  outb(b1, card->auxPort0);
}

static int stdaRestoreCache(SamCard *card)
{
  int i, box;

  for(i=0; i<SAM_NUMBER_OF(card->hardwareCache.stda.adda); i++)
    outb(card->hardwareCache.stda.adda[i], card->auxPort0);

  for(i=0; i<SamSTDABoxRouteIdxLast; i++) {
    for(box=0; box<SAM_STDA_BOX_COUNT; box++)
      if(box!=(card->hardwareCache.stda.boxRoutes[i]&SAM_STDA_ROUTE_BOX_MASK))
	adjustBoxRoute(card, i, box);
    adjustBoxRoute(card, i, -1);
  }

  return 0;
}

static int stdaAudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input)
{
  SamCard *master, *sibling;
  SamHWCtrlVendorInfo *hwInfo;
  unsigned char adda1, adda2, adda3;

  master=card->master;
  if(!master)
    master=card;

  if(card==master) {
    sibling=card->slave;
  } else {
    sibling=card->master;
  }

  down(&sibling->mixer.accessLock);

  adda1=master->hardwareCache.stda.adda[1];
  adda3=master->hardwareCache.stda.adda[3];
  adda2=master->hardwareCache.stda.adda[2];

  if(set) {
    adda1&=~0x10;
    adda3&=~0x0E;
    adda2&=~0x0C;
    switch(*input) {
    case SAM_MIXER_AUDIO_INPUT_DIGITAL: /* daughter board */
      adda1|=0x10;
      adda3|=0x08;
      adda2|=0x04;
      break;
    case SAM_MIXER_AUDIO_INPUT_MIC:
      adda1|=0x10;
      adda3|=0x02;
      adda2|=0x04;
      break;
    case SAM_MIXER_AUDIO_INPUT_LINE1:
      adda1|=0x10;
      adda2|=0x04;
      break;
    case SAM_MIXER_AUDIO_INPUT_LINE2: /* AUX */
      adda1|=0x10;
      adda3|=0x04;
      adda2|=0x04;
      break;
    case SAM_MIXER_AUDIO_INPUT_SLAVE_DSP:
      if(card==master)
	break;
      /* slave DSP will flow into next case */
    case SAM_MIXER_AUDIO_INPUT_SLAVE_BUS:
      if(card==master) {
	adda2|=0x04;
	break;
      }
      /* slave DSP will flow into next case */
    default: /* MASTER_BUS || SLAVE_BUS */
      adda2|=0x08;
    }
  }

  if(card==master && (adda2&0x08))
    *input=SAM_MIXER_AUDIO_INPUT_MASTER_BUS;
  else if(card==master && !(adda2&0x04))
    *input=SAM_MIXER_AUDIO_INPUT_SLAVE_DSP;
  else if(adda1&0x10) {
    if(adda3&0x08)
      *input=SAM_MIXER_AUDIO_INPUT_DIGITAL;
    else if(adda3&0x04)
      *input=SAM_MIXER_AUDIO_INPUT_LINE2;
    else if(adda3&0x02)
      *input=SAM_MIXER_AUDIO_INPUT_MIC;
    else
      *input=SAM_MIXER_AUDIO_INPUT_LINE1;
  } else
    *input=SAM_MIXER_AUDIO_INPUT_SLAVE_BUS;

  if(set) {
    if(card==master) {
      outb(adda2, master->auxPort0);
      master->hardwareCache.stda.adda[2]=adda2;
    }
    if(card!=master ||
       (*input!=SAM_MIXER_AUDIO_INPUT_SLAVE_DSP &&
	*input!=SAM_MIXER_AUDIO_INPUT_MASTER_BUS)) {
      outb(adda1, master->auxPort0);
      outb(adda3, master->auxPort0);
      master->hardwareCache.stda.adda[1]=adda1;
      master->hardwareCache.stda.adda[3]=adda3;

      if(sibling && sibling->firmwareLoaded) {
	/* trigger sibling's dirty flag */
	hwInfo=sibling->hardwareInfo->ctrlInfo+ctrlId-SAM_MIXER_HW_ID_FIRST;
	sibling->mixer.hwDirtyFlags[hwInfo->dirtyAddr+addrTag]=~0;
	wake_up(&sibling->mixer.waitDirty);
      }
    }
  }

  up(&sibling->mixer.accessLock);

  return 0;
}

static int stdaAudioOutputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *output)
{
  SamCard *master, *sibling;
  unsigned char adda1;

  master=card->master;
  if(!master)
    master=card;

  if(card==master) {
    sibling=card->slave;
  } else {
    sibling=card->master;
  }

  down(&sibling->mixer.accessLock);

  adda1=master->hardwareCache.stda.adda[1];

  if(set) {
    adda1&=~0x20;
    if(*output==SAM_MIXER_AUDIO_OUTPUT_MASTER_DSP)
      adda1|=0x20;
  }

  *output=adda1&0x20 ? SAM_MIXER_AUDIO_OUTPUT_MASTER_DSP : SAM_MIXER_AUDIO_OUTPUT_EXTERNAL;

  if(set) {
    outb(adda1, master->auxPort0);
    master->hardwareCache.stda.adda[1]=adda1;
  }

  up(&sibling->mixer.accessLock);

  return 0;
}

static int stdaPerBoxHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *box)
{
  SamCard *master, *sibling;
  SamHWCtrlVendorInfo *hwInfo;
  SamSTDABoxRouteIdx boxRouteIdx;
  unsigned char *boxRoute;
  int mask;

  master=card->master;
  if(!master)
    master=card;

  if(card==master) {
    sibling=card->slave;
    mask=SAM_STDA_ROUTE_MASTER_MASK;
  } else {
    sibling=card->master;
    mask=SAM_STDA_ROUTE_SLAVE_MASK;
  }

  if(ctrlId==SAM_MIXER_HW_ID_BOX_MIDI_IN)
    boxRouteIdx=SamSTDABoxRouteIdxMidi;
  else
    boxRouteIdx=SamSTDABoxRouteIdxCH0+addrTag;

  down(&sibling->mixer.accessLock);

  boxRoute=master->hardwareCache.stda.boxRoutes+boxRouteIdx;

  if(set) {
    if(*box>SAM_STDA_BOX_COUNT)
      *box=0;

    if(*box>0 &&
       *box-1!=(*boxRoute&SAM_STDA_ROUTE_BOX_MASK)) {
      /* a different box has been selected */
      adjustBoxRoute(master, boxRouteIdx, *boxRoute&SAM_STDA_ROUTE_BOX_MASK);
      *boxRoute=*box-1;
      if(sibling && sibling->firmwareLoaded) {
	/* trigger sibling's dirty flag */
	hwInfo=sibling->hardwareInfo->ctrlInfo+ctrlId-SAM_MIXER_HW_ID_FIRST;
	sibling->mixer.hwDirtyFlags[hwInfo->dirtyAddr+addrTag]=~0;
	wake_up(&sibling->mixer.waitDirty);
      }
    }
    if(*box>0)
      *boxRoute|=mask;
    else
      *boxRoute&=~mask;

    adjustBoxRoute(master, boxRouteIdx, -1);
  }

  if(*boxRoute & mask)
    *box=(*boxRoute&SAM_STDA_ROUTE_BOX_MASK)+1;
  else
    *box=0;

  up(&sibling->mixer.accessLock);
  
  return 0;
}

#endif /* SAM_ENABLE_HW_STDA */
