/*
  Copyright (C) 2000 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif

#include "driver.h"
#include "sync.h"

#define SAM_SYNC_GROUPS_PER_CLUSTER	16

typedef struct {
  atomic_t usageCount, notReadyCount;
  atomic_t usageMap[SAM_MAX_CARDS_COUNT][SamSyncDeviceSentinel];
} SyncGroup;

typedef struct SyncCluster {
  SyncGroup groups[SAM_SYNC_GROUPS_PER_CLUSTER];
  struct SyncCluster *next;
} SyncCluster;

static SyncCluster *syncClusters;
static SAM_DECLARE_MUTEX(accessLock);

static SyncGroup *findSyncGroup(int syncHandle)
{
  SyncCluster *cluster;
  int handle;

  if(syncHandle<0)
    return NULL;

  handle=syncHandle;
  for(cluster=syncClusters;
      cluster && handle>=SAM_SYNC_GROUPS_PER_CLUSTER;
      cluster=cluster->next)
    handle-=SAM_SYNC_GROUPS_PER_CLUSTER;

  if(!cluster)
    return NULL;

  return cluster->groups+handle;
}

static void decNotReadyCount(SyncGroup *syncGroup)
{
  int cardIdx;
  SamCard *card;
  atomic_t *usageMap;

  if(atomic_dec_and_test(&syncGroup->notReadyCount)) {
    for(cardIdx=0; cardIdx<samCardsCount; cardIdx++) {
      card=samCards[cardIdx];
      if(!card)
	continue;

      usageMap=syncGroup->usageMap[cardIdx];

      if(SAM_ATOMIC_READ(&usageMap[SamSyncDeviceAudio]))
	card->checkChannelStates=1;
      if(SAM_ATOMIC_READ(&usageMap[SamSyncDeviceSeq]))
	card->seq.checkPlayback=1;
      if(SAM_ATOMIC_READ(&usageMap[SamSyncDeviceMod]))
	card->mod.checkPlayback=1;
      samFeedThreadInfo.haveJobs=1;
      wake_up(&samFeedThreadInfo.feedSam);
    }
  }
}

int samSyncJoin(int *syncHandleP, int cardIdx, SamSyncDevice syncDevice)
{
  SyncCluster *cluster, *lastCluster;
  SyncGroup *syncGroup;
  int handle, i;

  down(&accessLock);

  if(*syncHandleP<0) {
    /* create a new sync group */

    handle=0;
    lastCluster=NULL;
    for(cluster=syncClusters; cluster; cluster=cluster->next) {
      lastCluster=cluster;
      for(i=0; i<SAM_SYNC_GROUPS_PER_CLUSTER; i++) {
	if(SAM_ATOMIC_READ(&cluster->groups[i].usageCount)==0) {
	  *syncHandleP=handle;
	  break;
	}
	handle++;
      }
      if(*syncHandleP>=0)
	break;
    }

    if(*syncHandleP<0) {
      /* no unallocated syncGroup available */
      cluster=kmalloc(sizeof(SyncCluster), GFP_KERNEL);
      if(!cluster) {
	up(&accessLock);
	return -ENOMEM;
      }
      memset(cluster, 0, sizeof(SyncCluster));
      if(lastCluster)
	lastCluster->next=cluster;
      else
	syncClusters=cluster;
      *syncHandleP=handle;
      syncGroup=cluster->groups+handle%SAM_SYNC_GROUPS_PER_CLUSTER;
    } else
      syncGroup=cluster->groups+*syncHandleP%SAM_SYNC_GROUPS_PER_CLUSTER;
    SAM_ATOMIC_SET(&syncGroup->notReadyCount, 0);
  } else {
    /* use an existing sync group */
    syncGroup=findSyncGroup(*syncHandleP);
    if(!syncGroup) {
      up(&accessLock);
      return -EINVAL;
    }
    if(SAM_ATOMIC_READ(&syncGroup->usageCount)==0) {
      up(&accessLock);
      return -EINVAL;
    }
    if(SAM_ATOMIC_READ(&syncGroup->notReadyCount)==0) {
      /* too late, it's playing already */
      up(&accessLock);
      return -EBUSY;
    }
  }

  atomic_inc(&syncGroup->usageCount);
  atomic_inc(&syncGroup->notReadyCount);
  atomic_inc(&syncGroup->usageMap[cardIdx][syncDevice]);

  up(&accessLock);

  return 0;
}

void samSyncLeave(int syncHandle, int cardIdx, SamSyncDevice syncDevice, int started)
{
  SyncGroup *syncGroup;

  if(!(syncGroup=findSyncGroup(syncHandle)))
    panic("sam9407: sync group consistency is screwed up");

  atomic_dec(&syncGroup->usageMap[cardIdx][syncDevice]);
  if(!started)
    decNotReadyCount(syncGroup);
  atomic_dec(&syncGroup->usageCount);
}

void samSyncStart(int syncHandle)
{
  SyncGroup *syncGroup;

  if(!(syncGroup=findSyncGroup(syncHandle)))
    panic("sam9407: sync group consistency is screwed up");

  decNotReadyCount(syncGroup);
}

int samSyncReady(int syncHandle)
{
  SyncGroup *syncGroup;

  if(!(syncGroup=findSyncGroup(syncHandle)))
    panic("sam9407: sync group consistency is screwed up");

  return SAM_ATOMIC_READ(&syncGroup->notReadyCount)==0;
}

void samReleaseSyncGroups(void)
{
  SyncCluster *cluster, *cluster2;

  for(cluster=syncClusters; cluster; cluster=cluster2) {
    cluster2=cluster->next;
    kfree(cluster);
  }
}
