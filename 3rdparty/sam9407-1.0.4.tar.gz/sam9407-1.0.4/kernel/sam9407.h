/*
  SAM9407 specific ioctl's

  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  sam9407 is free software, covered by the GNU General Public License,
  and you are welcome to change it and/or distribute copies of it under
  certain conditions.

  There is absolutely no warranty for sam9407.
*/
  
#ifndef _SAM9407_H
#define _SAM9407_H

#ifdef __KERNEL__
#include <linux/ioctl.h>
#include <linux/time.h>
#else
#include <sys/ioctl.h>
#include <sys/time.h>
#endif

/* API versions per minor device.
 * Those will change when introducing
 * incompatibilities. Verify with the results
 * from the SAM_IOC_API_INFO ioctl
 */
#define SAM_MIXER_API_VERSION	0x11
#define SAM_AUDIO_API_VERSION	0x10
#define SAM_SEQ_API_VERSION	0x10
#define SAM_MOD_API_VERSION	0x10

#define SAM_NROF_SBANKS		8
#define SAM_SBANK_NAME_LEN	8

/***** ioctl's known across all devices *****/

/* SamApiClass defines which set of control
 * id's you need to take to talk with the installed
 * firmware by means of SAM_IOC_AUDIO_{GET,SET,INFO}
 * and SAM_IOC_MIXER_{GET,SET,INFO}
 */

typedef enum SamApiClass {
  SAM_API_CLASS_NONE,
  SAM_API_CLASS_VANILLA,
  SAM_API_CLASS_HOMSTDR,
} SamApiClass;

typedef struct SamApiInfo {
  unsigned version;
  SamApiClass apiClass;
} SamApiInfo;

typedef struct SamControl {
  unsigned char id, addr;
  char isConfigured;			/* only valid for GET */
  unsigned value;
} SamControl;

/* return version information and firmware class */
#define SAM_IOC_API_INFO		_IOR ('S', 0x00, SamApiInfo)

/* join or create a sync playback group */
#define SAM_IOC_SYNC_JOIN		_IOWR('S', 0x01, int)

/* leave currently active sync playback group */
#define SAM_IOC_SYNC_LEAVE		_IO  ('S', 0x02)

/* query currently active sync playback group */
#define SAM_IOC_SYNC_INFO		_IOR ('S', 0x03, int)

/***** /dev/audio ioctl's *****/

/* control id's for SamControl, apiClass VANILLA */
typedef enum SamAudioId {
  SAM_AUDIO_ID_SENTINEL,		/* used to mark end of vector */
  SAM_AUDIO_ID_VOLUME_LEFT,		/* PLAY */
  SAM_AUDIO_ID_VOLUME_RIGHT,		/* PLAY */
  SAM_AUDIO_ID_VOLUME_AUX_LEFT,		/* PLAY */
  SAM_AUDIO_ID_VOLUME_AUX_RIGHT,	/* PLAY */
  SAM_AUDIO_ID_FILT_FC,
  SAM_AUDIO_ID_FILT_Q,
  SAM_AUDIO_ID_MUTE,
  SAM_AUDIO_ID_REC_MODE,		/* RECORD */
  SAM_AUDIO_ID_REC_VOL,			/* RECORD */
  SAM_AUDIO_ID_LAST
} SamAudioId;

/* control id's for SamControl, apiClass HOMSTDR */
typedef enum SamAudioHomstdrId {
  SAM_AUDIO_HOMSTDR_ID_SENTINEL,	/* used to mark end of vector */
  SAM_AUDIO_HOMSTDR_ID_SRC_CFG,		/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTL,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTR,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARL,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARR,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REV,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_SRC_VOL_CHR,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_CFG,		/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_LB,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB1,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB2,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB3,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB4,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EQ_LEV_HB,	/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_EFF_CFG,		/* #1 PLAY */
  SAM_AUDIO_HOMSTDR_ID_REV_TYPE,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_REV_TIME,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_REV_FEED,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_REV_VOLF,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_REV_VOLR,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_TYPE,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_DEL,		/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_FEED,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_RATE,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_DEPTH,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_VOLF,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_CHR_VOLR,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_FILT_FC,
  SAM_AUDIO_HOMSTDR_ID_FILT_Q,
  SAM_AUDIO_HOMSTDR_ID_FILTER_ON,	/* PLAY */
  SAM_AUDIO_HOMSTDR_ID_REC_MODE,	/* RECORD */
  SAM_AUDIO_HOMSTDR_ID_REC_VOL,		/* RECORD */
  SAM_AUDIO_HOMSTDR_ID_DINREC_VOL,	/* #1 */
  SAM_AUDIO_HOMSTDR_ID_LAST
} SamAudioHomstdrId;

typedef enum SamAudioAddress {
  SAM_AUDIO_ADDR_LEFT,
  SAM_AUDIO_ADDR_RIGHT,
} SamAudioAddress;

typedef struct SamChannelNumbers {
  char play, record;
} SamChannelNumbers;

/* retrieve the play/record channel # */
#define SAM_IOC_CHANNEL_INFO		_IOR ('S', 0x80, SamChannelNumbers)

/* redirect the play/record channel */
#define SAM_IOC_CHANNEL_REDIRECT	_IOW ('S', 0x81, SamChannelNumbers)

/* retrieve audio control values */
#define SAM_IOC_AUDIO_GET		_IOWR('S', 0x82, SamControl)

/* set audio control values */
#define SAM_IOC_AUDIO_SET		_IOW ('S', 0x83, SamControl)

/* retrieve supported audio control options */
#define SAM_IOC_AUDIO_INFO		_IOWR('S', 0x84, SamControl)

/***** /dev/mod ioctl's *****/

typedef enum SamModEventType {
  SAM_MOD_EVENT_ECHO,			/* SamModEchoEvent */
  SAM_MOD_EVENT_WAIT_ABS,		/* SamModTimerEvent */
  SAM_MOD_EVENT_WAIT_REL,		/* SamModTimerEvent */
  SAM_MOD_EVENT_MEM,			/* SamModMemEvent */
  SAM_MOD_EVENT_OPEN,			/* SamModTriggerEvent */
  SAM_MOD_EVENT_CLOSE,			/* SamModTriggerEvent */
  SAM_MOD_EVENT_START,			/* SamModTriggerEvent */
  SAM_MOD_EVENT_STOP,			/* SamModTriggerEvent */
  SAM_MOD_EVENT_VOL,			/* SamModVolOutEvent */
  SAM_MOD_EVENT_MAIN,			/* SamModVolSendEvent */
  SAM_MOD_EVENT_AUX,			/* SamModVolSendEvent */
  SAM_MOD_EVENT_PITCH,			/* SamModPitchEvent */
  SAM_MOD_EVENT_FILT,			/* SamModFilterEvent */
  SAM_MOD_EVENT_LAST
} SamModEventType;

typedef enum SamModSampleType {
  SamModSample16Bit,
  SamModSample8BitLow,
  SamModSample8BitHigh,
} SamModSampleType;

typedef enum SamModLoopType {
  SamModLoopForward,
  SamModLoopReverse,
  SamModLoopReverseSignInvert,
} SamModLoopType;

typedef struct SamModEchoEvent {
  SamModEventType type;
  void *closure;
} SamModEchoEvent;

typedef struct SamModTimerEvent {
  SamModEventType type;
  struct timeval time;
} SamModTimerEvent;

typedef struct SamModMemEvent {
  SamModEventType type;
  unsigned char voice, handle;
  SamModSampleType sampleType;
  SamModLoopType loopType;
  unsigned start, loop, end;
} SamModMemEvent;

typedef struct SamModTriggerEvent {
  SamModEventType type;
  unsigned char voice;
} SamModTriggerEvent;

typedef struct SamModVolOutEvent {
  SamModEventType type;
  unsigned char voice;
  unsigned char volume;
} SamModVolOutEvent;

typedef struct SamModVolSendEvent {
  SamModEventType type;
  unsigned char voice;
  unsigned char left, right;
} SamModVolSendEvent;

typedef struct SamModPitchEvent {
  SamModEventType type;
  unsigned char voice;
  unsigned freq;
} SamModPitchEvent;

typedef struct SamModFilterEvent {
  SamModEventType type;
  unsigned char voice;
  unsigned char q, fc;
} SamModFilterEvent;

typedef union SamModEvent {
  SamModEventType type;
  SamModEchoEvent echo;
  SamModTimerEvent timer;
  SamModMemEvent mem;
  SamModTriggerEvent trigger;
  SamModVolOutEvent volOut;
  SamModVolSendEvent volSend;
  SamModPitchEvent pitch;
  SamModFilterEvent filter;
} SamModEvent;

typedef struct SamModMemInfo {
  unsigned memMod, memFree;
} SamModMemInfo;

typedef struct SamModSamples {
  unsigned char handle;
  unsigned short *data;
  unsigned size;
} SamModSamples;

typedef struct SamModPosition {
  unsigned char voice;
  unsigned offset;
} SamModPosition;

/* query memory information */
#define SAM_IOC_MOD_MEM_INFO		_IOR ('S', 0x80, SamModMemInfo)

/* reset and discard play/recording events */
#define SAM_IOC_MOD_RESET		_IO  ('S', 0x81)

/* post pending play events */
#define SAM_IOC_MOD_POST		_IO  ('S', 0x82)

/* get the timer started */
#define SAM_IOC_MOD_TIMER_START		_IO  ('S', 0x83)

/* stop the timer */
#define SAM_IOC_MOD_TIMER_STOP		_IO  ('S', 0x84)

/* upload samples */
#define SAM_IOC_MOD_SAMPLES_LOAD	_IOW ('S', 0x85, SamModSamples)

/* dispose samples */
#define SAM_IOC_MOD_SAMPLES_UNLOAD	_IOW ('S', 0x86, unsigned char)

/* return the number of currently available voices */
#define SAM_IOC_MOD_GET_VOICES		_IOR ('S', 0x87, unsigned char)

/* return the position of current reading */
#define SAM_IOC_MOD_GET_POS		_IOWR('S', 0x88, SamModPosition)

/* add an offset to current reading */
#define SAM_IOC_MOD_ADD_POS		_IOW ('S', 0x89, SamModPosition)

/* query the timer resolution */
#define SAM_IOC_MOD_CTRLRATE_INFO	_IOR ('S', 0x8A, unsigned)

/***** /dev/mixer ioctl's *****/

#define SAM_EVENT_TYPE_MIXER		-1
#define SAM_EVENT_TYPE_NOCTRL		-2

typedef enum SamEventId {
  SAM_EVENT_FIRMWARE_CHANGED,
  SAM_EVENT_SBANK_CHANGED,
  SAM_EVENT_CHANNEL_OWNER_CHANGED,
} SamEventId;

/* control id's for SamControl, apiClass VANILLA */
typedef enum SamMixerId {
  SAM_MIXER_ID_SENTINEL,		/* used to mark end of vector */
  SAM_MIXER_ID_MASTER_VOL,
  SAM_MIXER_ID_EQ_LBL,
  SAM_MIXER_ID_EQ_MLBL,
  SAM_MIXER_ID_EQ_MHBL,
  SAM_MIXER_ID_EQ_HBL,
  SAM_MIXER_ID_EQ_LBR,
  SAM_MIXER_ID_EQ_MLBR,
  SAM_MIXER_ID_EQ_MHBR,
  SAM_MIXER_ID_EQ_HBR,
  SAM_MIXER_ID_EQF_LB,
  SAM_MIXER_ID_EQF_MLB,
  SAM_MIXER_ID_EQF_MHB,
  SAM_MIXER_ID_EQF_HB,
  SAM_MIXER_ID_AUD_SEL,
  SAM_MIXER_ID_AUD_GAINL,
  SAM_MIXER_ID_AUD_GAINR,
  SAM_MIXER_ID_AUDCHR_SEND,
  SAM_MIXER_ID_GMREV_SEND,
  SAM_MIXER_ID_GMCHR_SEND,
  SAM_MIXER_ID_AUDREV_SEND,
  SAM_MIXER_ID_ECH_LEV,
  SAM_MIXER_ID_ECH_TIM,
  SAM_MIXER_ID_ECH_FEED,
  SAM_MIXER_ID_SUR_VOL,
  SAM_MIXER_ID_SUR_DEL,
  SAM_MIXER_ID_SUR_INP,
  SAM_MIXER_ID_SUR_24,
  SAM_MIXER_ID_AUDL_VOL,
  SAM_MIXER_ID_AUDR_VOL,
  SAM_MIXER_ID_AUDL_PAN,
  SAM_MIXER_ID_AUDR_PAN,
  SAM_MIXER_ID_GM_VOL,
  SAM_MIXER_ID_GM_PAN,
  SAM_MIXER_ID_REV_VOL,
  SAM_MIXER_ID_CHR_VOL,
  SAM_MIXER_ID_GM_POST,
  SAM_MIXER_ID_WAVE_POST,
  SAM_MIXER_ID_MOD_POST,
  SAM_MIXER_ID_AUDECH_POST,
  SAM_MIXER_ID_EFF_POST,
  SAM_MIXER_ID_REV_TYPE,
  SAM_MIXER_ID_CHR_TYPE,
  SAM_MIXER_ID_CHR_DEL,
  SAM_MIXER_ID_CHR_FEED,
  SAM_MIXER_ID_CHR_RATE,
  SAM_MIXER_ID_CHR_DEPTH,
  SAM_MIXER_ID_REV_TIME,
  SAM_MIXER_ID_REV_FEED,
  /* config messages: those will reset the firmware
   * and can be used only if sam9407 is not busy
   */
  SAM_MIXER_ID_REC_CFG,			/* RESET */
  SAM_MIXER_ID_AUD_ONOFF,		/* RESET */
  SAM_MIXER_ID_ECH_ONOFF,		/* RESET */
  SAM_MIXER_ID_REV_ONOFF,		/* RESET */
  SAM_MIXER_ID_CHR_ONOFF,		/* RESET */
  SAM_MIXER_ID_EQU_TYPE,		/* RESET */
  SAM_MIXER_ID_SUR_ONOFF,		/* RESET */
  SAM_MIXER_ID_WAVE_ASS,		/* RESET */
  SAM_MIXER_ID_MOD_ASS,			/* RESET */
  /* hardware related controls */
  SAM_MIXER_ID_SAMPLE_RATE,
  SAM_MIXER_ID_MASTER_MUTE,
  SAM_MIXER_ID_MINUS_6DB,
  SAM_MIXER_ID_LAST
} SamMixerId;

/* control id's for SamControl, apiClass HOMSTDR */
typedef enum SamMixerHomstdrId {
  SAM_MIXER_HOMSTDR_ID_SENTINEL,	/* used to mark end of vector */
  SAM_MIXER_HOMSTDR_ID_MASTER_VOL,
  /* hardware related controls */
  SAM_MIXER_HOMSTDR_ID_MASTER_MUTE,
  SAM_MIXER_HOMSTDR_ID_LAST
} SamMixerHomstdrId;

/* firmware independent hardware controls */
typedef enum SamMixerHWId {
  SAM_MIXER_HW_ID_FIRST=0x80,
  SAM_MIXER_HW_ID_AUDIO_INPUT=SAM_MIXER_HW_ID_FIRST,
  SAM_MIXER_HW_ID_AUDIO_OUTPUT,
  SAM_MIXER_HW_ID_MIDI_ROUTE,
  SAM_MIXER_HW_ID_EXTERNAL_CLOCK,
  SAM_MIXER_HW_ID_DIGITAL_INPUT,
  SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT,
  SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION,
  SAM_MIXER_HW_ID_DIGITAL_IN_RATE,
  SAM_MIXER_HW_ID_ANALOG_OUT_VOL,	/* #3 */
  SAM_MIXER_HW_ID_BOX_MIDI_IN,
  SAM_MIXER_HW_ID_BOX_CHANNEL,		/* #3 */
  SAM_MIXER_HW_ID_LAST
} SamMixerHWId;

/* possible values for various SamMixerId's */
typedef enum SamMixerAudioInput {
  SAM_MIXER_AUDIO_INPUT_DIGITAL,
  SAM_MIXER_AUDIO_INPUT_CODEC,
  SAM_MIXER_AUDIO_INPUT_MIC,
  SAM_MIXER_AUDIO_INPUT_LINE1,
  SAM_MIXER_AUDIO_INPUT_LINE2,
  SAM_MIXER_AUDIO_INPUT_SLAVE_DSP,
  SAM_MIXER_AUDIO_INPUT_MASTER_BUS,
  SAM_MIXER_AUDIO_INPUT_SLAVE_BUS,
} SamMixerAudioInput;

typedef enum SamMixerAudioOutput {
  SAM_MIXER_AUDIO_OUTPUT_EXTERNAL,
  SAM_MIXER_AUDIO_OUTPUT_MASTER_DSP,
} SamMixerAudioOutput;

typedef enum SamMixerMidiRoute {
  SAM_MIXER_MIDI_ROUTE_DREAM,
  SAM_MIXER_MIDI_ROUTE_CODEC,
} SamMixerMidiRoute;

typedef enum SamMixerDigitalInput {
  SAM_MIXER_DIGITAL_INPUT_OPTICAL,
  SAM_MIXER_DIGITAL_INPUT_COAX,
} SamMixerDigitalInput;

typedef enum SamMixerDigitalInputRate {
  SAM_MIXER_DIR_UNKNOWN,
  SAM_MIXER_DIR_48K_4PERCENT,
  SAM_MIXER_DIR_44K_4PERCENT,
  SAM_MIXER_DIR_32K_4PERCENT,
  SAM_MIXER_DIR_48K_400PPM,
  SAM_MIXER_DIR_44_1K_400PPM,
  SAM_MIXER_DIR_44_056K_400PPM,
  SAM_MIXER_DIR_32K_400PPM,
} SamMixerDigitalInputRate;

typedef struct SamEvent {
  char type;
  unsigned char id, addr;
} SamEvent;

typedef struct SamDriverVersion {
  unsigned char major, minor, tiny;
} SamDriverVersion;

typedef struct SamDriverInfo {
  SamDriverVersion driverVersion;
  char hardware[16];
  char firmware[16];
  unsigned char haveAudio, haveMidi, haveMod;
  unsigned memTotal, memFree, memSBanks, memMod, memAudio;
  unsigned playChannelsUsed, playChannelsTotal;
  unsigned recordChannelsUsed, recordChannelsTotal;
  unsigned peakMeterValues;
} SamDriverInfo;

typedef struct SamHardwareHints {
  unsigned cardMem;
} SamHardwareHints;

typedef struct SamFirmware {
  unsigned short *data;
  unsigned size;
} SamFirmware;

typedef struct SamRedirectedAudioControl {
  unsigned char channel;
  SamControl *controls;
} SamRedirectedAudioControl;

typedef struct SamChannelOwnerInfo {
  int *pids;
  unsigned size;
} SamChannelOwnerInfo;

typedef struct SamSoundBank {
  unsigned char id;
  char *data;
  unsigned size;
} SamSoundBank;

typedef struct SamSoundBankPrio {
  unsigned char id;
  unsigned short priority;
} SamSoundBankPrio;

typedef struct SamSoundBankInfo {
  char name[SAM_SBANK_NAME_LEN+1];
  unsigned short priority;
} SamSoundBankInfo;

typedef struct SamPeakMeterInfo {
  unsigned short *data;
  unsigned size;
} SamPeakMeterInfo;

typedef struct SamMMTInfo {
  char *data;
  unsigned size;
} SamMMTInfo;

/* retrieve driver information  */
#define SAM_IOC_DRIVER_INFO		_IOR ('S', 0x80, SamDriverInfo)

/* query hardware hints from the driver */
#define SAM_IOC_HW_HINTS_GET		_IOR ('S', 0x81, SamHardwareHints)

/* give some hardware hints to the driver */
#define SAM_IOC_HW_HINTS_SET		_IOW ('S', 0x82, SamHardwareHints)

/* upload firmware */
#define SAM_IOC_FIRMWARE_LOAD		_IOW ('S', 0x83, SamFirmware)

/* retrieve mixer control values */
#define SAM_IOC_MIXER_GET		_IOWR('S', 0x84, SamControl)

/* set mixer control values */
#define SAM_IOC_MIXER_SET		_IOW ('S', 0x85, SamControl)

/* retrieve supported mixer control options */
#define SAM_IOC_MIXER_INFO		_IOWR('S', 0x86, SamControl)

/* retrieve audio control values from mixer interface */
#define SAM_IOC_MIXER_AUDIO_GET		_IOWR('S', 0x87, SamRedirectedAudioControl)

/* set audio control values from mixer interface */
#define SAM_IOC_MIXER_AUDIO_SET		_IOW ('S', 0x88, SamRedirectedAudioControl)

/* retrieve supported mixer control options from mixer interface */
#define SAM_IOC_MIXER_AUDIO_INFO	_IOWR('S', 0x89, SamRedirectedAudioControl)

/* retrieve the pid of the process owning an /dev/audio channel */
#define SAM_IOC_CHANNEL_OWNER_INFO	_IOWR('S', 0x8A, SamChannelOwnerInfo)

/* upload a .94B file */
#define SAM_IOC_BANK_LOAD		_IOW ('S', 0x8B, SamSoundBank)

/* dispose a soundbank */
#define SAM_IOC_BANK_UNLOAD		_IOW ('S', 0x8C, unsigned char)

/* change soundbank priority */
#define SAM_IOC_BANK_PRIO_CHG		_IOW ('S', 0x8D, SamSoundBankPrio)

/* query soundbanks */
#define SAM_IOC_BANK_INFO		_IOR ('S', 0x8E, SamSoundBankInfo)

/* retrieve peak meter table */
#define SAM_IOC_PEAK_METER_INFO		_IOWR('S', 0x8F, SamPeakMeterInfo)

/* the following ioctl's are only available if the driver
 * has been compiled in debugging mode
 */

/* retrieve MMT */
#define SAM_IOC_DEBUG_MMT_INFO		_IOR ('S', 0xF0, SamMMTInfo)

#endif /* _SAM9407_H */
