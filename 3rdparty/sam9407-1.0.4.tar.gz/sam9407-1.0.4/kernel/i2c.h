#ifndef _I2C_H
#define _I2C_H

#include "driver.h"

int samI2CWrite(SamCard *card,
		int (*output)(SamCard *card, int sda, int scl),
		int (*input)(SamCard *card),
		int addr, char *buf, int count);

int samI2CRead(SamCard *card,
	       int (*output)(SamCard *card, int sda, int scl),
	       int (*input)(SamCard *card),
	       int addr, char *buf, int count);

#endif /* _I2C_H */
