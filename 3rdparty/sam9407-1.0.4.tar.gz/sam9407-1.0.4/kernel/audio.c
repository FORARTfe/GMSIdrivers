/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#include <linux/soundcard.h>

#define __KERNEL_SYSCALLS__
#include <linux/unistd.h>

#include "driver.h"
#include "io.h"
#include "alloc.h"
#include "seq.h"
#include "mod.h"
#include "mixer.h"
#include "sync.h"
#include "ulaw.h"
#include "audio.h"

#define SAM_PLAY_BUF_OVERHEAD	16
#define SAM_MIN_RATE		4000
#define SAM_MAX_RATE		48000
#define SAM_DEFAULT_RATE	44100
#define SAM_MIN_FRAME_SIZE	2
#define SAM_MAX_FRAME_SIZE	((32768-SAM_PLAY_BUF_OVERHEAD)>>1)
#define SAM_MIN_FRAME_TIME	2		/* msec */
#define SAM_MIN_FRAME_COUNT	1
#define SAM_MAX_FRAME_COUNT	32
#define SAM_MAX_DATA_SIZE	65536
#define SAM_SHUTDOWN_TIMEOUT	(5*HZ)

#define SAM_FORMAT_16BIT(format)\
				((format)==AFMT_S16_LE ||\
				 (format)==AFMT_S16_BE ||\
				 (format)==AFMT_U16_LE ||\
				 (format)==AFMT_U16_BE)

SamAudioFeedThreadInfo samFeedThreadInfo;

/* calculate words needed for one frame */
static unsigned wordsNeeded(SamChannelInfo *chp)
{
  unsigned frameSize, time;

  if(!chp->frameSizeWantedBytes) {
    /* calculate words needed for 166 msec worth of sound
     * That will be a maximum frame size of 32016 words
     * for sampling rate 48000 in stereo
     */
    frameSize=chp->rate/6;
    if(chp->stereo)
      frameSize<<=1;
  } else
    frameSize=chp->frameSizeWantedBytes>>SAM_FORMAT_16BIT(chp->format);

  if(frameSize<SAM_MIN_FRAME_SIZE)
    frameSize=SAM_MIN_FRAME_SIZE;
  if(frameSize>SAM_MAX_FRAME_SIZE)
    frameSize=SAM_MAX_FRAME_SIZE;

  /* calculate the time one frame takes
   * to enfore a minimum frame length on it
   */
  time=(frameSize>>chp->stereo)*1000/chp->rate;
  if(time<SAM_MIN_FRAME_TIME)
    frameSize=((SAM_MIN_FRAME_TIME*chp->rate)/1000)<<chp->stereo;

  return frameSize;
}

static int allocBuffers(SamCard *card, int channel)
{
  SamChannelInfo *chp=card->channels+channel;
  int error;
  unsigned frameSize, size, magicOverhead;

  if(chp->data) /* already allocated */
    return 0;

  frameSize=wordsNeeded(chp);
  size=frameSize*chp->frameCount;
  chp->head=chp->count=0;
  chp->data=(short *)kmalloc(size<<1, GFP_KERNEL);

  if(!chp->data)
    return -ENOMEM;

  chp->frameSize=frameSize;
  chp->size=size;

  down(&card->usageCountLock);
  atomic_inc(&card->usageCount);
  up(&card->usageCountLock);
  if(card->firmwareInfo->mutexModRecAudio && channel>=card->firmwareInfo->playBackChannels)
    atomic_inc(&card->mod.recChannelsUsageCount);

  /* allocated twice the size needed in SAM9407
   * plus some magic overhead
   */
  magicOverhead=channel<card->firmwareInfo->playBackChannels ? SAM_PLAY_BUF_OVERHEAD : 0;
  if((error=samAlloc(card, (channel<<8)|SAM_MMT_ID_STR_WAVE, (chp->frameSize<<1)+magicOverhead, NULL,
		     SAM_ALIGN_EVEN, SAM_BOUNDARY_64K, NULL, NULL))<0) {
    chp->frameSize=chp->size=0;
    kfree(chp->data);
    chp->data=NULL;
    atomic_dec(&card->usageCount);
    return error;
  }

  return 0;
}

/* release both kernel and SAM9407 buffers */
static int releaseBuffers(SamCard *card, int channel)
{
  SamChannelInfo *chp=card->channels+channel;
  int error;

  if(!chp->data) /* already released */
    return 0;

  if(SAM_ATOMIC_READ(&chp->keepBuffersUsageCount))
    return -EBUSY;

  chp->counter.finishedBytes+=chp->count<<SAM_FORMAT_16BIT(chp->format);

  chp->head=chp->count=0;
  chp->frameSize=chp->size=0;
  kfree(chp->data);
  chp->data=NULL;
  error=samFree(card, (channel<<8)|SAM_MMT_ID_STR_WAVE, ~SAM_MMT_ROM_MASK);

  if(card->firmwareInfo->mutexModRecAudio && channel>=card->firmwareInfo->playBackChannels)
    atomic_dec(&card->mod.recChannelsUsageCount);
  atomic_dec(&card->usageCount);

  return error;
}

static void newCounterFrame(SamChannelInfo *chp, int recording, int count)
{
  SamAudioFrameCounter *newFrame, *oldFrame;

  /* playback requires 2 counter frames,
   * while recording can do with just one
   */
  if(!recording) {
    oldFrame=chp->counter.frames+chp->counter.frameIdx;
    newFrame=chp->counter.frames+!chp->counter.frameIdx;
  } else
    oldFrame=newFrame=chp->counter.frames;

  if(newFrame->used && newFrame->bytes) {
    chp->counter.finishedBytes+=newFrame->bytes;
    chp->counter.transitions++;
  }

  if(count>=0) {
    /* channel still open */
    newFrame->bytes=count<<SAM_FORMAT_16BIT(chp->format);
    newFrame->startJiffies=jiffies;
    newFrame->first=!oldFrame->used;
    newFrame->used=1;
  } else {
    /* channel is closing,
     * create an unused frame
     */
    newFrame->bytes=0;
    newFrame->used=0;
  }

  if(!recording)
    chp->counter.frameIdx=!chp->counter.frameIdx;
}

/* calculate the pointer in output/input
 * stream, based on the current time
 */
static unsigned calculateCounterPtr(SamChannelInfo *chp, int recording)
{
  SamAudioFrameCounter *frame;
  int intervalTime, deltaTime, bytes, max;

  /* playback requires 2 counter frames,
   * while recording can do with just one
   */
  if(!recording)
    frame=chp->counter.frames+!chp->counter.frameIdx;
  else
    frame=chp->counter.frames;

  if(!frame->used)
    return 0;

  intervalTime=HZ*chp->frameSize/chp->rate>>chp->stereo;
  deltaTime=jiffies-frame->startJiffies;
  /* for playback, starting with the second frame,
   * we're one interval behind
   */
  if(!recording && !frame->first)
    deltaTime-=intervalTime;
  if(deltaTime<0)
    deltaTime=0;

  bytes=(chp->rate<<(SAM_FORMAT_16BIT(chp->format)+chp->stereo))*deltaTime/HZ;
  max=frame->bytes;

  if(bytes>>SAM_FORMAT_16BIT(chp->format)>=chp->frameSize<<2) {
    /* if bytecount exceeds frame buffer size by 4 times
     * we can safely assume that data has reached it's destination
     * and append 2 unused frames
     */
    newCounterFrame(chp, recording, -1);
    newCounterFrame(chp, recording, -1);
  }

  return bytes<max ? bytes : max;
}

static __inline__ void syncLeave(SamCard *card, int channel)
{
  SamChannelInfo *chp=card->channels+channel;

  if(chp->syncGroup>=0) {
    samSyncLeave(chp->syncGroup, card->cardIdx, SamSyncDeviceAudio, chp->syncStarted);
    chp->syncGroup=-1;
  }
}

static int openChannel(SamCard *card, int channel)
{
  SamChannelInfo *chp=card->channels+channel;
  int error;
  unsigned char format;

  if(chp->state!=SamChannelStateClosed && chp->state!=SamChannelStateClosing)
    return 0;

  if(!chp->waitForTrigger && chp->syncGroup<0) {
    /* if we only have space for one audio frame
     * start by sending an empty frame first
     * to give write(2) system call some time
     * to fill up buffers
     */
    chp->justOpened=chp->size<chp->frameSize<<1;
  } else
    chp->justOpened=0;

  if(chp->stereo)
    format=0x02;
  else
    format=0x00;

  if(card->firmwareInfo->openAck || chp->waitForTrigger || chp->syncGroup>=0) {
    /* suspend sending W_START */
    chp->state=card->firmwareInfo->openAck ? SamChannelStateNotStarted : SamChannelStateSendStart;
    error=samTalk(card,
		  SamSendCtrl, 5, SAM_CMD_W_OPEN, channel, format, chp->rate, chp->rate>>8,
		  SamEndOfScript);
    if(!card->firmwareInfo->openAck) {
      /* if no open acknowledgement is expected,
       * wakeup audio feed thread, so sound output gets going
       */
      card->checkChannelStates=1;
      samFeedThreadInfo.haveJobs=1;
      wake_up(&samFeedThreadInfo.feedSam);
    }
  } else {
    /* channel is ready for output */
    chp->state=SamChannelStateOpen;
    error=samTalk(card,
		  SamSendCtrl, 5, SAM_CMD_W_OPEN, channel, format, chp->rate, chp->rate>>8,
		  SamSendCtrl, 2, SAM_CMD_W_START, channel,
		  SamEndOfScript);
  }

  if(error>=0 && channel>=card->firmwareInfo->playBackChannels)
    newCounterFrame(chp, 1, chp->frameSize);

  if(error>=0)
    error=samSendRememberedAudioCtrls(card, channel);

  return error;
}

static void initializeChannel(SamCard *card, int channel, SoundMinorDevice minor, int owner)
{
  SamChannelInfo *chp=card->channels+channel;
  int maxCtrlId, i;
  SamFWCtrlVendorInfo *ctrlInfo;

  chp->inUse=1;
#ifndef SAM_IGNORE_REC_OVERFLOW
  chp->recOverflow=0;
#endif
  chp->owner=owner;
  down(&card->mixer.accessLock);
  card->mixer.channelOwnerDirty=~0;
  up(&card->mixer.accessLock);

  SAM_ATOMIC_SET(&chp->keepBuffersUsageCount, 0);

  switch(minor) {
  case SoundMinorAudio:
    chp->format=AFMT_MU_LAW;
    chp->rate=8000;
    chp->stereo=0;
    break;
  default:
    chp->format=AFMT_S16_LE;
    chp->rate=SAM_DEFAULT_RATE;
    chp->stereo=1;
  }
  chp->frameSizeWantedBytes=0;
  chp->frameCount=2;

  memset(&chp->ctrlValues, 0, sizeof(chp->ctrlValues));
  if(card->firmwareInfo->initAudioCtrlValues)
    (*card->firmwareInfo->initAudioCtrlValues)(chp);

  /* set dirty flags on remembered control values
   * stored at chp->ctrlValues
   */
  down(&card->mixer.accessLock);
  maxCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
  for(i=0; i<maxCtrlId; i++) {
    ctrlInfo=card->firmwareInfo->audioCtrlInfo+i;
    if(ctrlInfo->type!=SamCtrlTypeUnsupported &&
       (ctrlInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE)
      memset(chp->dirtyFlags+ctrlInfo->dirtyAddr, ~0, (ctrlInfo->addrTagLimit+1)*sizeof(SamDirtyFlag));
  }
  wake_up(&card->mixer.waitDirty);
  up(&card->mixer.accessLock);

  memset(&chp->counter, 0, sizeof(chp->counter));
}

static int releaseChannel(SamCard *card, int channel, int ignoreError)
{
  SamChannelInfo *chp=card->channels+channel;
  int error;

  if(chp->waitForTrigger) {
    chp->waitForTrigger=0;
    card->checkChannelStates=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  }

  syncLeave(card, channel);

  if(chp->state==SamChannelStateClosed || chp->state==SamChannelStateClosing) {
    /* release channel if it's not open anymore */
    if((error=releaseBuffers(card, channel))<0) {
      if(ignoreError)
	printk(KERN_ERR "sam9407[#%d:%s]: can't release streaming wave buffer\n", card->cardIdx, card->hardwareInfo->name);
      else
	return error;
    }
  }

  chp->inUse=0;

  down(&card->mixer.accessLock);
  card->mixer.channelOwnerDirty=~0;
  wake_up(&card->mixer.waitDirty);
  up(&card->mixer.accessLock);

  return 0;
}

static int redirectChannel(SamCard *card, char *closure, SoundMinorDevice minor, int newChannel)
{
  int oldChannel=*closure;
  int error, owner;
  SamChannelInfo *chpOld, *chpNew;

  if(oldChannel==newChannel)
    return 0;

  /* sanity checks */
  if(oldChannel>=card->firmwareInfo->playBackChannels) {
    /* recording channel */
    if(newChannel<card->firmwareInfo->playBackChannels ||
       newChannel>=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels)
      return -EINVAL;
  } else {
    /* playback channel */
    if(newChannel>=card->firmwareInfo->playBackChannels)
      return -EINVAL;
  }

  chpOld=card->channels+oldChannel;
  down(&chpOld->accessLock);
  owner=chpOld->owner;
  if((error=releaseChannel(card, oldChannel, 0))<0) {
    up(&chpOld->accessLock);
    return error;
  }

  chpNew=card->channels+newChannel;
  down(&chpNew->accessLock);
  if(chpNew->inUse || chpNew->state!=SamChannelStateClosed) {
    up(&chpNew->accessLock);
    up(&chpOld->accessLock);
    return -EBUSY;
  }

  initializeChannel(card, newChannel, minor, owner);

  *closure=newChannel;

  up(&chpNew->accessLock);
  up(&chpOld->accessLock);

  return 0;
}

/* All audio streaming is done in a separate
 * thread, so we're able to close channels
 * when receiving an asynchronous notification
 * with no caller thread waiting
 */
static int audioFeedThread(void *arg)
{
  SamWaitQueue wait;
  SamCard *card;
  SamChannelInfo *chp;
  unsigned ofs;
  int error, cardIdx, channel, channels, oddCount;

#if LINUX_VERSION_CODE>=0x20200
  exit_mm(current);
  exit_files(current);
  exit_fs(current);
#if LINUX_VERSION_CODE>=0x20400
  daemonize();
#endif
#else /* Linux 2.0 */
  if(current->mm)
    current->mm->arg_end=current->mm->arg_start;
#endif

  current->session=1;
  current->pgrp=1;
  strcpy(current->comm, "sam9407d");

  /* audio streaming works more smoothly
   * with real time priority
   */
  current->policy=SCHED_RR;
  current->rt_priority=SAM_RT_PRIORITY;

#if LINUX_VERSION_CODE>=0x20200
    spin_lock_irq(&current->sigmask_lock);
    sigfillset(&current->blocked); /* block all signals */
    recalc_sigpending(current);
    spin_unlock_irq(&current->sigmask_lock);
#else /* Linux 2.0 */
    current->blocked=~0;
#endif

  for(;;) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &samFeedThreadInfo.feedSam, &wait);
    if(!samFeedThreadInfo.haveJobs)
      samSleepOn(&samFeedThreadInfo.feedSam, &wait);
    else
      samCancelSleepOn(&samFeedThreadInfo.feedSam, &wait);
    samFeedThreadInfo.haveJobs=0;

    if(samFeedThreadInfo.shutdown)
      break;

    for(cardIdx=0; cardIdx<samCardsCount; cardIdx++) {
      card=samCards[cardIdx];
      if(!card)
	continue;

      down(&card->usageCountLock);
      if(!card->firmwareLoaded) {
	up(&card->usageCountLock);
	continue;
      }
      atomic_inc(&card->usageCount);
      up(&card->usageCountLock);

      if(card->checkChannelStates) {
	card->checkChannelStates=0;

	channels=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;

	for(channel=0; channel<channels; channel++) {
	  chp=card->channels+channel;
	  if(chp->state==SamChannelStateSendStart || \
	     chp->state==SamChannelStateUnderflow || \
	     chp->state==SamChannelStateOverflow) {

	    down(&chp->accessLock);
	    switch(chp->state) {

	    case SamChannelStateSendStart:
	      if(!chp->waitForTrigger) {
		if(chp->syncGroup>=0 && !chp->syncStarted) {
		  samSyncStart(chp->syncGroup);
		  chp->syncStarted=1;
		}

		if(chp->syncGroup<0 || samSyncReady(chp->syncGroup)) {
		  chp->state=SamChannelStateOpen;
		  error=samTalkPickLock(card,
					SamSendCtrl, 2, SAM_CMD_W_START, channel,
					SamEndOfScript);
		  if(error<0)
		    printk(KERN_ERR "sam9407[#%d:%s]: error starting audio channel\n", card->cardIdx, card->hardwareInfo->name);
		}
	      }
	      break;

	    case SamChannelStateUnderflow:
	      if(chp->justOpened) {
		/* start by filling up half stream
		 * to give write(2) system call some time
		 * to fill up buffers
		 */
		newCounterFrame(chp, 0, 0);

		chp->state=SamChannelStateOpen;
		error=samTalkPickLock(card,
				      SamBurstWriteConst, 0, chp->frameSize,
				      SamSendCtrl, 2, SAM_CMD_END_XFER, channel,
				      SamEndOfScript);
		if(error<0)
		  printk(KERN_ERR "sam9407[#%d:%s]: error writing to audio channel\n", card->cardIdx, card->hardwareInfo->name);

		chp->justOpened=0;
	      } else {
		/* check if last received left channel value
		 * doesn't have a right channel counterpart
		 * so we can start the new frame with an odd
		 * number of values to avoid channel switching
		 */
		oddCount=chp->stereo && chp->count<chp->frameSize && (chp->count&1);
		if(oddCount)
		  chp->count&=~1;

		if(chp->count || (chp->syncGroup>=0 && !chp->closing)) {
		  newCounterFrame(chp, 0, SAM_MIN(chp->count, chp->frameSize));

		  /* fill up missing data with zeroes */
		  if(chp->count<chp->frameSize) {
		    memset(chp->data+chp->head+chp->count, 0, (chp->frameSize-chp->count)<<1);
		    /* in sync mode, skip the same amount of samples
		     * we've been missing here to keep playback in sync
		     */
		    if(chp->syncGroup>=0)
		      chp->syncSkipCount+=chp->frameSize-chp->count;
		  }

		  chp->state=SamChannelStateOpen;
		  error=samTalkPickLock(card,
					SamBurstWrite, chp->data+chp->head, chp->frameSize,
					SamSendCtrl, 2, SAM_CMD_END_XFER, channel,
					SamEndOfScript);
		  if(error<0)
		    printk(KERN_ERR "sam9407[#%d:%s]: error writing to audio channel\n", card->cardIdx, card->hardwareInfo->name);
		} else {
		  /* no data, close channel */
		  newCounterFrame(chp, 0, -1);

		  chp->state=SamChannelStateClosing;
		  error=samTalkPickLock(card,
					SamBurstWriteConst, 0, chp->frameSize,
					SamSendCtrl, 2, SAM_CMD_END_XFER, channel,
					SamSendCtrl, 2, SAM_CMD_W_CLOSE, channel,
					SamEndOfScript);
		  if(error<0)
		    printk(KERN_ERR "sam9407[#%d:%s]: can't close audio channel\n", card->cardIdx, card->hardwareInfo->name);

		  if(!chp->inUse)
		    /* not even in use anymore, release the channel */
		    if(releaseBuffers(card, channel)<0)
		      printk(KERN_ERR "sam9407[#%d:%s]: can't release streaming wave buffer\n", card->cardIdx, card->hardwareInfo->name);
		}

		if(chp->count>chp->frameSize) {
		  chp->count-=chp->frameSize;
		  chp->head+=chp->frameSize;
		  if(chp->head>=chp->size)
		    chp->head-=chp->size;
		} else if(oddCount) {
		  /* put odd left channel value to the front */
		  chp->data[0]=0;
		  chp->count=1;
		  chp->head=0;
		} else
		  chp->head=chp->count=0;
		wake_up(&chp->feedMe);
	      }
	      break;

	    case SamChannelStateOverflow:
	      if(chp->frameSize && chp->count+chp->frameSize<=chp->size) {
		newCounterFrame(chp, 1, chp->frameSize);

		ofs=chp->head+chp->count;
		if(ofs>=chp->size)
		  ofs-=chp->size;

		chp->state=SamChannelStateOpen;
		error=samTalkPickLock(card,
				      SamBurstRead, chp->data+ofs, chp->frameSize,
				      SamSendCtrl, 2, SAM_CMD_END_XFER, channel,
				      SamEndOfScript);
		if(error<0)
		  printk(KERN_ERR "sam9407[#%d:%s]: error reading from audio channel\n", card->cardIdx, card->hardwareInfo->name);

		chp->count+=chp->frameSize;
		wake_up(&chp->feedMe);
	      } else {
		/* no room to store data, close channel */
		newCounterFrame(chp, 1, -1);

		if(!card->firmwareInfo->closeAckRecChannel) {
		  chp->state=SamChannelStateClosed;
		  wake_up(&chp->waitClosed);
		} else
		  chp->state=SamChannelStateClosing;
		error=samTalkPickLock(card,
				      SamSendCtrl, 2, SAM_CMD_END_XFER, channel,
				      SamSendCtrl, 2, SAM_CMD_W_CLOSE, channel,
				      SamEndOfScript);
		if(error<0)
		  printk(KERN_ERR "sam9407[#%d:%s]: can't close audio channel\n", card->cardIdx, card->hardwareInfo->name);

		if(chp->inUse) {
#ifndef SAM_IGNORE_REC_OVERFLOW
		  /* signal error condition to user process */
		  chp->recOverflow=1;
		  wake_up(&chp->feedMe);
#endif
		} else {
		  /* not even in use anymore, release the channel */
		  if(releaseBuffers(card, channel)<0)
		    printk(KERN_ERR "sam9407[#%d:%s]: can't release streaming wave buffer\n", card->cardIdx, card->hardwareInfo->name);
		}
	      }
	      break;
	    default: /* make compiler happy */
	    }

	    up(&chp->accessLock);
	  }
	}
      }

      /* audioFeedThread is shared with the sequencer and mod device
       * to implement asynchronous playback of events
       */
      if(card->seq.checkPlayback) {
	card->seq.checkPlayback=0;
	samCheckPlaybackSeq(card);
      }

      if(card->mod.checkPlayback) {
	card->mod.checkPlayback=0;
	samCheckPlaybackMod(card);
      }

      atomic_dec(&card->usageCount);
    }
  }
  samFeedThreadInfo.shutdown=0;
  return 0;
}

int samStartFeedThread(void)
{
  int error;

  /* start audio streaming thread */
  if((error=kernel_thread(audioFeedThread, NULL, 0))<0) {
    printk(KERN_ERR "sam9407: can't fork off audio streaming thread.\n");
    return error;
  }

  return 0;
}

void samKillFeedThread(void)
{
  unsigned long start;

  samFeedThreadInfo.shutdown=1;
  start=jiffies;
  while(samFeedThreadInfo.shutdown && jiffies-start<SAM_SHUTDOWN_TIMEOUT) {
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
#if LINUX_VERSION_CODE>=0x20200
    if(current->need_resched)
      schedule();
#else /* Linux 2.0 */
    if(need_resched)
      schedule();
#endif /* Linux 2.0 */
  }
  if(samFeedThreadInfo.shutdown)
    panic("sam9407: oops, can't kill audio streaming thread.\n");
}

int samAllocateChannels(SamCard *card)
{
  int size, nChannels, channel;
  SamChannelInfo *channels, *chp;
  SamDirtyFlag *dirtyFlags;

  nChannels=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
  size=nChannels*(sizeof(SamChannelInfo)+card->firmwareInfo->audioDirty.n*sizeof(SamDirtyFlag));

  channels=(SamChannelInfo *)kmalloc(size, GFP_KERNEL);
  if(!channels)
    return -ENOMEM;

  memset(channels, 0, size);
  dirtyFlags=(SamDirtyFlag *)(channels+nChannels);
  chp=channels;
  for(channel=0; channel<nChannels; channel++) {
    SAM_INIT_MUTEX(&chp->accessLock);
    SAM_INIT_WAITQUEUE_HEAD(&chp->feedMe);
    SAM_INIT_WAITQUEUE_HEAD(&chp->waitClosed);
    chp->syncGroup=-1;
    chp->dirtyFlags=dirtyFlags;
    dirtyFlags+=card->firmwareInfo->audioDirty.n;
    chp++;
  }

  card->channels=channels;

  return 0;
}

void samReleaseChannels(SamCard *card)
{
  int nChannels, channel;
  SamChannelInfo *channels;

  if(!(channels=card->channels))
    return;

  card->channels=NULL;

  /* release any pending audio buffers,
   * as we know nobody is working on them anymore
   */
  nChannels=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
  for(channel=0; channel<nChannels; channel++)
    if(channels[channel].data)
      kfree(channels[channel].data);

  kfree(channels);
}

void samAudioNotification(SamCard *card, unsigned v)
{
  unsigned flags;
  int nChannels;

  SAM_BEGIN_CRITICAL(&card->firmwareAccessSpinLock, flags);
  if(!card->firmwareLoaded) {
    SAM_END_CRITICAL(&card->firmwareAccessSpinLock, flags);
    return;
  }
  nChannels=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
  if(v<card->firmwareInfo->playBackChannels) {
    card->channels[v].state=SamChannelStateUnderflow;
    card->checkChannelStates=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  } else if(v>=card->firmwareInfo->playBackChannels && v<nChannels) {
    card->channels[v].state=SamChannelStateOverflow;
    card->checkChannelStates=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  } else if(card->firmwareInfo->openAck && v>=card->firmwareInfo->openAck && v<card->firmwareInfo->openAck+nChannels) {
    card->channels[v-card->firmwareInfo->openAck].state=SamChannelStateSendStart;
    card->checkChannelStates=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  } else if(v>=card->firmwareInfo->closeAck && v<card->firmwareInfo->closeAck+nChannels) {
    card->channels[v-card->firmwareInfo->closeAck].state=SamChannelStateClosed;
    wake_up(&card->channels[v-card->firmwareInfo->closeAck].waitClosed);
  }
  SAM_END_CRITICAL(&card->firmwareAccessSpinLock, flags);
}

int samOpenAudio(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  SamChannelInfo *chp;
  int channel, start, end;

  if(!card->firmwareInfo->haveAudio)
    return -ENOPKG;

  if(card->firmwareInfo->mutexModRecAudio && (mode&SAM_MODE_READ_MASK)) {
    down(&card->mod.accessLock);
    if(card->mod.inUse) {
      up(&card->mod.accessLock);
      return -EBUSY;
    }
    atomic_inc(&card->mod.recChannelsUsageCount);
    up(&card->mod.accessLock);
  }

  if(mode&SAM_MODE_READ_MASK) {
    start=card->firmwareInfo->playBackChannels;
    end=start+card->firmwareInfo->recordChannels;
  } else {
    start=0;
    end=card->firmwareInfo->playBackChannels;
  }

  /* check for a free channel */
  for(channel=start; channel<end; channel++) {
    chp=card->channels+channel;
    down(&chp->accessLock);
    if(!chp->inUse && chp->state==SamChannelStateClosed) {
      initializeChannel(card, channel, SAM_MINOR_DEVICE(inode), current->pid);
      *closure=channel;
      up(&chp->accessLock);
      break;
    }
    up(&chp->accessLock);
  }

  if(channel>=end) {
    if(card->firmwareInfo->mutexModRecAudio && channel>=card->firmwareInfo->playBackChannels)
      atomic_dec(&card->mod.recChannelsUsageCount);
    return -EBUSY;
  }

  atomic_inc(&card->fastPollRequests);

  return 0;
}

void samReleaseAudio(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  SamWaitQueue wait;

  chp->closing=1;
  if(mode&SAM_MODE_WRITE_MASK) {
    /* make sure channel is open
     * so any pending data will eventually be flushed
     */
    down(&chp->accessLock);
    if(chp->count &&
       openChannel(card, channel)<0)
      printk(KERN_ERR "sam9407[#%d:%s]: can't open audio channel\n", card->cardIdx, card->hardwareInfo->name);
    up(&chp->accessLock);
  }

  for(;;) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &chp->waitClosed, &wait);
    if(chp->state==SamChannelStateClosed) {
      samCancelSleepOn(&chp->waitClosed, &wait);
      break;
    }
    samSleepOn(&chp->waitClosed, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      break;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      break;
#endif /* Linux 2.0 */
  }
  chp->closing=0;

  atomic_dec(&card->fastPollRequests);

  down(&chp->accessLock);
  releaseChannel(card, channel, 1);
  up(&chp->accessLock);

  if(card->firmwareInfo->mutexModRecAudio && channel>=card->firmwareInfo->playBackChannels)
    atomic_dec(&card->mod.recChannelsUsageCount);
}

int samReadAudio(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  SamWaitQueue wait;
  short *sp;
  char *cp;
  int error, efault, avail, n, i;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  cp=(char *)buf;
  n=count;

  down(&chp->accessLock);

  if(SAM_FORMAT_16BIT(chp->format) && n==1) {
    up(&chp->accessLock);
    return -EINVAL;
  }

  /* allocate buffers and open recording channel
   */
  if((error=allocBuffers(card, channel))<0 ||
     (error=openChannel(card, channel))<0) {
    up(&chp->accessLock);
    return error;
  }

  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     !chp->recOverflow &&
#endif
     chp->count==0 &&
     ((file->f_flags & O_NONBLOCK) ||
      chp->waitForTrigger)) {
    up(&chp->accessLock);
    return -EAGAIN;
  }

  /* wait for incoming data */
  while(
#ifndef SAM_IGNORE_REC_OVERFLOW
	!chp->recOverflow &&
#endif
	chp->count==0) {
    atomic_inc(&chp->keepBuffersUsageCount);
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &chp->feedMe, &wait);
    up(&chp->accessLock);
    samSleepOn(&chp->feedMe, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current)) {
      atomic_dec(&chp->keepBuffersUsageCount);
      return -ERESTARTSYS;
    }
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked) {
      atomic_dec(&chp->keepBuffersUsageCount);
      return -ERESTARTSYS;
    }
#endif /* Linux 2.0 */
    down(&chp->accessLock);
    atomic_dec(&chp->keepBuffersUsageCount);
  }

#ifndef SAM_IGNORE_REC_OVERFLOW
  if(chp->recOverflow) {
    chp->recOverflow=0;
    chp->head=chp->count=0;
    up(&chp->accessLock);
    return -EIO;
  }
#endif

  for(;;) {
    /* convert the data */
    sp=chp->data+chp->head;
    avail=chp->count;
    if(chp->head+avail>chp->size)
      avail=chp->size-chp->head;

    if(SAM_FORMAT_16BIT(chp->format)) {
      if(avail>n>>1)
	avail=n>>1;
    } else {
      if(avail>n)
	avail=n;
    }

    if(avail==0)
      break;

    efault=0;
    switch(chp->format) {
    case AFMT_MU_LAW:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(samShort2Ulaw(SAM_LE16_TO_CPU(sp[i])), cp+i);
      break;
    case AFMT_A_LAW:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(samShort2Alaw(SAM_LE16_TO_CPU(sp[i])), cp+i);
      break;
    case AFMT_S8:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(((char *)(sp+i))[1], cp+i);
      break;
    case AFMT_U8:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(((char *)(sp+i))[1]+0x80, cp+i);
      break;
    case AFMT_U16_LE:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(sp[i])+0x8000),
			    (short *)cp+i);
      break;
    case AFMT_S16_BE:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(SAM_CPU_TO_BE16(SAM_LE16_TO_CPU(sp[i])),
			    (short *)cp+i);
      break;
    case AFMT_U16_BE:
      for(i=0; !efault && i<avail; i++)
	efault=SAM_PUT_USER(SAM_CPU_TO_BE16(SAM_LE16_TO_CPU(sp[i])+0x8000),
			    (short *)cp+i);
      break;
    default: /* AFMT_S16_LE, our native format */
      efault=SAM_MEMCPY_TOFS(cp, sp, avail<<1);
    }
    if(efault) {
      up(&chp->accessLock);
      return -EFAULT;
    }

    chp->count-=avail;
    chp->head+=avail;
    if(chp->head>=chp->size)
      chp->head-=chp->size;

    if(SAM_FORMAT_16BIT(chp->format)) {
      cp+=avail<<1;
      n-=avail<<1;
    } else {
      cp+=avail;
      n-=avail;
    }
  }

  up(&chp->accessLock);

  return cp-(char *)buf;
}

int samWriteAudio(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  SamWaitQueue wait;
  unsigned ofs;
  short *sp;
  char *cp;
  int error, efault, sigPending, avail, n, i, v;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_READ, buf, count))<0)
    return error;

  cp=(char *)buf;
  n=count;

  down(&chp->accessLock);

  if(SAM_FORMAT_16BIT(chp->format) && (n&1)) {
    up(&chp->accessLock);
    return -EINVAL;
  }

  while(n>0) {
    if(chp->syncGroup>=0 && chp->syncSkipCount>0) {
      /* in sync mode, skip samples we've been dumping
       * already in order to keep playback in sync
       */
      avail=n>>SAM_FORMAT_16BIT(chp->format);
      if(avail>chp->syncSkipCount)
	avail=chp->syncSkipCount;
      chp->syncSkipCount-=avail;
      cp+=avail<<SAM_FORMAT_16BIT(chp->format);
      n-=avail<<SAM_FORMAT_16BIT(chp->format);
      newCounterFrame(chp, 0, avail);
      if(n<=0)
	break;
    }

    if(chp->size && chp->count>=chp->size &&
       ((file->f_flags & O_NONBLOCK) ||
	chp->waitForTrigger)) {
      up(&chp->accessLock);
      return cp>(char *)buf ? cp-(char *)buf : -EAGAIN;
    }

    /* wait until pending request finished
     */
    while(chp->size && chp->count>=chp->size) {
      atomic_inc(&chp->keepBuffersUsageCount);
      samPrepareSleepOn(TASK_INTERRUPTIBLE, &chp->feedMe, &wait);
      up(&chp->accessLock);
      /* signal inode semaphore to give other
       * channels a chance to receive data as well
       */
      up(&inode->i_sem);
      samSleepOn(&chp->feedMe, &wait);
      down(&inode->i_sem);
#if LINUX_VERSION_CODE>=0x20200
      sigPending=signal_pending(current);
#else /* Linux 2.0 */
      sigPending=current->signal & ~current->blocked;
#endif /* Linux 2.0 */
      if(sigPending) {
	atomic_dec(&chp->keepBuffersUsageCount);
	return cp>(char *)buf ? cp-(char *)buf : -ERESTARTSYS;
      }
      down(&chp->accessLock);
      atomic_dec(&chp->keepBuffersUsageCount);
    }

    /* okay, the stage is ours
     * allocate buffers first
     */
    if((error=allocBuffers(card, channel))<0) {
      up(&chp->accessLock);
      return error;
    }

    /* convert the data */
    ofs=chp->head+chp->count;
    if(ofs>=chp->size)
      ofs-=chp->size;
    sp=chp->data+ofs;

    avail=chp->size-chp->count;
    if(ofs+avail>chp->size)
      avail=chp->size-ofs;

    if(SAM_FORMAT_16BIT(chp->format)) {
      if(avail>n>>1)
	avail=n>>1;
    } else {
      if(avail>n)
	avail=n;
    }

    efault=0;
    switch(chp->format) {
    case AFMT_MU_LAW:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(samUlaw2Short(v));
      }
      break;
    case AFMT_A_LAW:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(samAlaw2Short(v));
      }
      break;
    case AFMT_S8:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(v<<8);
      }
      break;
    case AFMT_U8:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16((v<<8)-0x8000);
      }
      break;
    case AFMT_U16_LE:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, (short *)cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(v)-0x8000);
      }
      break;
    case AFMT_S16_BE:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, (short *)cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(SAM_BE16_TO_CPU(v));
      }
      break;
    case AFMT_U16_BE:
      for(i=0; i<avail; i++) {
	if((efault=SAM_GET_USER(v, (short *)cp+i)))
	  break;
	sp[i]=SAM_CPU_TO_LE16(SAM_BE16_TO_CPU(v)-0x8000);
      }
      break;
    default: /* AFMT_S16_LE, our native format */
      efault=SAM_MEMCPY_FROMFS(sp, cp, avail<<1);
    }
    if(efault) {
      up(&chp->accessLock);
      return -EFAULT;
    }

    chp->count+=avail;
    if(SAM_FORMAT_16BIT(chp->format)) {
      cp+=avail<<1;
      n-=avail<<1;
    } else {
      cp+=avail;
      n-=avail;
    }

    /* start sound output if there's enough data for
     * two audio frames, provided we have space for them
     * or just one audio frame when using a small streaming buffer
     */
    if(chp->count>=SAM_MIN(chp->size, chp->frameSize<<1)) {
      if((error=openChannel(card, channel))<0) {
	up(&chp->accessLock);
	return error;
      }
    }
  }

  up(&chp->accessLock);

  return cp-(char *)buf;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollAudio(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  unsigned mask;

  down(&chp->accessLock);

  mask=0;
  if(mode & SAM_MODE_READ_MASK) {
    if(
#ifndef SAM_IGNORE_REC_OVERFLOW
       chp->recOverflow ||
#endif
       chp->count ||
       chp->state==SamChannelStateClosed || chp->state==SamChannelStateClosing)
      mask|= POLLIN | POLLRDNORM;
  } else {
    if(!chp->frameSize || chp->count<chp->size)
      mask|= POLLOUT | POLLWRNORM;
  }
  poll_wait(file, &chp->feedMe, wait);

  up(&chp->accessLock);

  return mask;
}
#else /* Linux 2.0 */
int samSelectAudio(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  int avail=0;

  down(&chp->accessLock);

  switch(type) {
  case SEL_IN:
    avail=
#ifndef SAM_IGNORE_REC_OVERFLOW
      chp->recOverflow ||
#endif
      chp->count ||
      chp->state==SamChannelStateClosed || chp->state==SamChannelStateClosing;
    break;
  case SEL_OUT:
    avail=(!chp->frameSize || chp->count<chp->size);
    break;
  }
  if(!avail)
    select_wait(&chp->feedMe, wait);

  up(&chp->accessLock);

  return avail;
}
#endif /* Linux 2.0 */

int samIoctlAudio(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr)
{
  int channel=*closure;
  SamChannelInfo *chp=card->channels+channel;
  SamWaitQueue wait;
  unsigned v, frameSize, frameCount, size;
  int error, redirChannel, syncGroup;
  audio_buf_info bufInfo;
  count_info countInfo;
  SamChannelNumbers *channelNumbers;

  error=0;
  switch(cmd) {
  case SNDCTL_DSP_RESET:
    down(&chp->accessLock);
    error=releaseBuffers(card, channel);
    up(&chp->accessLock);
    break;
  case SNDCTL_DSP_SYNC:
    if(mode & SAM_MODE_WRITE_MASK) {
      down(&chp->accessLock);
      if(chp->count &&
	 (error=openChannel(card, channel))<0) {
	up(&chp->accessLock);
	return error;
      }
      while(chp->count>chp->stereo) {
	atomic_inc(&chp->keepBuffersUsageCount);
	samPrepareSleepOn(TASK_INTERRUPTIBLE, &chp->feedMe, &wait);
	up(&chp->accessLock);
	samSleepOn(&chp->feedMe, &wait);
#if LINUX_VERSION_CODE>=0x20200
	if(signal_pending(current)) {
	  atomic_dec(&chp->keepBuffersUsageCount);
	  return -ERESTARTSYS;
	}
#else /* Linux 2.0 */
	if(current->signal & ~current->blocked) {
	  atomic_dec(&chp->keepBuffersUsageCount);
	  return -ERESTARTSYS;
	}
#endif /* Linux 2.0 */
	down(&chp->accessLock);
	atomic_dec(&chp->keepBuffersUsageCount);
      }
      up(&chp->accessLock);
    }
    break;
  case SNDCTL_DSP_POST:
    if(mode & SAM_MODE_WRITE_MASK) {
      down(&chp->accessLock);
      if(chp->count)
	error=openChannel(card, channel);
      up(&chp->accessLock);
    }
    break;
  case SNDCTL_DSP_SPEED:
  case SOUND_PCM_READ_RATE:
    if(cmd!=SOUND_PCM_READ_RATE || (mode & SAM_MODE_READ_MASK)) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      if(SAM_GET_USER(v, (unsigned *)arg))
	return -EFAULT;
      if(v<SAM_MIN_RATE)
	v=SAM_MIN_RATE;
      if(v>SAM_MAX_RATE)
	v=SAM_MAX_RATE;
      if(SAM_PUT_USER(v, (unsigned *)arg))
	return -EFAULT;
      down(&chp->accessLock);
      if(chp->rate!=v)
	if((error=releaseBuffers(card, channel))>=0)
	  chp->rate=v;
      up(&chp->accessLock);
    }
    break;
  case SNDCTL_DSP_STEREO:
    if((error=verify_area(VERIFY_READ, (unsigned *)arg, sizeof(unsigned)))<0)
      return error;
    if(SAM_GET_USER(v, (unsigned *)arg))
      return -EFAULT;
    down(&chp->accessLock);
    if(chp->stereo!=!!v)
      if((error=releaseBuffers(card, channel))>=0)
	chp->stereo=!!v;
    up(&chp->accessLock);
    break;
  case SNDCTL_DSP_GETBLKSIZE:
    if(callNr==0) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      down(&chp->accessLock);
      if(chp->frameSize)
	v=chp->frameSize;
      else
	v=wordsNeeded(chp);
      if(SAM_PUT_USER(v<<SAM_FORMAT_16BIT(chp->format), (unsigned *)arg))
	error=-EFAULT;
      up(&chp->accessLock);
    }
    break;
  case SNDCTL_DSP_CHANNELS:
  case SOUND_PCM_READ_CHANNELS:
    if(cmd!=SOUND_PCM_READ_CHANNELS || (mode & SAM_MODE_READ_MASK)) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      if(SAM_GET_USER(v, (unsigned *)arg))
	return -EFAULT;
      if(v!=1 && v!=2) {
	v=2;
	if(SAM_PUT_USER(v, (unsigned *)arg))
	  return -EFAULT;
      }
      down(&chp->accessLock);
      if(chp->stereo!=(v==2)) {
	if((error=releaseBuffers(card, channel))>=0)
	  chp->stereo=(v==2);
      }
      up(&chp->accessLock);
    }
    break;
  case SOUND_PCM_WRITE_FILTER:
  case SOUND_PCM_READ_FILTER:
    return -EINVAL;
    break;
  case SNDCTL_DSP_SUBDIVIDE:
    /* ignored */
    break;
  case SNDCTL_DSP_SETFRAGMENT:
    if((error=verify_area(VERIFY_READ, (unsigned *)arg, sizeof(unsigned)))<0)
      return error;
    /* the lower 16 bits are log2(buffer size)
     * the upper 15 bits are buffer count
     */
    if(SAM_GET_USER(v, (unsigned *)arg))
      return -EFAULT;
    frameSize=1<<(v&0xFFFF);
    if(frameSize<1)
      frameSize=1;
    if(frameSize>SAM_MAX_DATA_SIZE)
      frameSize=SAM_MAX_DATA_SIZE;
    frameCount=(v>>16)&0x7FFF;
    if(frameCount<SAM_MIN_FRAME_COUNT)
      frameCount=SAM_MIN_FRAME_COUNT;
    if(frameCount>SAM_MAX_FRAME_COUNT)
      frameCount=SAM_MAX_FRAME_COUNT;
    if(frameSize*frameCount>SAM_MAX_DATA_SIZE)
      frameCount=SAM_MAX_DATA_SIZE/frameSize;
    down(&chp->accessLock);
    if(frameSize!=chp->frameSizeWantedBytes &&
       (error=releaseBuffers(card, channel))>=0) {
      chp->frameSizeWantedBytes=frameSize;
      chp->frameCount=frameCount;
    }
    up(&chp->accessLock);
    break;
  case SNDCTL_DSP_GETFMTS:
    if(callNr==0) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      if(SAM_PUT_USER(AFMT_MU_LAW |
		      AFMT_A_LAW |
		      AFMT_U8 |
		      AFMT_S16_LE |
		      AFMT_S16_BE |
		      AFMT_S8 |
		      AFMT_U16_LE |
		      AFMT_U16_BE, (unsigned *)arg))
	return -EFAULT;
    }
    break;
  case SNDCTL_DSP_SETFMT:
  case SOUND_PCM_READ_BITS:
    if(cmd!=SOUND_PCM_READ_BITS || (mode & SAM_MODE_READ_MASK)) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      if(SAM_GET_USER(v, (unsigned *)arg))
	return -EFAULT;
      if(v!=AFMT_MU_LAW &&
	 v!=AFMT_A_LAW &&
	 v!=AFMT_U8 &&
	 v!=AFMT_S16_LE &&
	 v!=AFMT_S16_BE &&
	 v!=AFMT_S8 &&
	 v!=AFMT_U16_LE &&
	 v!=AFMT_U16_BE) {
	v=AFMT_S16_LE;
	if(SAM_PUT_USER(v, (unsigned *)arg))
	  return -EFAULT;
      }
      down(&chp->accessLock);
      if(chp->format!=v &&
	 (error=releaseBuffers(card, channel))>=0)
	chp->format=v;
      up(&chp->accessLock);
    }
    break;
  case SNDCTL_DSP_GETOSPACE:
  case SNDCTL_DSP_GETISPACE:
    if((cmd==SNDCTL_DSP_GETOSPACE && (mode & SAM_MODE_WRITE_MASK)) ||
       (cmd==SNDCTL_DSP_GETISPACE && (mode & SAM_MODE_READ_MASK))) {
      if((error=verify_area(VERIFY_WRITE, (audio_buf_info *)arg, sizeof(audio_buf_info)))<0)
	return error;
      memset(&bufInfo, 0, sizeof(audio_buf_info));
      down(&chp->accessLock);
      if(chp->frameSize) {
	frameSize=chp->frameSize;
	size=chp->size;
      } else {
	frameSize=wordsNeeded(chp);
	size=frameSize*chp->frameCount;
      }
      bufInfo.fragments=chp->frameCount-(chp->count+frameSize-1)/frameSize;
      bufInfo.fragstotal=chp->frameCount;
      bufInfo.fragsize=frameSize<<SAM_FORMAT_16BIT(chp->format);
      bufInfo.bytes=(size-chp->count)<<SAM_FORMAT_16BIT(chp->format);
      up(&chp->accessLock);
      if(SAM_MEMCPY_TOFS((audio_buf_info *)arg, &bufInfo, sizeof(audio_buf_info)))
	return -EFAULT;
    }
    break;
  case SNDCTL_DSP_NONBLOCK:
    /* why does OSS carry a separate ioctl(2) for nonblocking I/O ? */
    break;
  case SNDCTL_DSP_GETCAPS:
    if(callNr==0) {
      if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
	return error;
      if(SAM_PUT_USER(DSP_CAP_DUPLEX|DSP_CAP_BATCH|DSP_CAP_COPROC, (unsigned *)arg))
	return -EFAULT;
    }
    break;
  case SNDCTL_DSP_SETTRIGGER:
    if((error=verify_area(VERIFY_READ, (unsigned *)arg, sizeof(unsigned)))<0)
      return error;
    if(SAM_GET_USER(v, (unsigned *)arg))
      return -EFAULT;
    down(&chp->accessLock);
    if(v & ((mode & SAM_MODE_READ_MASK) ? PCM_ENABLE_INPUT : PCM_ENABLE_OUTPUT)) {
      /* start playback/recording */
      if(chp->waitForTrigger) {
	chp->waitForTrigger=0;
	card->checkChannelStates=1;
	samFeedThreadInfo.haveJobs=1;
	wake_up(&samFeedThreadInfo.feedSam);
      }
    } else {
      /* suspend playback/recording */
      if(!chp->waitForTrigger) {
	if(chp->state!=SamChannelStateClosed && chp->state!=SamChannelStateClosing) {
	  up(&chp->accessLock);
	  return -EBUSY;
	}
	chp->waitForTrigger=1;
	if(mode & SAM_MODE_READ_MASK) {
	  /* allocate buffers and open recording channel
	   */
	  if((error=allocBuffers(card, channel))<0 ||
	     (error=openChannel(card, channel))<0) {
	    up(&chp->accessLock);
	    return error;
	  }
	}
      }
    }
    up(&chp->accessLock);
    break;
  case SNDCTL_DSP_GETTRIGGER:
    if((error=verify_area(VERIFY_WRITE, (unsigned *)arg, sizeof(unsigned)))<0)
      return error;
    if(callNr==0)
      v=0;
    else
      if(SAM_GET_USER(v, (unsigned *)arg))
	return -EFAULT;
    down(&chp->accessLock);
    if(!chp->waitForTrigger)
      v|=(mode & SAM_MODE_READ_MASK) ? PCM_ENABLE_INPUT : PCM_ENABLE_OUTPUT;
    up(&chp->accessLock);
    if(SAM_PUT_USER(v, (unsigned *)arg))
      return -EFAULT;
    break;
  case SNDCTL_DSP_GETIPTR:
  case SNDCTL_DSP_GETOPTR:
    if((cmd==SNDCTL_DSP_GETOPTR && (mode & SAM_MODE_WRITE_MASK)) ||
       (cmd==SNDCTL_DSP_GETIPTR && (mode & SAM_MODE_READ_MASK))) {
      if((error=verify_area(VERIFY_WRITE, (count_info *)arg, sizeof(count_info)))<0)
	return error;
      memset(&countInfo, 0, sizeof(countInfo));
      down(&chp->accessLock);
      countInfo.ptr=calculateCounterPtr(chp, mode & SAM_MODE_READ_MASK);
      countInfo.bytes=chp->counter.finishedBytes+countInfo.ptr;
      countInfo.blocks=chp->counter.transitions;
      chp->counter.transitions=0;
      up(&chp->accessLock);
      if(SAM_MEMCPY_TOFS((count_info *)arg, &countInfo, sizeof(count_info)))
	return -EFAULT;
    }
    break;
  case SNDCTL_DSP_MAPINBUF:
    return -EINVAL;
    break;
  case SNDCTL_DSP_MAPOUTBUF:
    return -EINVAL;
    break;
  case SNDCTL_DSP_SETSYNCRO:
    return -EINVAL;
    break;
  case SNDCTL_DSP_SETDUPLEX:
    /* we're always duplex */
    break;
  case SAM_IOC_API_INFO:
    if(callNr==0)
      error=samApiInfo(card, (SamApiInfo *)arg, SAM_AUDIO_API_VERSION);
    break;
  case SAM_IOC_SYNC_JOIN:
    if((error=verify_area(VERIFY_WRITE, (int *)arg, sizeof(int)))<0)
      return error;

    /* sync group will always be -1, if file is opened readonly */
    if(callNr==0 && !(file->f_mode & SAM_MODE_WRITE_MASK) &&
       SAM_PUT_USER(-1, (int *)arg))
      return -EFAULT;

    if(mode & SAM_MODE_WRITE_MASK) {
      if(SAM_GET_USER(syncGroup, (int *)arg))
	return -EFAULT;
      down(&chp->accessLock);
      if(chp->state!=SamChannelStateClosed && chp->state!=SamChannelStateClosing) {
	up(&chp->accessLock);
	return -EBUSY;
      }
      syncLeave(card, channel);
      if((error=samSyncJoin(&syncGroup, card->cardIdx, SamSyncDeviceAudio))>=0) {
	chp->syncGroup=syncGroup;
	chp->syncStarted=0;
	chp->syncSkipCount=0;
	if(SAM_PUT_USER(syncGroup, (int *)arg))
	  error=-EFAULT;
      }
      up(&chp->accessLock);
    }
    break;
  case SAM_IOC_SYNC_LEAVE:
    down(&chp->accessLock);
    syncLeave(card, channel);
    up(&chp->accessLock);
    break;
  case SAM_IOC_SYNC_INFO:
    if((error=verify_area(VERIFY_WRITE, (int *)arg, sizeof(int)))<0)
      return error;
    if(callNr==0 &&
       SAM_PUT_USER(-1, (int *)arg))
      return -EFAULT;
    if((mode & SAM_MODE_WRITE_MASK) &&
       SAM_PUT_USER(chp->syncGroup, (int *)arg))
      return -EFAULT;
    break;
  case SAM_IOC_CHANNEL_INFO:
    channelNumbers=(SamChannelNumbers *)arg;
    if((error=verify_area(VERIFY_WRITE, channelNumbers, sizeof(SamChannelNumbers)))<0)
      return error;
    if(callNr==0) {
      if(SAM_PUT_USER(-1, &channelNumbers->play) ||
	 SAM_PUT_USER(-1, &channelNumbers->record))
	return -EFAULT;
    }
    if((mode & SAM_MODE_WRITE_MASK) &&
       SAM_PUT_USER(channel, &channelNumbers->play))
      return -EFAULT;
    if((mode & SAM_MODE_READ_MASK) &&
       SAM_PUT_USER(channel, &channelNumbers->record))
      return -EFAULT;
    break;
  case SAM_IOC_CHANNEL_REDIRECT:
    channelNumbers=(SamChannelNumbers *)arg;
    if((error=verify_area(VERIFY_READ, channelNumbers, sizeof(SamChannelNumbers)))<0)
      return error;
    if(mode & SAM_MODE_WRITE_MASK) {
      if(SAM_GET_USER(redirChannel, &channelNumbers->play))
	return -EFAULT;
      if(redirChannel>=0 &&
	 (error=redirectChannel(card, closure, SAM_MINOR_DEVICE(inode), redirChannel))<0)
	return error;
    }
    if(mode & SAM_MODE_READ_MASK) {
      if(SAM_GET_USER(redirChannel, &channelNumbers->record))
	return -EFAULT;
      if(redirChannel>=0 &&
	 (error=redirectChannel(card, closure, SAM_MINOR_DEVICE(inode), redirChannel))<0)
	return error;
    }
    break;
  case SAM_IOC_AUDIO_GET:
    if(callNr==0) {
      down(&card->mixer.accessLock);
      down(&chp->accessLock);
      error=samCtrlsGet(card, channel, (SamControl *)arg);
      up(&chp->accessLock);
      up(&card->mixer.accessLock);
    }
    break;
  case SAM_IOC_AUDIO_SET:
    down(&card->mixer.accessLock);
    down(&chp->accessLock);
    error=samCtrlsSet(card, channel, (SamControl *)arg);
    up(&chp->accessLock);
    up(&card->mixer.accessLock);
    break;
  case SAM_IOC_AUDIO_INFO:
    if(callNr==0) {
      down(&card->mixer.accessLock);
      down(&chp->accessLock);
      error=samCtrlsInfo(card, channel, (SamControl *)arg);
      up(&chp->accessLock);
      up(&card->mixer.accessLock);
    }
    break;
  default:
    return -ENOSYS;
  }
  return error;
}

void samGetAudioInfo(SamCard *card, SamDriverInfo *driverInfo)
{
  int max, i;

  driverInfo->playChannelsUsed=driverInfo->recordChannelsUsed=0;
  driverInfo->playChannelsTotal=card->firmwareInfo->playBackChannels;
  driverInfo->recordChannelsTotal=card->firmwareInfo->recordChannels;

  max=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
  for(i=0; i<max; i++) {
    if(card->channels[i].inUse || card->channels[i].state!=SamChannelStateClosed) {
      if(i<card->firmwareInfo->playBackChannels)
	driverInfo->playChannelsUsed++;
      else
	driverInfo->recordChannelsUsed++;
    }
  }
}
