/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  EWS 64 XL support Copyright (C) 1999 by Florian Weimer.
  Portions Copyright (C) 1998 by TerraTec Electronic GmbH.

  Thanks to TerraTec Electronic GmbH and especially Clemens
  Lengersdorf for providing the necessary information.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <asm/io.h>

#include "driver.h"
#include "io.h"
#include "i2c.h"
#include "alloc.h"

#ifdef SAM_ENABLE_HW_EWS64S

static int ews64sReset(SamCard *card);
static int ews64sFillCache(SamCard *card);

SamHardwareInfo samEWS64SHardwareInfo={
  "ews64s",			/* name */
  NULL,				/* processHints */
  ews64sReset,			/* reset */
  NULL,				/* firmwareDetected */
  NULL,				/* probeMem */
  ews64sFillCache,		/* fillCache */
  0,				/* backupCacheSize */
  NULL,				/* restoreCache */
  NULL,				/* ctrlIsAvail */
  NULL,				/* ctrlInfo */
  NULL,				/* hookIsAvail */
  NULL,				/* hooks */
};

static SamPnpResource ews64sPnpResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (EWS64S)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (EWS64S)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResAuxPort0 */
    0,				/* isOptional */
    "sam9407 (EWS64S Dig. Ctrl #0)",
    3, 0,			/* ldn, idx */
    2,				/* extent */
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    "sam9407 (EWS64S Dig. Ctrl #1)",
    3, 1,			/* ldn, idx */
    2,				/* extent */
  },
};

SamPnPInfo samEWS64SPnPInfo={
  0x1211B250,
  &samEWS64SHardwareInfo,
  ews64sPnpResources,
};

static int ews64CtrlOut(SamCard *card, int sda, int scl)
{
  udelay(200);
  outb(0xF9|(sda<<2)|(scl<<1), card->auxPort0);
  return 0;
}

static int ews64CtrlIn(SamCard *card)
{
  udelay(200);
  return (inb(card->auxPort0)>>2)&1;
}

static int ews64sReset(SamCard *card)
{
  static char resetCodes[]={
    0xDE, 0x5E,
  };
  int error;

  if((error=samI2CWrite(card, ews64CtrlOut, ews64CtrlIn,
			0x20, resetCodes, SAM_NUMBER_OF(resetCodes)))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: digital controller is not responding\n", card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  card->hardwareCache.ews64s.reg20=resetCodes[SAM_NUMBER_OF(resetCodes)-1];

  return 0;
}

static int ews64sFillCache(SamCard *card)
{
  int error;

  if((error=samI2CRead(card, ews64CtrlOut, ews64CtrlIn,
		       0x20, &card->hardwareCache.ews64s.reg20, 1))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: digital controller is not responding\n", card->cardIdx, card->hardwareInfo->name);
    return error;
  }

  return 0;
}

#endif /* SAM_ENABLE_HW_EWS64S */
