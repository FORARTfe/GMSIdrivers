#ifndef _VENDOR_H
#define _VENDOR_H

#include "kconfig.h"

/* we use the highest bit of audio control values
 * to store if this control has been configured
 * by the user
 */
#define SAM_AUDIO_CTRL_CONFIGURED_MASK	(1<<31)
#define SAM_AUDIO_CTRL_VALUE_MASK	(~SAM_AUDIO_CTRL_CONFIGURED_MASK)

/* the 2 highest bits of storeAt determine
 * wether a mixer control is stored in kernel space
 * or on the card.
 * If both are clear, the control table address
 * on the card is equal to the control id.
 */
#define SAM_STORE_AT_MASK		(3<<30)
#define SAM_STORE_AT_CTRL_TBL_DEFAULT	(0<<30)
#define SAM_STORE_AT_CTRL_TBL_ADDR	(1<<30)
#define SAM_STORE_AT_KERNEL_SPACE	(2<<30)

/* the highest bit of SamMixerType is used
 * to indicate if a value should be sent
 * twice
 */
#define SAM_MIXER_TYPE_SEND_TWICE	(1<<15)

struct SamCard;
struct SamChannelInfo;

typedef int (*SamVendorHandler)(struct SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *v);

/*********** Firmware related ***********/

typedef enum {
  SamCtrlTypeUnsupported,
  SamCtrlTypeVendorHandler,
  SamCtrlTypeValue,
  SamCtrlTypeValueHalf,			/* value/2     */
  SamCtrlTypeValueHalfPlus,		/* (value+1)/2 */
} SamCtrlType;

typedef enum {
  SamAddrTagTypeNone,			/* no addr */
  SamAddrTagTypeAddr,			/* addr=addrTag */
  SamAddrTagTypeChannel,		/* addr=channel */
  SamAddrTagTypeChannelMSB,		/* addr=channel*(addrTagLimit+1)+addrTag */
  SamAddrTagTypePlayChannelLSB,		/* addr=addrTag*playChannels+channel */
} SamAddrTagType;

typedef enum {
  SamHWHookTypeNone,
  SamHWHookTypeMandatory,
  SamHWHookTypeOptional,
} SamHWHookType;

typedef enum {
  SamHWHookIdNone,			/* used only with SamHWHookTypeNone */
  SamHWHookIdSampleRate=0,
  SamHWHookIdMasterMute,
  SamHWHookIdMinus6dB,
} SamHWHookId;

typedef enum {
  SamCtrlResponseNone,
  SamCtrlResponseReset,
  SamCtrlResponseVoicesFree,
} SamCtrlResponseType;

typedef enum {
  SamChannelNoRestriction,
  SamChannelRestrictionPlayOnly,
  SamChannelRestrictionRecordOnly,
} SamChannelRestriction;

typedef struct {
  unsigned short type;			/* space saving, of type SamCtrlType */
  unsigned char addrTagType;		/* space saving, of type SamAddrTagType */
  unsigned char addrTagLimit;
  unsigned valueLimit;
  unsigned char ctrl;
  unsigned char hwHookType;		/* space saving, of type SamHWHookType */
  unsigned char hwHookId;		/* space saving, of type SamHWHookId */
  unsigned storeAt;
  unsigned char responseType;		/* space saving, of type SamCtrlResponseType */
  unsigned char channelRestriction;	/* space saving, of type SamChannelRestriction */
  /* commands that require more than just one value
   * need to be byte size and stored in the control table
   * indicated by SAM_STORE_AT_CTRL_TBL_ADDR
   * or SAM_STORE_AT_CTRL_TBL_DEFAULT.
   * In that case, the missing values are retrieved
   * from the control table.
   * valueBytesOfs points to the byte offset within the command sequence
   * while valueBytesLimit is actually (number-of-bytes - 1)
   */
  unsigned char valueBytesOfs, valueBytesLimit;
  /* vendor supplied functions for mixer id's
   * that can't be reached through ctrl's
   */
  SamVendorHandler vendorHandler;
  /* dirtyAddr will contain the offset to fwDirtyFlags
   * which is being calculated in initialization phase
   */
  unsigned dirtyAddr;
} SamFWCtrlVendorInfo;

/* buggy firmware doesn't remember all
 * mixer control values needed
 * We remember those values and restore/backup
 * them to SAM9407 when loading/unloading the
 * module
 */
#ifdef SAM_ENABLE_FW_EWS64
typedef struct {
  unsigned aud_onoff;
} SamEWS64CtrlValues;
#endif

/* stored settings for audio controls */
typedef struct {
  unsigned volleft, volright, volauxleft, volauxright;
  unsigned filt_fc, filt_q;
} SamGenuineAudioCtrlValues;

#ifdef SAM_ENABLE_FW_EWS64
typedef struct {
  unsigned volleft, volright, volauxleft, volauxright;
  unsigned filt_fc, filt_q, mute;
} SamEWS64AudioCtrlValues;
#endif

#ifdef SAM_ENABLE_FW_HOMSTDR
typedef struct {
  unsigned filt_fc, filt_q;
} SamHomstdrAudioCtrlValues;
#endif

typedef struct {
  unsigned nMixerCtrls;				/* # of mixer controls */
  unsigned nAudioCtrls;				/* # of audio controls */
} SamFirmwareClassInfo;

/* we keep the number of dirty flags and a dirtyFlag index
 * to control id translation table for both mixer and audio.
 * These values will be generated at initialization phase, as
 * they're basically redudant information calculated from
 * the contents of mixerCtrlInfo and audioCtrlInfo
 */
typedef struct {
  unsigned n;
  unsigned char *ctrlIds;
} SamDirtyAddrToCtrl;

typedef struct {
  char *name;
  unsigned probeAddr;
  char *probeStr;
  unsigned apiClass;
  unsigned initNapTimeout;			/* initial timeout (in jiffies) after firmware load */
  char verifyChecksum;				/* after firmware load */
  int (*setup)(struct SamCard *card);
  short mmtSlots;
  char largeCtrlTable;				/* true if control table is 256 bytes large */
  short peakMeterWords;				/* # of peak meter values located behind control table */
  char haveAudio, haveMidi, haveMod;
  char mutexModRecAudio;			/* firmware can't handle static audio and recording simultaneously */
  char supportsMaxi64Controls;			/* supports selecting audio input via Maxi64 prorietary controls */
  unsigned char playBackChannels, recordChannels;
  unsigned char getMMTAck;			/* GET_MMT ACK, 0==no ACK */
  unsigned char openAck;			/* W_OPEN ack start, 0==no ACK */
  unsigned char closeAck;			/* W_CLOSE ack start */
  char closeAckRecChannel;			/* W_CLOSE ack sent even for recording channel */
  char midiResetFixup;				/* Midi Reset doesn't turn off all notes */
  char getVoicesReadDummy;			/* dispose first dummy byte from the GET_VOI response */
  char getPosReturnsVoice;			/* GET_POS will return the voice# as first byte in the response */
  SamFWCtrlVendorInfo *mixerCtrlInfo;		/* indexed by SamMixerId */
  SamFWCtrlVendorInfo *audioCtrlInfo;		/* indexed by SamAudioId */
  unsigned char resetRestoreCtrl;		/* restore this control after firmware reset */
  unsigned nResetReadjust;			/* # of bytes in resetSend */
  unsigned char *resetReadjust;			/* send these controls after a firmware reset */
  unsigned nSBankRehash;			/* # of bytes in sbankRehash */
  unsigned char *sbankRehash;			/* send these controls after soundbank changes */
  unsigned char *midiSelCtrls;			/* midi channel selection controls */
  unsigned ctrlValuesSize;			/* how many bytes are stored in card->ctrlValues */
  void (*initAudioCtrlValues)(struct SamChannelInfo *chp);
  SamDirtyAddrToCtrl mixerDirty, audioDirty;
} SamFirmwareInfo;

extern SamFirmwareClassInfo samFirmwareClassInfo[];

extern SamFirmwareInfo *samFirmwareInfos[];

extern SamFWCtrlVendorInfo samGenuineMixerCtrlInfo[];
extern SamFWCtrlVendorInfo samGenuineAudioCtrlInfo[];
void samGenuineInitAudioCtrlValues(struct SamChannelInfo *chp);

extern SamFirmwareInfo samGenuineFirmwareInfo;
#ifdef SAM_ENABLE_FW_EWS64
extern SamFirmwareInfo samEWS64FirmwareInfo;
#endif
#ifdef SAM_ENABLE_FW_MAXI64
extern SamFirmwareInfo samG8500FirmwareInfo;
extern SamFirmwareInfo samHSTUDFirmwareInfo;
#endif
#ifdef SAM_ENABLE_FW_HOMSTDR
extern SamFirmwareInfo samHomstdrFirmwareInfo;
#endif
#ifdef SAM_ENABLE_FW_HOON4D
extern SamFirmwareInfo samHOPDFirmwareInfo;
extern SamFirmwareInfo samPD07FirmwareInfo;
#endif

/*********** Hardware related ***********/

/* cache hardware registers
 * to keep those values that can't be retrieved from hardware
 * and improve access time (e.g. I2C)
 */

#ifdef SAM_ENABLE_HW_EWS64S
typedef struct {
  char reg20;			/* I2C address 0x20 */
} SamEWS64SHardwareCache;
#endif

#ifdef SAM_ENABLE_HW_EWS64XL
typedef struct {
  int volume[2][2];		/* first index: output, second index:
				   left (0)/right (1), values in dB */
  char tea6320_07[2];		/* analog routing stuff */
  char pcf8574[8];		/* I2C addresses 0x20-0x27 */
  char pcf8574_active[8];	/* 1 for each register which is actually
				   present, 0 for inactive registers */
} SamEWS64XLHardwareCache;
#endif

#if defined(SAM_ENABLE_HW_ST128RUBY) || defined(SAM_ENABLE_HW_ST128PCI)
typedef struct {
  unsigned char dac;
} __attribute__((aligned(2))) SamST128HardwareCache;
#endif

#ifdef SAM_ENABLE_HW_STDA
#define SAM_STDA_BOX_COUNT		8
#define SAM_STDA_ROUTE_BOX_MASK		(SAM_STDA_BOX_COUNT-1)
#define SAM_STDA_ROUTE_MASTER_MASK	0x80
#define SAM_STDA_ROUTE_SLAVE_MASK	0x40

typedef enum {
  SamSTDABoxRouteIdxMidi,
  SamSTDABoxRouteIdxCH0,
  SamSTDABoxRouteIdxCH1,
  SamSTDABoxRouteIdxCH2,
  SamSTDABoxRouteIdxCH3,
  SamSTDABoxRouteIdxLast
} SamSTDABoxRouteIdx;

typedef struct {
  unsigned char boxRoutes[SamSTDABoxRouteIdxLast];
  unsigned char adda[4];
} __attribute__((aligned(2))) SamSTDAHardwareCache;
#endif /* SAM_ENABLE_HW_STDA */

#ifdef SAM_ENABLE_HW_MAXI64
typedef struct {
  unsigned char audioInput;
} __attribute__((aligned(2))) SamMaxi64HardwareCache;
#endif

typedef int (*SamHWHook)(struct SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *v);

typedef struct {
  SamVendorHandler vendorHandler;
  unsigned char addrTagLimit;
  /* dirtyAddr will contain the offset to hwDirtyFlags
   * which is being calculated in initialization phase
   */
  unsigned dirtyAddr;
} SamHWCtrlVendorInfo;

typedef struct {
  char *name;
  void (*processHints)(struct SamCard *card);
  int (*reset)(struct SamCard *card);
  int (*firmwareDetected)(struct SamCard *card);
  int (*probeMem)(struct SamCard *card);
  int (*fillCache)(struct SamCard *card);
  unsigned backupCacheSize;
  int (*restoreCache)(struct SamCard *card);
  int (*ctrlIsAvail)(struct SamCard *card, SamMixerHWId mixerId);
  SamHWCtrlVendorInfo *ctrlInfo;
  int (*hookIsAvail)(struct SamCard *card, SamHWHookId hookId);
  SamHWHook *hooks;
  SamDirtyAddrToCtrl mixerDirty;
} SamHardwareInfo;

typedef enum {
  SamHardwareResPort,
  SamHardwareResIrq,
  SamHardwareResAuxPort0,
  SamHardwareResAuxPort1,
  SamHardwareResSentinel
} SamHardwareResType;

typedef struct {
  int value;
  char *id;
  int extent;			/* used for aux-ports only */
} SamHardwareResource;

extern SamHardwareInfo *samHardwareInfos[];

#ifdef SAM_ENABLE_ISA
typedef struct {
  int isOptional;
  char *id;
  int ldn, idx;
  int extent, ofs;		/* used for aux-ports only */
} SamPnpResource;

typedef struct {
  unsigned id;			/* board id #, 0==end of list */
  SamHardwareInfo *hardwareInfo;
  SamPnpResource *resources;	/* indexed by SamHardwareResType */
} SamPnPInfo;

extern SamPnPInfo *samPnPInfos[];
#endif /* SAM_ENABLE_ISA */

#ifdef SAM_ENABLE_PCI
typedef struct {
  int isOptional;
  char *id;
  int where;
  int extent, ofs;		/* used for aux-ports only */
} SamPCIResource;

typedef struct SamPCIInfo {
  unsigned short vendor, devId;
  SamHardwareInfo *hardwareInfo;
  SamPCIResource *resources;	/* indexed by SamHardwareResType */
  int (*configure)(SamHardwareInfo **hardwareInfoMasterP, SamHardwareResource *resMaster,
		   SamHardwareInfo **hardwareInfoSlaveP, SamHardwareResource *resSlave,
		   unsigned bus, unsigned devFn);
} SamPCIInfo;

extern SamPCIInfo *samPCIInfos[];
#endif /* SAM_ENABLE_PCI */

#ifdef SAM_ENABLE_HW_EWS64S
extern SamHardwareInfo samEWS64SHardwareInfo;
extern SamPnPInfo samEWS64SPnPInfo;
#endif

#ifdef SAM_ENABLE_HW_EWS64XL
extern SamHardwareInfo samEWS64XLHardwareInfo;
extern SamPnPInfo samEWS64XLPnPInfo;
#endif

#ifdef SAM_ENABLE_HW_ST128RUBY
extern SamHardwareInfo samST128RubyHardwareInfo;
extern SamPnPInfo samST128RubyPnPInfo;
#endif

#ifdef SAM_ENABLE_HW_ST128PCI
extern SamHardwareInfo samST128PCIHardwareInfo;
#endif

#ifdef SAM_ENABLE_HW_STDA
extern SamHardwareInfo samSTDAMasterHardwareInfo;
extern SamHardwareInfo samSTDASlaveHardwareInfo;
#endif

#if defined(SAM_ENABLE_HW_ST128PCI) || defined(SAM_ENABLE_HW_STDA)
extern SamPCIInfo samST128PCIInfo;
#endif

#ifdef SAM_ENABLE_HW_MAXI64
extern SamHardwareInfo samMaxi64HardwareInfo;
extern SamPnPInfo samMaxi64PnPInfo;
extern SamPnPInfo samMaxi64ProPnPInfo;
#endif

int samAdjustVendorInformation(void);
void samReleaseVendorInformation(void);

#endif /* _VENDOR_H */
