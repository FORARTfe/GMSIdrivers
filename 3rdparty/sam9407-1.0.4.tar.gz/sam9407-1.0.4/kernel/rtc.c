/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>
  large parts copied straight from linux/drivers/char/rtc.c

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/ioport.h>
#include <linux/mc146818rtc.h>

#include "driver.h"
#include "rtc.h"

#ifdef SAM_ENABLE_RTC

#define SAM_RTC_IRQ			8
#define SAM_RTC_IO_EXTENT		0x10
#define SAM_RTC_IRQ_CHECK_INTERVAL	HZ

static int usageCount, irqSeen;
static struct timer_list recoverTimer;

static SamRTCCallbackNode *callbackNodes;

int samUsingRTC;

#if LINUX_VERSION_CODE>=0x20200
static spinlock_t cmosSpinLock __attribute__((unused))=SPIN_LOCK_UNLOCKED;
static spinlock_t nodeSpinLock __attribute__((unused))=SPIN_LOCK_UNLOCKED;
#endif

static void maskIrqBit(unsigned char bit)
{
  unsigned char val;
  unsigned flags;
  
  SAM_BEGIN_CRITICAL(&cmosSpinLock, flags);
  val = CMOS_READ(RTC_CONTROL);
  val &=  ~bit;
  CMOS_WRITE(val, RTC_CONTROL);
  CMOS_READ(RTC_INTR_FLAGS);
  SAM_END_CRITICAL(&cmosSpinLock, flags);
}

static void setIrqBit(unsigned char bit)
{
  unsigned char val;
  unsigned flags;

  SAM_BEGIN_CRITICAL(&cmosSpinLock, flags);
  val = CMOS_READ(RTC_CONTROL);
  val |= bit;
  CMOS_WRITE(val, RTC_CONTROL);
  CMOS_READ(RTC_INTR_FLAGS);
  SAM_END_CRITICAL(&cmosSpinLock, flags);
}

static void irqHandler(int irq, void *dev_id, struct pt_regs *regs)
{
  SamRTCCallbackNode *node;

  CMOS_READ(RTC_INTR_FLAGS);
  irqSeen=1;

  for(node=callbackNodes; node; node=node->next)
    if(node->enabled)
      (*node->callback)();
}

static void checkIRQ(unsigned long data)
{
  if(usageCount>0 && !irqSeen) {
    printk(KERN_WARNING "sam9407: RTC interrupt got stuck, trying to recover\n");
    CMOS_READ(RTC_INTR_FLAGS);
  }
  irqSeen=0;

  del_timer(&recoverTimer);
  recoverTimer.expires=jiffies+SAM_RTC_IRQ_CHECK_INTERVAL;
  add_timer(&recoverTimer);
}

void samRTCRegisterCallback(SamRTCCallbackNode *node)
{
  static SAM_DECLARE_MUTEX(accessLock);

  down(&accessLock);
  node->enabled=0;
  node->next=callbackNodes;
  callbackNodes=node;
  up(&accessLock);
}

void samRTCEnableCallback(SamRTCCallbackNode *node)
{
  unsigned flags;

  SAM_BEGIN_CRITICAL(&nodeSpinLock, flags);
  if(node->enabled) {
    SAM_END_CRITICAL(&nodeSpinLock, flags);
    return;
  }

  node->enabled=1;

  if(usageCount++==0) {
    setIrqBit(RTC_PIE);

    irqSeen=0;
    del_timer(&recoverTimer);
    recoverTimer.expires=jiffies+SAM_RTC_IRQ_CHECK_INTERVAL;
    add_timer(&recoverTimer);
  }
  SAM_END_CRITICAL(&nodeSpinLock, flags);
}

void samRTCDisableCallback(SamRTCCallbackNode *node)
{
  unsigned flags;

  SAM_BEGIN_CRITICAL(&nodeSpinLock, flags);
  if(!node->enabled) {
    SAM_END_CRITICAL(&nodeSpinLock, flags);
    return;
  }

  node->enabled=0;

  if(--usageCount==0) {
    maskIrqBit(RTC_PIE);
    del_timer(&recoverTimer);
  }
  SAM_END_CRITICAL(&nodeSpinLock, flags);
}

void samInitializeRTC(void)
{
  unsigned flags;

  samUsingRTC=1;
  if(check_region(RTC_PORT(0), SAM_RTC_IO_EXTENT)<0) {
    printk(KERN_WARNING "sam9407: RTC I/O port 0x%x is already in use\n", RTC_PORT(0));
    samUsingRTC=0;
  }

  if(samUsingRTC &&
     request_irq(SAM_RTC_IRQ, irqHandler, SA_SHIRQ, "sam9407 (RTC)", NULL)<0) {
    printk(KERN_WARNING "sam9407: RTC IRQ %d is already in use\n", SAM_RTC_IRQ);
    samUsingRTC=0;
  }

  if(!samUsingRTC) {
    printk(KERN_WARNING "sam9407: using less accurate system timer\n");
    return;
  }

  request_region(RTC_PORT(0), SAM_RTC_IO_EXTENT, "sam9407 (RTC)");

  SAM_BEGIN_CRITICAL(&cmosSpinLock, flags);
  /* Set periodic frequency to 4096Hz */
  CMOS_WRITE(((CMOS_READ(RTC_FREQ_SELECT) & 0xF0) | 0x04), RTC_FREQ_SELECT);
  SAM_END_CRITICAL(&cmosSpinLock, flags);
  maskIrqBit(RTC_PIE);

  /* recover from missed IRQ's by
   * setting up a conventional timer
   */
  init_timer(&recoverTimer);
  recoverTimer.function=checkIRQ;
  recoverTimer.expires=jiffies+SAM_RTC_IRQ_CHECK_INTERVAL;
}

void samReleaseRTC(void)
{
  if(!samUsingRTC)
    return;

  del_timer(&recoverTimer);
 
  maskIrqBit(RTC_PIE);

  free_irq(SAM_RTC_IRQ, NULL);

  release_region(RTC_PORT(0), SAM_RTC_IO_EXTENT);
}

#endif /* SAM_ENABLE_RTC */
