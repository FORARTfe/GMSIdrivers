/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/config.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/delay.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#include <linux/bios32.h>
#endif
#include <linux/pci.h>
#if defined(CONFIG_ISAPNP) || defined(CONFIG_ISAPNP_MODULE)
#include <linux/isapnp.h>
#endif
#include <asm/io.h>

#include "driver.h"
#include "cards.h"

#ifdef SAM_ENABLE_ISA
#if !defined(CONFIG_ISAPNP) && !defined(CONFIG_ISAPNP_MODULE)

#define SAM_PNP_ADDRPORT	0x279
#define SAM_PNP_WRITEPORT	0xA79
#define SAM_PNP_READPORT	pnpReadPort

#define SAM_PNP_REG_RDPORT	0x00
#define SAM_PNP_REG_ISOLATE	0x01
#define SAM_PNP_REG_CC		0x02
#define SAM_PNP_REG_WAKE	0x03
#define SAM_PNP_REG_CSN		0x06
#define SAM_PNP_REG_LDN		0x07
#define SAM_PNP_REG_PORT_BASE	0x60
#define SAM_PNP_REG_IRQ_BASE	0x70

#define SAM_PNP_REG_CC_WAIT_KEY	0x02

#define SAM_PNP_CC_RESET_CSN	0x04
#define SAM_PNP_CC_RESET_DRV	0x07

static int pnpReadPort;

static void pnpInitKey(void)
{
  int i;
  unsigned char lfsr;

  outb(0x00, SAM_PNP_ADDRPORT);
  outb(0x00, SAM_PNP_ADDRPORT);

  lfsr=0x6A;

  for(i=0; i<32; i++) {
    outb(lfsr, SAM_PNP_ADDRPORT);
    lfsr=(((lfsr&1)^((lfsr>>1)&1))<<7)|(lfsr>>1);
  }
}

static __inline__ void pnpOut(int value, int reg)
{
  outb(reg, SAM_PNP_ADDRPORT);
  outb(value, SAM_PNP_WRITEPORT);
}

static __inline__ unsigned pnpIn(int reg)
{
  outb(reg, SAM_PNP_ADDRPORT);
  return inb(SAM_PNP_READPORT);
}

static int pnpIsolateCard(int csn)
{
  int vendorIdx, i, j;
  int isConfigured;
  SamHardwareResource res[SamHardwareResSentinel];
  unsigned v;
  unsigned char lfsr, id[9], c1, c2, b;
  SamPnPInfo *pnpInfo;
  SamHardwareResType resType;
  SamPnpResource *resource;

  pnpOut(0x00, SAM_PNP_REG_WAKE);
  lfsr=0x6A;
  
  outb(SAM_PNP_REG_ISOLATE, SAM_PNP_ADDRPORT);
  udelay(750);
  for(i=0; i<9; i++) {
    id[i]=0;
    for(j=0; j<8; j++) {
      udelay(250);
      b=0;
      c1=inb(SAM_PNP_READPORT);
      c2=inb(SAM_PNP_READPORT);
      if(c1==0x55 && c2==0xAA)
	b=1;
      id[i]|=b<<j;
      if(i<8)
	lfsr=(((lfsr&1)^((lfsr>>1)&1)^b)<<7)+(lfsr>>1);
    }
  }
  if(id[8]!=lfsr)
    return 0;
  pnpOut(csn, SAM_PNP_REG_CSN);

  /* we've found an ISA PnP board
   * check if the ID# is known
   */
  for(vendorIdx=0; (pnpInfo=samPnPInfos[vendorIdx]); vendorIdx++) {
    if(pnpInfo->hardwareInfo && pnpInfo->id==*(unsigned *)id) {
      memset(res, 0, sizeof(res));
      isConfigured=1;
      pnpOut(csn, SAM_PNP_REG_WAKE);
      for(resType=0; resType<SamHardwareResSentinel; resType++) {
	resource=pnpInfo->resources+resType;

	v=0;
	if(resource->id) {
	  pnpOut(resource->ldn, SAM_PNP_REG_LDN);
	  switch(resType) {
	  case SamHardwareResPort:
	  case SamHardwareResAuxPort0:
	  case SamHardwareResAuxPort1:
	    v=pnpIn(SAM_PNP_REG_PORT_BASE+2*resource->idx)<<8 |
	      pnpIn(SAM_PNP_REG_PORT_BASE+2*resource->idx+1);
	    if(resType!=SamHardwareResPort && v)
	      v+=resource->ofs;
	    break;
#ifdef SAM_ENABLE_IRQ
	  case SamHardwareResIrq:
	    v=pnpIn(SAM_PNP_REG_IRQ_BASE+2*resource->idx);
	    break;
#endif
	  default:
	    /* make compiler happy */
	  }
	}

	if(!v && !resource->isOptional) {
	  isConfigured=0;
	  break;
	}

	res[resType].value=v;
	res[resType].id=resource->id;
	res[resType].extent=resource->extent;
      }
      if(isConfigured)
	samRegisterCard(pnpInfo->hardwareInfo, res, NULL);
      else
	printk(KERN_INFO "sam9407: board %s is not PnP configured\n", pnpInfo->hardwareInfo->name);

      break;
    }
  }

  return 1;
}

static void findPNPCards(void)
{
  int csn;
  pnpOut(SAM_PNP_CC_RESET_DRV, SAM_PNP_REG_CC);

  pnpInitKey();

  /* Reset all CSNs */
  pnpOut(SAM_PNP_CC_RESET_CSN, SAM_PNP_REG_CC);

  csn=1;
  for(pnpReadPort=0x203; pnpReadPort<0x400; pnpReadPort+=8) {
    if(check_region(pnpReadPort, 1)<0)
      continue;

    pnpOut(0x00, SAM_PNP_REG_WAKE);
    pnpOut(pnpReadPort>>2, SAM_PNP_REG_RDPORT);

    if(pnpIsolateCard(csn)) {
      csn++;
      break;
    }
  }
  if(pnpReadPort>=0x400) {
    pnpOut(SAM_PNP_REG_CC_WAIT_KEY, SAM_PNP_REG_CC);
    return;
  }

  while(pnpIsolateCard(csn++));

  pnpOut(SAM_PNP_REG_CC_WAIT_KEY, SAM_PNP_REG_CC);
}

#else /* CONFIG_ISAPNP || CONFIG_ISAPNP_MODULE */

static void findPNPCards(void)
{
  SamPnPInfo *pnpInfo;
  SamHardwareResource res[SamHardwareResSentinel];
  SamHardwareResType resType;
  SamPnpResource *resource;
  int vendorIdx, isConfigured, v;
  struct pci_bus *pnpCard;

  for(vendorIdx=0; (pnpInfo=samPnPInfos[vendorIdx]); vendorIdx++) {
    if(pnpInfo->hardwareInfo) {
      pnpCard=NULL;
      while((pnpCard=isapnp_find_card(pnpInfo->id&0xFFFF, (pnpInfo->id>>16)&0xFFFF, pnpCard))) {
	memset(res, 0, sizeof(res));
	isConfigured=1;
	for(resType=0; resType<SamHardwareResSentinel; resType++) {
	  resource=pnpInfo->resources+resType;

	  v=0;
	  if(resource->id) {
	    isapnp_cfg_begin(pnpCard->number, resource->ldn);
	    switch(resType) {
	    case SamHardwareResPort:
	    case SamHardwareResAuxPort0:
	    case SamHardwareResAuxPort1:
	      v=isapnp_read_word(ISAPNP_CFG_PORT+2*resource->idx);
	      if(resType!=SamHardwareResPort && v)
		v+=resource->ofs;
	      break;
#ifdef SAM_ENABLE_IRQ
	    case SamHardwareResIrq:
	      v=isapnp_read_byte(ISAPNP_CFG_IRQ+2*resource->idx);
	      break;
#endif
	    default:
	      /* make compiler happy */
	    }
	    isapnp_cfg_end();
	  }

	  if(!v && !resource->isOptional) {
	    isConfigured=0;
	    break;
	  }

	  res[resType].value=v;
	  res[resType].id=resource->id;
	  res[resType].extent=resource->extent;
	}
	if(isConfigured)
	  samRegisterCard(pnpInfo->hardwareInfo, res, NULL);
	else
	  printk(KERN_INFO "sam9407: board %s is not PnP configured\n", pnpInfo->hardwareInfo->name);
      }
    }
  }
}

#endif /* CONFIG_ISAPNP || CONFIG_ISAPNP_MODULE */
#endif /* SAM_ENABLE_ISA */

#ifdef SAM_ENABLE_PCI

static int getPCIResources(SamPCIInfo *pciInfo, SamHardwareResource *res, unsigned bus, unsigned devFn)
{
  int isConfigured;
  unsigned v;
#ifdef SAM_ENABLE_IRQ
  unsigned char b;
#endif
  SamHardwareResType resType;
  SamPCIResource *resource;

  memset(res, 0, SamHardwareResSentinel*sizeof(SamHardwareResource));
  isConfigured=1;
  for(resType=0; resType<SamHardwareResSentinel; resType++) {
    resource=pciInfo->resources+resType;
    v=0;
    if(resource->id) {
      switch(resType) {
      case SamHardwareResPort:
      case SamHardwareResAuxPort0:
      case SamHardwareResAuxPort1:
	if(pcibios_read_config_dword(bus, devFn, resource->where, &v)==PCIBIOS_SUCCESSFUL) {
	  v&=PCI_BASE_ADDRESS_IO_MASK;
	  if(resType!=SamHardwareResPort && v)
	    v+=resource->ofs;
	} else
	  v=0;
	break;
#ifdef SAM_ENABLE_IRQ
      case SamHardwareResIrq:
	if(pcibios_read_config_byte(bus, devFn, resource->where, &b)==PCIBIOS_SUCCESSFUL &&
	   b!=0xFF)
	  v=b;
	break;
#endif
      default:
	/* make compiler happy */
      }
    }
    
    if(!v && !resource->isOptional) {
      isConfigured=0;
      break;
    }

    res[resType].value=v;
    res[resType].id=resource->id;
    res[resType].extent=resource->extent;
  }

  return isConfigured;
}

static void findPCICards(void)
{
  SamHardwareInfo *hardwareInfoMaster, *hardwareInfoSlave;
  SamHardwareResource resMaster[SamHardwareResSentinel], resSlave[SamHardwareResSentinel];
  SamCard *master;
  SamPCIInfo *pciInfo;
  int vendorIdx, idx;
#if LINUX_VERSION_CODE>=0x20200
  struct pci_dev *pciDev;
#endif
  unsigned char bus, devFn;

  for(vendorIdx=0; (pciInfo=samPCIInfos[vendorIdx]); vendorIdx++) {
#if LINUX_VERSION_CODE>=0x20200
    pciDev=NULL;
#endif
    for(idx=0;;idx++) {
#if LINUX_VERSION_CODE>=0x20200
      if(!(pciDev=pci_find_device(pciInfo->vendor, pciInfo->devId, pciDev)))
	break;
      bus=pciDev->bus->number;
      devFn=pciDev->devfn;
#else /* Linux 2.0 */
      if(pcibios_find_device(pciInfo->vendor, pciInfo->devId, idx, &bus, &devFn)!=PCIBIOS_SUCCESSFUL)
	break;
#endif /* Linux 2.0 */
      hardwareInfoMaster=pciInfo->hardwareInfo;
      if(getPCIResources(pciInfo, resMaster, bus, devFn)) {
	hardwareInfoSlave=NULL;
	memset(resSlave, 0, sizeof(resSlave));
	if(!pciInfo->configure ||
	   (*pciInfo->configure)(&hardwareInfoMaster, resMaster,
				 &hardwareInfoSlave, resSlave,
				 bus, devFn)>=0) {
	  if(hardwareInfoMaster)
	    master=samRegisterCard(hardwareInfoMaster, resMaster, NULL);
	  else
	    master=NULL;
	  if(hardwareInfoSlave)
	    samRegisterCard(hardwareInfoSlave, resSlave, master);
	} else
	  if(hardwareInfoMaster)
	    printk(KERN_ERR "sam9407: couldn't PCI configure board %s\n", hardwareInfoMaster->name);
      } else
	if(hardwareInfoMaster)
	  printk(KERN_INFO "sam9407: board %s is not PCI configured\n", hardwareInfoMaster->name);
    }
  }
}

#endif /* SAM_ENABLE_PCI */

void samFindCards(void)
{
#ifdef SAM_ENABLE_ISA
  findPNPCards();
#endif
#ifdef SAM_ENABLE_PCI
  findPCICards();
#endif
}
