#ifndef _ALLOC_H
#define _ALLOC_H

#include "driver.h"

#define SAM_ALIGN_DONT_CARE		1
#define SAM_ALIGN_EVEN			2

#define SAM_BOUNDARY_64K		(64<<10)
#define SAM_BOUNDARY_256K		(256<<10)

/* Initialize MMT structures */
int samInitializeMMT(SamCard *card);

void samReleaseMMT(SamCard *card);

/* return a memory chunk
 * and store it in MMT
 * returns id or <0 if failed
 * align specifies the address alignment
 * boundary specifies memory boundary that shouldn't be crossed
 * optional callback will be called before
 * activating the new MMT
 */
int samAlloc(SamCard *card, int id, int words, unsigned *ptr, unsigned align, unsigned boundary,
	     int (*callback)(SamCard *card, unsigned addr, void *closure), void *closure);

int samFree(SamCard *card, int id, int mask);

/* probes available memory and stores the result in the MMT */
int samGenericProbeMem(SamCard *card);

/* find an MMT entry and store
 * the address at ptr, length at len
 * returns 0 if not found, <0 if failed
 */
int samFindMMT(SamCard *card, int id, int mask, unsigned *ptr, unsigned *len);

void samGetMemInfo(SamCard *card, SamDriverInfo *driverInfo);

#ifdef SAM_DEBUG
int samDebugMMTInfo(SamCard *card, SamMMTInfo *mmtInfo);
#endif

#endif /* _ALLOC_H */
