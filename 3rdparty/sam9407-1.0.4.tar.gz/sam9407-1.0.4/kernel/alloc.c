/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* memory allocation functions */

/* According to SAM9407 Firmware API
 * Memory Mapping table and Midi Mapping Table
 * need to be consecutive.
 * We keep a second MMT, including the midi mapping
 * table reserved, and a flag telling, if the
 * second midi table needs to be synchronized
 * with the first one.
 * That way we can avoid transferring
 * Midi Mapping Table unnecessarily often.
 */

#include <stdarg.h>
#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#include <asm/io.h>

#include "driver.h"
#include "io.h"
#include "mixer.h"
#include "alloc.h"

#ifndef __LITTLE_ENDIAN
/* convert from little endian to host byte order */
static __inline__ void importMMT(SamMMTEntry *dst, SamMMTEntry *src, int slots)
{
  SamMMTSBank *srcSBank, *dstSBank;
  int i;

  for(i=0; i<slots; i++) {
    dst[i].id=SAM_LE16_TO_CPU(src[i].id);
    dst[i].addr=SAM_LE32_TO_CPU(src[i].addr);
    if((dst[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
  }

  srcSBank=(SamMMTSBank *)(src+slots);
  dstSBank=(SamMMTSBank *)(dst+slots);
  for(i=0; i<SAM_NROF_SBANKS; i++) {
    memcpy(dstSBank[i].name, srcSBank[i].name, SAM_SBANK_NAME_LEN);
    dstSBank[i].priority=SAM_LE16_TO_CPU(srcSBank[i].priority);
  }
}

/* convert from host byte order to little endian */
static __inline__ void exportMMT(SamMMTEntry *dst, SamMMTEntry *src, int slots)
{
  SamMMTSBank *srcSBank, *dstSBank;
  int i;

  for(i=0; i<slots; i++) {
    dst[i].id=SAM_CPU_TO_LE16(src[i].id);
    dst[i].addr=SAM_CPU_TO_LE32(src[i].addr);
  }

  srcSBank=(SamMMTSBank *)(src+slots);
  dstSBank=(SamMMTSBank *)(dst+slots);
  for(i=0; i<SAM_NROF_SBANKS; i++) {
    memcpy(dstSBank[i].name, srcSBank[i].name, SAM_SBANK_NAME_LEN);
    dstSBank[i].priority=SAM_CPU_TO_LE16(srcSBank[i].priority);
  }
}
#endif /* !__LITTLE_ENDIAN */

static int cleanupMMT(SamCard *card, int export)
{
  int done, dispose, modified, i;

  /* cleanup MMT */
  done=modified=0;
  for(i=0; !done && i<card->firmwareInfo->mmtSlots; i++) {
    dispose=1;
    switch(card->mem.mmt[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_SAVED_CTRLS:
    case SAM_MMT_ID_SAVED_HWCACHE:
    case SAM_MMT_ID_SAVED_HWHINTS:
      dispose=!export;
    case SAM_MMT_ID_MMT_COPY:
    case SAM_MMT_ID_MIDI_MT_COPY:
    case SAM_MMT_ID_TMP_RESERVED:
    case SAM_MMT_ID_STR_WAVE:
      if(dispose) {
	if(card->mem.mmt[i].id&SAM_MMT_ROM_MASK)
	  card->mem.mmt[i].id=SAM_MMT_ID_RESERVED|SAM_MMT_ROM_MASK;
	else
	  card->mem.mmt[i].id=SAM_MMT_ID_FREE;
	modified=1;
      }
      break;
    case SAM_MMT_ID_EOM:
      done=1;
      break;
    }
  }

  /* reset unused slots */
  if(i<card->firmwareInfo->mmtSlots)
    memset(card->mem.mmt+i, 0, (card->firmwareInfo->mmtSlots-i)*sizeof(SamMMTEntry));

  return modified;
}

int samGenericProbeMem(SamCard *card)
{
  int error, i;
  unsigned low, high, probe;
  unsigned short v, pattern;

  for(i=0; i<card->firmwareInfo->mmtSlots; i++)
    if((card->mem.mmt[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;

  if(i>=card->firmwareInfo->mmtSlots)
    return -EIO;

  if(!card->hints.cardMem) {
    if(i>0)
      low=card->mem.mmt[i-1].addr;
    else
      low=0;
    high=32<<20; /* assume a maximum memory of 64M */
    pattern=0x55AA;
    while(low+1<high) {
      probe=(low+high)/2;
      if((error=samTalk(card,
			SamWriteMem, probe, &pattern, 1,
			SamReadMem, probe, &v, 1,
			SamEndOfScript))<0)
	return error;
      if(v!=pattern)
	high=probe;
      else
	low=probe;
    }
  } else
    high=card->hints.cardMem;

  /* adjust the MMT */
  card->mem.mmt[0].addr=card->mem.mmt[i].addr=high;

  return 0;
}

int samInitializeMMT(SamCard *card)
{
  SamMMTEntry *mmt, *tmpMMT, *leMMT;
  int error, mmtSize, done, i;
  unsigned addr;

  mmtSize=card->firmwareInfo->mmtSlots*sizeof(SamMMTEntry)+SAM_NROF_SBANKS*sizeof(SamMMTSBank);
  mmt=(SamMMTEntry *)kmalloc(mmtSize, GFP_KERNEL);
  tmpMMT=(SamMMTEntry *)kmalloc(mmtSize, GFP_KERNEL);

  if(!mmt || !tmpMMT) {
    if(mmt)
      kfree(mmt);
    if(tmpMMT)
      kfree(tmpMMT);
    return -ENOMEM;
  }

  memset(mmt, 0, mmtSize);
  memset(tmpMMT, 0, mmtSize);

  if((error=samTalk(card,
		    SamGetMMT, &addr,
		    SamReadMemP, &addr, mmt, mmtSize>>1,
		    SamEndOfScript))<0) {
    kfree(mmt);
    kfree(tmpMMT);
    return error;
  }

#ifndef __LITTLE_ENDIAN
  importMMT(mmt, mmt, card->firmwareInfo->mmtSlots);
#endif

  card->mem.mmtSize=mmtSize;
  card->mem.mmt=mmt;
  card->mem.tmpMMT=tmpMMT;
  card->mem.sbank=(SamMMTSBank *)(mmt+card->firmwareInfo->mmtSlots);
  card->mem.tmpSBank=(SamMMTSBank *)(tmpMMT+card->firmwareInfo->mmtSlots);

  if((card->mem.mmt[0].id&SAM_MMT_ID_MASK)!=SAM_MMT_ID_MEMSIZE)
    return -EIO;

  if(!card->mem.mmt[0].addr) {
    /* MMT doesn't contain correct memory size,
     * we need to probe RAM or use cardMem hint
     */
    if(card->hardwareInfo->probeMem)
      error=(*card->hardwareInfo->probeMem)(card);
    else
      error=samGenericProbeMem(card);
    if(error<0)
      return error;
  }

  memset(&card->ctrlValues, 0, sizeof(card->ctrlValues));
  /* try to restore saved control values
   * and saved harware cache
   */
  done=0;
  for(i=0; !done && i<card->firmwareInfo->mmtSlots; i++) {
    switch(card->mem.mmt[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_SAVED_CTRLS:
      if(card->firmwareInfo->ctrlValuesSize &&
	 (card->mem.mmt[i+1].addr-card->mem.mmt[i].addr)<<1>=card->firmwareInfo->ctrlValuesSize) {
	if(samTalk(card,
		   SamReadMem, card->mem.mmt[i].addr, &card->ctrlValues, card->firmwareInfo->ctrlValuesSize>>1,
		   SamEndOfScript)<0) {
	  printk(KERN_ERR "sam9407[#%d:%s]: can't restore saved control values\n", card->cardIdx, card->hardwareInfo->name);
	  memset(&card->ctrlValues, 0, sizeof(card->ctrlValues));
	}
      }
      break;
    case SAM_MMT_ID_SAVED_HWCACHE:
      if(card->hardwareInfo->backupCacheSize && card->hardwareInfo->restoreCache && 
	 (card->mem.mmt[i+1].addr-card->mem.mmt[i].addr)<<1>=card->hardwareInfo->backupCacheSize) {
	if(samTalk(card,
		   SamReadMem, card->mem.mmt[i].addr, &card->hardwareCache, card->hardwareInfo->backupCacheSize>>1,
		   SamEndOfScript)>=0) {
	  if((error=(*card->hardwareInfo->restoreCache)(card))<0)
	    return error;
	} else {
	  printk(KERN_ERR "sam9407[#%d:%s]: can't restore saved harware cache\n", card->cardIdx, card->hardwareInfo->name);
	  if(card->hardwareInfo->fillCache) {
	    if((error=(*card->hardwareInfo->fillCache)(card))<0)
	      return error;
	  } else
	    memset(&card->hardwareCache, 0, card->hardwareInfo->backupCacheSize);
	}
      }
      break;
    case SAM_MMT_ID_SAVED_HWHINTS:
      if(card->mem.mmt[i+1].addr-card->mem.mmt[i].addr>=sizeof(SamHardwareHints)>>1) {
	if(samTalk(card,
		   SamReadMem, card->mem.mmt[i].addr, &card->hints, sizeof(SamHardwareHints)>>1,
		   SamEndOfScript)<0) {
	  printk(KERN_ERR "sam9407[#%d:%s]: can't restore saved hardware hints\n", card->cardIdx, card->hardwareInfo->name);
	  memset(&card->hints, 0, sizeof(SamHardwareHints));
	}
      }
      break;
    case SAM_MMT_ID_EOM:
      done=1;
      break;
    }
  }

  if(cleanupMMT(card, 0)) {
#ifdef __LITTLE_ENDIAN
    leMMT=card->mem.mmt;
#else /* !__LITTLE_ENDIAN */
    exportMMT(card->mem.tmpMMT, card->mem.mmt, card->firmwareInfo->mmtSlots);
    leMMT=card->mem.tmpMMT;
#endif /* !__LITTLE_ENDIAN */
    if((error=samTalk(card,
		      SamWriteMem, addr, leMMT, card->mem.mmtSize>>1,
		      SamEndOfScript))<0)
      return error;
  }

  if(card->firmwareInfo->haveMidi &&
     (error=samRelocateMidiTable(card))<0)
    return error;

  return 0;
}

void samReleaseMMT(SamCard *card)
{
  SamMMTEntry *mmt, *tmpMMT, *leMMT;
  unsigned addr;

  if(card->mem.mmt) {
    if(card->firmwareInfo->ctrlValuesSize) {
      /* try to backup saved control values */
      if(samAlloc(card, SAM_MMT_ID_SAVED_CTRLS, card->firmwareInfo->ctrlValuesSize>>1, &addr,
		  SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K, NULL, NULL)<0 ||
	 samTalk(card,
		 SamWriteMem, addr, &card->ctrlValues, card->firmwareInfo->ctrlValuesSize>>1,
		 SamEndOfScript)<0)
	printk(KERN_ERR "sam9407[#%d:%s]: can't backup saved control values\n", card->cardIdx, card->hardwareInfo->name);
    }

    if(card->hardwareInfo->backupCacheSize && card->hardwareInfo->restoreCache) {
      /* try to backup harware cache */
      if(samAlloc(card, SAM_MMT_ID_SAVED_HWCACHE, card->hardwareInfo->backupCacheSize>>1, &addr,
		  SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K, NULL, NULL)<0 ||
	 samTalk(card,
		 SamWriteMem, addr, &card->hardwareCache, card->hardwareInfo->backupCacheSize>>1,
		 SamEndOfScript)<0)
	printk(KERN_ERR "sam9407[#%d:%s]: can't backup hardware cache\n", card->cardIdx, card->hardwareInfo->name);
    }
    /* try to backup harware hints */
    if(samAlloc(card, SAM_MMT_ID_SAVED_HWHINTS, sizeof(SamHardwareHints)>>1, &addr,
		SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K, NULL, NULL)<0 ||
       samTalk(card,
	       SamWriteMem, addr, &card->hints, sizeof(SamHardwareHints)>>1,
	       SamEndOfScript)<0)
      printk(KERN_ERR "sam9407[#%d:%s]: can't backup hardware hints\n", card->cardIdx, card->hardwareInfo->name);

    if(cleanupMMT(card, 1)) {
#ifdef __LITTLE_ENDIAN
      leMMT=card->mem.mmt;
#else /* !__LITTLE_ENDIAN */
      exportMMT(card->mem.tmpMMT, card->mem.mmt, card->firmwareInfo->mmtSlots);
      leMMT=card->mem.tmpMMT;
#endif /* !__LITTLE_ENDIAN */
      if(samTalk(card,
		 SamGetMMT, &addr,
		 SamWriteMemP, &addr, leMMT, card->mem.mmtSize>>1,
		 SamEndOfScript)<0)
	printk(KERN_ERR "sam9407[#%d:%s]: can't cleanup MMT\n", card->cardIdx, card->hardwareInfo->name);
    }
  }
  memset(&card->ctrlValues, 0, sizeof(card->ctrlValues));

  mmt=card->mem.mmt;
  tmpMMT=card->mem.tmpMMT;
  card->mem.mmt=NULL;
  card->mem.sbank=NULL;
  card->mem.tmpMMT=NULL;
  card->mem.tmpSBank=NULL;

  if(mmt)
    kfree(mmt);
  if(tmpMMT)
    kfree(tmpMMT);
}

static int findBestSlot(SamCard *card, SamMMTEntry *mmt, int words, unsigned align, unsigned boundary)
{
  struct {
    unsigned idx, addr, size, avail;
  } best, search;
  unsigned entries, alignWords, alignMask, boundaryWords, boundaryMask;

  if(words<=0)
    return -EINVAL;

  alignWords=align-1;
  alignMask=~alignWords;
  boundaryWords=words-1;
  boundaryMask=~(boundary-1);

  best.idx=0;
  for(search.idx=0; search.idx<card->firmwareInfo->mmtSlots; search.idx++) {
    if((mmt[search.idx].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
    if((mmt[search.idx].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_FREE) {
      search.addr=(mmt[search.idx].addr+alignWords)&alignMask;

      /* if the space would exceed the page boundary
       * let the address start at next page
       */
      if((search.addr&boundaryMask) != ((search.addr+boundaryWords)&boundaryMask))
	search.addr=(search.addr+boundaryWords)&boundaryMask;

      if(search.addr>=mmt[search.idx+1].addr)
	continue;

      search.size=mmt[search.idx+1].addr-mmt[search.idx].addr;
      search.avail=mmt[search.idx+1].addr-search.addr;

      if(search.avail>=words &&
	 (!best.idx || search.size<best.size))
	memcpy(&best, &search, sizeof(best));
    }
  }

  if(!best.idx)
    /* card ran out of memory */
    return -ENOSPC;

  if(best.avail==best.size && best.avail==words)
    /* fits exactly, no splitting needed */
    return best.idx;

  entries=search.idx+1;

  if(best.avail!=best.size) {
    if(best.avail==words) {
      /* fits exactly into second slot,
       * split one entry into 2
       */
      if(entries+1>=card->firmwareInfo->mmtSlots)
	/* no more space in MMT */
	return -ENOSPC;

      memmove(mmt+best.idx+1, mmt+best.idx, (entries-best.idx)*sizeof(SamMMTEntry));
      mmt[best.idx+1].addr=best.addr;
      return best.idx+1;
    } else {
      /* split one entry into 3 */
      if(entries+2>=card->firmwareInfo->mmtSlots)
	/* no more space in MMT */
	return -ENOSPC;
      
      memmove(mmt+best.idx+2, mmt+best.idx, (entries-best.idx)*sizeof(SamMMTEntry));
      mmt[best.idx+1].id=SAM_MMT_ID_FREE;
      mmt[best.idx+1].addr=best.addr;
      mmt[best.idx+2].addr=best.addr+words;
      return best.idx+1;
    }
  } else {
    /* split one entry into 2 */
    if(entries+1>=card->firmwareInfo->mmtSlots)
      /* no more space in MMT */
      return -ENOSPC;

    memmove(mmt+best.idx+1, mmt+best.idx, (entries-best.idx)*sizeof(SamMMTEntry));
    mmt[best.idx+1].addr=best.addr+words;
    return best.idx;
  }
}

int samAlloc(SamCard *card, int id, int words, unsigned *ptr, unsigned align, unsigned boundary,
	     int (*callback)(SamCard *card, unsigned addr, void *closure), void *closure)
{
  int error, idx;
  unsigned midiSize, size, n, i, j, mmtIdx, mmtCopyIdx, addr;

  down(&card->mem.accessLock);

  /* compress free slots */
  mmtIdx=mmtCopyIdx=0;
  for(i=j=0; i<card->firmwareInfo->mmtSlots; i++, j++) {
    memcpy(card->mem.tmpMMT+j, card->mem.mmt+i, sizeof(SamMMTEntry));
    switch(card->mem.mmt[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_MMT:
      mmtIdx=j;
      break;
    case SAM_MMT_ID_MMT_COPY:
      mmtCopyIdx=j;
      break;
    case SAM_MMT_ID_FREE:
      while((card->mem.mmt[i+1].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_FREE)
	i++;
      break;
    }
    if((card->mem.mmt[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
  }

  if(mmtIdx && mmtCopyIdx && id!=SAM_MMT_ID_MIDI_MT) {
    /* just exchange MMT copy with the current */
    card->mem.tmpMMT[mmtIdx].id=SAM_MMT_ID_MMT_COPY;
    card->mem.tmpMMT[mmtIdx+1].id=SAM_MMT_ID_MIDI_MT_COPY;
    card->mem.tmpMMT[mmtCopyIdx].id=SAM_MMT_ID_MMT;
    card->mem.tmpMMT[mmtCopyIdx+1].id=SAM_MMT_ID_MIDI_MT;
  } else {
    /* mark MMT, MIDI_MT and their copies to be released
     */
    for(i=0; i<card->firmwareInfo->mmtSlots; i++) {
      switch(card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK) {
      case SAM_MMT_ID_MMT:
      case SAM_MMT_ID_MIDI_MT:
      case SAM_MMT_ID_MIDI_MT_EXT:
      case SAM_MMT_ID_MMT_COPY:
      case SAM_MMT_ID_MIDI_MT_COPY:
	card->mem.tmpMMT[i].id=(card->mem.tmpMMT[i].id&~SAM_MMT_ID_MASK)|SAM_MMT_ID_TMP_RESERVED;
	break;
      }
      if((card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
	break;
    }

    /* need to relocate MMT,
     * so we'll lose old Midi Mapping Table too
     */
    if(id==SAM_MMT_ID_MIDI_MT)
      midiSize=words<<1;
    else
      midiSize=0;
    size=(card->mem.mmtSize+midiSize)>>1;
    if(size>64<<10)
      return -ENOSPC;

    /* now allocate MMT and a copy */
    for(n=0; n<2; n++) {
      if((idx=findBestSlot(card, card->mem.tmpMMT, size,
			   SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K))<0) {
	up(&card->mem.accessLock);
	return idx;
      }
      /* search of EOM marker, counting the number of entries so far */
      for(i=0; i<card->firmwareInfo->mmtSlots; i++)
	if((card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM) {
	  i++;
	  break;
	}
      /* need space for one more entry */
      if(i+1>card->firmwareInfo->mmtSlots)
	return -ENOSPC;

      /* splice the MMT entry */
      memmove(card->mem.tmpMMT+idx+2, card->mem.tmpMMT+idx+1, (i-idx-1)*sizeof(SamMMTEntry));
      
      /* the MMT */
      card->mem.tmpMMT[idx].id=n==0 ? SAM_MMT_ID_MMT : SAM_MMT_ID_MMT_COPY;
      
      /* the Midi Mapping Table */
      card->mem.tmpMMT[idx+1].id=n==0 ? SAM_MMT_ID_MIDI_MT : SAM_MMT_ID_MIDI_MT_COPY;
      card->mem.tmpMMT[idx+1].addr=card->mem.tmpMMT[idx].addr+(card->mem.mmtSize>>1);
    }
  }

  /* If Midi Mapping Table is requested
   * assignment of addr will be delayed
   */
  if(id!=SAM_MMT_ID_MIDI_MT) {
    /* find a free slot for the data */
    if((idx=findBestSlot(card, card->mem.tmpMMT, words, align, boundary))<0) {
      up(&card->mem.accessLock);
      return idx;
    }
    card->mem.tmpMMT[idx].id=id;
    addr=card->mem.tmpMMT[idx].addr;
  } else {
    idx=0;
    addr=0;
  }

  /* release TMP_RESERVED markers and release
   * stale entries with the same id as being requested too
   */
  for(i=0; i<card->firmwareInfo->mmtSlots; i++) {
    if((card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_TMP_RESERVED ||
       (idx && i!=idx && (card->mem.tmpMMT[i].id&~SAM_MMT_ROM_MASK)==id)) {
      if(card->mem.tmpMMT[i].id&SAM_MMT_ROM_MASK)
	card->mem.tmpMMT[i].id=SAM_MMT_ID_RESERVED|SAM_MMT_ROM_MASK;
      else
	card->mem.tmpMMT[i].id=SAM_MMT_ID_FREE;
    }
    if((card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
  }

  /* compress new MMT again and search for mmtIdx & mmtCopyIdx */
  mmtIdx=mmtCopyIdx=0;
  for(i=j=0; i<card->firmwareInfo->mmtSlots; i++, j++) {
    if(i!=j)
      memcpy(card->mem.tmpMMT+j, card->mem.tmpMMT+i, sizeof(SamMMTEntry));
    switch(card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_MMT:
      mmtIdx=j;
      break;
    case SAM_MMT_ID_MMT_COPY:
      mmtCopyIdx=j;
      break;
    case SAM_MMT_ID_FREE:
      while((card->mem.tmpMMT[i+1].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_FREE)
	i++;
      break;
    }
    if((card->mem.tmpMMT[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM) {
      j++;
      break;
    }
  }

  if(j<card->firmwareInfo->mmtSlots)
    memset(card->mem.tmpMMT+j, 0, (card->firmwareInfo->mmtSlots-j)*sizeof(SamMMTEntry));

  /* delayed assignment of addr */
  if(id==SAM_MMT_ID_MIDI_MT)
    addr=card->mem.tmpMMT[mmtIdx+1].addr;

  if(callback) {
    if((error=(*callback)(card, addr, closure))<0) {
      up(&card->mem.accessLock);
      return error;
    }
    if(id==SAM_MMT_ID_MIDI_MT && mmtCopyIdx) {
      /* apply callback to second midi mapping table too */
      if((error=(*callback)(card, card->mem.tmpMMT[mmtCopyIdx+1].addr, closure))<0) {
	up(&card->mem.accessLock);
	return error;
      }
    }
  }

  if(ptr)
    *ptr=addr;

  /* copy soundbank information */
  memcpy(card->mem.tmpSBank, card->mem.sbank, SAM_NROF_SBANKS*sizeof(SamMMTSBank));

  /* write new MMT back */
#ifndef __LITTLE_ENDIAN
  exportMMT(card->mem.tmpMMT, card->mem.tmpMMT, card->firmwareInfo->mmtSlots);
#endif
  addr=card->mem.tmpMMT[mmtIdx].addr;
  if((error=samTalk(card,
		    SamWriteMem, addr, card->mem.tmpMMT, card->mem.mmtSize>>1,
		    SamSetMMT, addr,
		    SamEndOfScript))<0) {
    up(&card->mem.accessLock);
    return error;
  }

#ifdef __LITTLE_ENDIAN
  memcpy(card->mem.mmt, card->mem.tmpMMT, card->mem.mmtSize);
#else /* !__LITTLE_ENDIAN */
  importMMT(card->mem.mmt, card->mem.tmpMMT, card->firmwareInfo->mmtSlots);
#endif /* !__LITTLE_ENDIAN */

  up(&card->mem.accessLock);

  return id;
}

int samFree(SamCard *card, int id, int mask)
{
  int i;

  down(&card->mem.accessLock);

  for(i=0; i<card->firmwareInfo->mmtSlots; i++) {
    if((card->mem.mmt[i].id&mask)==id) {
      if(card->mem.mmt[i].id&SAM_MMT_ROM_MASK)
	card->mem.mmt[i].id=SAM_MMT_ID_RESERVED|SAM_MMT_ROM_MASK;
      else
	card->mem.mmt[i].id=SAM_MMT_ID_FREE;
    }
    if((card->mem.mmt[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
  }

  up(&card->mem.accessLock);

  return 0;
}

int samFindMMT(SamCard *card, int id, int mask, unsigned *ptr, unsigned *len)
{
  int result, i;

  down(&card->mem.accessLock);

  result=0;
  for(i=0; i<card->firmwareInfo->mmtSlots; i++) {
    if((card->mem.mmt[i].id&SAM_MMT_ID_MASK)==SAM_MMT_ID_EOM)
      break;
    if((card->mem.mmt[i].id&mask)==id) {
      if(ptr)
	*ptr=card->mem.mmt[i].addr;
      if(len)
	*len=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
      result=1;
      break;
    }
  }

  up(&card->mem.accessLock);

  return result;
}

void samGetMemInfo(SamCard *card, SamDriverInfo *driverInfo)
{
  int done, i;
  down(&card->mem.accessLock);

  driverInfo->memTotal=0;
  driverInfo->memFree=0;
  driverInfo->memSBanks=0;
  driverInfo->memMod=0;
  driverInfo->memAudio=0;

  if((card->mem.mmt[0].id&SAM_MMT_ID_MASK)!=SAM_MMT_ID_MEMSIZE) {
    up(&card->mem.accessLock);
    return;
  }

  done=0;
  for(i=1; !done && i<card->firmwareInfo->mmtSlots; i++) {
    switch(card->mem.mmt[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_FREE:
      driverInfo->memFree+=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
      break;
    case SAM_MMT_ID_MIDI_PAR:
    case SAM_MMT_ID_MIDI_PCM:
      driverInfo->memSBanks+=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
      break;
    case SAM_MMT_ID_STAT_WAVE:
      driverInfo->memMod+=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
      break;
    case SAM_MMT_ID_STR_WAVE:
      driverInfo->memAudio+=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
      break;
    case SAM_MMT_ID_EOM:
      done=1;
      break;
    }
    if(!done && !(card->mem.mmt[i].id&SAM_MMT_ROM_MASK))
      driverInfo->memTotal+=card->mem.mmt[i+1].addr-card->mem.mmt[i].addr;
  }

  up(&card->mem.accessLock);
}

#ifdef SAM_DEBUG
int samDebugMMTInfo(SamCard *card, SamMMTInfo *mmtInfo)
{
  int error;
  unsigned size, sizeWanted;
  char *data;

  if((error=verify_area(VERIFY_WRITE, mmtInfo, sizeof(SamMMTInfo)))<0)
    return error;

  if(SAM_GET_USER(data, &mmtInfo->data) ||
     SAM_GET_USER(size, &mmtInfo->size))
    return -EFAULT;

  sizeWanted=card->firmwareInfo->mmtSlots*sizeof(SamMMTEntry);
  if(sizeWanted<size) {
    size=sizeWanted;
    if(SAM_PUT_USER(size, &mmtInfo->size))
      return -EFAULT;
  }

  if((error=verify_area(VERIFY_WRITE, data, size))<0)
    return error;

  down(&card->mem.accessLock);
  if(SAM_MEMCPY_TOFS(data, card->mem.mmt, size))
    error=-EFAULT;
  up(&card->mem.accessLock);

  if(error<0)
    return error;

  return size;
}
#endif
