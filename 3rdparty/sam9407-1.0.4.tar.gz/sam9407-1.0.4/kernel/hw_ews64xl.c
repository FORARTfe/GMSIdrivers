/*
  Copyright (C) 1999 by Florian Weimer.
  Portions Copyright (C) 1998 by TerraTec Electronic GmbH.

  Thanks to TerraTec Electronic GmbH and especially Clemens
  Lengersdorf for providing the necessary information.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/delay.h>
#include <asm/io.h>

#include "driver.h"
#include "io.h"
#include "i2c.h"
#include "alloc.h"

#ifdef SAM_ENABLE_HW_EWS64XL

static int ews64xlProbeMem(SamCard *card);
static int ews64xlReset(SamCard *card);
static int ews64xlFillCache(SamCard *card);
static int ews64xlRestoreCache(SamCard *card);
static int ews64xlCtrlIsAvail(struct SamCard *card, SamMixerHWId mixerId);
static int ews64xlHookIsAvail(struct SamCard *card, SamHWHookId hookId);

static int ews64xlSetMasterOutputVolume(SamCard *card, int out, int volL, int volR);

static int ews64xlAudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input);
static int ews64xlExternalClockHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *coaxOpt);
static int ews64xlDigitalInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *coaxOpt);
static int ews64xlDigitalOutCopyInhibitHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *onOff);
static int ews64xlDigitalOutGenerationHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *onOff);
static int ews64xlDigitalInRateHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *rate);
static int ews64xlAnalogOutVolHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *vol);

static int ews64xlSampleRateHook(struct SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *sampleRate);
static int ews64xlMinus6dBHook(SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *onOff);

static SamHWCtrlVendorInfo ews64xlCtrlInfo[]={
  {					/* SAM_MIXER_HW_ID_AUDIO_INPUT */
    ews64xlAudioInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_AUDIO_OUTPUT */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_MIDI_ROUTE */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_EXTERNAL_CLOCK */
    ews64xlExternalClockHandler,	/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_INPUT */
    ews64xlDigitalInputHandler,		/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT */
    ews64xlDigitalOutCopyInhibitHandler,/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION */
    ews64xlDigitalOutGenerationHandler,	/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_DIGITAL_IN_RATE */
    ews64xlDigitalInRateHandler,	/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_ANALOG_OUT_VOL */
    ews64xlAnalogOutVolHandler,		/* vendorHandler */
    3,					/* addrTagLimit */
  },
  {					/* SAM_MIXER_HW_ID_BOX_MIDI_IN */
    NULL,				/* vendorHandler */
  },
  {					/* SAM_MIXER_HW_ID_BOX_CHANNEL */
    NULL,				/* vendorHandler */
  },
};

static SamHWHook ews64xlHooks[]={
  ews64xlSampleRateHook,		/* SamHWHookIdSampleRate */
  NULL,					/* SamHWHookIdMasterMute */
  ews64xlMinus6dBHook,			/* SamHWHookIdMinus6dB */
};

SamHardwareInfo samEWS64XLHardwareInfo={
  "ews64xl",			/* name */
  NULL,				/* processHints */
  ews64xlReset,			/* reset */
  NULL,				/* firmwareDetected */
  ews64xlProbeMem,		/* probeMem */
  ews64xlFillCache,		/* fillCache */
  SAM_OFFSET_OF(SamEWS64XLHardwareCache, pcf8574),	/* backupCacheSize */
  ews64xlRestoreCache,		/* restoreCache */
  ews64xlCtrlIsAvail,		/* ctrlIsAvail */
  ews64xlCtrlInfo,		/* ctrlInfo */
  ews64xlHookIsAvail,		/* hookIsAvail */
  ews64xlHooks,			/* hooks */
};

static SamPnpResource ews64xlPnpResources[]={
  {				/* SamHardwareResPort */
    0,				/* isOptional */
    "sam9407 (EWS64XL)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResIrq */
    1,				/* isOptional */
    "sam9407 (EWS64XL)",
    4, 0,			/* ldn, idx */
  },
  {				/* SamHardwareResAuxPort0 */
    0,				/* isOptional */
    "sam9407 (EWS64XL Dig. Ctrl)",
    5, 0,			/* ldn, idx */
    2,				/* extent */
  },
  {				/* SamHardwareResAuxPort1 */
    1,				/* isOptional */
    NULL,
  },
};

SamPnPInfo samEWS64XLPnPInfo={
  0x36A8630E,
  &samEWS64XLHardwareInfo,
  ews64xlPnpResources,
};

static int ews64CtrlOut0(SamCard *card, int sda, int scl)
{
  udelay(200);
  outb(0xF9|(sda<<2)|(scl<<1), card->auxPort0);
  return 0;
}

static int ews64CtrlIn0(SamCard *card)
{
  udelay(200);
  return (inb(card->auxPort0)>>2)&1;
}

static int ews64CtrlOut1(SamCard *card, int sda, int scl)
{
  udelay(200);
  outb(0xF5|(sda<<3)|(scl<<1), card->auxPort0);
  return 0;
}

static int ews64CtrlIn1(SamCard *card)
{
  udelay(200);
  return (inb(card->auxPort0)>>3)&1;
}

static int ews64xlSetSimmBits(SamCard *card, char simmBits)
{
  card->hardwareCache.ews64xl.pcf8574[1] =
    (card->hardwareCache.ews64xl.pcf8574[1] & ~0x03)
    | simmBits;
  return samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x21,
		     &card->hardwareCache.ews64xl.pcf8574[1], 1);
}

static void DBG_EWS_Poke_Mem(SamCard *card, unsigned addr, unsigned short what)
{
  samTalk(card,
	  SamWriteMem, addr >> 1, &what, 1,
	  SamEndOfScript);
}

static unsigned DBG_EWS_Peek_Mem(SamCard *card, unsigned addr)
{
  unsigned short data;
  samTalk(card,
	  SamReadMem, addr >> 1, &data, 1,
	  SamEndOfScript);
  return data;
}

/* Memory probing routine donated by TerraTec.	Works only with L/XL
   version 1.2. */
static unsigned ews64xlGetMemBlocks(SamCard *pHw)
{
  struct MemBlDefTyp {
    unsigned short Type;
    unsigned Address;
  };
  struct MemBlDefTyp MemTable[32];
  unsigned EWS_First_Offset;
  unsigned w0 = 0, w1 = 0;
  unsigned i, z;
  unsigned dwRet = 0;
  int bCondition = 0;

  EWS_First_Offset = 0x400;
  i = 0;
  MemTable[i].Type = 0;
  do {
    z = 100;
    /* Check for valid Memory */
    do {
      udelay(100);
      w0 = DBG_EWS_Peek_Mem(pHw, EWS_First_Offset);
      DBG_EWS_Poke_Mem(pHw, EWS_First_Offset, (unsigned short)(w0 ^ 0x55AA));
      w1 = DBG_EWS_Peek_Mem(pHw, EWS_First_Offset);
      DBG_EWS_Poke_Mem(pHw, EWS_First_Offset, (unsigned short)w0);
      if (z < 10) {
	dwRet = 0;
      }
    }
    while (((w0 == -1) || (w1 == -1)) && (z-- > 0));
    if	((w0 == -1) | (w1 == -1)) {
      return dwRet;
    }
    if ((w0 ^ 0x55AA) == w1) {
      /* RAM */
      w0 = 0x0001;
    } else {
      /* ROM */
      w0 = 0x0082;
    }
    if (MemTable[i].Type != w0) {
      i++;
      MemTable[i].Type = (unsigned short)w0;
      MemTable[i].Address = EWS_First_Offset >> 1;
      MemTable[i + 1].Type = 0xFFFF;
    }
    if (i > 254) return dwRet;
    EWS_First_Offset = ((EWS_First_Offset >> 15) + 1) << 15;
    bCondition = (EWS_First_Offset >= 64*1024*1024)
      || ((MemTable[i].Type != 0x0001)
	  && ((EWS_First_Offset >> 1) - MemTable[i].Address > 4*1024*1024));
  }
  while (!bCondition);
  if (MemTable[i].Type != 0x0001) {
    /* IF Last Type was ROM, dwOfs is total RAM size */
    MemTable[i].Type = 0xFFFF;
    MemTable[0].Address = MemTable[i].Address;
    dwRet = MemTable[i].Address + MemTable[i].Address;
  } else {
    /* IF Last Type was RAM, FirstOfs is total RAM size */
    i++;
    MemTable[i].Type = 0xFFFF;
    MemTable[i].Address = EWS_First_Offset >> 1;
    MemTable[0].Address = EWS_First_Offset >> 1;
    dwRet = EWS_First_Offset;
  }
  return dwRet;
}

/* Detect modulo by SIMM card, addr1 and addr2 are given in MB.
   Donated by TerraTec. */
static int ews64xlDetectModulo(SamCard *pHw, unsigned Adr1, unsigned Adr2)
{
  DBG_EWS_Poke_Mem(pHw, Adr1*1024*1024, 0);
  DBG_EWS_Poke_Mem(pHw, Adr2*1024*1024,1);
  return (DBG_EWS_Peek_Mem(pHw, Adr1*1024*1024) != 0);
}

/* SIMM detection routine donated by TerraTec. */
static int ews64xlProbeMem(SamCard *card)
{
  int error;
  SamDriverInfo driverInfo;
  unsigned sizeInMB, sizeInMB2;
  const char * simmMsg = "64 MB";

  if (!card->hardwareCache.ews64xl.pcf8574_active[1]) {
    /* Not an EWS 64 L/XL revision 1.2, do only standard probing. */
    return samGenericProbeMem(card);
  }
  /* Reset has already set decoding to 16 MB SIMMs, as suggested by
     TerraTec. */
  sizeInMB = ews64xlGetMemBlocks(card)>>20;

  if (sizeInMB == 0) {
    printk(KERN_ERR "sam9407[#%d:%s]: no memory on board, giving up\n", card->cardIdx, card->hardwareInfo->name);
    return -ENODEV;
  }

  if (sizeInMB == 2) {
    ews64xlSetSimmBits(card, 0);
  } else if (sizeInMB == 18) {
    /* 4/8S/16/64MB; Check for MODULO */
    if (ews64xlDetectModulo(card, 2, 4)) {
      /* MODULO from 2M to 4M =>4M SIMM */
      simmMsg = "4 MB";
      ews64xlSetSimmBits(card, 0);
    } else if (ews64xlDetectModulo(card, 2, 6)) {
      /* MODULO from 10M to 14M =>8MS SIMM */
      simmMsg = "8 MB single-sided";
      ews64xlSetSimmBits(card, 1);
    } else {
      /* 16/64MB; Check for MODULO */
      ews64xlSetSimmBits(card, 3);
    }
    if (ews64xlDetectModulo(card, 2, 10)) {
      /* MODULO from 24M to 40M =>16M SIMM */
      simmMsg = "16 MB";
      ews64xlSetSimmBits(card, 2);
    }
    /* ELSE 64 MB SIMM */
  } else if (sizeInMB == 34) {
    /* 8D/32MB; Check for MODULO */
    if (ews64xlDetectModulo(card, 18, 20)) {
      /* MODULO from 18M to 20M =>8MD SIMM */
      simmMsg = "8 MB double-sided";
      ews64xlSetSimmBits(card, 0);
    }
    /* ELSE 32 MB SIMM */
    simmMsg = "32 MB";
  } else {
    printk(KERN_ERR "sam9407[#%d:%s]: SIMM detection failed, giving up\n", card->cardIdx, card->hardwareInfo->name);
    return -ENODEV;
  }
  printk(KERN_INFO "sam9407[#%d:%s]: %s SIMM detected\n",
	 card->cardIdx, card->hardwareInfo->name, simmMsg);

  /* Use standard probing routine to fill MMT */
  if ((error=samGenericProbeMem(card))<0) {
    return error;
  }
  samGetMemInfo(card, &driverInfo);
  sizeInMB = driverInfo.memTotal>>19;
  sizeInMB2 = ews64xlGetMemBlocks(card)>>20;
  if (sizeInMB == sizeInMB2) {
    printk(KERN_INFO "sam9407[#%d:%s]: detected %d MB total\n",
	   card->cardIdx, card->hardwareInfo->name, sizeInMB);
  } else {
    printk(KERN_ERR "sam9407[#%d:%s]: memory detection mismatch -- %d vs. %d MB\n",
	   card->cardIdx, card->hardwareInfo->name, sizeInMB, sizeInMB2);
    return -ENODEV;
  }
  return 0;
}

static int ews64xlReset(SamCard *card)
{
  int error;

  card->hardwareCache.ews64xl.pcf8574[0]
    = 0x03			/* disable MIDI on joystick port */
    | 0x08			/* 44.1 kHz internal sample rate */
    | 0x10;			/* ADC output to SAM9407 input */
  if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			   &card->hardwareCache.ews64xl.pcf8574[0], 1))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't write to digital control port (i0)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }

  card->hardwareCache.ews64xl.pcf8574[1]
    = 0x02			/* 16 MB SIMM, will be corrected by
				   ews64xlProbeMem */
    | 0x0c;			/* don't activate -6 dB firmware */
  if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x21,
			   &card->hardwareCache.ews64xl.pcf8574[1], 1))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't write to digital control port (i1)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }

  if (card->hardwareCache.ews64xl.pcf8574_active[7]) {
    /* We've got a front module. */

    card->hardwareCache.ews64xl.pcf8574[7]
      = 0x60;			  /* set copy protection and generation flag
				     on digital output. */
    if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			     &card->hardwareCache.ews64xl.pcf8574[7], 1))<0) {
      printk(KERN_WARNING "sam9407[#%d:%s]: couldn't initialize EWS 64 XL front panel\n",
	     card->cardIdx, card->hardwareInfo->name);
    }
  }

  /* sending reset signal to sam9407 */
  card->hardwareCache.ews64xl.pcf8574[0] |= 0x80;
  if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			   &card->hardwareCache.ews64xl.pcf8574[0], 1))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't write to digital control port (i2)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  udelay(1000);
  card->hardwareCache.ews64xl.pcf8574[0] &= ~0x80;
  if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			   &card->hardwareCache.ews64xl.pcf8574[0], 1))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't write to digital control port (i3)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  udelay(1000);			/* give sam9407 some time to recover */

  return 0;
}

static int ews64xlWriteTEA6320(SamCard *card, int bus, char reg, char byte)
{
  char data[2];

  data[0] = reg;
  data[1] = byte;

  return samI2CWrite(card,
		     (bus == 0) ? ews64CtrlOut0 : ews64CtrlOut1,
		     (bus == 0) ? ews64CtrlIn0 : ews64CtrlIn1,
		     0x40, data, 2);
}

static int ews64xlFillCache(SamCard *card)
{
  int reg, error;

  for (reg = 0; reg < 8; reg++) {
    card->hardwareCache.ews64xl.pcf8574_active[reg] =
      samI2CRead(card, ews64CtrlOut0, ews64CtrlIn0, 0x20 + reg,
		 &card->hardwareCache.ews64xl.pcf8574[reg], 1)>=0;
  }

  if (!card->hardwareCache.ews64xl.pcf8574_active[0]) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not detect first EWS64 L/XL control register\n",
	   card->cardIdx, card->hardwareInfo->name);
    return -ENODEV;
  }

  if (card->hardwareCache.ews64xl.pcf8574_active[1]) {
    if (card->hardwareCache.ews64xl.pcf8574_active[2]) {
      printk(KERN_ERR "sam9407[#%d:%s]: no known EWS card -- both control registers 0x21 and 0x22 detected\n",
	     card->cardIdx, card->hardwareInfo->name);
      return -ENODEV;
    } else {
      printk(KERN_INFO "sam9407[#%d:%s]: EWS 64 L/XL hardware revision 1.2 detected\n",
	     card->cardIdx, card->hardwareInfo->name);
    }
  } else {
    if (card->hardwareCache.ews64xl.pcf8574_active[2]) {
      printk(KERN_INFO "sam9407[#%d:%s]: EWS 64 L/XL hardware revision 1.0 or 1.1 detected\n",
	     card->cardIdx, card->hardwareInfo->name);
      printk(KERN_ERR "sam9407[#%d:%s]: EWS 64 L/XL revision 1.0 and 1.1 not yet supported, sorry\n",
	     card->cardIdx, card->hardwareInfo->name);
      return -ENODEV;
    } else {
      printk(KERN_ERR "sam9407[#%d:%s]: could not detect second EWS64 L/XL control register\n",
	     card->cardIdx, card->hardwareInfo->name);
      return -ENODEV;
    }
  }

  if (card->hardwareCache.ews64xl.pcf8574_active[7]) {
    if (card->hardwareCache.ews64xl.pcf8574_active[5]) {
      printk(KERN_INFO "sam9407[#%d:%s]: EWS 64 L/XL Digital Extension R detected\n",
	     card->cardIdx, card->hardwareInfo->name);
      printk(KERN_WARNING "sam9407[#%d:%s]: EWS64 Digital Extension R not yet supported\n",
	     card->cardIdx, card->hardwareInfo->name);
    } else {
      printk(KERN_INFO "sam9407[#%d:%s]: EWS64 XL front panel detected\n",
	     card->cardIdx, card->hardwareInfo->name);
    }
  } else {
    if (card->hardwareCache.ews64xl.pcf8574_active[5]) {
      printk(KERN_WARNING "sam9407[#%d:%s]: unknown EWS configuration detected (0x25 responding)\n",
	     card->cardIdx, card->hardwareInfo->name);
    } else {
      printk(KERN_INFO "sam9407[#%d:%s]: no EWS 64 L/XL extensions detected\n",
	     card->cardIdx, card->hardwareInfo->name);
    }
  }
  if (card->hardwareCache.ews64xl.pcf8574_active[3]) {
    printk(KERN_WARNING "sam9407[#%d:%s]: unknown EWS configuration detected (0x23 responding)\n",
	   card->cardIdx, card->hardwareInfo->name);
  }
  if (card->hardwareCache.ews64xl.pcf8574_active[4]) {
    printk(KERN_WARNING "sam9407[#%d:%s]: unknown EWS configuration detected (0x24 responding)\n",
	   card->cardIdx, card->hardwareInfo->name);
  }
  if (card->hardwareCache.ews64xl.pcf8574_active[6]) {
    printk(KERN_WARNING "sam9407[#%d:%s]: unknown EWS configuration detected (0x26 responding)\n",
	   card->cardIdx, card->hardwareInfo->name);
  }

  /* we can't read the TEA6320 registers, so fill them with known values. */
  if ((error=ews64xlSetMasterOutputVolume(card, 0, 0, 0))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not set master output volume (1)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  if ((error=ews64xlSetMasterOutputVolume(card, 1, 0, 0))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not set master output volume (2)\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  /* set unused registers to default values */
  if ((error=ews64xlWriteTEA6320(card, 0, 0x01, 0x00))<0 ||
      (error=ews64xlWriteTEA6320(card, 0, 0x02, 0x00))<0 ||
      (error=ews64xlWriteTEA6320(card, 0, 0x05, 0x11))<0 ||
      (error=ews64xlWriteTEA6320(card, 0, 0x06, 0x11))<0 ||
      (error=ews64xlWriteTEA6320(card, 1, 0x03, 0x00))<0 ||
      (error=ews64xlWriteTEA6320(card, 1, 0x04, 0x00))<0 ||
      (error=ews64xlWriteTEA6320(card, 1, 0x05, 0x11))<0 ||
      (error=ews64xlWriteTEA6320(card, 1, 0x06, 0x11))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not write unused TEA6320 registers\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }

  card->hardwareCache.ews64xl.tea6320_07[0] = 0x06;
  if ((error=ews64xlWriteTEA6320(card, 0, 0x07, 0x06))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not set Out1 to SAM9407\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }
  card->hardwareCache.ews64xl.tea6320_07[1] = 0x07;
  if ((error=ews64xlWriteTEA6320(card, 1, 0x07, 0x07))<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: could not set sam9407 input to codec\n",
	   card->cardIdx, card->hardwareInfo->name);
    return error;
  }

  return 0;
}

/* restore the hardware cache from saved values */
static int ews64xlRestoreCache(SamCard *card)
{
  int error, i;

  for(i=0; i<2; i++)
    if ((error=ews64xlWriteTEA6320(card, i, 0x07, card->hardwareCache.ews64xl.tea6320_07[i]))<0) {
      printk(KERN_ERR "sam9407[#%d:%s]: could not write TEA6320 registers\n",
	     card->cardIdx, card->hardwareInfo->name);
      return error;
    }
  for(i=0; i<2; i++)
    if ((error=ews64xlSetMasterOutputVolume(card, i, card->hardwareCache.ews64xl.volume[i][0], card->hardwareCache.ews64xl.volume[i][1]))<0) {
      printk(KERN_ERR "sam9407[#%d:%s]: could not set master output volume (%d)\n",
	     card->cardIdx, card->hardwareInfo->name, i+1);
      return error;
    }
  return 0;
}

static int ews64xlCtrlIsAvail(struct SamCard *card, SamMixerHWId mixerId)
{
  switch(mixerId) {
  case SAM_MIXER_HW_ID_AUDIO_INPUT:
  case SAM_MIXER_HW_ID_ANALOG_OUT_VOL:
    return 1;
  case SAM_MIXER_HW_ID_EXTERNAL_CLOCK:
  case SAM_MIXER_HW_ID_DIGITAL_INPUT:
  case SAM_MIXER_HW_ID_DIGITAL_OUT_COPY_INHIBIT:
  case SAM_MIXER_HW_ID_DIGITAL_OUT_GENERATION:
  case SAM_MIXER_HW_ID_DIGITAL_IN_RATE:
    return card->hardwareCache.ews64xl.pcf8574_active[7];
    break;
  default:
    return 0;
  }
}

static int ews64xlHookIsAvail(struct SamCard *card, SamHWHookId hookId)
{
  switch(hookId) {
  case SamHWHookIdSampleRate:
    return 1;
  case SamHWHookIdMinus6dB:
    return card->hardwareCache.ews64xl.pcf8574_active[1];
  default:
    return 0;
  }
}

static int ews64xlSetMasterOutputVolume(SamCard *card, int out, int volL, int volR)
{
  int error, volMain, adjL, adjR, intVolL, intVolR;

  /*  clip values if necessary */
  if (volL > 20) volL = 20;
  if (volL < -94) volL = -94;
  if (volR > 20) volR = 20;
  if (volR < -94) volR = -94;

  intVolL = volL + 0xeb;
  intVolR = volR + 0xeb;
  volMain = (intVolL > intVolR) ? intVolL : intVolR;
  if (volMain < 0xcc) {
    /* volMain has to be 0xcc or higher. */
    volMain = 0xcc;
  }

  adjL = 0x3f - volMain + intVolL;
  if (adjL < 0x00) adjL = 0;
  if (adjL > 0x3f) adjL = 0x3f;
  adjR = 0x3f - volMain + intVolR;
  if (adjR < 0x00) adjR = 0;
  if (adjR > 0x3f) adjR = 0x3f;

  switch (out) {
  case 0:
    if ((error=ews64xlWriteTEA6320(card, 0, 0x00, volMain))<0 ||
	(error=ews64xlWriteTEA6320(card, 0, 0x03, adjR))<0 ||
	(error=ews64xlWriteTEA6320(card, 0, 0x04, adjL))<0) {
      return error;
    }
    break;
  case 1:
    if ((error=ews64xlWriteTEA6320(card, 1, 0x00, volMain))<0 ||
	(error=ews64xlWriteTEA6320(card, 1, 0x01, adjR))<0 ||
	(error=ews64xlWriteTEA6320(card, 1, 0x02, adjL))<0) {
      return error;
    }
    break;
  }

  card->hardwareCache.ews64xl.volume[out][0] = volL;
  card->hardwareCache.ews64xl.volume[out][1] = volR;

  return 0;
}

static int ews64xlAudioInputHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *input)
{
  int error;
  char pcf8574_0, tea6320_07_1;

  pcf8574_0=card->hardwareCache.ews64xl.pcf8574[0];
  tea6320_07_1=card->hardwareCache.ews64xl.tea6320_07[1];

  if (set) {
    switch(*input) {
    case SAM_MIXER_AUDIO_INPUT_CODEC:
      pcf8574_0 |= 0x10;
      tea6320_07_1 = 0x07;
      break;
    case SAM_MIXER_AUDIO_INPUT_MIC:
    case SAM_MIXER_AUDIO_INPUT_LINE1:
    case SAM_MIXER_AUDIO_INPUT_LINE2:
      pcf8574_0 |= 0x10;
      tea6320_07_1 = 0x06;
      break;
    default: /* SAM_MIXER_AUDIO_INPUT_DIGITAL */
      if (card->hardwareCache.ews64xl.pcf8574_active[7])
	pcf8574_0 &= ~0x10;
      break;
    }
  }

  if (pcf8574_0 & 0x10) {
    /* analog input */
    if (tea6320_07_1 == 0x07)
      *input = SAM_MIXER_AUDIO_INPUT_CODEC;
    else
      *input = SAM_MIXER_AUDIO_INPUT_LINE2;
  } else
    *input = SAM_MIXER_AUDIO_INPUT_DIGITAL;

  if(set) {
    if ((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			   &pcf8574_0, 1))<0)
      return error;
    card->hardwareCache.ews64xl.pcf8574[0]=pcf8574_0;
    if(pcf8574_0 & 0x10) {
      if((error=ews64xlWriteTEA6320(card, 1, 0x07, tea6320_07_1))<0)
	return error;
      card->hardwareCache.ews64xl.tea6320_07[1]=tea6320_07_1;
    }
  }

  return 0;
}

static int ews64xlExternalClockHandler(struct SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *onOff)
{
  if (set) {
    if (*onOff) {
      /* switch on external syncing */
      card->hardwareCache.ews64xl.pcf8574[0] &= ~0x0c;
      return samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			 &card->hardwareCache.ews64xl.pcf8574[0], 1);
    } else {
      /*  This is a bit ugly but it works. */
      unsigned sampleRate;
      ews64xlSampleRateHook(card, 0, SamHWHookIdSampleRate, 0, &sampleRate);
      /* switch off external syncing and restore sample rate */
      card->hardwareCache.ews64xl.pcf8574[0] |= 0x0c;
      return ews64xlSampleRateHook(card, 1, SamHWHookIdSampleRate, 0, &sampleRate);
    }
  } else { /* !set */
    *onOff = (card->hardwareCache.ews64xl.pcf8574[0] & 0x0c) == 0x00;
    return 0;
  }
}

static int ews64xlDigitalInputHandler(struct SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *digCoax)
{
  int error;
  char pcf8574_7;

  pcf8574_7=card->hardwareCache.ews64xl.pcf8574[7];

  if (set) {
    if (*digCoax==SAM_MIXER_DIGITAL_INPUT_OPTICAL)
      pcf8574_7 &= ~0x80;
    else /* SAM_MIXER_DIGITAL_INPUT_COAX */
      pcf8574_7 |= 0x80;
  }

  *digCoax = (pcf8574_7 & 0x80) ? SAM_MIXER_DIGITAL_INPUT_COAX : SAM_MIXER_DIGITAL_INPUT_OPTICAL;

  if(set) {
    if((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			  &pcf8574_7, 1))<0)
      return error;
    card->hardwareCache.ews64xl.pcf8574[7]=pcf8574_7;
  }

  return 0;
}

static int ews64xlDigitalOutCopyInhibitHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *onOff)
{
  int error;
  char pcf8574_7;

  pcf8574_7=card->hardwareCache.ews64xl.pcf8574[7];

  if (set) {
    if (*onOff)
      pcf8574_7 |= 0x20;
    else
      pcf8574_7 &= ~0x20;
  }

  *onOff = (pcf8574_7 & 0x20) != 0;

  if(set) {
    if((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			  &pcf8574_7, 1))<0)
      return error;
    card->hardwareCache.ews64xl.pcf8574[7]=pcf8574_7;
  }

  return 0;
}

static int ews64xlDigitalOutGenerationHandler(SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *onOff)
{
  int error;
  char pcf8574_7;

  pcf8574_7=card->hardwareCache.ews64xl.pcf8574[7];

  if (set) {
    if (*onOff)
      pcf8574_7 |= 0x40;
    else
      pcf8574_7 &= ~0x40;
  }

  *onOff = (pcf8574_7 & 0x40) != 0;

  if(set) {
    if((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			  &pcf8574_7, 1))<0)
      return error;
    card->hardwareCache.ews64xl.pcf8574[7]=pcf8574_7;
  }

  return 0;
}

static int ews64xlDigitalInRateHandler(struct SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *rate)
{
  static SamMixerDigitalInputRate digitalInRates[]={
    SAM_MIXER_DIR_UNKNOWN,
    SAM_MIXER_DIR_48K_4PERCENT,
    SAM_MIXER_DIR_44K_4PERCENT,
    SAM_MIXER_DIR_32K_4PERCENT,
    SAM_MIXER_DIR_48K_400PPM,
    SAM_MIXER_DIR_44_1K_400PPM,
    SAM_MIXER_DIR_44_056K_400PPM,
    SAM_MIXER_DIR_32K_400PPM
  };
  int error;

  /* pull up bits before reading them */
  card->hardwareCache.ews64xl.pcf8574[7] |= 0x1c;
  if ((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			 &card->hardwareCache.ews64xl.pcf8574[7], 1))<0) {
    return error;
  }
  if ((error=samI2CRead(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			&card->hardwareCache.ews64xl.pcf8574[7], 1))<0) {
    return error;
  }

  *rate=digitalInRates[(card->hardwareCache.ews64xl.pcf8574[7] >> 2) & 0x07];

  return 0;
}

static int ews64xlAnalogOutVolHandler(struct SamCard *card, int set, SamMixerId ctrlId, unsigned addrTag, unsigned *vol)
{
  if (set) {
    if (*vol > 114) 
      *vol=114;

    switch (addrTag) {
    case 0:
      return ews64xlSetMasterOutputVolume(card, 0, *vol - 94,
					  card->hardwareCache.ews64xl.volume[0][1]);
    case 1:
      return ews64xlSetMasterOutputVolume(card, 0,
					  card->hardwareCache.ews64xl.volume[0][0],
					  *vol - 94);
    case 2:
      return ews64xlSetMasterOutputVolume(card, 1, *vol - 94,
					  card->hardwareCache.ews64xl.volume[1][1]);
    case 3:
      return ews64xlSetMasterOutputVolume(card, 1,
					  card->hardwareCache.ews64xl.volume[1][0],
					  *vol - 94);
    }
  }

  *vol = card->hardwareCache.ews64xl.volume[addrTag>>1][addrTag&1] + 94;

  return 0;
}

static int ews64xlSampleRateHook(struct SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *sampleRate)
{
  int error, external_sync;
  char pcf8574_0, pcf8574_7;

  pcf8574_0=card->hardwareCache.ews64xl.pcf8574[0];
  pcf8574_7=card->hardwareCache.ews64xl.pcf8574[7];

  external_sync=
    card->hardwareCache.ews64xl.pcf8574_active[7]
    && ((pcf8574_0 & 0x0c) == 0x00);

  if (set) {
    /* clear the relevant bits */
    if (!external_sync) {
      /*  we have to preserve the external sync setting if it's active */
      pcf8574_0 &= ~0x0c;
    }
    pcf8574_7 &= ~0x03;

    switch (*sampleRate) {
    case 32000:
      if (!external_sync)
	pcf8574_0 |= 0x0c;
      pcf8574_7 |= 0x02;
      break;
    case 48000:
      if (!external_sync)
	pcf8574_0 |= 0x04;
      pcf8574_7 |= 0x01;
      break;
    default: /* 44100 */
      if (!external_sync)
	pcf8574_0 |= 0x08;
      /* we don't have to set bits in reg 27 */
      break;
    }
  }

  switch (pcf8574_0 & 0x0c) {
  case 0x0c:
    *sampleRate = 32000;
    break;
  case 0x08:
    *sampleRate = 44100;
    break;
  case 0x04:
    *sampleRate = 48000;
    break;
  case 0x00:
    /* sync to external source, use register 0x27 if present
       to get actual sample rate */
    if (!card->hardwareCache.ews64xl.pcf8574_active[7]) {
      *sampleRate = 0;	/* no front module, what shall we do? */
    } else {
      switch (pcf8574_7 & 0x03) {
      case 0x00:
      case 0x03:		/* should not be used */
	*sampleRate = 44100;
	break;
      case 0x01:
	*sampleRate = 48000;
	break;
      case 0x02:
	*sampleRate = 32000;
	break;
      default:
	*sampleRate = 0;
	break;
      }
    }
  }

  if(set) {
    if (!external_sync) {
      if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x20,
			       &pcf8574_0, 1))<0) {
	return error;
      }
      card->hardwareCache.ews64xl.pcf8574[0]=pcf8574_0;
    }
    if (card->hardwareCache.ews64xl.pcf8574_active[7]) {
      /* Do this only if we've got a front module. */
      if ((error = samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x27,
			       &pcf8574_7, 1))<0) {
	return error;
      }
      card->hardwareCache.ews64xl.pcf8574[7]=pcf8574_7;
    }
  }

  return 0;
}

static int ews64xlMinus6dBHook(struct SamCard *card, int set, SamHWHookId hookId, unsigned addrTag, unsigned *onOff)
{
  int error;
  char pcf8574_1;

  pcf8574_1=card->hardwareCache.ews64xl.pcf8574[1];

  if (set) {
    if (*onOff)
      pcf8574_1 &= ~0x04;
    else
      pcf8574_1 |= 0x04;
  }

  *onOff = !(pcf8574_1 & 0x04);

  if(set) {
    if((error=samI2CWrite(card, ews64CtrlOut0, ews64CtrlIn0, 0x21,
			  &pcf8574_1, 1))<0)
      return error;
    card->hardwareCache.ews64xl.pcf8574[1]=pcf8574_1;
  }

  return 0;
}

#endif /* SAM_ENABLE_HW_EWS64XL */
