/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#include <linux/soundcard.h>

#include "driver.h"
#include "io.h"
#include "alloc.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif
#include "midi.h"
#include "seq.h"

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t accessSpinLock;
#endif
  struct timer_list timer;
  unsigned references;
  unsigned long lastTickerJiffies;
} MidiTimerInfo;

#ifdef SAM_ENABLE_RTC
static void midiRTCTicker(void);
#endif
static void midiTicker(unsigned long data);

#ifdef SAM_ENABLE_RTC
static SamRTCCallbackNode rtcCallbackInfo={
  midiRTCTicker
};
#endif
static MidiTimerInfo timerInfo={
#if LINUX_VERSION_CODE>=0x20200
  SPIN_LOCK_UNLOCKED,
#endif
  SAM_TIMER_INIT(midiTicker)
};

static void checkWakeup(int deltaTicks)
{
  int i;
  SamCard *card;

  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    if(card->midi.timerRunning && SAM_ATOMIC_READ(&card->midi.recSuspendTicks)>0) {
      atomic_sub(deltaTicks, &card->midi.recSuspendTicks);
      if(SAM_ATOMIC_READ(&card->midi.recSuspendTicks)<=0)
	wake_up(&card->midi.dataAvail);
    }
  }
}

#ifdef SAM_ENABLE_RTC
static void midiRTCTicker(void)
{
  checkWakeup(1);
}
#endif

static void midiTicker(unsigned long data)
{
  unsigned flags;
  int deltaTicks;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  deltaTicks=jiffies-timerInfo.lastTickerJiffies;
  timerInfo.lastTickerJiffies=jiffies;
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);

  checkWakeup(deltaTicks);

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references) {
    timerInfo.timer.expires=jiffies+SAM_MIDI_SYSTEM_POLL_INTERVAL;
    add_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStop(SamCard *card)
{
  unsigned flags;

  if(!card->midi.timerRunning)
    return;

  card->midi.timerRunning=0;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(--timerInfo.references==0) {
#ifdef SAM_ENABLE_RTC
    samRTCDisableCallback(&rtcCallbackInfo);
#endif
    del_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStart(SamCard *card)
{
  unsigned flags;

  if(card->midi.timerRunning)
    return;

  timerStop(card);

  card->midi.timerRunning=1;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references++==0) {
#ifdef SAM_ENABLE_RTC
    if(samUsingRTC) {
      samRTCEnableCallback(&rtcCallbackInfo);
    } else {
#endif
      timerInfo.lastTickerJiffies=jiffies;
      timerInfo.timer.expires=timerInfo.lastTickerJiffies+SAM_MIDI_SYSTEM_POLL_INTERVAL;
      add_timer(&timerInfo.timer);
#ifdef SAM_ENABLE_RTC
    }
#endif
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

int samSendMidiReset(SamCard *card, SamMidiPortType portType)
{
  int error;

  if((error=samTalk(card,
		    SamSendCtrl, 1, card->firmwareInfo->midiSelCtrls[portType],
		    SamSendMidi, 1, 0xFF,
		    SamEndOfScript))<0)
    return error;

  /* send a GM reset if the MIDI Reset doesn't turn off all notes
   * due to a buggy firmware
   */
  if(card->firmwareInfo->midiResetFixup &&
     (error=samTalk(card,
		    SamSendCtrl, 1, card->firmwareInfo->midiSelCtrls[portType],
		    SamSendMidi, 6, 0xF0, 0x7E, 0x7F, 0x09, 0x01, 0xF7,
		    SamEndOfScript))<0)
    return error;

  return 0;
}

/* handle external midi events */
void samMidiInput(SamCard *card, unsigned v)
{
  unsigned flags;
  int i;

  switch(card->midi.ports[SamMidiPortExternal].ownerRead) {
  case SamMidiPortOwnerSeq:
    samMidiInputSeq(card, v);
    break;
  case SamMidiPortOwnerMidi:
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->midi.rec.ringBuffer) {
      if(card->midi.rec.usedCount<SAM_STORED_MIDI_EVENTS) {
	i=(card->midi.rec.usedIdx+card->midi.rec.usedCount)%SAM_STORED_MIDI_EVENTS;
	card->midi.rec.ringBuffer[i]=v;
	if(card->midi.rec.usedCount++==0)
	  SAM_ATOMIC_SET(&card->midi.recSuspendTicks, SAM_MIDI_REC_SUSPEND_TICKS);
	else if(card->midi.rec.usedCount>=SAM_STORED_MIDI_EVENTS/2) {
	  SAM_ATOMIC_SET(&card->midi.recSuspendTicks, 0);
	  wake_up(&card->midi.dataAvail);
	}
      } else {
#ifndef SAM_IGNORE_REC_OVERFLOW
	SAM_ATOMIC_SET(&card->midi.recSuspendTicks, 0);
	card->midi.recOverflow=1;
	wake_up(&card->midi.dataAvail);
#endif
      }
    }
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    break;
  default:
    /* SamMidiPortOwnerNone */
  }
}

static void resetMidiInput(SamCard *card, SamMidiPortType portType)
{
  unsigned flags;

  timerStop(card);
  SAM_ATOMIC_SET(&card->midi.recSuspendTicks, 0);

  SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
  card->midi.rec.usedIdx=card->midi.rec.usedCount=0;
#ifndef SAM_IGNORE_REC_OVERFLOW
  card->midi.recOverflow=0;
#endif
  SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
}

int samOpenMidi(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  unsigned portIdx=SAM_PORT_IDX(inode);
  SamMidiPort *port;
  unsigned flags;
  int error;

  if(portIdx>=SamMidiPortSentinel)
    return -ENODEV;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  down(&card->midi.accessLock);
  
  port=card->midi.ports+portIdx;
  if(((file->f_mode & SAM_MODE_READ_MASK) && port->ownerRead!=SamMidiPortOwnerNone) ||
     ((file->f_mode & SAM_MODE_WRITE_MASK) && port->ownerWrite!=SamMidiPortOwnerNone)) {
    up(&card->midi.accessLock);
    return -EBUSY;
  }

  file->private_data=(void *)(long)portIdx;
  if(file->f_mode & SAM_MODE_READ_MASK)
    port->ownerRead=SamMidiPortOwnerMidi;
  if(file->f_mode & SAM_MODE_WRITE_MASK)
    port->ownerWrite=SamMidiPortOwnerMidi;

  error=0;

  if(file->f_mode & SAM_MODE_READ_MASK) {
    resetMidiInput(card, portIdx);
    card->midi.rec.ringBuffer=(unsigned char *)kmalloc(SAM_STORED_MIDI_EVENTS, GFP_KERNEL);
    if(!card->midi.rec.ringBuffer)
      error=-ENOMEM;
  }

  if(error>=0 && (file->f_mode & SAM_MODE_WRITE_MASK))
    error=samSendMidiReset(card, portIdx);

  if(error<0) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->midi.rec.ringBuffer) {
      kfree(card->midi.rec.ringBuffer);
      card->midi.rec.ringBuffer=NULL;
    }
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    if(file->f_mode & SAM_MODE_READ_MASK)
      port->ownerRead=SamMidiPortOwnerNone;
    if(file->f_mode & SAM_MODE_WRITE_MASK)
      port->ownerWrite=SamMidiPortOwnerNone;
    up(&card->midi.accessLock);
    return error;
  }

  if(file->f_mode & SAM_MODE_READ_MASK)
    timerStart(card);

  up(&card->midi.accessLock);

  if(portIdx==SamMidiPortExternal)
    atomic_inc(&card->fastPollRequests);

  return 0;
}

void samReleaseMidi(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  int portIdx=(long)file->private_data;
  SamMidiPort *port=card->midi.ports+portIdx;
  unsigned flags;

  if(portIdx==SamMidiPortExternal)
    atomic_dec(&card->fastPollRequests);

  down(&card->midi.accessLock);

  if(file->f_mode & SAM_MODE_READ_MASK) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->midi.rec.ringBuffer) {
      kfree(card->midi.rec.ringBuffer);
      card->midi.rec.ringBuffer=NULL;
    }
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);

    resetMidiInput(card, portIdx);
  }

  if((file->f_mode & SAM_MODE_WRITE_MASK) &&
     samSendMidiReset(card, portIdx)<0)
    printk(KERN_ERR "sam9407[#%d:%s]: couldn't reset midi channel\n",
	   card->cardIdx, card->hardwareInfo->name);

  if(file->f_mode & SAM_MODE_READ_MASK)
    port->ownerRead=SamMidiPortOwnerNone;
  if(file->f_mode & SAM_MODE_WRITE_MASK)
    port->ownerWrite=SamMidiPortOwnerNone;

  up(&card->midi.accessLock);
}

int samReadMidi(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  int portIdx=(long)file->private_data;
  SamWaitQueue wait;
  unsigned flags;
  int error, n;
  unsigned char *cp;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  /* only SamMidiPortExternal can return useful data */
  if(portIdx!=SamMidiPortExternal)
    return 0;

  cp=(unsigned char *)buf;
  n=count;

  down(&card->midi.accessLock);

  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     !card->midi.recOverflow &&
#endif
     (!card->midi.rec.usedCount || SAM_ATOMIC_READ(&card->midi.recSuspendTicks)>0) &&
     (file->f_flags & O_NONBLOCK)) {
    up(&card->midi.accessLock);
    return -EAGAIN;
  }

  /* wait for incoming data */
  for(;;) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->midi.dataAvail, &wait);
    if(
#ifndef SAM_IGNORE_REC_OVERFLOW
       card->midi.recOverflow ||
#endif
       (card->midi.rec.usedCount && SAM_ATOMIC_READ(&card->midi.recSuspendTicks)<=0)) {
      samCancelSleepOn(&card->midi.dataAvail, &wait);
      break;
    }
    up(&card->midi.accessLock);
    samSleepOn(&card->midi.dataAvail, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      return -ERESTARTSYS;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      return -ERESTARTSYS;
#endif /* Linux 2.0 */
    down(&card->midi.accessLock);
  }

#ifndef SAM_IGNORE_REC_OVERFLOW
  if(card->midi.recOverflow) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    card->midi.recOverflow=0;
    card->midi.rec.usedIdx=card->midi.rec.usedCount=0;
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    up(&card->midi.accessLock);
    return -EIO;
  }
#endif

  while(n>0) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(!card->midi.rec.usedCount) {
      SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
      break;
    }
    put_user(card->midi.rec.ringBuffer[card->midi.rec.usedIdx], cp);
    card->midi.rec.usedIdx=(card->midi.rec.usedIdx+1)%SAM_STORED_MIDI_EVENTS;
    card->midi.rec.usedCount--;
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    cp++;
    n--;
  }

  up(&card->midi.accessLock);

  return cp-(unsigned char *)buf;
}

int samWriteMidi(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure)
{ 
  int portIdx=(long)file->private_data;
  unsigned char *cp;
  int error, sigPending, n, size;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_READ, buf, count))<0)
    return error;

  n=count;
  cp=(unsigned char *)buf;

  down(&card->midi.accessLock);

  while(n>0) {
    /* check for pending signals */
#if LINUX_VERSION_CODE>=0x20200
    sigPending=signal_pending(current);
#else /* Linux 2.0 */
    sigPending=current->signal & ~current->blocked;
#endif /* Linux 2.0 */
    if(sigPending) {
      up(&card->midi.accessLock);
      if(cp>(unsigned char *)buf)
	return cp-(unsigned char *)buf;
      else
	return -ERESTARTSYS;
    }

    /* limit transfers to SAM_STORED_MIDI_EVENTS
     * so we won't block signals for too long a time
     */
    size=n;
    if(size>SAM_STORED_MIDI_EVENTS)
      size=SAM_STORED_MIDI_EVENTS;
    if((error=samTalk(card,
		      SamSendCtrl, 1, card->firmwareInfo->midiSelCtrls[portIdx],
		      SamSendMidiFS, size, cp,
		      SamEndOfScript))<0)
      return error;
    cp+=size;
    n-=size;
  }
 
  up(&card->midi.accessLock);

  return cp-(unsigned char *)buf;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMidi(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  unsigned portIdx=SAM_PORT_IDX(inode);
  unsigned flags, mask;

  mask=POLLOUT | POLLWRNORM;

  if(portIdx==SamMidiPortExternal) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);

    if(
#ifndef SAM_IGNORE_REC_OVERFLOW
       card->midi.recOverflow ||
#endif
       (card->midi.rec.usedCount && SAM_ATOMIC_READ(&card->midi.recSuspendTicks)<=0))
      mask|=POLLIN | POLLRDNORM;

    poll_wait(file, &card->midi.dataAvail, wait);
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
  } else
    /* non-external ports always return EOF */
    mask|=POLLIN | POLLRDNORM;

  return mask;
}
#else /* Linux 2.0 */
int samSelectMidi(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  unsigned portIdx=SAM_PORT_IDX(inode);
  unsigned flags;
  int avail=0;

  switch(type) {
  case SEL_IN:
    /* non-external ports always return EOF */
    if(portIdx==SamMidiPortExternal) {
      SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
      avail=
#ifndef SAM_IGNORE_REC_OVERFLOW
	card->midi.recOverflow ||
#endif
	(card->midi.rec.usedCount && SAM_ATOMIC_READ(&card->midi.recSuspendTicks)<=0);
      if(!avail)
	select_wait(&card->midi.dataAvail, wait);
      SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    } else
      avail=1;
    break;
  case SEL_OUT:
    avail=1;
    break;
  }
  return avail;
}
#endif /* Linux 2.0 */

int samIoctlMidi(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr)
{
  switch(cmd) {
  default:
    return -ENOSYS;
  }
}

void samInitializeMidi(void)
{
#ifdef SAM_ENABLE_RTC
  samRTCRegisterCallback(&rtcCallbackInfo);
#endif
}
