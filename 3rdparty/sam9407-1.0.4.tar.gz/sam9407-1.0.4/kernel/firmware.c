/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif

#include "driver.h"
#include "io.h"
#include "alloc.h"
#include "audio.h"
#include "mixer.h"

#define SAM_FIRMWARE_OFS	0x200
#define SAM_MAX_FIRMWARE_SIZE	0x10000

static unsigned short samBoot[]={
  0xD0CE,0x0111,0xD0CE,0x01D4,0x0001,0x0003,0x0004,0x0006,
  0x0001,0x0003,0x0002,0x0002,0x0006,0x0002,0x0001,0x0006,
  0x0006,0x7A0C,0xE628,0x0001,0xD448,0x1010,0xC4CB,0xD1CB,
  0xE2FE,0x4F01,0xE3FC,0x4E0D,0xE0FA,0x4700,0x8407,0xD148,
  0x0104,0x9107,0x7A08,0x7A09,0xC590,0xD1CB,0xE2FE,0x4F01,
  0xE3EE,0xC74D,0x6DFA,0xD44A,0x012E,0xC449,0x7816,0x7819,
  0x7821,0x781D,0x782E,0x7830,0x7835,0x783A,0x783F,0x7849,
  0x784C,0x786F,0x786E,0x7914,0x01F8,0x7A10,0x7A11,0x7915,
  0x0000,0x7913,0x0007,0x7A12,0xD1CA,0xC44F,0xC4C4,0xD0CE,
  0x01CD,0xC64F,0xC54F,0xC44F,0xCB4C,0xD5C4,0x78C4,0xC64F,
  0xC74F,0xCF4C,0xC64F,0xC54F,0xCB4C,0x3D09,0xC64F,0xC54F,
  0xCB4C,0x3D08,0xD449,0x0130,0xE302,0xC480,0x786E,0xCF80,
  0x78B2,0xC04F,0xC4C9,0x7869,0xC64F,0xC54F,0xCB4C,0xC04F,
  0xC5CB,0x78A9,0xC54F,0xC44F,0xC94A,0xD1CE,0x8405,0x785D,
  0xC54F,0xC44F,0xC94A,0xD1CE,0x8406,0x7857,0xC74F,0xC64F,
  0xCD4E,0xC74F,0xC54F,0xCB4E,0xC74F,0xC44F,0xC94E,0xD1CF,
  0x7892,0xC64F,0xC54F,0xCB4C,0xC549,0xC04F,0x0001,0x0400,
  0xC4CB,0xD148,0x0015,0x0406,0xC04F,0xD0C1,0x7D01,0x6CFC,
  0xD0CA,0x8418,0x0001,0xC4CB,0xD1C9,0x0001,0x840C,0xE901,
  0x0000,0x7803,0xE911,0xD048,0xFFFF,0x7B00,0xE920,0xD1C8,
  0xC04F,0xC14F,0xC24F,0xC34F,0xC44F,0xC54F,0xC64F,0xC74F,
  0xD1CA,0x8704,0x0001,0x0410,0xC4CB,0xC54F,0xC44F,0xC94A,
  0x3C0D,0xC54F,0xC44F,0xC94A,0x3C0F,0xC54F,0xC44F,0xC94A,
  0x3C0E,0x0001,0xD448,0x2010,0xD548,0x3010,0xD749,0x013A,
  0xE304,0xD448,0x1010,0xD548,0x1010,0xC4CB,0xC5CB,0x0006,
  0xC4CB,0x7B0D,0xE3FE,0xD0CE,0x0113,0x0006,0xC4CB,0x0007,
  0xC849,0xC4CB,0xD0CE,0x0113,0xC74D,0xC64D,0xC54D,0xC44D,
  0xC34D,0xC24D,0xC14D,0xC04D,0x7A05,0x840C,0x4100,0xE101,
  0x4104,0xE301,0x4201,0xE501,0x4302,0xD94A,0xD94B,0x3C0C,
  0x0001,0x0400,0xC4CB,0xD0C8,0xD148,0x0010,0x0406,0xC0C1,
  0xC04D,0x7C01,0x6CFC,0xD0CF,0x013B,0xD448,0x55AA,0x78D5,
  0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000
};

static void napTimedOut(unsigned long data)
{
  wake_up((SamWaitQueueHead *)data);
}

static int releaseFirmware(SamCard *card)
{
  unsigned flags;

  down(&card->usageCountLock);
  if(SAM_ATOMIC_READ(&card->usageCount)) {
    up(&card->usageCountLock);
    return -EBUSY;
  }

  /* make sure we don't mess with an IRQ that requires the firmware */
  SAM_BEGIN_CRITICAL(&card->firmwareAccessSpinLock, flags);
  card->firmwareLoaded=0;
  SAM_END_CRITICAL(&card->firmwareAccessSpinLock, flags);

  up(&card->usageCountLock);

  samReleaseChannels(card);
  samReleaseMMT(card);
  samReleaseMixerDirtyFlags(card);

  card->firmwareInfo=&samGenuineFirmwareInfo;

  card->mixer.firmwareDirty=~0;
  card->mixer.sbankDirty=0;
  card->mixer.channelOwnerDirty=0;
  wake_up(&card->mixer.waitDirty);

  return 0;
}

int samFirmwareLoad(SamCard *card, SamFirmware *firmwareP)
{
  SamCard *master, *sibling;
  SamFirmware firmware;
  int error, retry, useHardwareReset, size, len, i;
  unsigned short *sp, sv;
  unsigned short cksumExpected, cksumReceived;
  char buf[32];
  struct timer_list napTimer;
  SamWaitQueue wait;
  SamWaitQueueHead napWakeup;
  SamFirmwareInfo *firmwareInfo;

#ifndef SAM_FIRMLOAD_ANYONE
  if(!SAM_CAP_SYS_ADMIN())
    return -EACCES;
#endif /* !SAM_FIRMLOAD_ANYONE */

  master=card->master;
  if(!master)
    master=card;

  if(card==master)
    sibling=card->slave;
  else
    sibling=card->master;

  if((error=verify_area(VERIFY_READ, firmwareP, sizeof(SamFirmware)))<0)
    return error;

  if(SAM_MEMCPY_FROMFS(&firmware, firmwareP, sizeof(SamFirmware)))
    return -EFAULT;

  if(firmware.size<SAM_FIRMWARE_OFS ||
     firmware.size>SAM_MAX_FIRMWARE_SIZE)
    return -EINVAL;

  if((error=verify_area(VERIFY_READ, firmware.data, firmware.size<<1))<0)
    return error;

  if((error=releaseFirmware(card))<0)
    return error;

  retry=0;

  for(;;) {
    if(master->hardwareInfo->reset) {
      if(sibling) {
	down(&sibling->mixer.accessLock);
	/* if a hardware reset would affect the sibling DSP
	 * perform it only on the second pass
	 * or if the sibling doesn't have any firmware loaded
	 */
	useHardwareReset=retry || !sibling->firmwareLoaded;
	if(!useHardwareReset)
	  up(&sibling->mixer.accessLock);
      } else
	useHardwareReset=1;
      retry=!useHardwareReset;
    } else {
      useHardwareReset=0;
      retry=0;
    }

    if(useHardwareReset) {
      if(sibling &&
	 (error=releaseFirmware(sibling))<0) {
	up(&sibling->mixer.accessLock);
	return error;
      }

      error=(*master->hardwareInfo->reset)(master);

      if(sibling)
	up(&sibling->mixer.accessLock);

      if(error<0) {
#ifdef SAM_DEBUG
	printk(KERN_DEBUG "sam9407[#%d:%s]: hardware reset failed\n", master->cardIdx, master->hardwareInfo->name);
#endif
	return error;
      }
    } else {
      /* try to reset old firmware */
      if(samFirmwareDetect(card))
	samTalk(card,
		SamSendCtrl, 1, SAM_CMD_EN_CONTROL,
		SamSendCtrl, 2, SAM_CMD_HOT_RES, 0x11,
		SamExpect, 0x00,
		SamEndOfScript);
    }

    /* upload new firmware */
    sp=firmware.data+SAM_FIRMWARE_OFS;
    size=firmware.size-SAM_FIRMWARE_OFS;
    if((error=samTalk(card,
		      SamBurstWrite, samBoot, SAM_NUMBER_OF(samBoot),
		      /* xfer firmware */
		      SamSendCtrlInit, 7, 0x0B,
		      /* offset */
		      SAM_FIRMWARE_OFS,
		      SAM_FIRMWARE_OFS>>8,
		      /* page */
		      0x00, 0x00,
		      /* size */
		      size,
		      size>>8,
		      SamDiscardInput,
		      /* write firmware */
		      SamBurstWriteFS, sp, size,
		      /* start firmware */
		      SamSendCtrlInit, 3, 0x09,
		      SAM_FIRMWARE_OFS,
		      SAM_FIRMWARE_OFS>>8,
		      SamEndOfScript))<0) {
#ifdef SAM_DEBUG
      printk(KERN_DEBUG "sam9407[#%d:%s]: firmware loading failed\n", card->cardIdx, card->hardwareInfo->name);
#endif
      return -EIO;
    }

    /* probe firmware type */
    for(i=0; (firmwareInfo=samFirmwareInfos[i]); i++) {
      if(firmwareInfo->probeStr) {
	len=strlen(firmwareInfo->probeStr);
	if(len<sizeof(buf)-1 && firmwareInfo->probeAddr+len<=firmware.size<<1) {
	  if(SAM_MEMCPY_FROMFS(buf, (char *)firmware.data+firmwareInfo->probeAddr, len))
	    return -EFAULT;
	  buf[len]=0;
	  if(strcmp(buf, firmwareInfo->probeStr)==0) {
	    card->firmwareInfo=firmwareInfo;
	    break;
	  }
	}
      }
    }

    /* after firmware loading
     * take a nap, so firmware can initialize itself
     * and become ready
     */
    SAM_INIT_WAITQUEUE_HEAD(&napWakeup);
    init_timer(&napTimer);
    napTimer.expires=jiffies+card->firmwareInfo->initNapTimeout;
    napTimer.data=(unsigned long)&napWakeup;
    napTimer.function=napTimedOut;
    samPrepareSleepOn(TASK_UNINTERRUPTIBLE, &napWakeup, &wait);
    add_timer(&napTimer);
    samSleepOn(&napWakeup, &wait);
    
    if(card->firmwareInfo->verifyChecksum) {
      cksumExpected=0;
      for(i=0; i<size; i++) {
	if(SAM_GET_USER(sv, sp+i))
	  return -EFAULT;
	cksumExpected+=SAM_LE16_TO_CPU(sv);
      }

      if((error=samTalk(card, SamGetWord, &cksumReceived, SamEndOfScript))<0)
	return error;
      if(cksumReceived!=cksumExpected) {
#ifdef SAM_DEBUG
	printk(KERN_DEBUG "sam9407[#%d:%s]: checksum mismatch: expected=0x%x, received=0x%x\n",
	       card->cardIdx, card->hardwareInfo->name, cksumExpected, cksumReceived);
#endif
	return -EIO;
      }
    }

    if(samFirmwareDetect(card))
      break;

    if(!retry) {
#ifdef SAM_DEBUG
      printk(KERN_DEBUG "sam9407[#%d:%s]: loaded firmware doesn't respond\n", card->cardIdx, card->hardwareInfo->name);
#endif
      return -EIO;
    }
  }

  if(error>=0 && card->hardwareInfo->firmwareDetected)
    error=(*card->hardwareInfo->firmwareDetected)(card);

  if(error>=0 && card->firmwareInfo->setup)
    error=(*card->firmwareInfo->setup)(card);

  /* firmware did reset, so readjust resetRestoreCtrl
   * and send resetReadjust
   */
  if(error>=0 && card->firmwareInfo->resetRestoreCtrl)
    error=samTalk(card,
		  SamSendCtrl, 2, card->firmwareInfo->resetRestoreCtrl, 0,
		  SamEndOfScript);

  if(error>=0 && card->firmwareInfo->nResetReadjust)
    error=samTalk(card,
		  SamSendCtrlP, card->firmwareInfo->nResetReadjust, card->firmwareInfo->resetReadjust,
		  SamEndOfScript);

  if(error>=0)
    error=samAllocMixerDirtyFlags(card);
  if(error>=0)
    error=samInitializeMMT(card);
  if(error>=0)
    error=samAllocateChannels(card);

  if(error<0) {
    card->firmwareInfo=&samGenuineFirmwareInfo;
    samReleaseChannels(card);
    samReleaseMMT(card);
    samReleaseMixerDirtyFlags(card);
    return error;
  }

  card->firmwareLoaded=1;

  return 0;
}
