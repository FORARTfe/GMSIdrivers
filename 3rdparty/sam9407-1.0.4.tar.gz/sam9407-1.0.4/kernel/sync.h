#ifndef _SYNC_H
#define _SYNC_H

#include "driver.h"

typedef enum {
  SamSyncDeviceMixer,
  SamSyncDeviceAudio,
  SamSyncDeviceSeq,
  SamSyncDeviceMod,
  SamSyncDeviceSentinel /* == last_device + 1 */
} SamSyncDevice;

int samSyncJoin(int *syncHandleP, int cardIdx, SamSyncDevice syncDevice);
void samSyncLeave(int syncHandle, int cardIdx, SamSyncDevice syncDevice, int started);
void samSyncStart(int syncHandle);
int samSyncReady(int syncHandle);

void samReleaseSyncGroups(void);

#endif /* _SYNC_H */
