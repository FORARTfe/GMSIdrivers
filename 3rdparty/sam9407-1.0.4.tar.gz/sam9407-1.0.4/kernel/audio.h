#ifndef _AUDIO_H
#define _AUDIO_H

#include "driver.h"

int samOpenAudio(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseAudio(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadAudio(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
int samWriteAudio(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollAudio(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectAudio(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
int samIoctlAudio(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);

/* Initialize some structures */
int samStartFeedThread(void);

/* kill audioFeedThread and release buffers */
void samKillFeedThread(void);

/* allocate audio channels after firmware upload */
int samAllocateChannels(SamCard *card);

/* free memory allocated by audio channels */
void samReleaseChannels(SamCard *card);

/* SAM9407 asynchronous notifications handler */
void samAudioNotification(SamCard *card, unsigned v);

void samGetAudioInfo(SamCard *card, SamDriverInfo *driverInfo);

#endif /* _AUDIO_H */
