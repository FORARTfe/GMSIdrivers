/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#include <linux/vmalloc.h>
#else
#include <linux/malloc.h>
#endif

#include "driver.h"
#include "io.h"
#include "alloc.h"
#include "mixer.h"

#define SAM_MMT_BANK_MASK		0x77F
#define SAM_MAX_BANK_SIZE		(256<<20)
#define SAM_MAX_MT_WORDS		(64<<10)
#define SAM_PARAM_PAGE_WORDS		(64<<10)
#define SAM_PARAM_BLOCKS		2
#define SAM_SAMPLE_PAGE_WORDS		(256<<10)
#define SAM_SAMPLE_BLOCKS		32
#define SAM_INSTR_PROGRAMS		128

#define SAM_CKID_VALUE(c1,c2,c3,c4)	((c1)|(c2)<<8|(c3)<<16|(c4)<<24)
#define SAM_CKID_DRCP			SAM_CKID_VALUE('D','R','C','P')
#define SAM_CKID_PRIO			SAM_CKID_VALUE('P','R','I','O')
#define SAM_CKID_IMAP			SAM_CKID_VALUE('I','M','A','P')
#define SAM_CKID_RLOC			SAM_CKID_VALUE('R','L','O','C')
#define SAM_CKID_PARA			SAM_CKID_VALUE('P','A','R','A')
#define SAM_CKID_SAMP			SAM_CKID_VALUE('S','A','M','P')
#define SAM_CKID_TTPR			SAM_CKID_VALUE('T','T','P','R')
#define SAM_CKID_TTIM			SAM_CKID_VALUE('T','T','I','M')
#define SAM_CKID_TTRL			SAM_CKID_VALUE('T','T','R','L')
#define SAM_CKID_TTPA			SAM_CKID_VALUE('T','T','P','A')
#define SAM_CKID_TTSA			SAM_CKID_VALUE('T','T','S','A')
#define SAM_CKID_TTMA			SAM_CKID_VALUE('T','T','M','A')
#define SAM_CKID_TTEL			SAM_CKID_VALUE('T','T','E','L')
#define SAM_CKID_TTSL			SAM_CKID_VALUE('T','T','S','L')
#define SAM_CKID_TTKL			SAM_CKID_VALUE('T','T','K','L')

#define SAM_RELOC_TYPE_PARAM		0
#define SAM_RELOC_TYPE_MA2_PG		1
#define SAM_RELOC_TYPE_MA2_LOOP		2
#define SAM_RELOC_TYPE_MB_END		3

typedef struct {
  unsigned id;
  unsigned size;
} RiffChunk;

typedef struct {
  unsigned addr;
  unsigned char type, block;
} __attribute__((packed)) RelocEntry;

typedef struct {
  unsigned short program;
  unsigned char variation;
  unsigned char page;
  unsigned short paramPtr;
} ImapEntry;

typedef struct {
  unsigned short length;
  unsigned short paramPages[SAM_NROF_SBANKS*SAM_PARAM_BLOCKS];
  unsigned short instrPtrs[SAM_INSTR_PROGRAMS];
} MidiTable;

typedef struct {
  unsigned char variation;
  unsigned char bank;
  unsigned short paramPtr;
} InstrDef;

typedef struct {
  unsigned short program;
  unsigned char variation;
  unsigned char bank;
  unsigned short paramPtr;
} DrumDef;

typedef enum {
  PriorityItemImapInstr,
  PriorityItemImapDrum,
  PriorityItemInstrDef,
  PriorityItemDrumDef,
  PriorityItemIgnore,
} PriorityItemType;

typedef struct {
  PriorityItemType type;
  union {
    struct {
      ImapEntry entry;
    } imap;
    struct {
      InstrDef *ptr;
      unsigned short program;
    } instr;
    struct {
      DrumDef *ptr;
    } drum;
  } u;
} PriorityItem;

static int allocBlocks(SamCard *card,
		       int id, unsigned short *source, unsigned words, unsigned boundary,
		       unsigned blockWords, int maxBlocks, unsigned *blockAddrs, int *nBlocks)
{
  unsigned n, i;
  int error;
  *nBlocks=0;
  for(i=0; i<words; i+=blockWords) {
    if(*nBlocks>=maxBlocks) {
#ifdef SAM_DEBUG
      printk(KERN_DEBUG "sam9407[#%d:%s]: sounbank alloc: too many blocks\n",
	     card->cardIdx, card->hardwareInfo->name);
#endif
      return -EINVAL;
    }
    n=words-i<blockWords ? words-i : blockWords;
    if((error=samAlloc(card, id|(*nBlocks<<11), n, blockAddrs+*nBlocks,
		       SAM_ALIGN_DONT_CARE, boundary, NULL, NULL))<0)
      return error;
    if(source)
      if((error=samTalk(card, SamWriteMemFS, blockAddrs[*nBlocks], source+i, n, SamEndOfScript))<0)
	return error;
    (*nBlocks)++;
  }
  return 0;
}

static int loadMidiTable(SamCard *card, MidiTable **midiTableP)
{
  int error, i;
  unsigned addr, len, addr2, len2;
  unsigned char *cp;
  MidiTable *midiTable;

  *midiTableP=NULL;

  if((error=samFindMMT(card, SAM_MMT_ID_MIDI_MT, SAM_MMT_ID_MASK, &addr, &len))<0)
    return error;
  if(error==0)
    /* no Midi Mapping Table available */
    return 0;
  if((error=samFindMMT(card, SAM_MMT_ID_MIDI_MT_EXT, SAM_MMT_ID_MASK, &addr2, &len2))<0)
    return error;
  if(error>0 && addr2==addr+len)
    len+=len2;
  if((len<<1)<sizeof(MidiTable)) {
    /* table is too short */
    return 0;
  }
  if(!(cp=(unsigned char *)kmalloc(len<<1, GFP_KERNEL)))
    return -ENOMEM;
  midiTable=(MidiTable *)cp;
  if((error=samTalk(card, SamReadMem, addr, cp, len, SamEndOfScript))<0) {
    kfree(cp);
    return error;
  }

  if(SAM_LE16_TO_CPU(midiTable->length)>len) {
    /* truncated Midi Mapping Table */
    kfree(cp);
    return 0;
  }

  /* adjust midi mapping table offsets downwards */
  if(addr&0xFFFF)
    for(i=0; i<SAM_INSTR_PROGRAMS; i++)
      midiTable->instrPtrs[i]=SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(midiTable->instrPtrs[i])-(addr&0xFFFF));

  *midiTableP=midiTable;
  return 0;
}

static int relocateWriteMidiTable(SamCard *card, unsigned addr, void *closure)
{
  MidiTable *midiTable=(MidiTable *)closure;
  int error, i;

  /* relocate instrument pointers */
  if(addr&0xFFFF)
    for(i=0; i<SAM_INSTR_PROGRAMS; i++)
      midiTable->instrPtrs[i]=SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(midiTable->instrPtrs[i])+(addr&0xFFFF));

  error=samTalk(card,
		SamWriteMem, addr, midiTable, SAM_LE16_TO_CPU(midiTable->length),
		SamEndOfScript);

  /* change instrument pointers back */
  if(addr&0xFFFF)
    for(i=0; i<SAM_INSTR_PROGRAMS; i++)
      midiTable->instrPtrs[i]=SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(midiTable->instrPtrs[i])-(addr&0xFFFF));

  return error;
}

static int countInstruments(SamCard *card,
			    unsigned char *imapPtr, unsigned imapSize,
			    MidiTable *midiTable,
			    PriorityItem *prioItems,
			    int *nInstrs, int *nDrums)
{
  ImapEntry *imapEntry;
  PriorityItem *prioItem;
  InstrDef *instrDef;
  DrumDef *drumDef;
  short *limit;
  unsigned short program;
  unsigned char page, bank;
  int nPrioItems, isBackup, isDrums, i;

  if(nInstrs)
    *nInstrs=0;
  if(nDrums)
    *nDrums=0;

  nPrioItems=0;

  /* count instruments & drums from IMAP */
  if(imapPtr) {
    i=0;
    for(isDrums=0; isDrums<2; isDrums++) {
      for(;;) {
	if(i+2>imapSize) {
	  /* instrument set not finished correctly */
#ifdef SAM_DEBUG
	  printk(KERN_DEBUG "sam9407[#%d:%s]: instrument set not finished correctly\n",
		 card->cardIdx, card->hardwareInfo->name);
#endif
	  return -EINVAL;
	}
	imapEntry=(ImapEntry *)(imapPtr+i);
	if(SAM_MEMCPY_FROMFS(&program, &imapEntry->program, 2))
	  return -EFAULT;
	if(program==0xFFFF) {
	  i+=2;
	  break;
	}
	if(SAM_GET_USER(page, &imapEntry->page))
	  return -EFAULT;
	if(page>=SAM_PARAM_BLOCKS) {
#ifdef SAM_DEBUG
	  printk(KERN_DEBUG "sam9407[#%d:%s]: too many parameter block pages\n",
		 card->cardIdx, card->hardwareInfo->name);
#endif
	  return -EINVAL;
	}
	if(isDrums) {
	  if(nDrums)
	    (*nDrums)++;
	} else {
	  if(SAM_LE16_TO_CPU(program)>=SAM_INSTR_PROGRAMS) {
#ifdef SAM_DEBUG
	    printk(KERN_DEBUG "sam9407[#%d:%s]: instrument program out of range\n",
		   card->cardIdx, card->hardwareInfo->name);
#endif
	    return -EINVAL;
	  }
	  if(nInstrs)
	    (*nInstrs)++;
	}
	if(prioItems) {
	  prioItem=prioItems+nPrioItems++;
	  prioItem->type=isDrums ? PriorityItemImapDrum : PriorityItemImapInstr;
	  if(SAM_MEMCPY_FROMFS(&prioItem->u.imap.entry, imapEntry, sizeof(ImapEntry)))
	    return -EFAULT;
	}
	i+=sizeof(ImapEntry);
      }
    }
  }

  /* count instruments & drums from MidiTable */
  if(midiTable) {
    /* count instruments */
    limit=(short *)midiTable+SAM_LE16_TO_CPU(midiTable->length);

    for(i=0; i<SAM_INSTR_PROGRAMS; i++) {
      instrDef=(InstrDef *)((short *)midiTable+SAM_LE16_TO_CPU(midiTable->instrPtrs[i]));
      for(isBackup=0; isBackup<2; isBackup++) {
	while((short *)(instrDef+1)<=limit &&
	      *(unsigned short *)instrDef!=0xFFFF) {
	  bank=instrDef->bank/SAM_PARAM_BLOCKS;
	  if(bank<SAM_NROF_SBANKS &&
	     *card->mem.sbank[bank].name) {
	    if(nInstrs)
	      (*nInstrs)++;
	    if(prioItems) {
	      prioItem=prioItems+nPrioItems++;
	      prioItem->type=PriorityItemInstrDef;
	      prioItem->u.instr.ptr=instrDef;
	      prioItem->u.instr.program=SAM_CPU_TO_LE16(i);
	    }
	  }
	  instrDef++;
	}
	instrDef=(InstrDef *)((short *)instrDef+1);
      }
    }

    /* count drums */
    limit=(short *)midiTable+SAM_LE16_TO_CPU(midiTable->length);

    drumDef=(DrumDef *)&midiTable[1];
    for(isBackup=0; isBackup<2; isBackup++) {
      while((short *)(drumDef+1)<=limit &&
	    *(unsigned short *)drumDef!=0xFFFF) {
	bank=drumDef->bank/SAM_PARAM_BLOCKS;
	if(bank<SAM_NROF_SBANKS &&
	   *card->mem.sbank[bank].name) {
	  if(nDrums)
	    (*nDrums)++;
	  if(prioItems) {
	    prioItem=prioItems+nPrioItems++;
	    prioItem->type=PriorityItemDrumDef;
	    prioItem->u.drum.ptr=drumDef;
	  }
	}
	drumDef++;
      }
      drumDef=(DrumDef *)((short *)drumDef+1);
    }
  }

  return 0;
}

/* sorting helper functions */
static __inline__ int prioIsInstr(PriorityItem *item)
{
  switch(item->type) {
  case PriorityItemImapInstr:
  case PriorityItemInstrDef:
    return 1;
  default:
    return 0;
  }
}

static __inline__ int prioProgramNr(PriorityItem *item)
{
  switch(item->type) {
  case PriorityItemImapInstr:
  case PriorityItemImapDrum:
    return SAM_LE16_TO_CPU(item->u.imap.entry.program);
  case PriorityItemInstrDef:
    return SAM_LE16_TO_CPU(item->u.instr.program);
  case PriorityItemDrumDef:
    return SAM_LE16_TO_CPU(item->u.drum.ptr->program);
  default:
    /* PriorityItemIgnore:
     * will never be called that way,
     * but we want to keep the compiler happy
     */
    return 0;
  }
}

static __inline__ int prioVariationNr(PriorityItem *item)
{
  switch(item->type) {
  case PriorityItemImapInstr:
  case PriorityItemImapDrum:
    return item->u.imap.entry.variation;
  case PriorityItemInstrDef:
    return item->u.instr.ptr->variation;
  case PriorityItemDrumDef:
    return item->u.drum.ptr->variation;
  default:
    /* PriorityItemIgnore:
     * will never be called that way,
     * but we want to keep the compiler happy
     */
    return 0;
  }
}

static __inline__ int prioSBank(SamCard *card, int imapId, PriorityItem *item)
{
  switch(item->type) {
  case PriorityItemImapInstr:
  case PriorityItemImapDrum:
    return imapId;
    break;
  case PriorityItemInstrDef:
    return item->u.instr.ptr->bank/SAM_PARAM_BLOCKS;
  case PriorityItemDrumDef:
    return item->u.drum.ptr->bank/SAM_PARAM_BLOCKS;
  default:
    /* PriorityItemIgnore:
     * will never be called that way,
     * but we want to keep the compiler happy
     */
    return 0;
  }
}

static __inline__ int prioPriority(SamCard *card, int imapId, PriorityItem *item)
{
  return card->mem.sbank[prioSBank(card, imapId, item)].priority;
}

static __inline__ int comparePrioItem(SamCard *card, int imapId, PriorityItem *a, PriorityItem *b)
{
  int cmp;
  /* we sort according to:
   * (drum|instr) / program / variation / priority / sbank
   */
  if((cmp=prioIsInstr(a)-prioIsInstr(b)))
    return cmp;

  if((cmp=prioProgramNr(a)-prioProgramNr(b)))
    return cmp;

  if((cmp=prioVariationNr(a)-prioVariationNr(b)))
    return cmp;

  if((cmp=prioPriority(card, imapId, b)-prioPriority(card, imapId, a)))
    return cmp;

  if((cmp=prioSBank(card, imapId, b)-prioSBank(card, imapId, a)))
    return cmp;

  return 0;
}

static __inline__ void exchangePrioItems(PriorityItem *a, PriorityItem *b)
{
  PriorityItem tmp;

  memcpy(&tmp, a, sizeof(PriorityItem));
  memcpy(a, b, sizeof(PriorityItem));
  memcpy(b, &tmp, sizeof(PriorityItem));
}

/* sort prioItems vector according to priorities */
static void qsortPrioItems(SamCard *card, int imapId, PriorityItem *low, PriorityItem *high)
{
  PriorityItem *i, *j, m;

  i=low;
  j=high;

  memcpy(&m, low+(high-low)/2, sizeof(PriorityItem));

  while(i<=j) {
    while(i<high && comparePrioItem(card, imapId, i, &m)<0)
      i++;
    while(j>low && comparePrioItem(card, imapId, j, &m)>0)
      j--;
    if(i<=j) {
      if(i!=j)
	exchangePrioItems(i, j);
      i++;
      j--;
    }
  }

  if(low<j)
    qsortPrioItems(card, imapId, low, j);

  if(i<high)
    qsortPrioItems(card, imapId, i, high);
}

static void fillupMidiTable(SamCard *card, int imapId,
			    MidiTable *midiTable, unsigned *paramAddrs,
			    PriorityItem *prioItems, int nPrioItems)
{
  PriorityItem *prioItem;
  InstrDef *instrDef;
  DrumDef *drumDef;
  short *dest;
  int expectInstr, expectProgram, expectBackup;
  int lastProgram, lastVariation;
  int maxProgram, prioIdx, prioIdxSaved;

  dest=(short *)&midiTable[1];
  prioIdx=0;

  for(expectInstr=0; expectInstr<2; expectInstr++) {
    maxProgram=expectInstr ? SAM_INSTR_PROGRAMS : 1;
    for(expectProgram=0; expectProgram<maxProgram; expectProgram++) {
      /* setup instrument pointers in midiTable */
      if(expectInstr)
	midiTable->instrPtrs[expectProgram]=SAM_CPU_TO_LE16(dest-(short *)midiTable);

      /* PriorityItem doesn't distinguish between
       * current/backup instrument/drum definitions
       * so we restart from here for both current and
       * backup definitions
       * We mark already handled items in prioItems
       */
      prioIdxSaved=prioIdx;
      lastProgram=lastVariation=-1;
      for(expectBackup=0; expectBackup<2; expectBackup++) {
	prioIdx=prioIdxSaved;
	while(prioIdx<nPrioItems) {
	  prioItem=prioItems+prioIdx;

	  if(prioItem->type==PriorityItemIgnore) {
	    prioIdx++;
	    continue;
	  }

	  /* check if the prioItem points to an element we expect */
	  if(expectInstr!=prioIsInstr(prioItem))
	    break;
	  if(expectInstr && expectProgram!=prioProgramNr(prioItem))
	    break;

	  /* in current instrument/drum set
	   * we skip ambiguous program/variation combinations
	   * to be handled in backup set
	   */
	  if(!expectBackup &&
	     lastProgram==prioProgramNr(prioItem) &&
	     lastVariation==prioVariationNr(prioItem)) {
	    prioIdx++;
	    continue;
	  }

	  /* all checks succeeded, append this entry */
	  switch(prioItem->type) {
	  case PriorityItemImapInstr:
	    instrDef=(InstrDef *)dest;
	    instrDef->variation=prioItem->u.imap.entry.variation;
	    instrDef->bank=imapId*SAM_PARAM_BLOCKS+prioItem->u.imap.entry.page;
	    instrDef->paramPtr=
	      SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(prioItem->u.imap.entry.paramPtr)+
			      (paramAddrs[prioItem->u.imap.entry.page]&0xFFFF));
	    *(char **)&dest+=sizeof(InstrDef);
	    break;
	  case PriorityItemImapDrum:
	    drumDef=(DrumDef *)dest;
	    drumDef->program=prioItem->u.imap.entry.program;
	    drumDef->variation=prioItem->u.imap.entry.variation;
	    drumDef->bank=imapId*SAM_PARAM_BLOCKS+prioItem->u.imap.entry.page;
	    drumDef->paramPtr=
	      SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(prioItem->u.imap.entry.paramPtr)+
			      (paramAddrs[prioItem->u.imap.entry.page]&0xFFFF));
	    *(char **)&dest+=sizeof(DrumDef);
	    break;
	  case PriorityItemInstrDef:
	    instrDef=(InstrDef *)dest;
	    memcpy(instrDef, prioItem->u.instr.ptr, sizeof(InstrDef));
	    *(char **)&dest+=sizeof(InstrDef);
	    break;
	  case PriorityItemDrumDef:
	    drumDef=(DrumDef *)dest;
	    memcpy(drumDef, prioItem->u.drum.ptr, sizeof(DrumDef));
	    *(char **)&dest+=sizeof(DrumDef);
	    break;
	  default:
	    /* PriorityItemIgnore:
	     * will never be called that way,
	     * but we want to keep the compiler happy
	     */
	  }

	  lastProgram=prioProgramNr(prioItem);
	  lastVariation=prioVariationNr(prioItem);
	  prioItem->type=PriorityItemIgnore;
	  prioIdx++;
	}
	/* finish instr/drum definition */
	*dest++=~0;
      }
    }
    /* finish drumsets */
    if(!expectInstr)
      *dest++=~0;
  }
}

static int adjustMidiTable(SamCard *card, int id, unsigned char *imapPtr, unsigned imapSize, unsigned *paramAddrs)
{
  int error, nInstrs, nDrums, newMidiTableSize, i;
  MidiTable *oldMidiTable, *newMidiTable;
  PriorityItem *prioItems;

  if((error=loadMidiTable(card, &oldMidiTable))<0)
    return error;

  /* first count how many instruments we have in total */
  if((error=countInstruments(card, imapPtr, imapSize, oldMidiTable, NULL, &nInstrs, &nDrums))<0) {
    if(oldMidiTable)
      kfree(oldMidiTable);
    return error;
  }

  newMidiTableSize=sizeof(MidiTable)+nDrums*sizeof(DrumDef)+6+nInstrs*sizeof(InstrDef)+SAM_INSTR_PROGRAMS*4;
  if(newMidiTableSize>SAM_MAX_MT_WORDS<<1) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: midi mapping table too large (%d bytes)\n",
	   card->cardIdx, card->hardwareInfo->name, newMidiTableSize);
#endif
    if(oldMidiTable)
      kfree(oldMidiTable);
    return -ENOSPC;
  }

  if(nDrums+nInstrs>0) {
    if(!(prioItems=(PriorityItem *)kmalloc((nDrums+nInstrs)*sizeof(PriorityItem), GFP_KERNEL))) {
      if(oldMidiTable)
	kfree(oldMidiTable);
      return -ENOMEM;
    }

    /* now get the prioItems vector filled */
    if((error=countInstruments(card, imapPtr, imapSize, oldMidiTable, prioItems, NULL, NULL))<0) {
      if(prioItems)
	kfree(prioItems);
      if(oldMidiTable)
	kfree(oldMidiTable);
      return error;
    }

    if(nDrums+nInstrs>1)
      qsortPrioItems(card, id, prioItems, prioItems+nDrums+nInstrs-1);
  } else
    prioItems=NULL;

  if(!(newMidiTable=(MidiTable *)kmalloc(newMidiTableSize, GFP_KERNEL))) {
    if(prioItems)
      kfree(prioItems);
    if(oldMidiTable)
      kfree(oldMidiTable);
    return -ENOMEM;
  }
  memset(newMidiTable, 0, newMidiTableSize);
  if(oldMidiTable)
    memcpy(newMidiTable, oldMidiTable, sizeof(MidiTable));

  /* setup MIDI mapping table */
  newMidiTable->length=SAM_CPU_TO_LE16(newMidiTableSize/2);

  if(id>=0) {
    if(paramAddrs)
      for(i=0; i<SAM_PARAM_BLOCKS; i++)
	newMidiTable->paramPages[id*SAM_PARAM_BLOCKS+i]=SAM_CPU_TO_LE16(paramAddrs[i]>>16);
    else
      for(i=0; i<SAM_PARAM_BLOCKS; i++)
	newMidiTable->paramPages[id*SAM_PARAM_BLOCKS+i]=0;
  }

  fillupMidiTable(card, id, newMidiTable, paramAddrs, prioItems, nDrums+nInstrs);

  /* relocate instrument pointers and write midi table back */
  error=samAlloc(card, SAM_MMT_ID_MIDI_MT, SAM_LE16_TO_CPU(newMidiTable->length), NULL,
		 SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K, relocateWriteMidiTable, (void *)newMidiTable);

  if(error>=0 && card->firmwareInfo->nSBankRehash)
    error=samTalk(card,
		  SamSendCtrlP, card->firmwareInfo->nSBankRehash, card->firmwareInfo->sbankRehash,
		  SamEndOfScript);

  kfree(newMidiTable);
  if(prioItems)
    kfree(prioItems);
  if(oldMidiTable)
    kfree(oldMidiTable);
  return error;
}

int samRelocateMidiTable(SamCard *card)
{
  int error;
  MidiTable *midiTable;

  if((error=loadMidiTable(card, &midiTable))<0)
    return error;

  if(midiTable) {
    /* relocate and write midi mapping table back */
    error=samAlloc(card,
		   SAM_MMT_ID_MIDI_MT, SAM_LE16_TO_CPU(midiTable->length), NULL,
		   SAM_ALIGN_DONT_CARE, SAM_BOUNDARY_64K, relocateWriteMidiTable, (void *)midiTable);

    if(error>=0 && card->firmwareInfo->nSBankRehash)
      error=samTalk(card,
		    SamSendCtrlP, card->firmwareInfo->nSBankRehash, card->firmwareInfo->sbankRehash,
		    SamEndOfScript);

    kfree(midiTable);
  }

  return error;
}

static int disposeBank(SamCard *card, int id)
{
  int error;

  if(!*card->mem.sbank[id].name)
    return 0;
  memset(card->mem.sbank+id, 0, sizeof(SamMMTSBank));

  if((error=adjustMidiTable(card, id, NULL, 0, NULL))<0 ||
     (error=samFree(card, SAM_MMT_ID_MIDI_PCM|(id<<8), SAM_MMT_BANK_MASK))<0 ||
     (error=samFree(card, SAM_MMT_ID_MIDI_PAR|(id<<8), SAM_MMT_BANK_MASK))<0)
    return error;
  return 0;
}

int samSBankLoad(SamCard *card, SamSoundBank *bank)
{
  int error, id, n, i, ofs;
  RiffChunk chunk, *chunkP;
  RelocEntry reloc, *relocP;
  unsigned paramAddrs[SAM_PARAM_BLOCKS], sampleAddrs[SAM_SAMPLE_BLOCKS];
  int nParamBlocks, nSampleBlocks, paramBytes;
  unsigned size, nReloc, paramStartAddr, imapSize, v;
  unsigned char *base, *cp, *paramBuf, *imapPtr;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  if((error=verify_area(VERIFY_READ, bank, sizeof(SamSoundBank)))<0)
    return error;

  if(SAM_GET_USER(id, &bank->id))
    return -EFAULT;
  if(id>=SAM_NROF_SBANKS) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: sounbank id out of range\n",
	   card->cardIdx, card->hardwareInfo->name);
#endif
    return -EINVAL;
  }

  card->mixer.sbankDirty=~0;
  wake_up(&card->mixer.waitDirty);

  if((error=disposeBank(card, id))<0)
    return error;

  /* traverse through soundbank chunks */
  if(SAM_GET_USER(base, &bank->data) ||
     SAM_GET_USER(size, &bank->size))
    return -EFAULT;

  if(!base || !size || size>SAM_MAX_BANK_SIZE) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: invalid soundbank size\n",
	   card->cardIdx, card->hardwareInfo->name);
#endif
    return -EINVAL;
  }
  chunkP=(RiffChunk *)base;
  memset(paramAddrs, 0, sizeof(paramAddrs));
  relocP=NULL; nReloc=0;
  paramStartAddr=0;
  paramBuf=NULL; paramBytes=0;
  nParamBlocks=nSampleBlocks=0;
  imapPtr=NULL; imapSize=0;
  error=0;
  while(error>=0 && size>0) {
    if(size<sizeof(RiffChunk)) {
      error=-EINVAL;
      break;
    }
    if((error=verify_area(VERIFY_READ, chunkP, sizeof(RiffChunk)))<0)
      break;
    if(SAM_MEMCPY_FROMFS(&chunk, chunkP, sizeof(RiffChunk))) {
      error=-EFAULT;
      break;
    }
#ifndef __LITTLE_ENDIAN
    chunk.id=SAM_LE32_TO_CPU(chunk.id);
    chunk.size=SAM_LE32_TO_CPU(chunk.size);
#endif
    cp=(char *)chunkP+sizeof(RiffChunk);
    if((error=verify_area(VERIFY_READ, cp, chunk.size))<0)
      break;
    if(chunk.size>SAM_MAX_BANK_SIZE ||
       sizeof(RiffChunk)+chunk.size>size) {
#ifdef SAM_DEBUG
      printk(KERN_DEBUG "sam9407[#%d:%s]: RIFF chunk too large\n", card->cardIdx, card->hardwareInfo->name);
#endif
      error=-EINVAL;
      break;
    }
    switch(chunk.id) {
    case SAM_CKID_DRCP:
    case SAM_CKID_TTMA:
    case SAM_CKID_TTEL:
    case SAM_CKID_TTSL:
    case SAM_CKID_TTKL:
      /* ignored */
      break;
    case SAM_CKID_PRIO:
    case SAM_CKID_TTPR:
      if(chunk.size>=sizeof(SamMMTSBank)) {
	if(SAM_MEMCPY_FROMFS(card->mem.sbank+id, cp, sizeof(SamMMTSBank)))
	  error=-EFAULT;
#ifndef __LITTLE_ENDIAN
	if(error>=0)
	  card->mem.sbank[id].priority=SAM_LE16_TO_CPU(card->mem.sbank[id].priority);
#endif
      } else {
#ifdef SAM_DEBUG
	printk(KERN_DEBUG "sam9407[#%d:%s]: PRIO chunk too small\n", card->cardIdx, card->hardwareInfo->name);
#endif
	error=-EINVAL;
      }
      break;
    case SAM_CKID_IMAP:
    case SAM_CKID_TTIM:
      imapPtr=cp;
      imapSize=chunk.size;
      break;
    case SAM_CKID_RLOC:
    case SAM_CKID_TTRL:
      relocP=(RelocEntry *)cp;
      nReloc=chunk.size/sizeof(RelocEntry);
      break;
    case SAM_CKID_PARA:
    case SAM_CKID_TTPA:
      paramStartAddr=cp-base;
      paramBytes=chunk.size;
      if(paramBuf) {
	vfree(paramBuf);
	paramBuf=NULL;
      }
      if(paramBytes>0) {
	if((paramBuf=vmalloc(paramBytes))) {
	  if(SAM_MEMCPY_FROMFS(paramBuf, cp, paramBytes))
	    error=-EFAULT;
	  else
	    error=allocBlocks(card, SAM_MMT_ID_MIDI_PAR|(id<<8), NULL, paramBytes>>1, SAM_BOUNDARY_64K,
			      SAM_PARAM_PAGE_WORDS, SAM_PARAM_BLOCKS, paramAddrs, &nParamBlocks);
	} else
	  error=-ENOMEM;
      } else
	nParamBlocks=0;
      break;
    case SAM_CKID_SAMP:
    case SAM_CKID_TTSA:
      error=allocBlocks(card, SAM_MMT_ID_MIDI_PCM|(id<<8), (unsigned short *)cp, chunk.size>>1, SAM_BOUNDARY_256K,
			SAM_SAMPLE_PAGE_WORDS, SAM_SAMPLE_BLOCKS, sampleAddrs, &nSampleBlocks);
      break;
    default:
#ifdef SAM_DEBUG
      printk(KERN_DEBUG "sam9407[#%d:%s]: unknown RIFF chunk 0x%08x\n",
	     card->cardIdx, card->hardwareInfo->name, chunk.id);
#endif
      error=-EINVAL;
      break;
    }
    if(error<0)
      break;
    size-=sizeof(RiffChunk)+chunk.size;
    chunkP=(RiffChunk *)((char *)chunkP+sizeof(RiffChunk)+chunk.size);
  }

  if(error>=0 && relocP && paramBytes>0) {
    /* relocate the param blocks */
    for(i=0; error>=0 && i<nReloc; i++) {
      if(SAM_MEMCPY_FROMFS(&reloc, relocP+i, sizeof(RelocEntry))) {
	error=-EFAULT;
	break;
      }
      reloc.block&=0x7F;
      reloc.addr=SAM_LE32_TO_CPU(reloc.addr)-paramStartAddr;
      switch(reloc.type) {
      case SAM_RELOC_TYPE_PARAM:
	if(reloc.addr+2<=paramBytes) {
	  if(reloc.block+1==nParamBlocks)
	    *(unsigned short *)(paramBuf+reloc.addr)=
	      SAM_CPU_TO_LE16(SAM_LE16_TO_CPU(*(unsigned short *)(paramBuf+reloc.addr))+
			      (paramAddrs[reloc.block]&0xFFFF));
	} else {
#ifdef SAM_DEBUG
	  printk(KERN_DEBUG "sam9407[#%d:%s]: relocation address out of range\n",
		 card->cardIdx, card->hardwareInfo->name);
#endif
	  error=-EINVAL;
	}
	break;
      case SAM_RELOC_TYPE_MA2_PG:
	if(reloc.addr+6<=paramBytes) {
	  if(reloc.block<nSampleBlocks)
	    *(unsigned short *)(paramBuf+reloc.addr+4)=
	      SAM_CPU_TO_LE16((SAM_LE16_TO_CPU(*(unsigned short *)(paramBuf+reloc.addr+4))&0xE03f) |
			      ((sampleAddrs[reloc.block]>>12)&~0x3f));
	} else {
#ifdef SAM_DEBUG
	  printk(KERN_DEBUG "sam9407[#%d:%s]: relocation address out of range\n",
		 card->cardIdx, card->hardwareInfo->name);
#endif
	  error=-EINVAL;
	}
	break;
      case SAM_RELOC_TYPE_MA2_LOOP:
	if(reloc.block+1==nSampleBlocks) {
	  if(reloc.addr+4<=paramBytes) {
	    v=SAM_LE16_TO_CPU(((unsigned short *)(paramBuf+reloc.addr))[0])<<2 |
	      SAM_LE16_TO_CPU(((unsigned short *)(paramBuf+reloc.addr))[1])>>14;
	    v+=sampleAddrs[reloc.block]&0x3FFFF;
	    ((unsigned short *)(paramBuf+reloc.addr))[0]=SAM_CPU_TO_LE16(v>>2);
	    ((unsigned short *)(paramBuf+reloc.addr))[1]&=SAM_CPU_TO_LE16(0x3FFF);
	    ((unsigned short *)(paramBuf+reloc.addr))[1]|=SAM_CPU_TO_LE16((v&3)<<14);
	  } else {
#ifdef SAM_DEBUG
	    printk(KERN_DEBUG "sam9407[#%d:%s]: relocation address out of range\n",
		   card->cardIdx, card->hardwareInfo->name);
#endif
	    error=-EINVAL;
	  }
	}
	break;
      case SAM_RELOC_TYPE_MB_END:
	if(reloc.block+1==nSampleBlocks) {
	  if(reloc.addr+4<=paramBytes) {
	    v=SAM_LE16_TO_CPU(((unsigned short *)(paramBuf+reloc.addr))[1])<<2 |
	      SAM_LE16_TO_CPU(((unsigned short *)(paramBuf+reloc.addr))[0])>>14;
	    v+=sampleAddrs[reloc.block]&0x3FFFF;
	    ((unsigned short *)(paramBuf+reloc.addr))[1]=SAM_CPU_TO_LE16(v>>2);
	    ((unsigned short *)(paramBuf+reloc.addr))[0]&=SAM_CPU_TO_LE16(0x3FFF);
	    ((unsigned short *)(paramBuf+reloc.addr))[0]|=SAM_CPU_TO_LE16((v&3)<<14);
	  } else {
#ifdef SAM_DEBUG
	    printk(KERN_DEBUG "sam9407[#%d:%s]: relocation address out of range\n",
		   card->cardIdx, card->hardwareInfo->name);
#endif
	    error=-EINVAL;
	  }
	}
	break;
      default:
#ifdef SAM_DEBUG
	printk(KERN_DEBUG "sam9407[#%d:%s]: unknown relocation type %d\n",
	       card->cardIdx, card->hardwareInfo->name, reloc.type);
#endif
	error=-EINVAL;
      }
    }
  }

  if(error>=0 && paramBytes>0) {
    /* transfer the param blocks */
    for(i=0; error>=0 && i<nParamBlocks; i++) {
      ofs=i*SAM_PARAM_PAGE_WORDS;
      n=(paramBytes>>1)-ofs;
      if(n>SAM_PARAM_PAGE_WORDS)
	n=SAM_PARAM_PAGE_WORDS;
      error=samTalk(card, SamWriteMem, paramAddrs[i], (unsigned short *)paramBuf+ofs, n, SamEndOfScript);
    }
  }

  if(paramBuf)
    vfree(paramBuf);

  if(error>=0 && imapPtr && imapSize && *card->mem.sbank[id].name)
    error=adjustMidiTable(card, id, imapPtr, imapSize, paramAddrs);

  if(error<0)
    disposeBank(card, id);

  return error;
}

int samSBankUnload(SamCard *card, unsigned char *idP)
{
  unsigned char id;
  int error;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  if((error=verify_area(VERIFY_READ, idP, sizeof(unsigned char)))<0)
    return error;
  if(SAM_GET_USER(id, idP))
    return -EFAULT;

  if(id>=SAM_NROF_SBANKS) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: sounbank id out of range\n",
	   card->cardIdx, card->hardwareInfo->name);
#endif
    return -EINVAL;
  }

  card->mixer.sbankDirty=~0;
  wake_up(&card->mixer.waitDirty);

  return disposeBank(card, id);
}

int samSBankPrioChange(SamCard *card, SamSoundBankPrio *prioP)
{
  SamSoundBankPrio prio;
  int error;
  SamMMTSBank *sbank;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  if((error=verify_area(VERIFY_READ, prioP, sizeof(SamSoundBankPrio)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&prio, prioP, sizeof(SamSoundBankPrio)))
    return -EFAULT;

  if(prio.id>=SAM_NROF_SBANKS) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: sounbank id out of range\n",
	   card->cardIdx, card->hardwareInfo->name);
#endif
    return -EINVAL;
  }
  sbank=card->mem.sbank+prio.id;
  if(!*sbank->name) {
#ifdef SAM_DEBUG
    printk(KERN_DEBUG "sam9407[#%d:%s]: sounbank %d not loaded\n",
	   card->cardIdx, card->hardwareInfo->name, prio.id);
#endif
    return -EINVAL;
  }

  card->mixer.sbankDirty=~0;
  wake_up(&card->mixer.waitDirty);

  sbank->priority=prio.priority;
  return adjustMidiTable(card, -1, NULL, 0, NULL);
}

int samSBankInfo(SamCard *card, SamSoundBankInfo *info)
{
  int error, i;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  if((error=verify_area(VERIFY_WRITE, info, SAM_NROF_SBANKS*sizeof(SamSoundBankInfo)))<0)
    return error;

  for(i=0; i<SAM_NROF_SBANKS; i++) {
    if(SAM_MEMCPY_TOFS(info[i].name, card->mem.sbank[i].name, SAM_SBANK_NAME_LEN) ||
       SAM_PUT_USER(0, info[i].name+SAM_SBANK_NAME_LEN) ||
       SAM_PUT_USER(card->mem.sbank[i].priority, &info[i].priority)) {
      error=-EFAULT;
      break;
    }
  }

  if(error<0)
    return error;

  return 0;
}
