/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#include <linux/soundcard.h>

#include "driver.h"
#include "io.h"
#include "alloc.h"
#include "audio.h"
#include "sync.h"
#include "mixer.h"

int samAllocMixerDirtyFlags(SamCard *card)
{
  int hwSize, fwSize;

  hwSize=card->hardwareInfo->mixerDirty.n*sizeof(SamDirtyFlag);
  if(hwSize>0)
    card->mixer.hwDirtyFlags=(SamDirtyFlag *)kmalloc(hwSize, GFP_KERNEL);
  else
    card->mixer.hwDirtyFlags=NULL;

  fwSize=card->firmwareInfo->mixerDirty.n*sizeof(SamDirtyFlag);
  card->mixer.fwDirtyFlags=(SamDirtyFlag *)kmalloc(fwSize, GFP_KERNEL);

  if((hwSize>0 && !card->mixer.hwDirtyFlags) ||
     !card->mixer.fwDirtyFlags) {
    samReleaseMixerDirtyFlags(card);
    return -ENOMEM;
  }

  memset(card->mixer.hwDirtyFlags, 0, hwSize);
  memset(card->mixer.fwDirtyFlags, 0, fwSize);

  return 0;
}

void samReleaseMixerDirtyFlags(SamCard *card)
{
  SamDirtyFlag *dirtyFlags;

  if((dirtyFlags=card->mixer.hwDirtyFlags)) {
    card->mixer.hwDirtyFlags=NULL;
    kfree(dirtyFlags);
  }

  if((dirtyFlags=card->mixer.fwDirtyFlags)) {
    card->mixer.fwDirtyFlags=NULL;
    kfree(dirtyFlags);
  }
}

static __inline__ unsigned ctrlTblAddr(SamCard *card, int channel, SamFWCtrlVendorInfo *info, unsigned addrTag)
{
  if(channel>=0) {
    /* audio */
    switch(info->addrTagType) {
    case SamAddrTagTypeAddr:
      return addrTag;
    case SamAddrTagTypeChannel:
      return channel;
    case SamAddrTagTypeChannelMSB:
      return channel*(info->addrTagLimit+1)+addrTag;
    case SamAddrTagTypePlayChannelLSB:
      return addrTag*card->firmwareInfo->playBackChannels+channel;
    default: /* SamAddrTagTypeNone */
      return 0;
    }
  } else {
    /* mixer */
    switch(info->addrTagType) {
    case SamAddrTagTypeAddr:
      return addrTag;
    default: /* SamAddrTagTypeNone */
      return 0;
    }
  }
}

static __inline__ unsigned ctrlTypeSize(SamCtrlType type, unsigned valueLimit)
{
  return (!!valueLimit+(valueLimit>0xFF))<<!!(type&SAM_MIXER_TYPE_SEND_TWICE);
}

static __inline__ unsigned ctrlConvertValueExport(SamCtrlType type, unsigned valueLimit, unsigned value)
{
  unsigned result;

  switch(type&~SAM_MIXER_TYPE_SEND_TWICE) {
  case SamCtrlTypeValueHalf:
    result=value<<1;
    break;
  case SamCtrlTypeValueHalfPlus:
    result=value<<1;
    if(result>0)
      result--;
    break;
  default:
    result=value;
  }

  if(result>valueLimit)
    result=valueLimit;

  return result;
}

static __inline__ unsigned ctrlConvertValueImport(SamCtrlType type, unsigned valueLimit, unsigned value)
{
  unsigned result;

  result=value;
  if(valueLimit<result)
    result=valueLimit;

  switch(type&~SAM_MIXER_TYPE_SEND_TWICE) {
  case SamCtrlTypeValueHalf:
    result>>=1;
    break;
  case SamCtrlTypeValueHalfPlus:
    result=(result+1)>>1;
    break;
  default:
    /* make compiler happy */
  }

  /* booleans are represented as 0x00/0x7F */
  if(valueLimit==1)
    result=result ? 0x7F : 0x00;

  if(type&SAM_MIXER_TYPE_SEND_TWICE)
    result=(result<<(ctrlTypeSize(type, valueLimit)<<2)) | result;

  return result;
}

static __inline__ unsigned *storeAtAddr(SamCard *card, int channel, unsigned storeAt, unsigned addrTag)
{
  char *base;
  if(channel>=0)
    base=(char *)&card->channels[channel].ctrlValues;
  else
    base=(char *)&card->ctrlValues;
  return (unsigned *)((char *)base+(storeAt&~SAM_STORE_AT_MASK))+addrTag;
}

static __inline__ void syncLeave(SamCard *card)
{
  if(card->mixer.syncGroup>=0) {
    samSyncLeave(card->mixer.syncGroup, card->cardIdx, SamSyncDeviceMixer, card->mixer.syncStarted);
    card->mixer.syncGroup=-1;
  }
}

static __inline__ int putInt(unsigned long arg, int value)
{
  int error;

  if((error=verify_area(VERIFY_WRITE, (void *)arg, sizeof(int)))<0)
    return error;
  if(SAM_PUT_USER(value, (int *)arg))
    return -EFAULT;
  return 0;
}

static __inline__ int putEvent(SamEvent *userEvent, SamEvent *kernelEvent, int type, int id, int addr)
{
  kernelEvent->type=type;
  kernelEvent->id=id;
  kernelEvent->addr=addr;
  if(SAM_MEMCPY_TOFS(userEvent, kernelEvent, sizeof(SamEvent)))
    return -EFAULT;

  return 0;
}

static int inputAvailable(SamCard *card, SamDirtyFlag mask)
{
  int channelLimit, channel, nDirtyFlags, i;
  SamChannelInfo *chp;

  if(card->mixer.firmwareDirty&mask)
    return 1;

  if(!card->firmwareLoaded)
    return 0;

  if(card->firmwareInfo->haveMidi && (card->mixer.sbankDirty&mask))
    return 1;

  if(card->firmwareInfo->haveAudio && (card->mixer.channelOwnerDirty&mask))
    return 1;

  nDirtyFlags=card->hardwareInfo->mixerDirty.n;
  for(i=0; i<nDirtyFlags; i++)
    if((card->mixer.hwDirtyFlags[i]&mask))
      return 1;

  nDirtyFlags=card->firmwareInfo->mixerDirty.n;
  for(i=0; i<nDirtyFlags; i++)
    if((card->mixer.fwDirtyFlags[i]&mask))
      return 1;

  if(card->firmwareInfo->haveAudio) {
    channelLimit=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
    nDirtyFlags=card->firmwareInfo->audioDirty.n;
    for(channel=0; channel<channelLimit; channel++) {
      chp=card->channels+channel;
      down(&chp->accessLock);
      for(i=0; i<nDirtyFlags; i++)
	if((chp->dirtyFlags[i]&mask)) {
	  up(&chp->accessLock);
	  return 1;
	}
      up(&chp->accessLock);
    }
  }

  return 0;
}

int samApiInfo(SamCard *card, SamApiInfo *apiInfo, unsigned version)
{
  int error;

  if((error=verify_area(VERIFY_WRITE, apiInfo, sizeof(SamApiInfo)))<0)
    return error;

  if(SAM_PUT_USER(version, &apiInfo->version))
    return -EFAULT;

  if(SAM_PUT_USER(card->firmwareLoaded ? card->firmwareInfo->apiClass : SAM_API_CLASS_NONE, &apiInfo->apiClass))
    return -EFAULT;

  return 0;
}

static int syncJoin(SamCard *card, int *syncGroupP)
{
  int error, syncGroup;

  if((error=verify_area(VERIFY_WRITE, syncGroupP, sizeof(int)))<0)
    return error;
  if(SAM_GET_USER(syncGroup, syncGroupP))
    return -EFAULT;

  syncLeave(card);
  if((error=samSyncJoin(&syncGroup, card->cardIdx, SamSyncDeviceMixer))>=0) {
    card->mixer.syncGroup=syncGroup;
    card->mixer.syncStarted=0;
    if(SAM_PUT_USER(syncGroup, syncGroupP))
      error=-EFAULT;
  }

  return error;
}

static int driverInfo(SamCard *card, SamDriverInfo *info)
{
  int error;
  SamDriverInfo tmpInfo;

  if((error=verify_area(VERIFY_WRITE, info, sizeof(SamDriverInfo)))<0)
    return error;

  memset(&tmpInfo, 0, sizeof(tmpInfo));

  tmpInfo.driverVersion.major=SAM_VERSION_MAJOR;
  tmpInfo.driverVersion.minor=SAM_VERSION_MINOR;
  tmpInfo.driverVersion.tiny=SAM_VERSION_TINY;

  strncpy(tmpInfo.hardware, card->hardwareInfo->name, sizeof(tmpInfo.hardware)-1);

  if(card->firmwareLoaded) {
    strncpy(tmpInfo.firmware, card->firmwareInfo->name, sizeof(tmpInfo.firmware)-1);
    tmpInfo.haveAudio=card->firmwareInfo->haveAudio;
    tmpInfo.haveMidi=card->firmwareInfo->haveMidi;
    tmpInfo.haveMod=card->firmwareInfo->haveMod;
    samGetMemInfo(card, &tmpInfo);
    samGetAudioInfo(card, &tmpInfo);
    tmpInfo.peakMeterValues=card->firmwareInfo->peakMeterWords;
  }

  if(SAM_MEMCPY_TOFS(info, &tmpInfo, sizeof(SamDriverInfo)))
    return -EFAULT;

  return 0;
}

static int getHardwareHints(SamCard *card, SamHardwareHints *hints)
{
  int error;

  if((error=verify_area(VERIFY_WRITE, hints, sizeof(SamHardwareHints)))<0)
    return error;

  if(SAM_MEMCPY_TOFS(hints, &card->hints, sizeof(SamHardwareHints)))
    return -EFAULT;

  return 0;
}

static int setHardwareHints(SamCard *card, SamHardwareHints *hints)
{
  int error;

  if(!SAM_CAP_SYS_ADMIN())
    return -EACCES;

  if((error=verify_area(VERIFY_READ, hints, sizeof(SamHardwareHints)))<0)
    return error;

  if(SAM_MEMCPY_FROMFS(&card->hints, hints, sizeof(SamHardwareHints)))
    return -EFAULT;

  if(card->hardwareInfo->processHints)
    (*card->hardwareInfo->processHints)(card);

  return 0;
}

int samCtrlsInfo(SamCard *card, int channel, SamControl *ctrls)
{
  int error, maxFWCtrlId;
  SamControl *ctrlP;
  SamMixerId ctrlId;
  SamFWCtrlVendorInfo *fwInfoBase, *fwInfo;

  if(channel>=0) {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
    fwInfoBase=card->firmwareInfo->audioCtrlInfo;
  } else {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nMixerCtrls;
    fwInfoBase=card->firmwareInfo->mixerCtrlInfo;
  }

  for(ctrlP=ctrls;;ctrlP++) {
    if((error=verify_area(VERIFY_WRITE, ctrlP, sizeof(SamControl)))<0)
      return error;
    if(SAM_GET_USER(ctrlId, &ctrlP->id))
      return -EFAULT;
    if(ctrlId==SAM_MIXER_ID_SENTINEL)
      return 0;
    if(channel<0 && ctrlId>=SAM_MIXER_HW_ID_FIRST) {
      /* firmware independent hardware control */
      if(ctrlId>=SAM_MIXER_HW_ID_LAST)
	return -EINVAL;
      if(SAM_PUT_USER(card->hardwareInfo->ctrlInfo &&
		      card->hardwareInfo->ctrlInfo[ctrlId-SAM_MIXER_HW_ID_FIRST].vendorHandler &&
		      (!card->hardwareInfo->ctrlIsAvail ||
		       (*card->hardwareInfo->ctrlIsAvail)(card, ctrlId)),
		      &ctrlP->value))
	return -EFAULT;
      continue;
    }

    /* firmware dependent control */
    if(ctrlId>=maxFWCtrlId)
      return -EINVAL;
    fwInfo=fwInfoBase+ctrlId;
    if(SAM_PUT_USER(fwInfo->type!=SamCtrlTypeUnsupported &&
		    (fwInfo->hwHookType!=SamHWHookTypeMandatory ||
		     (card->hardwareInfo->hooks && card->hardwareInfo->hooks[fwInfo->hwHookId] &&
		      (!card->hardwareInfo->hookIsAvail ||
		       (*card->hardwareInfo->hookIsAvail)(card, fwInfo->hwHookId)))), &ctrlP->value))
      return -EFAULT;
  }
  return 0;
}

int samCtrlsGet(SamCard *card, int channel, SamControl *ctrls)
{
  int error, maxFWCtrlId, haveCtrlTbl, hwHookIsAvail;
  unsigned addr, v, addrTag;
  unsigned char ctrlTbl[256];
  SamControl *ctrlP;
  SamMixerId ctrlId;
  SamVendorHandler vendorHandler;
  SamHWCtrlVendorInfo *hwInfo;
  SamFWCtrlVendorInfo *fwInfoBase, *fwInfo;
  
  if(channel>=0) {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
    fwInfoBase=card->firmwareInfo->audioCtrlInfo;
  } else {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nMixerCtrls;
    fwInfoBase=card->firmwareInfo->mixerCtrlInfo;
  }

  haveCtrlTbl=0;
  for(ctrlP=ctrls;;ctrlP++) {
    if((error=verify_area(VERIFY_WRITE, ctrlP, sizeof(SamControl)))<0)
      return error;
    if(SAM_GET_USER(ctrlId, &ctrlP->id))
      return -EFAULT;
    if(ctrlId==SAM_MIXER_ID_SENTINEL)
      return 0;

    if(channel<0 && ctrlId>=SAM_MIXER_HW_ID_FIRST) {
      /* firmware independent hardware control */
      if(ctrlId>=SAM_MIXER_HW_ID_LAST)
	return -EINVAL;
      if(!card->hardwareInfo->ctrlInfo)
	continue;
      hwInfo=card->hardwareInfo->ctrlInfo+ctrlId-SAM_MIXER_HW_ID_FIRST;
      if(!hwInfo->vendorHandler)
	continue;
      if(card->hardwareInfo->ctrlIsAvail &&
	 !(*card->hardwareInfo->ctrlIsAvail)(card, ctrlId))
	continue;
      if(SAM_GET_USER(addrTag, &ctrlP->addr))
	return -EFAULT;
      if(addrTag>hwInfo->addrTagLimit)
	return -EINVAL;
      v=0;
      if((error=(*hwInfo->vendorHandler)(card, 0, ctrlId, addrTag, &v))<0)
	return error;
      if(SAM_PUT_USER(v, &ctrlP->value))
	return -EFAULT;
      continue;
    }

    /* firmware dependent control */
    if(ctrlId>=maxFWCtrlId)
      return -EINVAL;
    fwInfo=fwInfoBase+ctrlId;
    if(fwInfo->type==SamCtrlTypeUnsupported)
      continue;
    hwHookIsAvail=fwInfo->hwHookType!=SamHWHookTypeNone &&
      card->hardwareInfo->hooks && card->hardwareInfo->hooks[fwInfo->hwHookId] &&
      (!card->hardwareInfo->hookIsAvail || (*card->hardwareInfo->hookIsAvail)(card, fwInfo->hwHookId));
    if((fwInfo->hwHookType==SamHWHookTypeMandatory && !hwHookIsAvail) ||
       (fwInfo->channelRestriction==SamChannelRestrictionPlayOnly && channel>=card->firmwareInfo->playBackChannels) ||
       (fwInfo->channelRestriction==SamChannelRestrictionRecordOnly && channel<card->firmwareInfo->playBackChannels))
      continue;

    if(SAM_GET_USER(addrTag, &ctrlP->addr))
      return -EFAULT;
    if(addrTag>fwInfo->addrTagLimit)
      return -EINVAL;

    if(fwInfo->type==SamCtrlTypeVendorHandler) {
      if((fwInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE) {
	if(SAM_PUT_USER(1, &ctrlP->isConfigured) ||
	   SAM_PUT_USER(*storeAtAddr(card, channel, fwInfo->storeAt, addrTag), &ctrlP->value))
	  return -EFAULT;
      } else {
	v=0;
	vendorHandler=fwInfo->vendorHandler;
	if(!vendorHandler && hwHookIsAvail)
	  vendorHandler=card->hardwareInfo->hooks[fwInfo->hwHookId];
	if(vendorHandler &&
	   (error=(*vendorHandler)(card, 0, ctrlId, addrTag, &v))<0)
	  return error;
	if(SAM_PUT_USER(1, &ctrlP->isConfigured) ||
	   SAM_PUT_USER(v, &ctrlP->value))
	  return -EFAULT;
      }
      continue;
    }

    /* plain SAM control */
    if((fwInfo->storeAt&SAM_STORE_AT_MASK)!=SAM_STORE_AT_KERNEL_SPACE &&
       !haveCtrlTbl) {
      /* need to load ctrlTbl */
      if((error=samFindMMT(card, SAM_MMT_ID_CTRL_TBL, SAM_MMT_ID_MASK, &addr, NULL))<0)
	return error;
      if(error==0)
	return -EIO;
      /* temporarily lift the audio channel accessLock, as we might get
       * a streaming wave interrupt, demanding attention
       */
      if(channel>=0)
	up(&card->channels[channel].accessLock);
      error=samTalk(card,
		    SamReadMem, addr, &ctrlTbl, sizeof(ctrlTbl)>>(1+!card->firmwareInfo->largeCtrlTable),
		    SamEndOfScript);
      if(channel>=0)
	down(&card->channels[channel].accessLock);
      if(error<0)
	return error;
      haveCtrlTbl=1;
    }

    switch(fwInfo->storeAt&SAM_STORE_AT_MASK) {
    case SAM_STORE_AT_KERNEL_SPACE:
      v=*storeAtAddr(card, channel, fwInfo->storeAt, addrTag);
      if(SAM_PUT_USER(channel>=0 ? !!(v&SAM_AUDIO_CTRL_CONFIGURED_MASK) : 1, &ctrlP->isConfigured))
	return -EFAULT;
      v&=SAM_AUDIO_CTRL_VALUE_MASK;
      break;
    case SAM_STORE_AT_CTRL_TBL_ADDR:
      v=ctrlTbl[(fwInfo->storeAt&~SAM_STORE_AT_MASK)+
	       ctrlTblAddr(card, channel, fwInfo, addrTag)*(1+fwInfo->valueBytesLimit)+
	       fwInfo->valueBytesOfs];
      if(SAM_PUT_USER(1, &ctrlP->isConfigured))
	return -EFAULT;
      break;
    default: /* SAM_STORE_AT_CTRL_TBL_DEFAULT */
      v=ctrlTbl[fwInfo->ctrl+
	       ctrlTblAddr(card, channel, fwInfo, addrTag)*(1+fwInfo->valueBytesLimit)+
	       fwInfo->valueBytesOfs];
      if(SAM_PUT_USER(1, &ctrlP->isConfigured))
	return -EFAULT;
    }

    v=ctrlConvertValueExport(fwInfo->type, fwInfo->valueLimit, v);
    if(SAM_PUT_USER(v, &ctrlP->value))
      return -EFAULT;
  }
  return 0;
}

static int triggerAllDirtyFlags(SamCard *card)
{
  int error, channelLimit, channel;
  SamMixerId maxFWCtrlId, ctrlId;
  SamFWCtrlVendorInfo *fwCtrlInfo;
  SamChannelInfo *chp;

  error=0;

  /* mixer controls */
  maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nMixerCtrls;
  for(ctrlId=0; ctrlId<maxFWCtrlId; ctrlId++) {
    fwCtrlInfo=card->firmwareInfo->mixerCtrlInfo+ctrlId;
    if(fwCtrlInfo->type==SamCtrlTypeUnsupported ||
       fwCtrlInfo->responseType==SamCtrlResponseReset ||
       (fwCtrlInfo->hwHookType==SamHWHookTypeMandatory &&
	(!card->hardwareInfo->hooks || !card->hardwareInfo->hooks[fwCtrlInfo->hwHookId] ||
	 (card->hardwareInfo->hookIsAvail && !(*card->hardwareInfo->hookIsAvail)(card, fwCtrlInfo->hwHookId)))))
	  continue;
    memset(card->mixer.fwDirtyFlags+fwCtrlInfo->dirtyAddr, ~0, (fwCtrlInfo->addrTagLimit+1)*sizeof(SamDirtyFlag));
  }

  /* audio controls */
  if(card->firmwareInfo->haveAudio) {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
    channelLimit=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
    for(channel=0; channel<channelLimit; channel++) {
      chp=card->channels+channel;
      down(&chp->accessLock);
      for(ctrlId=0; ctrlId<maxFWCtrlId; ctrlId++) {
	fwCtrlInfo=card->firmwareInfo->audioCtrlInfo+ctrlId;
	/* we don't need to trigger values store at kernel space
	 * as no channel could've been open when sending
	 * a reset control
	 */
	if(fwCtrlInfo->type==SamCtrlTypeUnsupported ||
	   (fwCtrlInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE)
	  continue;
	memset(chp->dirtyFlags+fwCtrlInfo->dirtyAddr, ~0, (fwCtrlInfo->addrTagLimit+1)*sizeof(SamDirtyFlag));
      }
      up(&chp->accessLock);
    }
  }

  wake_up(&card->mixer.waitDirty);

  return error;
}

static int sendCtrlCmdSeq(SamCard *card, int channel, int *triggeredAllDirtyFlags, SamFWCtrlVendorInfo *info, unsigned char *cmds, int nCmds)
{
  int error, tmpError;
  unsigned addr;
  unsigned short ctrlValue;
  char voicesFree;

  error=0;
  switch(info->responseType) {
  case SamCtrlResponseReset:
    if(card->firmwareInfo->resetRestoreCtrl) {
      /* retrieve the current value to send along with
       * reset hook control
       */
      if((error=samFindMMT(card, SAM_MMT_ID_CTRL_TBL, SAM_MMT_ID_MASK, &addr, NULL))<0)
	return error;
      if(error==0)
	return -EIO;
      /* temporarily lift the audio channel accessLock, as we might get
       * a streaming wave interrupt, demanding attention
       */
      if(channel>=0)
	up(&card->channels[channel].accessLock);
      /* read word aligned word boundary from control table */
      error=samTalk(card,
		    SamReadMem, addr+(card->firmwareInfo->resetRestoreCtrl>>1), &ctrlValue, 1,
		    SamEndOfScript);
      if(channel>=0)
	down(&card->channels[channel].accessLock);
      if(error<0)
	return error;
      /* if offset is odd, take the MSB, otherwise LSB */
      if(card->firmwareInfo->resetRestoreCtrl&1)
	ctrlValue>>=8;
      ctrlValue&=0xFF;
    }

    error=samTalkNotBusy(card,
			 SamSendCtrlP, nCmds, cmds,
			 SamExpect, 0,
			 SamUARTMode,
			 SamSendCtrlIf, card->firmwareInfo->resetRestoreCtrl, 2, card->firmwareInfo->resetRestoreCtrl, ctrlValue,
			 SamSendCtrlP, card->firmwareInfo->nResetReadjust, card->firmwareInfo->resetReadjust,
			 SamEndOfScript);

    /* whenever the card received a reset
     * assume that all non-reset controls have become dirty
     */
    if(!*triggeredAllDirtyFlags) {
      if((tmpError=triggerAllDirtyFlags(card))<0 && error>=0)
	error=tmpError;
      *triggeredAllDirtyFlags=1;
    }
    break;
  case SamCtrlResponseVoicesFree:
    error=samTalk(card,
		  SamSendCtrlP, nCmds, cmds,
		  SamGetByte, &voicesFree,
		  SamEndOfScript);
    if(error>=0 && voicesFree<0)
      error=-ENOSPC;
    break;
  default:
    /* SamCtrlResponseNone */
    error=samTalk(card,
		  SamSendCtrlP, nCmds, cmds,
		  SamEndOfScript);
  }
  
  return error;
}

int samCtrlsSet(SamCard *card, int channel, SamControl *ctrls)
{
  int error, ctrlTblOfs, i, maxFWCtrlId, haveCtrlTbl, hwHookIsAvail;
  int sendCmds, nCmds, triggeredAllDirtyFlags, gotBackupValue;
  unsigned addr, v, v2, backupValue, addrTag;
  unsigned char ctrlTbl[256];
  unsigned char cmds[32];
  SamControl *ctrlP;
  SamMixerId ctrlId;
  SamHWCtrlVendorInfo *hwInfo;
  SamFWCtrlVendorInfo *fwInfoBase, *fwInfo;
  struct {
    SamFWCtrlVendorInfo *fwInfo;
    unsigned addrTag;
  } multiValueCtrls[256];

  if(channel>=0) {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
    fwInfoBase=card->firmwareInfo->audioCtrlInfo;
  } else {
    maxFWCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nMixerCtrls;
    fwInfoBase=card->firmwareInfo->mixerCtrlInfo;
  }

  haveCtrlTbl=0;
  triggeredAllDirtyFlags=0;
  for(ctrlP=ctrls;;ctrlP++) {
    if((error=verify_area(VERIFY_WRITE, ctrlP, sizeof(SamControl)))<0)
      return error;
    if(SAM_GET_USER(ctrlId, &ctrlP->id))
      return -EFAULT;
    if(ctrlId==SAM_MIXER_ID_SENTINEL)
      break;
    if(channel<0 && ctrlId>=SAM_MIXER_HW_ID_FIRST) {
      /* firmware independent hardware control */
      if(ctrlId>=SAM_MIXER_HW_ID_LAST)
	return -EINVAL;
      if(!card->hardwareInfo->ctrlInfo)
	continue;
      hwInfo=card->hardwareInfo->ctrlInfo+ctrlId-SAM_MIXER_HW_ID_FIRST;
      if(!hwInfo->vendorHandler)
	continue;
      if(card->hardwareInfo->ctrlIsAvail &&
	 !(*card->hardwareInfo->ctrlIsAvail)(card, ctrlId))
	continue;
      if(SAM_GET_USER(addrTag, &ctrlP->addr))
	return -EFAULT;
      if(addrTag>hwInfo->addrTagLimit)
	return -EINVAL;
      if(SAM_GET_USER(v, &ctrlP->value))
	return -EFAULT;
      if((error=(*hwInfo->vendorHandler)(card, 1, ctrlId, addrTag, &v))<0)
	return error;
      if(SAM_PUT_USER(v, &ctrlP->value))
	return -EFAULT;
      /* trigger dirty flag */
      card->mixer.hwDirtyFlags[hwInfo->dirtyAddr+addrTag]=~0;
      wake_up(&card->mixer.waitDirty);
      continue;
    }

    /* firmware dependent control */
    if(ctrlId>=maxFWCtrlId)
      return -EINVAL;
    fwInfo=fwInfoBase+ctrlId;
    if(fwInfo->type==SamCtrlTypeUnsupported)
      continue;
    hwHookIsAvail=fwInfo->hwHookType!=SamHWHookTypeNone &&
      card->hardwareInfo->hooks && card->hardwareInfo->hooks[fwInfo->hwHookId] &&
      (!card->hardwareInfo->hookIsAvail || (*card->hardwareInfo->hookIsAvail)(card, fwInfo->hwHookId));
    if((fwInfo->hwHookType==SamHWHookTypeMandatory && !hwHookIsAvail) ||
       (fwInfo->channelRestriction==SamChannelRestrictionPlayOnly && channel>=card->firmwareInfo->playBackChannels) ||
       (fwInfo->channelRestriction==SamChannelRestrictionRecordOnly && channel<card->firmwareInfo->playBackChannels))
      continue;

    if(SAM_GET_USER(addrTag, &ctrlP->addr))
      return -EFAULT;
    if(addrTag>fwInfo->addrTagLimit)
      return -EINVAL;

    if(fwInfo->type==SamCtrlTypeVendorHandler) {
      if(fwInfo->responseType==SamCtrlResponseReset) {
	down(&card->usageCountLock);
	if(SAM_ATOMIC_READ(&card->usageCount))
	  error=-EBUSY;
      }

      if(error>=0 && SAM_GET_USER(v, &ctrlP->value))
	error=-EFAULT;

      backupValue=0;
      gotBackupValue=0;
      if(error>=0 && fwInfo->vendorHandler) {
	if(hwHookIsAvail) {
	  /* retrieve the old value so we can restore it
	   * in case the hardware hook fails
	   */
	  if((fwInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE)
	    backupValue=*storeAtAddr(card, channel, fwInfo->storeAt, addrTag);
	  else
	    error=(*fwInfo->vendorHandler)(card, 0, ctrlId, addrTag, &backupValue);
	  gotBackupValue=error>=0;
	}
	if(error>=0)
	  error=(*fwInfo->vendorHandler)(card, 1, ctrlId, addrTag, &v);
      }

      if(error>=0 && hwHookIsAvail) {
	error=(*card->hardwareInfo->hooks[fwInfo->hwHookId])(card, 1, fwInfo->hwHookId, addrTag, &v);
	/* restore backupValue in case of an error */
	if(error<0 && gotBackupValue) {
	  v=backupValue;
	  if((*fwInfo->vendorHandler)(card, 1, ctrlId, addrTag, &v)<0)
	    printk(KERN_ERR "sam9407[#%d:%s]: can't restore original control value\n", card->cardIdx, card->hardwareInfo->name);
	}
      }

      if(error>=0 && SAM_PUT_USER(v, &ctrlP->value))
	error=-EFAULT;

      if(error>=0 &&
	 (fwInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE)
	*storeAtAddr(card, channel, fwInfo->storeAt, addrTag)=v;

      if(fwInfo->responseType==SamCtrlResponseReset)
	up(&card->usageCountLock);

      if(error<0)
	return error;

      /* trigger dirty flag */
      if(channel>=0)
	card->channels[channel].dirtyFlags[fwInfo->dirtyAddr+addrTag]=~0;
      else
	card->mixer.fwDirtyFlags[fwInfo->dirtyAddr+addrTag]=~0;
      wake_up(&card->mixer.waitDirty);

      continue;
    }

    /* plain SAM control */
    if(SAM_GET_USER(v, &ctrlP->value))
      return -EFAULT;
    v=ctrlConvertValueImport(fwInfo->type, fwInfo->valueLimit, v);

    if(fwInfo->valueBytesLimit) {
      /* this is a multi-value control,
       * which requires the non-given values
       * to be retrieved from the control table.
       * We remember a pointer to the first SamFWCtrlVendorInfo
       * in multiValueCtrls, indexed by the control table offset
       */
      if(!haveCtrlTbl) {
	/* need to load ctrlTbl */
	if((error=samFindMMT(card, SAM_MMT_ID_CTRL_TBL, SAM_MMT_ID_MASK, &addr, NULL))<0)
	  return error;
	if(error==0)
	  return -EIO;
	/* temporarily lift the audio channel accessLock, as we might get
	 * a streaming wave interrupt, demanding attention
	 */
	if(channel>=0)
	  up(&card->channels[channel].accessLock);
	error=samTalk(card,
		      SamReadMem, addr, &ctrlTbl, sizeof(ctrlTbl)>>(1+!card->firmwareInfo->largeCtrlTable),
		      SamEndOfScript);
	if(channel>=0)
	  down(&card->channels[channel].accessLock);
	if(error<0)
	  return error;
	memset(multiValueCtrls, 0, sizeof(multiValueCtrls));
	haveCtrlTbl=1;
      }

      switch(fwInfo->storeAt&SAM_STORE_AT_MASK) {
      case SAM_STORE_AT_CTRL_TBL_ADDR:
	ctrlTblOfs=(fwInfo->storeAt&~SAM_STORE_AT_MASK)+
	  ctrlTblAddr(card, channel, fwInfo, addrTag)*(1+fwInfo->valueBytesLimit);
	break;
      case SAM_STORE_AT_CTRL_TBL_DEFAULT:
	ctrlTblOfs=fwInfo->ctrl+
	  ctrlTblAddr(card, channel, fwInfo, addrTag)*(1+fwInfo->valueBytesLimit);
	break;
      default:
	/* oops, somebody screwed up consistency
	 * in SamFWCtrlVendorInfo
	 */
	panic("sam9407: vendor information for firmware %s is screwed up", card->firmwareInfo->name);
      }

      multiValueCtrls[ctrlTblOfs].fwInfo=fwInfo;
      multiValueCtrls[ctrlTblOfs].addrTag=addrTag;

      ctrlTbl[ctrlTblOfs+fwInfo->valueBytesOfs]=v;

      /* multi-value controls will be handled at the very end,
       * as we're still collecting parameters and don't want
       * to send any redundant control commands
       */
      sendCmds=0;
    } else
      sendCmds=1;

    if(channel>=0 &&
       (fwInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE) {
      /* sam9407 can process commands on /dev/audio that need to be configured
       * only while the channel is open
       */
      switch(card->channels[channel].state) {
      case SamChannelStateClosed:
      case SamChannelStateClosing:
	sendCmds=0;
      default:
	/* make compiler happy */
      }
    }

    if(sendCmds) {
      /* build the command sequence */
      nCmds=0;
      cmds[nCmds++]=fwInfo->ctrl;
      if(fwInfo->addrTagType!=SamAddrTagTypeNone)
	cmds[nCmds++]=ctrlTblAddr(card, channel, fwInfo, addrTag);
      v2=v;
      for(i=ctrlTypeSize(fwInfo->type, fwInfo->valueLimit); i>0; i--) {
	cmds[nCmds++]=v2;
	v2>>=8;
      }

      if((error=sendCtrlCmdSeq(card, channel, &triggeredAllDirtyFlags, fwInfo, cmds, nCmds))<0)
	return error;
    }

    if((fwInfo->storeAt&SAM_STORE_AT_MASK)==SAM_STORE_AT_KERNEL_SPACE)
      *storeAtAddr(card, channel, fwInfo->storeAt, addrTag)=v|SAM_AUDIO_CTRL_CONFIGURED_MASK;

    if(channel>=0)
      card->channels[channel].dirtyFlags[fwInfo->dirtyAddr+addrTag]=~0;
    else
      card->mixer.fwDirtyFlags[fwInfo->dirtyAddr+addrTag]=~0;
    wake_up(&card->mixer.waitDirty);
  }

  if(haveCtrlTbl)
    /* check all multi-value controls and send them now */
    for(ctrlTblOfs=0; ctrlTblOfs<SAM_NUMBER_OF(multiValueCtrls); ctrlTblOfs++)
      if(multiValueCtrls[ctrlTblOfs].fwInfo) {
	fwInfo=multiValueCtrls[ctrlTblOfs].fwInfo;
	addrTag=multiValueCtrls[ctrlTblOfs].addrTag;

	/* build the command sequence */
	nCmds=0;
	cmds[nCmds++]=fwInfo->ctrl;
	if(fwInfo->addrTagType!=SamAddrTagTypeNone)
	  cmds[nCmds++]=ctrlTblAddr(card, channel, fwInfo, addrTag);

	for(i=0; i<=fwInfo->valueBytesLimit; i++)
	  cmds[nCmds++]=ctrlTbl[ctrlTblOfs+i];

	if((error=sendCtrlCmdSeq(card, channel, &triggeredAllDirtyFlags, fwInfo, cmds, nCmds))<0)
	  return error;
      }

  return 0;
}

int samSendRememberedAudioCtrls(SamCard *card, int channel)
{
  int error, id, i, maxCtrlId, nCmds, triggeredAllDirtyFlags;
  unsigned v, addrTag;
  SamFWCtrlVendorInfo *infoBase, *info;
  unsigned char cmds[32];

  maxCtrlId=samFirmwareClassInfo[card->firmwareInfo->apiClass].nAudioCtrls;
  infoBase=card->firmwareInfo->audioCtrlInfo;

  triggeredAllDirtyFlags=0;
  for(id=SAM_AUDIO_ID_SENTINEL+1; id<maxCtrlId; id++) {
    info=infoBase+id;
    if(info->type==SamCtrlTypeUnsupported ||
       (info->storeAt&SAM_STORE_AT_MASK)!=SAM_STORE_AT_KERNEL_SPACE)
      continue;

    for(addrTag=0; addrTag<=info->addrTagLimit; addrTag++) {
      v=*storeAtAddr(card, channel, info->storeAt, addrTag);
      if(!(v&SAM_AUDIO_CTRL_CONFIGURED_MASK))
	continue;
      v&=SAM_AUDIO_CTRL_VALUE_MASK;
      
      /* build the command sequence */
      nCmds=0;
      cmds[nCmds++]=info->ctrl;
      if(info->addrTagType!=SamAddrTagTypeNone)
	cmds[nCmds++]=ctrlTblAddr(card, channel, info, addrTag);
      for(i=ctrlTypeSize(info->type, info->valueLimit); i>0; i--) {
	cmds[nCmds++]=v;
	v>>=8;
      }

      if((error=sendCtrlCmdSeq(card, channel, &triggeredAllDirtyFlags, info, cmds, nCmds))<0)
	return error;
    }
  }

  return 0;
}

static int redirectedAudioControl(SamCard *card, unsigned cmd, SamRedirectedAudioControl *redirControlP)
{
  SamRedirectedAudioControl redirControl;
  int error;

  if(!card->firmwareInfo->haveAudio)
    return -ENOPKG;

  if((error=verify_area(VERIFY_READ, redirControlP, sizeof(SamRedirectedAudioControl)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&redirControl, redirControlP, sizeof(SamRedirectedAudioControl)))
    return -EFAULT;

  if(redirControl.channel>=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels)
    return -EINVAL;

  down(&card->channels[redirControl.channel].accessLock);
  switch(cmd) {
  case SAM_IOC_MIXER_AUDIO_GET:
    error=samCtrlsGet(card,
		      redirControl.channel,
		      redirControl.controls);
    break;
  case SAM_IOC_MIXER_AUDIO_SET:
    error=samCtrlsSet(card,
		      redirControl.channel,
		      redirControl.controls);
    break;
  default: /* SAM_IOC_MIXER_AUDIO_INFO */
    error=samCtrlsInfo(card,
		       redirControl.channel,
		       redirControl.controls);
  }
  up(&card->channels[redirControl.channel].accessLock);

  return error;
}

static int channelOwnerInfo(SamCard *card, SamChannelOwnerInfo *ownerInfoP)
{
  SamChannelOwnerInfo ownerInfo;
  int error, channel;
  SamChannelInfo *chp;

  if(!card->firmwareInfo->haveAudio)
    return -ENOPKG;

  if((error=verify_area(VERIFY_WRITE, ownerInfoP, sizeof(SamChannelOwnerInfo)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&ownerInfo, ownerInfoP, sizeof(SamChannelOwnerInfo)))
    return -EFAULT;

  if(card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels<ownerInfo.size) {
    ownerInfo.size=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
    if(SAM_PUT_USER(ownerInfo.size, &ownerInfoP->size))
      return -EFAULT;
  }

  if((error=verify_area(VERIFY_WRITE, ownerInfo.pids, ownerInfo.size*sizeof(int)))<0)
    return error;

  for(channel=0; error>=0 && channel<ownerInfo.size; channel++) {
    chp=card->channels+channel;
    down(&chp->accessLock);
    if(SAM_PUT_USER(chp->inUse ? chp->owner : 0, ownerInfo.pids+channel))
      error=-EFAULT;
    up(&chp->accessLock);
  }

  if(error<0)
    return error;

  return 0;
}

static int peakMeterInfo(SamCard *card, SamPeakMeterInfo *peakMeterInfoP)
{
  SamPeakMeterInfo peakMeterInfo;
  int error;
  unsigned addr;

  if((error=verify_area(VERIFY_WRITE, peakMeterInfoP, sizeof(SamPeakMeterInfo)))<0)
    return error;
  if(SAM_MEMCPY_FROMFS(&peakMeterInfo, peakMeterInfoP, sizeof(SamPeakMeterInfo)))
    return -EFAULT;

  if(card->firmwareInfo->peakMeterWords<peakMeterInfo.size) {
    peakMeterInfo.size=card->firmwareInfo->peakMeterWords;
    if(SAM_PUT_USER(peakMeterInfo.size, &peakMeterInfoP->size))
      return -EFAULT;
  }

  if((error=verify_area(VERIFY_WRITE,
			peakMeterInfo.data,
			peakMeterInfo.size<<1))<0)
    return error;

  /* need to load ctrlTbl */
  if((error=samFindMMT(card, SAM_MMT_ID_CTRL_TBL, SAM_MMT_ID_MASK, &addr, NULL))<0)
    return error;
  if(error==0)
    return -EIO;
  addr+=card->firmwareInfo->largeCtrlTable ? 128 : 64;
  if((error=samTalk(card,
		    SamReadMemFS, addr, peakMeterInfo.data, peakMeterInfo.size,
		    SamEndOfScript))<0)
    return error;

  return 0;
}

int samOpenMixer(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  int i, slot, nDirtyFlags, channelLimit, channel;
  SamDirtyFlag mask;
  SamChannelInfo *chp;

  down(&card->mixer.accessLock);

  /* find a free slot in usedMask */
  for(slot=0; slot<sizeof(SamDirtyFlag)*8; slot++)
    if(!(card->mixer.usedMask & (1<<slot))) {
      card->mixer.usedMask|=(1<<slot);
      file->private_data=(void *)(long)slot;
      break;
    }

  if(slot>=sizeof(SamDirtyFlag)*8) {
    /* all slots used */
    up(&card->mixer.accessLock);
    return -EBUSY;
  }

  /* reset dirty flags */
  mask=~(1<<slot);

  card->mixer.firmwareDirty&=mask;

  if(card->firmwareLoaded) {
    if(card->firmwareInfo->haveMidi)
      card->mixer.sbankDirty&=mask;

    if(card->firmwareInfo->haveAudio)
      card->mixer.channelOwnerDirty&=mask;

    nDirtyFlags=card->hardwareInfo->mixerDirty.n;
    for(i=0; i<nDirtyFlags; i++)
      card->mixer.hwDirtyFlags[i]&=mask;

    nDirtyFlags=card->firmwareInfo->mixerDirty.n;
    for(i=0; i<nDirtyFlags; i++)
      card->mixer.fwDirtyFlags[i]&=mask;

    if(card->firmwareInfo->haveAudio) {
      channelLimit=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
      nDirtyFlags=card->firmwareInfo->audioDirty.n;
      for(channel=0; channel<channelLimit; channel++) {
	chp=card->channels+channel;
	down(&chp->accessLock);
	for(i=0; i<nDirtyFlags; i++)
	  chp->dirtyFlags[i]&=mask;
	up(&chp->accessLock);
      }
    }
  }

  up(&card->mixer.accessLock);
  return 0;
}

void samReleaseMixer(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  int slot=(long)file->private_data;
  
  down(&card->mixer.accessLock);
  syncLeave(card);
  card->mixer.usedMask&=~(1<<slot);
  up(&card->mixer.accessLock);
}

int samReadMixer(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  int slot=(long)file->private_data;
  SamWaitQueue wait;
  SamDirtyFlag mask;
  int error, i, id, nDirtyFlags, channelLimit, channel;
  SamEvent kernelEvent, *event, *eventLimit;
  SamChannelInfo *chp;

  if(count<0 || (count>0 && count<sizeof(SamEvent)))
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  /* we initialize an own SamEvent structure
   * to cope with alignment structure fillups
   * so we won't return unitialized data
   */
  memset(&kernelEvent, 0, sizeof(kernelEvent));

  down(&card->mixer.accessLock);

  mask=1<<slot;

  if(!inputAvailable(card, mask) && (file->f_flags & O_NONBLOCK)) {
    up(&card->mixer.accessLock);
    return -EAGAIN;
  }

  /* wait for dirty flags */
  while(!inputAvailable(card, mask)) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->mixer.waitDirty, &wait);
    up(&card->mixer.accessLock);
    samSleepOn(&card->mixer.waitDirty, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      return -ERESTARTSYS;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      return -ERESTARTSYS;
#endif /* Linux 2.0 */
    down(&card->mixer.accessLock);
  }

  error=0;
  event=(SamEvent *)buf;
  eventLimit=event+count/sizeof(SamEvent);

  if(error>=0 && event<eventLimit && (card->mixer.firmwareDirty&mask)) {
    error=putEvent(event++, &kernelEvent, SAM_EVENT_TYPE_NOCTRL, SAM_EVENT_FIRMWARE_CHANGED, 0);
    card->mixer.firmwareDirty&=~mask;
  }

  if(card->firmwareLoaded) {
    if(error>=0 && card->firmwareInfo->haveMidi && event<eventLimit && (card->mixer.sbankDirty&mask)) {
      error=putEvent(event++, &kernelEvent, SAM_EVENT_TYPE_NOCTRL, SAM_EVENT_SBANK_CHANGED, 0);
      card->mixer.sbankDirty&=~mask;
    }

    if(error>=0 && card->firmwareInfo->haveAudio && event<eventLimit && (card->mixer.channelOwnerDirty&mask)) {
      error=putEvent(event++, &kernelEvent, SAM_EVENT_TYPE_NOCTRL, SAM_EVENT_CHANNEL_OWNER_CHANGED, 0);
      card->mixer.channelOwnerDirty&=~mask;
    }

    /* handle mixer dirty flags */
    nDirtyFlags=card->hardwareInfo->mixerDirty.n;
    for(i=0; error>=0 && i<nDirtyFlags && event<eventLimit; i++)
      if(card->mixer.hwDirtyFlags[i]&mask) {
	id=card->hardwareInfo->mixerDirty.ctrlIds[i];
	error=putEvent(event++, &kernelEvent, SAM_EVENT_TYPE_MIXER, id,
		 i-card->hardwareInfo->ctrlInfo[id-SAM_MIXER_HW_ID_FIRST].dirtyAddr);
	card->mixer.hwDirtyFlags[i]&=~mask;
      }

    nDirtyFlags=card->firmwareInfo->mixerDirty.n;
    for(i=0; error>=0 && i<nDirtyFlags && event<eventLimit; i++)
      if(card->mixer.fwDirtyFlags[i]&mask) {
	id=card->firmwareInfo->mixerDirty.ctrlIds[i];
	error=putEvent(event++, &kernelEvent, SAM_EVENT_TYPE_MIXER, id,
		 i-card->firmwareInfo->mixerCtrlInfo[id].dirtyAddr);
	card->mixer.fwDirtyFlags[i]&=~mask;
      }

    if(card->firmwareInfo->haveAudio) {
      /* handle audio dirty flags */
      channelLimit=card->firmwareInfo->playBackChannels+card->firmwareInfo->recordChannels;
      nDirtyFlags=card->firmwareInfo->audioDirty.n;
      for(channel=0; channel<channelLimit && event<eventLimit; channel++) {
	chp=card->channels+channel;
	down(&chp->accessLock);
	for(i=0; error>=0 && i<nDirtyFlags && event<eventLimit; i++)
	  if((chp->dirtyFlags[i]&mask)) {
	    id=card->firmwareInfo->audioDirty.ctrlIds[i];
	    error=putEvent(event++, &kernelEvent, channel, id,
			   i-card->firmwareInfo->audioCtrlInfo[id].dirtyAddr);
	    chp->dirtyFlags[i]&=~mask;
	  }
	up(&chp->accessLock);
      }
    }
  }

  up(&card->mixer.accessLock);

  if(error<0)
    return error;

  return (char *)event-buf;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMixer(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  int slot=(long)file->private_data;
  unsigned mask;

  down(&card->mixer.accessLock);

  mask=0;
  if(inputAvailable(card, 1<<slot))
    mask|= POLLIN | POLLRDNORM;

  poll_wait(file, &card->mixer.waitDirty, wait);

  up(&card->mixer.accessLock);

  return mask;
}
#else /* Linux 2.0 */
int samSelectMixer(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  int slot=(long)file->private_data;
  int avail=0;

  switch(type) {
  case SEL_IN:
    down(&card->mixer.accessLock);
    avail=inputAvailable(card, 1<<slot);
    if(!avail)
      select_wait(&card->mixer.waitDirty, wait);
    up(&card->mixer.accessLock);
    break;
  case SEL_OUT:
    /* write(2) not used for mixer */
    break;
  }

  return avail;
}
#endif /* Linux 2.0 */

int samIoctlMixer(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr)
{
  int error;

  down(&card->mixer.accessLock);
  switch(cmd) {
  case SOUND_MIXER_READ_DEVMASK:
  case SAM_IOC_API_INFO:
  case SAM_IOC_SYNC_JOIN:
  case SAM_IOC_SYNC_LEAVE:
  case SAM_IOC_SYNC_INFO:
  case SAM_IOC_DRIVER_INFO:
  case SAM_IOC_HW_HINTS_GET:
  case SAM_IOC_HW_HINTS_SET:
  case SAM_IOC_FIRMWARE_LOAD:
    break;
  default:
    if(!card->firmwareLoaded) {
      up(&card->mixer.accessLock);
      return -ENOPKG;
    }
  }

  error=0;
  switch(cmd) {
  case SOUND_MIXER_READ_DEVMASK:
    error=putInt(arg, 0);
    break;
  case SAM_IOC_API_INFO:
    error=samApiInfo(card, (SamApiInfo *)arg, SAM_MIXER_API_VERSION);
    break;
  case SAM_IOC_SYNC_JOIN:
    error=syncJoin(card, (int *)arg);
    break;
  case SAM_IOC_SYNC_LEAVE:
    syncLeave(card);
    break;
  case SAM_IOC_SYNC_INFO:
    error=putInt(arg, card->mixer.syncGroup);
    break;
  case SAM_IOC_DRIVER_INFO:
    error=driverInfo(card, (SamDriverInfo *)arg);
    break;
  case SAM_IOC_HW_HINTS_GET:
    error=getHardwareHints(card, (SamHardwareHints *)arg);
    break;
  case SAM_IOC_HW_HINTS_SET:
    error=setHardwareHints(card, (SamHardwareHints *)arg);
    break;
  case SAM_IOC_FIRMWARE_LOAD:
    error=samFirmwareLoad(card, (SamFirmware *)arg);
    break;
  case SAM_IOC_MIXER_GET:
    error=samCtrlsGet(card, -1, (SamControl *)arg);
    break;
  case SAM_IOC_MIXER_SET:
    error=samCtrlsSet(card, -1, (SamControl *)arg);
    break;
  case SAM_IOC_MIXER_INFO:
    error=samCtrlsInfo(card, -1, (SamControl *)arg);
    break;
  case SAM_IOC_MIXER_AUDIO_GET:
  case SAM_IOC_MIXER_AUDIO_SET:
  case SAM_IOC_MIXER_AUDIO_INFO:
    error=redirectedAudioControl(card, cmd, (SamRedirectedAudioControl *)arg);
    break;
  case SAM_IOC_CHANNEL_OWNER_INFO:
    error=channelOwnerInfo(card, (SamChannelOwnerInfo *)arg);
    break;
  case SAM_IOC_BANK_LOAD:
    error=samSBankLoad(card, (SamSoundBank *)arg);
    break;
  case SAM_IOC_BANK_UNLOAD:
    error=samSBankUnload(card, (unsigned char *)arg);
    break;
  case SAM_IOC_BANK_PRIO_CHG:
    error=samSBankPrioChange(card, (SamSoundBankPrio *)arg);
    break;
  case SAM_IOC_BANK_INFO:
    error=samSBankInfo(card, (SamSoundBankInfo *)arg);
    break;
  case SAM_IOC_PEAK_METER_INFO:
    error=peakMeterInfo(card, (SamPeakMeterInfo *)arg);
    break;
#ifdef SAM_DEBUG
  case SAM_IOC_DEBUG_MMT_INFO:
    error=samDebugMMTInfo(card, (SamMMTInfo *)arg);
    break;
#endif
  default:
    error=-ENOSYS;
  }
  up(&card->mixer.accessLock);

  return error;
}
