#ifndef _IO_H
#define _IO_H

#include "driver.h"

typedef enum {
  SamEndOfScript,
  SamDiscardInput,
  SamUARTMode,
  SamSendCtrlInit,	/* int n, unsigned char cmd, ...		*/
  SamSendCtrl,		/* int n, unsigned char cmd, ...		*/
  SamSendCtrlIf,	/* int condition, int n, unsigned char cmd, ...	*/
  SamSendCtrlP,		/* int n, unsigned char *cmds			*/
  SamSendMidi,		/* int n, unsigned char msg, ...		*/
  SamSendMidiP,		/* int n, unsigned char *msgs			*/
  SamSendMidiFS,	/* int n, unsigned char *msgs			*/
  SamExpect,		/* unsigned char				*/
  SamExpectRedo,	/* unsigned char ack, unsigned char nak		*/
  SamGetByte,		/* unsigned char *dest				*/
  SamGetWord,		/* unsigned short *dest				*/
  SamGetDWord,		/* unsigned *dest				*/
  SamBurstRead,		/* unsigned short *dest, int n			*/
  SamBurstReadFS,	/* unsigned short *dest, int n			*/
  SamBurstWrite,	/* unsigned short *source, int n		*/
  SamBurstWriteFS,	/* unsigned short *source, int n		*/
  SamBurstWriteConst,	/* unsigned short v, int n			*/
  SamReadMem,		/* unsigned addr, unsigned short *dest, int words    */
  SamReadMemP,		/* unsigned *addr, unsigned short *dest, int words   */
  SamReadMemFS,		/* unsigned addr, unsigned short *dest, int words    */
  SamWriteMem,		/* unsigned addr, unsigned short *source, int words  */
  SamWriteMemP,		/* unsigned *addr, unsigned short *source, int words */
  SamWriteMemFS,	/* unsigned addr, unsigned short *source, int words  */
  SamGetMMT,		/* unsigned *dest				*/
  SamSetMMT,		/* unsigned addr				*/
} SamTalkCmd;

/* check if firmware is installed and responding */
int samFirmwareDetect(SamCard *card);

/* execute the script provided */
int samTalk(SamCard *card, SamTalkCmd cmd, ...);

/* similar to samTalk, but will return -EBUSY
 * if sam9407 is currently in use (i.e. card->usageCount!=0)
 */
int samTalkNotBusy(SamCard *card, SamTalkCmd cmd, ...);

/* An asynchronous audio notification might be received
 * from SAM9407 anytime, in which case we need to
 * feed it with some audio data.
 * This function is called from within the
 * streaming audio delivery thread audioFeedThread
 * and will get a forced access to the device lock.
 * The pending command from samTalk will be rescheduled
 */
int samTalkPickLock(SamCard *card, SamTalkCmd cmd, ...);

#ifdef SAM_ENABLE_IRQ
void samInterrupt(int irq, void *devId, struct pt_regs *regs);
#endif

/* start/stop polling for asynchronous notifications */
void samStartPollNotifications(void);
void samStopPollNotifications(void);

#endif /* _IO_H */
