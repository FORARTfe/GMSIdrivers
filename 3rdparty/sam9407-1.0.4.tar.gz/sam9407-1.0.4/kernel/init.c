/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/config.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/ioport.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#ifdef CONFIG_DEVFS_FS
#include <linux/devfs_fs_kernel.h>
#endif
#include <asm/io.h>

#include "driver.h"
#include "cards.h"
#include "io.h"
#include "alloc.h"
#include "audio.h"
#include "mixer.h"
#include "midi.h"
#include "seq.h"
#include "mod.h"
#include "sndstat.h"
#include "sync.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif

typedef struct {
  char needsFirmware, separateReadWrite;
  int (*open) (struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
  void (*release) (struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
  int (*read) (struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
  int (*write) (struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
  unsigned (*poll)(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
  int (*select) (struct inode *inode, struct file *file, int, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
  int (*ioctl) (struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);
} SamMinorOps;

#ifdef CONFIG_DEVFS_FS
typedef struct {
  char *name;
  int minor;
} SamDevFSMinorNode;
#endif

/* SAM file operations */
#if LINUX_VERSION_CODE>=0x20200
int samOpen(struct inode *inode, struct file *file);
int samRelease(struct inode *inode, struct file *file);
ssize_t samRead(struct file *file, char *buf, size_t count, loff_t *pos);
ssize_t samWrite(struct file *file, const char *buf, size_t count, loff_t *pos);
unsigned samPoll(struct file *file, poll_table *wait);
int samIoctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
#else /* Linux 2.0 */
int samOpen(struct inode *inode, struct file *file);
void samRelease(struct inode *inode, struct file *file);
int samRead(struct inode *inode, struct file *file, char *buf, int count);
int samWrite(struct inode *inode, struct file *file, const char *buf, int count);
int samSelect(struct inode *inode, struct file *file, int type, select_table *wait);
int samIoctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
#endif /* Linux 2.0 */

int samMajor=SAM_DEV_MAJOR;
int samCardsMap[SAM_MAX_CARDS_COUNT];

int samCardsCount;
SamCard *samCards[SAM_MAX_CARDS_COUNT];

#ifdef CONFIG_DEVFS_FS
devfs_handle_t samDevFSHandle;
#endif

#if LINUX_VERSION_CODE>=0x20200
struct file_operations samFileOps={
#if LINUX_VERSION_CODE>=0x20400
  THIS_MODULE,			/* owner */
#endif
  NULL,				/* lseek */
  samRead,			/* read */
  samWrite,			/* write */
  NULL,				/* readdir */
  samPoll,			/* select */
  samIoctl,			/* ioctl */
  NULL,				/* mmap */
  samOpen,			/* open */
  NULL,				/* flush */
  samRelease,			/* release */
  NULL,				/* fsync */
  NULL,				/* fasync */
  NULL,				/* check_media_change */
  NULL,				/* revalidate */
  NULL				/* lock */
};
#else /* Linux 2.0 */
struct file_operations samFileOps={
  NULL,				/* lseek */
  samRead,			/* read */
  samWrite,			/* write */
  NULL,				/* readdir */
  samSelect,			/* select */
  samIoctl,			/* ioctl */
  NULL,				/* mmap */
  samOpen,			/* open */
  samRelease,			/* release */
  NULL,				/* fsync */
  NULL,				/* fasync */
  NULL,				/* check_media_change */
  NULL				/* revalidate */
};
#endif /* Linux 2.0 */

SamMinorOps samMinorOps[]={
  {				/* SoundMinorCtl */
    0,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenMixer,		/* open */
    samReleaseMixer,		/* release */
    samReadMixer,		/* read */
    NULL,			/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollMixer,		/* poll */
#else /* Linux 2.0 */
    samSelectMixer,		/* select */
#endif /* Linux 2.0 */
    samIoctlMixer		/* ioctl */
  },
  {				/* SoundMinorSeq */
    1,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenSeq,			/* open */
    samReleaseSeq,		/* release */
    samReadSeq,			/* read */
    samWriteSeq,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollSeq,			/* poll */
#else /* Linux 2.0 */
    samSelectSeq,		/* select */
#endif /* Linux 2.0 */
    samIoctlSeq			/* ioctl */
  },
  {				/* SoundMinorMidi */
    1,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenMidi,		/* open */
    samReleaseMidi,		/* release */
    samReadMidi,		/* read */
    samWriteMidi,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollMidi,		/* poll */
#else /* Linux 2.0 */
    samSelectMidi,		/* select */
#endif /* Linux 2.0 */
    samIoctlMidi		/* ioctl */
  },
  {				/* SoundMinorDsp */
    1,				/* needsFirmware */
    1,				/* separateReadWrite */
    samOpenAudio,		/* open */
    samReleaseAudio,		/* release */
    samReadAudio,		/* read */
    samWriteAudio,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollAudio,		/* poll */
#else /* Linux 2.0 */
    samSelectAudio,		/* select */
#endif /* Linux 2.0 */
    samIoctlAudio		/* ioctl */
  },
  {				/* SoundMinorAudio */
    1,				/* needsFirmware */
    1,				/* separateReadWrite */
    samOpenAudio,		/* open */
    samReleaseAudio,		/* release */
    samReadAudio,		/* read */
    samWriteAudio,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollAudio,		/* poll */
#else /* Linux 2.0 */
    samSelectAudio,		/* select */
#endif /* Linux 2.0 */
    samIoctlAudio		/* ioctl */
  },
  {				/* SoundMinorDsp16 */
    1,				/* needsFirmware */
    1,				/* separateReadWrite */
    samOpenAudio,		/* open */
    samReleaseAudio,		/* release */
    samReadAudio,		/* read */
    samWriteAudio,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollAudio,		/* poll */
#else /* Linux 2.0 */
    samSelectAudio,		/* select */
#endif /* Linux 2.0 */
    samIoctlAudio		/* ioctl */
  },
  {				/* SoundMinorStatus */
    0,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenSndStat,		/* open */
    samReleaseSndStat,		/* release */
    samReadSndStat,		/* read */
    NULL,			/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollSndStat,		/* poll */
#else /* Linux 2.0 */
    samSelectSndStat,		/* select */
#endif /* Linux 2.0 */
    NULL			/* ioctl */
  },
  {				/* SoundMinorAwfm */
  },
  {				/* SoundMinorSeq2 */
    1,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenSeq,			/* open */
    samReleaseSeq,		/* release */
    samReadSeq,			/* read */
    samWriteSeq,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollSeq,			/* poll */
#else /* Linux 2.0 */
    samSelectSeq,		/* select */
#endif /* Linux 2.0 */
    samIoctlSeq			/* ioctl */
  },
  {				/* SoundMinorSndproc */
  },
  {				/* SoundMinorMod */
    1,				/* needsFirmware */
    0,				/* separateReadWrite */
    samOpenMod,			/* open */
    samReleaseMod,		/* release */
    samReadMod,			/* read */
    samWriteMod,		/* write */
#if LINUX_VERSION_CODE>=0x20200
    samPollMod,			/* poll */
#else /* Linux 2.0 */
    samSelectMod,		/* select */
#endif /* Linux 2.0 */
    samIoctlMod			/* ioctl */
  },
};

#ifdef CONFIG_DEVFS_FS
SamDevFSMinorNode samDevFSMinorNodes[]={
  { "mixer",		SoundMinorCtl },
  { "sequencer",	SoundMinorSeq },
  { "midi_int",		SoundMinorMidi },
  { "midi_ext",		SoundMinorMidi | 0x10 },
  { "dsp",		SoundMinorDsp },
  { "audio",		SoundMinorAudio },
  { "status",		SoundMinorStatus },
  { "mod",		SoundMinorMod },
};
#endif

/* SAM file operations */
int samOpen(struct inode *inode, struct file *file)
{
  int cardIdx=SAM_CARD_IDX(inode);
  SamCard *card;
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  int error;
  char *closure;

  if(cardIdx>=samCardsCount || !samCards[cardIdx] ||
     minor<0 || minor>=SAM_NUMBER_OF(samMinorOps) ||
     !samMinorOps[minor].open)
    return -ENODEV;

  card=samCards[cardIdx];
  if(samMinorOps[minor].needsFirmware) {
    down(&card->usageCountLock);
    if(!card->firmwareLoaded) {
      up(&card->usageCountLock);
      return -ENOPKG;
    }
    atomic_inc(&card->usageCount);
    up(&card->usageCountLock);
  }

  if(samMinorOps[minor].separateReadWrite) {
    closure=(char *)&file->private_data;
    if(file->f_mode & SAM_MODE_READ_MASK)
      if((error=(*samMinorOps[minor].open)(inode, file, card, SAM_MODE_READ_MASK, closure))<0) {
	if(samMinorOps[minor].needsFirmware)
	  atomic_dec(&card->usageCount);
	return error;
      }
    if(file->f_mode & SAM_MODE_WRITE_MASK)
      if((error=(*samMinorOps[minor].open)(inode, file, card, SAM_MODE_WRITE_MASK, closure+1))<0) {
	if(samMinorOps[minor].release && (file->f_mode & SAM_MODE_READ_MASK))
	  (*samMinorOps[minor].release)(inode, file, card, SAM_MODE_READ_MASK, closure);
	if(samMinorOps[minor].needsFirmware)
	  atomic_dec(&card->usageCount);
	return error;
      }
  } else
    if((error=(*samMinorOps[minor].open)(inode, file, card, 0, NULL))<0) {
      if(samMinorOps[minor].needsFirmware)
	atomic_dec(&card->usageCount);
      return error;
    }

  MOD_INC_USE_COUNT;
  return 0;
}

#if LINUX_VERSION_CODE>=0x20200
int samRelease(struct inode *inode, struct file *file)
#else /* Linux 2.0 */
void samRelease(struct inode *inode, struct file *file)
#endif /* Linux 2.0 */
{
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  char *closure;

  if(samMinorOps[minor].release) {
    if(samMinorOps[minor].separateReadWrite) {
      closure=(char *)&file->private_data;
      if(file->f_mode & SAM_MODE_READ_MASK)
	(*samMinorOps[minor].release)(inode, file, card, SAM_MODE_READ_MASK, closure);
      if(file->f_mode & SAM_MODE_WRITE_MASK)
	(*samMinorOps[minor].release)(inode, file, card, SAM_MODE_WRITE_MASK, closure+1);
    } else
      (*samMinorOps[minor].release)(inode, file, card, 0, NULL);
  }
  if(samMinorOps[minor].needsFirmware)
    atomic_dec(&card->usageCount);
  MOD_DEC_USE_COUNT;

#if LINUX_VERSION_CODE>=0x20200
  return 0;
#endif /* Linux 2.0 */
}

#if LINUX_VERSION_CODE>=0x20200
ssize_t samRead(struct file *file, char *buf, size_t count, loff_t *pos)
#else /* Linux 2.0 */
int samRead(struct inode *inode, struct file *file, char *buf, int count)
#endif /* Linux 2.0 */
{
#if LINUX_VERSION_CODE>=0x20200
  struct inode *inode=file->f_dentry->d_inode;
#endif /* Linux 2.0 */
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  char *closure;

  if(samMinorOps[minor].read) {
    if(samMinorOps[minor].separateReadWrite)
      closure=(char *)&file->private_data;
    else
      closure=NULL;
    return (*samMinorOps[minor].read)(inode, file, buf, count, card, closure);
  } else
    return -ENOSYS;
}

#if LINUX_VERSION_CODE>=0x20200
ssize_t samWrite(struct file *file, const char *buf, size_t count, loff_t *pos)
#else /* Linux 2.0 */
int samWrite(struct inode *inode, struct file *file, const char *buf, int count)
#endif /* Linux 2.0 */
{
#if LINUX_VERSION_CODE>=0x20200
  struct inode *inode=file->f_dentry->d_inode;
#endif /* Linux 2.0 */
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  char *closure;

  if(samMinorOps[minor].write) {
    if(samMinorOps[minor].separateReadWrite)
      closure=(char *)&file->private_data+1;
    else
      closure=NULL;
    return (*samMinorOps[minor].write)(inode, file, buf, count, card, closure);
  } else
    return -ENOSYS;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPoll(struct file *file, poll_table *wait)
{
  struct inode *inode=file->f_dentry->d_inode;
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  char *closure;
  unsigned mask;

  if(samMinorOps[minor].poll) {
    if(samMinorOps[minor].separateReadWrite) {
      closure=(char *)&file->private_data;
      mask=0;
      if(file->f_mode & SAM_MODE_READ_MASK)
	mask|=(*samMinorOps[minor].poll)(inode, file, wait, card, SAM_MODE_READ_MASK, closure);
      if(file->f_mode & SAM_MODE_WRITE_MASK)
	mask|=(*samMinorOps[minor].poll)(inode, file, wait, card, SAM_MODE_WRITE_MASK, closure+1);
    } else
      mask=(*samMinorOps[minor].poll)(inode, file, wait, card, 0, NULL);
    return mask;
  } else
    return 0;
}
#else /* Linux 2.0 */
int samSelect(struct inode *inode, struct file *file, int type, select_table *wait)
{
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  char *closure;
  if(samMinorOps[minor].select) {
    if(samMinorOps[minor].separateReadWrite) {
      closure=(char *)&file->private_data;
      if(type==SEL_OUT)
	closure++;
    } else
      closure=NULL;
    return (*samMinorOps[minor].select)(inode, file, type, wait, card, closure);
  } else
    return -ENOSYS;
}
#endif /* Linux 2.0 */

int samIoctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
  SamCard *card=SAM_CARD(inode);
  SoundMinorDevice minor=SAM_MINOR_DEVICE(inode);
  int result, callNr;
  char *closure;

  if(samMinorOps[minor].ioctl) {
    closure=(char *)&file->private_data;
    result=0;
    if(samMinorOps[minor].separateReadWrite) {
      callNr=0;
      if(file->f_mode & SAM_MODE_WRITE_MASK)
	if((result=(*samMinorOps[minor].ioctl)(inode, file, cmd, arg, card, SAM_MODE_WRITE_MASK, closure+1, callNr++))<0)
	  return result;
      if(file->f_mode & SAM_MODE_READ_MASK)
	if((result=(*samMinorOps[minor].ioctl)(inode, file, cmd, arg, card, SAM_MODE_READ_MASK, closure, callNr++))<0)
	  return result;
    } else
      result=(*samMinorOps[minor].ioctl)(inode, file, cmd, arg, card, 0, NULL, 0);
    return result;
  } else
    return -ENOSYS;
}

/* Initialization */

SamCard *samRegisterCard(SamHardwareInfo *hardwareInfo, SamHardwareResource *res, SamCard *master)
{
  static int registeredCount;

  int error, cardIdx, len, i;
  SamCard *card;
  SamFirmwareInfo *firmwareInfo;
  char buf[256], *cp;
#ifdef CONFIG_DEVFS_FS
  devfs_handle_t devFSCardHandle;
  SamDevFSMinorNode *node;
#endif

  if(registeredCount>=SAM_MAX_CARDS_COUNT) {
    printk(KERN_ERR "sam9407[#%d:%s]: too many cards\n", registeredCount, hardwareInfo->name);
    return NULL;
  }

  cardIdx=samCardsMap[registeredCount];
  while(samCards[cardIdx]) {
    if(++cardIdx>=SAM_MAX_CARDS_COUNT)
      cardIdx=0;
  }

#ifdef CONFIG_DEVFS_FS
  sprintf(buf, "card%d", cardIdx);
  if(!(devFSCardHandle=devfs_mk_dir(samDevFSHandle, buf, NULL))) {
    printk(KERN_ERR "sam9407[#%d:%s]: can't register \"sam9407/%s\" devfs directory\n",
	   cardIdx, hardwareInfo->name, buf);
    return NULL;
  }
  for(i=0; i<SAM_NUMBER_OF(samDevFSMinorNodes); i++) {
    node=samDevFSMinorNodes+i;
    if(!devfs_register(devFSCardHandle, node->name,
		       DEVFS_FL_DEFAULT, samMajor, node->minor | cardIdx<<6,
		       S_IFCHR | S_IRUSR | S_IWUSR,
		       &samFileOps, NULL)) {
      printk(KERN_ERR "sam9407[#%d:%s]: can't register \"sam9407/%s/%s\" devfs node\n",
	     cardIdx, hardwareInfo->name, buf, node->name);
      devfs_unregister(devFSCardHandle);
      return NULL;
    }
  }
#endif

  if(check_region(res[SamHardwareResPort].value, 4)<0) {
    printk(KERN_ERR "sam9407[#%d:%s]: I/O port 0x%x already in use\n",
	   cardIdx, hardwareInfo->name, res[SamHardwareResPort].value);
#ifdef CONFIG_DEVFS_FS
    devfs_unregister(devFSCardHandle);
#endif
    return NULL;
  }
  for(i=SamHardwareResAuxPort0; i<=SamHardwareResAuxPort1; i++) {
    if(res[i].value && check_region(res[i].value, res[i].extent)<0) {
      printk(KERN_ERR "sam9407[#%d:%s]: I/O port 0x%x already in use\n",
	     cardIdx, hardwareInfo->name, res[i].value);
#ifdef CONFIG_DEVFS_FS
      devfs_unregister(devFSCardHandle);
#endif
      return NULL;
    }
  }

  card=(SamCard *)kmalloc(sizeof(SamCard), GFP_KERNEL);
  if(!card) {
    printk(KERN_ERR "sam9407[#%d:%s]: out of memory\n", cardIdx, hardwareInfo->name);
#ifdef CONFIG_DEVFS_FS
    devfs_unregister(devFSCardHandle);
#endif
    return NULL;
  }
  memset(card, 0, sizeof(SamCard));

  request_region(res[SamHardwareResPort].value, 4, res[SamHardwareResPort].id);
  for(i=SamHardwareResAuxPort0; i<=SamHardwareResAuxPort1; i++) {
    if(res[i].value)
      request_region(res[i].value, res[i].extent, res[i].id);
  }

  card->cardIdx=cardIdx;
  card->master=master;
  if(master)
    master->slave=card;

  card->port=res[SamHardwareResPort].value;
  card->auxPort0=res[SamHardwareResAuxPort0].value;
  card->auxPort0Extent=res[SamHardwareResAuxPort0].extent;
  card->auxPort1=res[SamHardwareResAuxPort1].value;
  card->auxPort1Extent=res[SamHardwareResAuxPort1].extent;

  card->hardwareInfo=hardwareInfo;
  card->firmwareInfo=&samGenuineFirmwareInfo;

  card->mixer.syncGroup=-1;
  card->seq.syncGroup=-1;
  card->mod.syncGroup=-1;

#if LINUX_VERSION_CODE>=0x20200
  card->firmwareAccessSpinLock=SPIN_LOCK_UNLOCKED;
  card->io.statusRegSpinLock=SPIN_LOCK_UNLOCKED;
  card->midi.recSpinLock=SPIN_LOCK_UNLOCKED;
#endif

  SAM_INIT_MUTEX(&card->usageCountLock);
  SAM_INIT_MUTEX(&card->io.ioLock);
  SAM_INIT_MUTEX(&card->io.stillTryingLock);
  SAM_INIT_MUTEX(&card->mem.accessLock);
  SAM_INIT_MUTEX(&card->mixer.accessLock);
  SAM_INIT_MUTEX(&card->midi.accessLock);
  SAM_INIT_MUTEX(&card->mod.accessLock);
  SAM_INIT_MUTEX(&card->sndStat.accessLock);

  SAM_INIT_WAITQUEUE_HEAD(&card->io.somethingHappened);
  SAM_INIT_WAITQUEUE_HEAD(&card->io.pickLockScreaming);
  SAM_INIT_WAITQUEUE_HEAD(&card->io.pickLockHappy);
  SAM_INIT_WAITQUEUE_HEAD(&card->mixer.waitDirty);
  SAM_INIT_WAITQUEUE_HEAD(&card->midi.dataAvail);
  SAM_INIT_WAITQUEUE_HEAD(&card->seq.moreSpace);
  SAM_INIT_WAITQUEUE_HEAD(&card->seq.dataAvail);
  SAM_INIT_WAITQUEUE_HEAD(&card->mod.moreSpace);
  SAM_INIT_WAITQUEUE_HEAD(&card->mod.dataAvail);

  card->io.ioTimeout=SAM_IO_TIMEOUT;

  if(card->hardwareInfo->fillCache)
    if((*card->hardwareInfo->fillCache)(card)<0) {
      release_region(res[SamHardwareResPort].value, 4);
      for(i=SamHardwareResAuxPort0; i<=SamHardwareResAuxPort1; i++) {
	if(res[i].value)
	  release_region(res[i].value, res[i].extent);
      }
      kfree(card);
#ifdef CONFIG_DEVFS_FS
      devfs_unregister(devFSCardHandle);
#endif
      return NULL;
    }

  samCards[cardIdx]=card;
  if(cardIdx>=samCardsCount)
    samCardsCount=cardIdx+1;
  registeredCount++;

  /* try to detect firmware */
  if(samFirmwareDetect(card)) {
    error=0;
    for(i=0; (firmwareInfo=samFirmwareInfos[i]); i++) {
      if(firmwareInfo->probeStr) {
	len=strlen(firmwareInfo->probeStr);
	if(len<sizeof(buf)-2) {
	  if((error=samTalk(card,
			    SamReadMem, firmwareInfo->probeAddr>>1, buf, (len+1)>>1,
			    SamEndOfScript))<0)
	    break;
	  cp=buf+(firmwareInfo->probeAddr&1);
	  cp[len]=0;
	  if(strcmp(cp, firmwareInfo->probeStr)==0) {
	    card->firmwareInfo=firmwareInfo;
	    break;
	  }
	}
      }
    }
    if(error>=0 && card->hardwareInfo->firmwareDetected)
      error=(*card->hardwareInfo->firmwareDetected)(card);
    if(error>=0)
      error=samAllocMixerDirtyFlags(card);
    if(error>=0)
      error=samInitializeMMT(card);
    if(error>=0)
      error=samAllocateChannels(card);
    if(error<0) {
      /* firmware seems to be broken
       */
      card->firmwareInfo=&samGenuineFirmwareInfo;
      samReleaseChannels(card);
      samReleaseMMT(card);
      samReleaseMixerDirtyFlags(card);
    }

    if(error>=0)
      card->firmwareLoaded=1;
  }

#ifdef SAM_ENABLE_IRQ
  if(res[SamHardwareResIrq].value) {
    if(request_irq(res[SamHardwareResIrq].value, samInterrupt, SA_SHIRQ, res[SamHardwareResIrq].id, card)<0)
      printk(KERN_WARNING "sam9407[#%d:%s]: Unable to register IRQ %d\n",
	     card->cardIdx, card->hardwareInfo->name, res[SamHardwareResIrq].value);
    else
      card->irq=res[SamHardwareResIrq].value;
  }
#endif

  i=sprintf(buf, "sam9407[#%d:%s]: registered port=0x%x",
	    card->cardIdx, card->hardwareInfo->name, card->port);
#ifdef SAM_ENABLE_IRQ
  if(card->irq)
    i+=sprintf(buf+i, ", irq=%d", card->irq);
  else
    i+=sprintf(buf+i, ", irq=n/a");
#endif

  printk(KERN_INFO "%s\n", buf);

  return card;
}

int sam9407_init(void)
{
  int i, cardsCount, cardIdx;
  char usageMap[SAM_MAX_CARDS_COUNT];

  /* check consistency of samCardsMap */
  cardsCount=0;
  memset(usageMap, 0, sizeof(usageMap));
  for(i=0; i<SAM_MAX_CARDS_COUNT; i++) {
    cardIdx=samCardsMap[i];
    if(cardIdx<0 || cardIdx>=SAM_MAX_CARDS_COUNT) {
      printk(KERN_ERR "sam9407: invalid card# specified in samCardsMap\n");
      return -EIO;
    }
    usageMap[cardIdx]=1;
    if(cardIdx>=cardsCount)
      cardsCount=cardIdx+1;
  }
  for(i=0; i<cardsCount; i++) {
    if(!usageMap[i]) {
      printk(KERN_ERR "sam9407: samCardsMap is non-contiguous\n");
      return -EIO;
    }
  }

  SAM_INIT_WAITQUEUE_HEAD(&samFeedThreadInfo.feedSam);

  if(samAdjustVendorInformation()<0)
    return -EIO;

  if(register_chrdev(samMajor, "sam9407", &samFileOps)<0) {
    printk(KERN_ERR "sam9407: can't register sound dev, sound module already loaded ?\n");
    samReleaseVendorInformation();
    return -EIO;
  }

#ifdef CONFIG_DEVFS_FS
  if(!(samDevFSHandle=devfs_mk_dir(NULL, "sam9407", NULL))) {
    printk(KERN_ERR "sam9407: can't register \"sam9407\" devfs directory\n");
    if(unregister_chrdev(samMajor, "sam9407")<0)
      panic("sam9407: Unable to unregister device\n");
    samReleaseVendorInformation();
    return -EIO;
  }
#endif

  if(samStartFeedThread()<0) {
#ifdef CONFIG_DEVFS_FS
    devfs_unregister(samDevFSHandle);
#endif
    if(unregister_chrdev(samMajor, "sam9407")<0)
      panic("sam9407: Unable to unregister device\n");
    samReleaseVendorInformation();
    return -EIO;
  }

  samInitializeMidi();
  samInitializeSeq();
  samInitializeMod();

#ifdef SAM_ENABLE_RTC
  samInitializeRTC();
#endif

  samStartPollNotifications();

  samFindCards();

  return 0;
}

#ifdef MODULE
#if LINUX_VERSION_CODE>=0x20200
MODULE_PARM(samMajor, "i");
MODULE_PARM(samCardsMap, "1-" __MODULE_STRING(SAM_MAX_CARDS_COUNT) "i");
#endif

#ifdef MODULE_LICENSE
MODULE_LICENSE("GPL");
#endif

int init_module(void)
{
  return sam9407_init();
}

void cleanup_module(void)
{
  unsigned flags;
  SamCard *card;
  int i;

#ifdef CONFIG_DEVFS_FS
    devfs_unregister(samDevFSHandle);
#endif
  if(unregister_chrdev(samMajor, "sam9407")<0)
    panic("sam9407: Unable to unregister device\n");

#ifdef SAM_ENABLE_IRQ
  /* disable IRQ's first
   * to avoid bad surprises
   */
  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    if(card->irq) {
      free_irq(card->irq, card);
      card->irq=0;
    }
  }
#endif

  samStopPollNotifications();

#ifdef SAM_ENABLE_RTC
  samReleaseRTC();
#endif

  samKillFeedThread();

  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    /* make sure we don't mess with an IRQ that requires the firmware */
    SAM_BEGIN_CRITICAL(&card->firmwareAccessSpinLock, flags);
    card->firmwareLoaded=0;
    SAM_END_CRITICAL(&card->firmwareAccessSpinLock, flags);

    samReleaseChannels(card);
    samReleaseMMT(card);
    samReleaseMixerDirtyFlags(card);

    release_region(card->port, 4);
    if(card->auxPort0)
      release_region(card->auxPort0, card->auxPort0Extent);
    if(card->auxPort1)
      release_region(card->auxPort1, card->auxPort1Extent);

    samCards[i]=NULL;
    kfree(card);
  }

  samReleaseVendorInformation();
  samReleaseSyncGroups();
}
#endif
