/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/stddef.h>
#include <linux/kernel.h>

#include "driver.h"

#ifdef SAM_ENABLE_FW_HOON4D

SamFirmwareInfo samHOPDFirmwareInfo={
  "hoon4d",			/* name */
  0x420,			/* probeAddr */
  "SAMHOPD",			/* probeStr */
  SAM_API_CLASS_VANILLA,	/* apiClass */
  HZ/2,				/* initNapTimeout */
  0,				/* verifyChecksum */
  NULL,				/* setup */
  64,				/* mmtSlots */
  0,				/* largeCtrlTable */
  0,				/* peakMeterWords */
  1,				/* haveAudio */
  1,				/* haveMidi */
  1,				/* haveMod */
  1,				/* mutexModRecAudio */
  0,				/* supportsMaxi64Controls */
  8,				/* playBackChannels */
  1,				/* recordChannels */
  0x00,				/* getMMTAck */
  0x00,				/* openAck */
  0xC0,				/* closeAck */
  0,				/* closeAckRecChannel */
  1,				/* midiResetFixup */
  0,				/* getVoicesReadDummy */
  0,				/* getPosReturnsVoice */
  samGenuineMixerCtrlInfo,	/* mixerCtrlInfo */
  samGenuineAudioCtrlInfo,	/* audioCtrlInfo */
  0x00,				/* resetRestoreCtrl */
  0,				/* nResetReadjust */
  NULL,				/* resetReadjust */
  0,				/* nSBankRehash */
  NULL,				/* sbankRehash */
  "\xB1\xB0",			/* midiSelCtrls */
  0,				/* ctrlValuesSize */
  samGenuineInitAudioCtrlValues,/* initAudioCtrlValues */
};

SamFirmwareInfo samPD07FirmwareInfo={
  "hoon4d",			/* name */
  0x420,			/* probeAddr */
  "SAMPD07",			/* probeStr */
  SAM_API_CLASS_VANILLA,	/* apiClass */
  HZ,				/* initNapTimeout */
  0,				/* verifyChecksum */
  NULL,				/* setup */
  64,				/* mmtSlots */
  0,				/* largeCtrlTable */
  0,				/* peakMeterWords */
  1,				/* haveAudio */
  1,				/* haveMidi */
  1,				/* haveMod */
  1,				/* mutexModRecAudio */
  0,				/* supportsMaxi64Controls */
  8,				/* playBackChannels */
  1,				/* recordChannels */
  0x00,				/* getMMTAck */
  0x00,				/* openAck */
  0xC0,				/* closeAck */
  0,				/* closeAckRecChannel */
  1,				/* midiResetFixup */
  0,				/* getVoicesReadDummy */
  0,				/* getPosReturnsVoice */
  samGenuineMixerCtrlInfo,	/* mixerCtrlInfo */
  samGenuineAudioCtrlInfo,	/* audioCtrlInfo */
  0x00,				/* resetRestoreCtrl */
  0,				/* nResetReadjust */
  NULL,				/* resetReadjust */
  0,				/* nSBankRehash */
  NULL,				/* sbankRehash */
  "\xB1\xB0",			/* midiSelCtrls */
  0,				/* ctrlValuesSize */
  samGenuineInitAudioCtrlValues,/* initAudioCtrlValues */
};

#endif /* SAM_ENABLE_FW_HOON4D */
