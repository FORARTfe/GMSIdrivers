#ifndef _CARDS_H
#define _CARDS_H

void samFindCards(void);

#endif /* _CARDS_H */
