#ifndef _SNDSTAT_H
#define _SNDSTAT_H

#include "driver.h"

int samOpenSndStat(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseSndStat(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadSndStat(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollSndStat(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectSndStat(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */

#endif /* _SNDSTAT_H */
