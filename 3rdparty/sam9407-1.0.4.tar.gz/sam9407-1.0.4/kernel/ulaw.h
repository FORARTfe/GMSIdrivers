#ifndef _ULAW_H
#define _ULAW_H

unsigned char samShort2Ulaw(short sample);
short samUlaw2Short(unsigned char ulawbyte);
unsigned char samShort2Alaw(short sample);
short samAlaw2Short(unsigned char ulawbyte);

#endif /* _ULAW_H */
