#ifndef _LONGLONG_H
#define _LONGLONG_H

#include <asm/types.h>

/*
 * 64-bit arithmetic functions
 *
 * samLLAdd64(unsigned *rl, unsigned *rh, unsigned al, unsigned ah)
 *         adds two 64-bit unsigned integers, represented by their
 *         low / high 32-bit parts, and updates *rl / *rh with the result
 * samLLMul32(unsigned *rl, unsigned *rh, unsigned a, unsigned b)
 *         multiplies two 32-bit unsigned integers and returns the
 *         64-bit result in it's low / high 32-bit parts *rl / *rh
 * samLLDivMod24(unsigned nl, unsigned nh, unsigned d, unsigned *q, unsigned *r)
 *         divides the 64-bit unsigned integer, represented by it's
 *         low / high 32-bit parts nl / nh, by the 24-bit divisor d
 *         and returns the 32-bit quotient in *q and the remainder in *r.
 *         Please note that the divisor must be greater than nh and
 *         smaller than 1<<24.
 */

#ifdef __i386__
static __inline__ void samLLAdd64(unsigned *rl, unsigned *rh, unsigned al, unsigned ah)
{
  __asm__ __volatile__
    ("addl %4, %0\n"
     "adcl %5, %1\n"
     : "=r" (*rl), "=r" (*rh)
     : "0" (*rl), "1" (*rh), "r" (al), "r" (ah));
}

static __inline__ void samLLMul32(unsigned *rl, unsigned *rh, unsigned a, unsigned b)
{
  __asm__ __volatile__
    ("mull %3\n"
     : "=a" (*rl), "=d" (*rh)
     : "0" (a), "r" (b));
}

static __inline__ void samLLDivMod24(unsigned nl, unsigned nh, unsigned d, unsigned *q, unsigned *r)
{
  __asm__ __volatile__
    ("divl %4\n"
     : "=a" (*q), "=d" (*r)
     : "0" (nl), "1" (nh), "r" (d));
}
#elif BITS_PER_LONG>=64
static __inline__ void samLLAdd64(unsigned *rl, unsigned *rh, unsigned al, unsigned ah)
{
  unsigned long v;

  v=al+ah;
  *rl=v;
  *rh=v>>32;
}
static __inline__ void samLLMul32(unsigned *rl, unsigned *rh, unsigned a, unsigned b)
{
  unsigned long v;

  v=a*b;
  *rl=v;
  *rh=v>>32;
}
static __inline__ void samLLDivMod24(unsigned nl, unsigned nh, unsigned d, unsigned *q, unsigned *r)
{
  unsigned long v;

  v=(unsigned long)nh<<32 | nl;
  *q=v/d;
  *r=v%d;
}
#else
static __inline__ void samLLAdd64(unsigned *rl, unsigned *rh, unsigned al, unsigned ah)
{
  *rl+=al;
  *rh+=ah+(*rl<al);
}

static __inline__ void samLLMul32(unsigned *rl, unsigned *rh, unsigned a, unsigned b)
{
  unsigned al, ah, bl, bh, v;

  al=a&0xFFFF; ah=a>>16;
  bl=b&0xFFFF; bh=b>>16;

  *rl=al*bl;
  *rh=ah*bh;
  v=al*bh; samLLAdd64(rl, rh, v<<16, v>>16);
  v=ah*bl; samLLAdd64(rl, rh, v<<16, v>>16);
}

static __inline__ void samLLDivMod24(unsigned nl, unsigned nh, unsigned d, unsigned *q, unsigned *r)
{
  int i;

  *q=nh/d;
  *r=nh%d;
  for(i=24; i>=0; i-=8) {
    *r=*r<<8 | (nl>>i & 0xFF);
    *q=*q<<8 | *r/d;
    *r%=d;
  }
}
#endif

#endif /* _LONGLONG_H */
