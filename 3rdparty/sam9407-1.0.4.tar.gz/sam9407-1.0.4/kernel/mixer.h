#ifndef _MIXER_H
#define _MIXER_H

#include "driver.h"

int samOpenMixer(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseMixer(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadMixer(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMixer(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectMixer(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
int samIoctlMixer(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);

/* allocate dirty flags after firmware upload */
int samAllocMixerDirtyFlags(SamCard *card);

/* release memory allocated by dirty flags */
void samReleaseMixerDirtyFlags(SamCard *card);

/* shared handling of
 * SAM_IOC_AUDIO_INFO, SAM_IOC_AUDIO_GET, SAM_IOC_AUDIO_SET and
 * SAM_IOC_MIXER_INFO, SAM_IOC_MIXER_GET, SAM_IOC_MIXER_SET
 * if channel is >=0, we're dealing with audio ctrl's
 */
int samCtrlsInfo(SamCard *card, int channel, SamControl *ctrls);
int samCtrlsGet(SamCard *card, int channel, SamControl *ctrls);
int samCtrlsSet(SamCard *card, int channel, SamControl *ctrls);

/* resend all audio controls that have been stored in KERNEL_SPACE */
int samSendRememberedAudioCtrls(SamCard *card, int channel);

int samApiInfo(SamCard *card, SamApiInfo *apiInfo, unsigned version);

int samFirmwareLoad(SamCard *card, SamFirmware *firmware);

int samRelocateMidiTable(SamCard *card);
int samSBankLoad(SamCard *card, SamSoundBank *bank);
int samSBankUnload(SamCard *card, unsigned char *id);
int samSBankPrioChange(SamCard *card, SamSoundBankPrio *prio);
int samSBankInfo(SamCard *card, SamSoundBankInfo *info);

#endif /* _MIXER_H */
