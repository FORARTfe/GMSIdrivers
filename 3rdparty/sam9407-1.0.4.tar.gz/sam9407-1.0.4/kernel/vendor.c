/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif

#include "driver.h"

SamFirmwareClassInfo samFirmwareClassInfo[]={
  {				/* SAM_API_CLASS_NONE */
    0,				/* nMixerCtrls */
    0,				/* nAudioCtrls */
  },
  {				/* SAM_API_CLASS_VANILLA */
    SAM_MIXER_ID_LAST,		/* nMixerCtrls */
    SAM_AUDIO_ID_LAST,		/* nAudioCtrls */
  },
  {				/* SAM_API_CLASS_HOMSTDR */
    SAM_MIXER_HOMSTDR_ID_LAST,	/* nMixerCtrls */
    SAM_AUDIO_HOMSTDR_ID_LAST,	/* nAudioCtrls */
  },
};

SamFirmwareInfo *samFirmwareInfos[]={
  &samGenuineFirmwareInfo,
#ifdef SAM_ENABLE_FW_EWS64
  &samEWS64FirmwareInfo,
#endif
#ifdef SAM_ENABLE_FW_MAXI64
  &samG8500FirmwareInfo,
  &samHSTUDFirmwareInfo,
#endif
#ifdef SAM_ENABLE_FW_HOMSTDR
  &samHomstdrFirmwareInfo,
#endif
#ifdef SAM_ENABLE_FW_HOON4D
  &samHOPDFirmwareInfo,
  &samPD07FirmwareInfo,
#endif
  NULL				/* sentinel */
};

SamHardwareInfo *samHardwareInfos[]={
#ifdef SAM_ENABLE_HW_EWS64S
  &samEWS64SHardwareInfo,
#endif
#ifdef SAM_ENABLE_HW_EWS64XL
  &samEWS64XLHardwareInfo,
#endif
#ifdef SAM_ENABLE_HW_ST128RUBY
  &samST128RubyHardwareInfo,
#endif
#ifdef SAM_ENABLE_HW_ST128PCI
  &samST128PCIHardwareInfo,
#endif
#ifdef SAM_ENABLE_HW_STDA
  &samSTDAMasterHardwareInfo,
  &samSTDASlaveHardwareInfo,
#endif
#ifdef SAM_ENABLE_HW_MAXI64
  &samMaxi64HardwareInfo,
#endif
  NULL				/* sentinel */
};

#ifdef SAM_ENABLE_ISA
SamPnPInfo *samPnPInfos[]={
#ifdef SAM_ENABLE_HW_EWS64S
  &samEWS64SPnPInfo,
#endif
#ifdef SAM_ENABLE_HW_EWS64XL
  &samEWS64XLPnPInfo,
#endif
#ifdef SAM_ENABLE_HW_ST128RUBY
  &samST128RubyPnPInfo,
#endif
#ifdef SAM_ENABLE_HW_MAXI64
  &samMaxi64PnPInfo,
  &samMaxi64ProPnPInfo,
#endif
  NULL				/* sentinel */
};
#endif /* SAM_ENABLE_ISA */

#ifdef SAM_ENABLE_PCI
SamPCIInfo *samPCIInfos[]={
#if defined(SAM_ENABLE_HW_ST128PCI) || defined(SAM_ENABLE_HW_STDA)
  &samST128PCIInfo,
#endif
  NULL				/* sentinel */
};
#endif /* SAM_ENABLE_PCI */

static int adjustHWVendorInfo(SamHWCtrlVendorInfo *vendorInfo, int ofs, int count, SamDirtyAddrToCtrl *dirtyInfo)
{
  int i;
  unsigned addr, addr2;

  if(!vendorInfo) {
    dirtyInfo->n=0;
    dirtyInfo->ctrlIds=NULL;
    return 0;
  }

  addr=0;
  for(i=0; i<count; i++) {
    if(vendorInfo[i].vendorHandler) {
      vendorInfo[i].dirtyAddr=addr;
      addr+=vendorInfo[i].addrTagLimit+1;
    }
  }

  dirtyInfo->n=addr;
  dirtyInfo->ctrlIds=(unsigned char *)kmalloc(addr, GFP_KERNEL);
  if(!dirtyInfo->ctrlIds) {
    printk(KERN_ERR "sam9407: out of memory\n");
    return -ENOMEM;
  }

  addr=addr2=0;
  for(i=0; i<count; i++) {
    if(vendorInfo[i].vendorHandler) {
      addr+=vendorInfo[i].addrTagLimit+1;
      while(addr2<addr)
	dirtyInfo->ctrlIds[addr2++]=ofs+i;
    }
  }

  return 0;
}

static int adjustFWVendorInfo(SamFWCtrlVendorInfo *vendorInfo, int ofs, int count, SamDirtyAddrToCtrl *dirtyInfo)
{
  int i;
  unsigned addr, addr2;

  addr=0;
  for(i=0; i<count; i++) {
    if(vendorInfo[i].type!=SamCtrlTypeUnsupported) {
      vendorInfo[i].dirtyAddr=addr;
      addr+=vendorInfo[i].addrTagLimit+1;
    }
  }

  dirtyInfo->n=addr;
  dirtyInfo->ctrlIds=(unsigned char *)kmalloc(addr, GFP_KERNEL);
  if(!dirtyInfo->ctrlIds) {
    printk(KERN_ERR "sam9407: out of memory\n");
    return -ENOMEM;
  }

  addr=addr2=0;
  for(i=0; i<count; i++) {
    if(vendorInfo[i].type!=SamCtrlTypeUnsupported) {
      addr+=vendorInfo[i].addrTagLimit+1;
      while(addr2<addr)
	dirtyInfo->ctrlIds[addr2++]=ofs+i;
    }
  }

  return 0;
}

int samAdjustVendorInformation(void)
{
  int error, i;
  SamHardwareInfo *hardwareInfo;
  SamFirmwareInfo *firmwareInfo;

  error=0;

  for(i=0; (hardwareInfo=samHardwareInfos[i]); i++) {
    /* adjust hardware dirtyAddrs */
    error=adjustHWVendorInfo(hardwareInfo->ctrlInfo,
			     SAM_MIXER_HW_ID_FIRST, SAM_MIXER_HW_ID_LAST-SAM_MIXER_HW_ID_FIRST,
			     &hardwareInfo->mixerDirty);
    if(error<0)
      break;
  }
  if(error<0) {
    samReleaseVendorInformation();
    return error;
  }

  for(i=0; (firmwareInfo=samFirmwareInfos[i]); i++) {
    /* adjust mixer dirtyAddrs */
    error=adjustFWVendorInfo(firmwareInfo->mixerCtrlInfo,
			     0, samFirmwareClassInfo[firmwareInfo->apiClass].nMixerCtrls,
			     &firmwareInfo->mixerDirty);
    if(error<0)
      break;

    /* adjust audio dirtyAddrs */
    error=adjustFWVendorInfo(firmwareInfo->audioCtrlInfo,
			     0, samFirmwareClassInfo[firmwareInfo->apiClass].nAudioCtrls,
			     &firmwareInfo->audioDirty);
    if(error<0)
      break;
  }
  if(error<0) {
    samReleaseVendorInformation();
    return error;
  }

  return 0;
}

void samReleaseVendorInformation(void)
{
  int i;
  SamHardwareInfo *hardwareInfo;
  SamFirmwareInfo *firmwareInfo;

  for(i=0; (firmwareInfo=samFirmwareInfos[i]); i++) {
    if(firmwareInfo->mixerDirty.ctrlIds) {
      kfree(firmwareInfo->mixerDirty.ctrlIds);
      firmwareInfo->mixerDirty.ctrlIds=NULL;
    }

    if(firmwareInfo->audioDirty.ctrlIds) {
      kfree(firmwareInfo->audioDirty.ctrlIds);
      firmwareInfo->audioDirty.ctrlIds=NULL;
    }
  }

  for(i=0; (hardwareInfo=samHardwareInfos[i]); i++) {
    if(hardwareInfo->mixerDirty.ctrlIds) {
      kfree(hardwareInfo->mixerDirty.ctrlIds);
      hardwareInfo->mixerDirty.ctrlIds=NULL;
    }
  }
}
