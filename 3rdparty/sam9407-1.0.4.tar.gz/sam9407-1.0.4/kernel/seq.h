#ifndef _SEQ_H
#define _SEQ_H

#include "driver.h"

void samCheckPlaybackSeq(SamCard *card);

/* handle external midi events */
void samMidiInputSeq(SamCard *card, unsigned v);

int samOpenSeq(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseSeq(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadSeq(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
int samWriteSeq(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollSeq(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectSeq(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
int samIoctlSeq(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);

void samInitializeSeq(void);

#endif /* _SEQ_H */
