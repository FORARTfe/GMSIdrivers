#ifndef _MIDI_H
#define _MIDI_H

#include "driver.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif

#define SAM_STORED_MIDI_EVENTS		512
#ifdef SAM_ENABLE_RTC
#define SAM_MIDI_TICKER_FREQ		(samUsingRTC ? SAM_RTC_FREQ : HZ)
#else
#define SAM_MIDI_TICKER_FREQ		HZ
#endif
#define SAM_MIDI_SYSTEM_POLL_INTERVAL	1
#define SAM_MIDI_REC_SUSPEND_TICKS	(SAM_MIDI_TICKER_FREQ/50)

int samSendMidiReset(SamCard *card, SamMidiPortType portType);

/* handle external midi events */
void samMidiInput(SamCard *card, unsigned v);

int samOpenMidi(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseMidi(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadMidi(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
int samWriteMidi(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMidi(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectMidi(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
int samIoctlMidi(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);

void samInitializeMidi(void);

#endif /* _MIDI_H */
