#ifndef _MOD_H
#define _MOD_H

#include "driver.h"

void samCheckPlaybackMod(SamCard *card);

int samOpenMod(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
void samReleaseMod(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure);
int samReadMod(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure);
int samWriteMod(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure);
#if LINUX_VERSION_CODE>=0x20200
unsigned samPollMod(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure);
#else /* Linux 2.0 */
int samSelectMod(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure);
#endif /* Linux 2.0 */
int samIoctlMod(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr);

void samInitializeMod(void);

#endif /* _MOD_H */
