/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#include <linux/vmalloc.h>
#else
#include <linux/malloc.h>
#endif
#include <linux/soundcard.h>

#include "driver.h"
#include "io.h"
#include "alloc.h"
#include "audio.h"
#include "sndstat.h"

#define SAM_MAX_INFO_SIZE	4096

int samOpenSndStat(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  SamSndStatMsg *msg;
  SamDriverInfo driverInfo;

  if(!(msg=vmalloc(SAM_MAX_INFO_SIZE)))
    return -ENOMEM;
  msg->n=msg->i=0;
  file->private_data=msg;

  down(&card->usageCountLock);
  atomic_inc(&card->usageCount);
  up(&card->usageCountLock);

  msg->n+=sprintf(msg->s+msg->n, "driver:\t\tsam9407-%d.%d.%d\n", SAM_VERSION_MAJOR, SAM_VERSION_MINOR, SAM_VERSION_TINY);
  msg->n+=sprintf(msg->s+msg->n, "soundcard:\t%s\n", card->hardwareInfo->name);
  if(card->firmwareLoaded) {
    memset(&driverInfo, 0, sizeof(driverInfo));
    samGetMemInfo(card, &driverInfo);
    samGetAudioInfo(card, &driverInfo);

    msg->n+=sprintf(msg->s+msg->n, "firmware:\t%s\n", card->firmwareInfo->name);
    msg->n+=sprintf(msg->s+msg->n, "have-audio:\t%s\n", card->firmwareInfo->haveAudio ? "yes" : "no");
    msg->n+=sprintf(msg->s+msg->n, "have-midi:\t%s\n", card->firmwareInfo->haveMidi ? "yes" : "no");
    msg->n+=sprintf(msg->s+msg->n, "have-mod:\t%s\n", card->firmwareInfo->haveMod ? "yes" : "no");
    msg->n+=sprintf(msg->s+msg->n, "memory-total:\t%dk\n", driverInfo.memTotal>>9);
    msg->n+=sprintf(msg->s+msg->n, "memory-free:\t%dk\n", driverInfo.memFree>>9);
    msg->n+=sprintf(msg->s+msg->n, "memory-sbank:\t%dk\n", driverInfo.memSBanks>>9);
    msg->n+=sprintf(msg->s+msg->n, "memory-mod:\t%dk\n", driverInfo.memMod>>9);
    msg->n+=sprintf(msg->s+msg->n, "memory-audio:\t%dk\n", driverInfo.memAudio>>9);
    if(card->firmwareInfo->haveAudio) {
      msg->n+=sprintf(msg->s+msg->n, "channels-play:\t%d/%d\n", driverInfo.playChannelsUsed, driverInfo.playChannelsTotal);
      msg->n+=sprintf(msg->s+msg->n, "channels-rec:\t%d/%d\n", driverInfo.recordChannelsUsed, driverInfo.recordChannelsTotal);
    }
  } else
    msg->n+=sprintf(msg->s+msg->n, "firmware:\tn/a\n");

  atomic_dec(&card->usageCount);

  return 0;
}

void samReleaseSndStat(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  vfree(file->private_data);
}

int samReadSndStat(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  SamSndStatMsg *msg=(SamSndStatMsg *)file->private_data;
  int error, n;

  if(count<0)
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  down(&card->sndStat.accessLock);
  n=msg->n-msg->i;
  if(count<n)
    n=count;

  if(n>0) {
    if(SAM_MEMCPY_TOFS(buf, msg->s+msg->i, n)) {
      up(&card->sndStat.accessLock);
      return -EFAULT;
    }
    msg->i+=n;
  }

  up(&card->sndStat.accessLock);
  return n;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollSndStat(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  return POLLIN | POLLRDNORM;
}
#else /* Linux 2.0 */
int samSelectSndStat(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  return type==SEL_IN;
}
#endif /* Linux 2.0 */
