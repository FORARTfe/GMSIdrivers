#ifndef _FIRMWARE_H
#define _FIRMWARE_H

#include "sam9407.h"

/***** firmware specific definitions *****/

#define SAM_STATUS_TE			0x80
#define SAM_STATUS_RF			0x40

#define SAM_STATUS_ID_MASK		0x30
/* MIDI & AUDIO are sending asynchronous
 * notifications, while
 * MOD & GENERAL are working synchonously
 */
#define SAM_STATUS_ID_SYNC		0x20
#define SAM_STATUS_ID_MIDI		0x00
#define SAM_STATUS_ID_AUDIO		0x10
#define SAM_STATUS_ID_MOD		0x20
#define SAM_STATUS_ID_GENERAL		0x30

#define SAM_CMD_WRT_MEM			0x01
#define SAM_CMD_RD_MEM			0x02
#define SAM_CMD_GET_MMT			0x03
#define SAM_CMD_SET_MMT			0x04
#define SAM_CMD_EN_MIDOUT		0x3D
#define SAM_CMD_UART_MOD		0x3F
#define SAM_CMD_W_OPEN			0x40
#define SAM_CMD_W_CLOSE			0x41
#define SAM_CMD_W_START			0x42
#define SAM_CMD_END_XFER		0x43
#define SAM_CMD_GET_VOI			0x51
#define SAM_CMD_VOI_OPEN		0x52
#define SAM_CMD_VOI_CLOSE		0x53
#define SAM_CMD_VOI_START		0x54
#define SAM_CMD_VOI_STOP		0x55
#define SAM_CMD_VOI_VOL			0x56
#define SAM_CMD_VOI_MAIN		0x57
#define SAM_CMD_VOI_PITCH		0x58
#define SAM_CMD_VOI_AUX			0x59
#define SAM_CMD_VOI_FILT		0x5A
#define SAM_CMD_VOI_MEM			0x5B
#define SAM_CMD_GET_POS			0x5C
#define SAM_CMD_ADD_POS			0x5D
#define SAM_CMD_HOT_RES			0x70
#define SAM_CMD_EN_CONTROL		0xBE
#define SAM_CMD_RESET			0xFF

#define SAM_ACK_UART_MOD		0xFE
#define SAM_ACK_OP			0xAC
#define SAM_NAK_OP			0xAB

#define SAM_MAX_TRANSFER_SIZE		0x8000

#define SAM_MMT_ID_MASK			0x7F
#define SAM_MMT_ROM_MASK		0x80

#define SAM_MMT_ID_MEMSIZE		0x00
#define SAM_MMT_ID_FREE			0x01
#define SAM_MMT_ID_RESERVED		0x02
#define SAM_MMT_ID_MMT			0x03
#define SAM_MMT_ID_MIDI_MT		0x04
#define SAM_MMT_ID_MIDI_MT_EXT		0x05
#define SAM_MMT_ID_CTRL_TBL		0x06
#define SAM_MMT_ID_MIDI_PAR		0x10
#define SAM_MMT_ID_MIDI_PCM		0x11
#define SAM_MMT_ID_STR_WAVE		0x20
#define SAM_MMT_ID_STAT_WAVE		0x30
#define SAM_MMT_ID_EOM			0x7F

/* non-official ID's */
#define SAM_MMT_ID_MMT_COPY		0x08
#define SAM_MMT_ID_MIDI_MT_COPY		0x09
#define SAM_MMT_ID_SAVED_CTRLS		0x0A
#define SAM_MMT_ID_SAVED_HWCACHE	0x0B
#define SAM_MMT_ID_SAVED_HWHINTS	0x0C
#define SAM_MMT_ID_TMP_RESERVED		0x0F

typedef struct {
  unsigned short id;
  unsigned addr;
} __attribute__((packed)) SamMMTEntry;

typedef struct {
  char name[SAM_SBANK_NAME_LEN];
  unsigned short priority;
} __attribute__((packed)) SamMMTSBank;

#endif /* _FIRMWARE_H */
