/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/stddef.h>
#include <linux/kernel.h>

#include "driver.h"

/* indexed by SamMixerId */
SamFWCtrlVendorInfo samGenuineMixerCtrlInfo[]={
  {				/* SAM_MIXER_ID_SENTINEL */
  },
  {				/* SAM_MIXER_ID_MASTER_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x07,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_LBL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x10,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_MLBL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x11,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_MHBL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x12,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_HBL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x13,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_LBR */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x14,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_MLBR */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x15,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_MHBR */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x16,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQ_HBR */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x17,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQF_LB */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x18,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQF_MLB */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x19,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQF_MHB */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x1A,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EQF_HB */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x1B,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUD_SEL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x20,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUD_GAINL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x21,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUD_GAINR */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x22,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDCHR_SEND */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x24,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_GMREV_SEND */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x25,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_GMCHR_SEND */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x26,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDREV_SEND */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x27,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_ECH_LEV */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x28,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_ECH_TIM */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x29,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_ECH_FEED */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x2A,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_SUR_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x30,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_SUR_DEL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x31,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_SUR_INP */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x32,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_SUR_24 */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x33,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDL_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x34,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDR_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x35,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDL_PAN */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x36,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDR_PAN */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x37,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_GM_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x38,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_GM_PAN */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x39,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_REV_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x3A,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_VOL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0xFF,			/* valueLimit */
    0x3B,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_GM_POST */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x62,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_WAVE_POST */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x63,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_MOD_POST */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x64,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_AUDECH_POST */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x65,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_EFF_POST */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x66,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_REV_TYPE */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    7,				/* valueLimit */
    0x69,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_TYPE */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    7,				/* valueLimit */
    0x6A,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_DEL */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x74,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_FEED */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x75,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_RATE */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x76,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_CHR_DEPTH */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x77,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_REV_TIME */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x78,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_REV_FEED */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0x7F,			/* valueLimit */
    0x79,			/* ctrl */
  },
  {				/* SAM_MIXER_ID_REC_CFG */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x09,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_AUD_ONOFF */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x6F,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_ECH_ONOFF */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x68,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_REV_ONOFF */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x6C,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_CHR_ONOFF */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x6D,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_EQU_TYPE */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    2,				/* valueLimit */
    0x6B,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_SUR_ONOFF */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x6E,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_WAVE_ASS */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x60,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_MOD_ASS */
    SamCtrlTypeValue,		/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    1,				/* valueLimit */
    0x61,			/* ctrl */
    SamHWHookTypeNone,		/* hwHookType */
    SamHWHookIdNone,		/* hwHookId */
    0,				/* storeAt */
    SamCtrlResponseReset,	/* responseType */
  },
  {				/* SAM_MIXER_ID_SAMPLE_RATE */
    SamCtrlTypeUnsupported	/* type */
  },
  {				/* SAM_MIXER_ID_MASTER_MUTE */
    SamCtrlTypeVendorHandler,	/* type */
    SamAddrTagTypeNone,		/* addrTagType */
    0,				/* addrTagLimit */
    0,				/* valueLimit */
    0x00,			/* ctrl */
    SamHWHookTypeMandatory,	/* hwHookType */
    SamHWHookIdMasterMute,	/* hwHookId */
  },
  {				/* SAM_MIXER_ID_MINUS_6DB */
    SamCtrlTypeUnsupported
  },
};

SamFWCtrlVendorInfo samGenuineAudioCtrlInfo[]={
  {								/* SAM_AUDIO_ID_SENTINEL */
  },
  {								/* SAM_AUDIO_ID_VOLUME_LEFT */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x45,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, volleft),
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_ID_VOLUME_RIGHT */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x46,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, volright),
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_ID_VOLUME_AUX_LEFT */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x47,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, volauxleft),
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_ID_VOLUME_AUX_RIGHT */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x49,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, volauxright),
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionPlayOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_ID_FILT_FC */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x4A,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, filt_fc),
  },
  {								/* SAM_AUDIO_ID_FILT_Q */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeChannel,					/* addrTagType */
    0,								/* addrTagLimit */
    0xFFFF,							/* valueLimit */
    0x4B,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_KERNEL_SPACE |					/* storeAt */
    SAM_OFFSET_OF(SamGenuineAudioCtrlValues, filt_q),
  },
  {								/* SAM_AUDIO_ID_MUTE */
    SamCtrlTypeUnsupported					/* type */
  },
  {								/* SAM_AUDIO_ID_REC_MODE */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0x7F,							/* valueLimit */
    0x08,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_DEFAULT,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionRecordOnly,				/* channelRestriction */
  },
  {								/* SAM_AUDIO_ID_REC_VOL */
    SamCtrlTypeValue,						/* type */
    SamAddrTagTypeNone,						/* addrTagType */
    0,								/* addrTagLimit */
    0xFF,							/* valueLimit */
    0x0A,							/* ctrl */
    SamHWHookTypeNone,						/* hwHookType */
    SamHWHookIdNone,						/* hwHookId */
    SAM_STORE_AT_CTRL_TBL_DEFAULT,				/* storeAt */
    SamCtrlResponseNone,					/* responseType */
    SamChannelRestrictionRecordOnly,				/* channelRestriction */
  },
};

SamFirmwareInfo samGenuineFirmwareInfo={
  "genuine",			/* name */
  0,				/* probeAddr */
  NULL,				/* probeStr */
  SAM_API_CLASS_VANILLA,	/* apiClass */
  HZ/2,				/* initNapTimeout */
  0,				/* verifyChecksum */
  NULL,				/* setup */
  64,				/* mmtSlots */
  0,				/* largeCtrlTable */
  0,				/* peakMeterWords */
  1,				/* haveAudio */
  1,				/* haveMidi */
  1,				/* haveMod */
  1,				/* mutexModRecAudio */
  0,				/* supportsMaxi64Controls */
  8,				/* playBackChannels */
  1,				/* recordChannels */
  0x00,				/* getMMTAck */
  0x00,				/* openAck */
  0xC0,				/* closeAck */
  0,				/* closeAckRecChannel */
  0,				/* midiResetFixup */
  0,				/* getVoicesReadDummy */
  0,				/* getPosReturnsVoice */
  samGenuineMixerCtrlInfo,	/* mixerCtrlInfo */
  samGenuineAudioCtrlInfo,	/* audioCtrlInfo */
  0x00,				/* resetRestoreCtrl */
  0,				/* nResetReadjust */
  NULL,				/* resetReadjust */
  0,				/* nSBankRehash */
  NULL,				/* sbankRehash */
  "\xB1\xB0",			/* midiSelCtrls */
  0,				/* ctrlValuesSize */
  samGenuineInitAudioCtrlValues,/* initAudioCtrlValues */
};

void samGenuineInitAudioCtrlValues(struct SamChannelInfo *chp)
{
  chp->ctrlValues.genuine.volleft=chp->ctrlValues.genuine.volright=
    SAM_AUDIO_CTRL_CONFIGURED_MASK|0xFFFF;
  chp->ctrlValues.genuine.volauxleft=chp->ctrlValues.genuine.volauxright=
    SAM_AUDIO_CTRL_CONFIGURED_MASK|0x0000;
}
