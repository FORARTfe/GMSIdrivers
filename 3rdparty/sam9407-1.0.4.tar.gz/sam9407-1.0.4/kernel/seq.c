/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <linux/version.h>
#include <linux/stddef.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#if LINUX_VERSION_CODE>=0x20200
#include <linux/slab.h>
#else
#include <linux/malloc.h>
#endif
#include <linux/soundcard.h>

#include "driver.h"
#include "longlong.h"
#include "io.h"
#include "alloc.h"
#include "mixer.h"
#include "sync.h"
#ifdef SAM_ENABLE_RTC
#include "rtc.h"
#endif
#include "midi.h"
#include "seq.h"

#define SAM_SEQ_EVENT_SIZE		8
#define SAM_DEFAULT_TIMEBASE		100
#define SAM_MIN_TIMEBASE		1
#define SAM_MAX_TIMEBASE		1000
#define SAM_DEFAULT_TEMPO		60
#define SAM_MIN_TEMPO			8
#define SAM_MAX_TEMPO			360

typedef struct {
  unsigned char msgs[SAM_STORED_MIDI_EVENTS];
  int nMsgs;
} SamTmpMidiBuffer;

typedef struct {
#if LINUX_VERSION_CODE>=0x20200
  spinlock_t accessSpinLock;
#endif
  struct timer_list timer;
  unsigned references;
  unsigned long lastTickerJiffies;
} SeqTimerInfo;

#ifdef SAM_ENABLE_RTC
static void seqRTCTicker(void);
#endif
static void seqTicker(unsigned long data);

#ifdef SAM_ENABLE_RTC
static SamRTCCallbackNode rtcCallbackInfo={
  seqRTCTicker
};
#endif
static SeqTimerInfo timerInfo={
#if LINUX_VERSION_CODE>=0x20200
  SPIN_LOCK_UNLOCKED,
#endif
  SAM_TIMER_INIT(seqTicker)
};

static void checkWakeup(int deltaTicks)
{
  int i;
  SamCard *card;

  for(i=0; i<samCardsCount; i++) {
    card=samCards[i];
    if(!card)
      continue;

    if(card->seq.rec.timerRunning) {
      atomic_add(deltaTicks, &card->seq.rec.timerTicks);
      if((unsigned)SAM_ATOMIC_READ(&card->seq.rec.timerTicks)<deltaTicks &&
	 !card->seq.rec.timerOverflow) {
	card->seq.rec.timerOverflow=1;
	printk(KERN_WARNING "sam9407[#%d:%s]: sequencer record timer overflow\n",
	       card->cardIdx, card->hardwareInfo->name);
      }
      if(SAM_ATOMIC_READ(&card->seq.recSuspendTicks)>0) {
	atomic_sub(deltaTicks, &card->seq.recSuspendTicks);
	if(SAM_ATOMIC_READ(&card->seq.recSuspendTicks)<=0)
	  wake_up(&card->seq.dataAvail);
      }
    }

    if(card->seq.play.timerRunning) {
      atomic_add(deltaTicks, &card->seq.play.timerTicks);
      if((unsigned)SAM_ATOMIC_READ(&card->seq.play.timerTicks)<deltaTicks &&
	 !card->seq.play.timerOverflow) {
	card->seq.play.timerOverflow=1;
	printk(KERN_WARNING "sam9407[#%d:%s]: sequencer playback timer overflow\n",
	       card->cardIdx, card->hardwareInfo->name);
      }
      if(card->seq.sleeping &&
	 (unsigned)SAM_ATOMIC_READ(&card->seq.play.timerTicks)>=card->seq.wakeupTicks) {
	card->seq.checkPlayback=1;
	samFeedThreadInfo.haveJobs=1;
	wake_up(&samFeedThreadInfo.feedSam);
      }
    }
  }
}

#ifdef SAM_ENABLE_RTC
static void seqRTCTicker(void)
{
  checkWakeup(1);
}
#endif

static void seqTicker(unsigned long data)
{
  unsigned flags;
  int deltaTicks;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  deltaTicks=jiffies-timerInfo.lastTickerJiffies;
  timerInfo.lastTickerJiffies=jiffies;
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);

  checkWakeup(deltaTicks);

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references) {
    timerInfo.timer.expires=jiffies+SAM_MIDI_SYSTEM_POLL_INTERVAL;
    add_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStop(SamSeqBuffer *seqBuffer)
{
  unsigned flags;

  if(!seqBuffer->timerRunning)
    return;

  seqBuffer->timerRunning=0;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(--timerInfo.references==0) {
#ifdef SAM_ENABLE_RTC
    samRTCDisableCallback(&rtcCallbackInfo);
#endif
    del_timer(&timerInfo.timer);
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void timerStart(SamSeqBuffer *seqBuffer, int reset)
{
  unsigned flags;

  if(!reset && seqBuffer->timerRunning)
    return;

  timerStop(seqBuffer);
  if(reset) {
    SAM_ATOMIC_SET(&seqBuffer->timerTicks, 0);
    seqBuffer->timerOverflow=0;
  }

  seqBuffer->timerRunning=1;

  SAM_BEGIN_CRITICAL(&timerInfo.accessSpinLock, flags);
  if(timerInfo.references++==0) {
#ifdef SAM_ENABLE_RTC
    if(samUsingRTC) {
      samRTCEnableCallback(&rtcCallbackInfo);
    } else {
#endif
      timerInfo.lastTickerJiffies=jiffies;
      timerInfo.timer.expires=timerInfo.lastTickerJiffies+SAM_MIDI_SYSTEM_POLL_INTERVAL;
      add_timer(&timerInfo.timer);
#ifdef SAM_ENABLE_RTC
    }
#endif
  }
  SAM_END_CRITICAL(&timerInfo.accessSpinLock, flags);
}

static void playTimerStop(SamCard *card)
{
  if(card->seq.syncGroup<0 || card->seq.playing) {
    timerStop(&card->seq.play);
  } else
    card->seq.syncStartTimer=0;
}

static void playTimerStart(SamCard *card, int reset)
{
  if(card->seq.syncGroup<0 || card->seq.playing) {
    timerStart(&card->seq.play, reset);
    if(reset) {
      card->seq.lastWaitTimerTicks=0;
      card->seq.lastWaitTimerDrift=0;
    }
  } else {
    card->seq.syncStartTimer=1;
    card->seq.checkPlayback=1;
    samFeedThreadInfo.haveJobs=1;
    wake_up(&samFeedThreadInfo.feedSam);
  }
}

static __inline__ void syncLeave(SamCard *card)
{
  if(card->seq.syncGroup>=0) {
    samSyncLeave(card->seq.syncGroup, card->cardIdx, SamSyncDeviceSeq, card->seq.syncStarted);
    card->seq.syncGroup=-1;
  }
}

static __inline__ int putInt(unsigned long arg, int value)
{
  int error;

  if((error=verify_area(VERIFY_WRITE, (void *)arg, sizeof(int)))<0)
    return error;
  if(SAM_PUT_USER(value, (int *)arg))
    return -EFAULT;

  return 0;
}

static void appendRecEvent(SamCard *card, unsigned char *buf, int suspend)
{
  int i;

  if(card->seq.rec.usedCount<SAM_STORED_MIDI_EVENTS) {
    i=(card->seq.rec.usedIdx+card->seq.rec.usedCount)%SAM_STORED_MIDI_EVENTS;
    memcpy(card->seq.rec.ringBuffer+i*SAM_SEQ_EVENT_SIZE, buf, *buf&0x80 ? 8 : 4);
    if(card->seq.rec.usedCount++==0 && suspend)
      SAM_ATOMIC_SET(&card->seq.recSuspendTicks, SAM_MIDI_REC_SUSPEND_TICKS);
    else if(card->seq.rec.usedCount>=SAM_STORED_MIDI_EVENTS/2 ||
	    SAM_ATOMIC_READ(&card->seq.recSuspendTicks)<=0) {
      SAM_ATOMIC_SET(&card->seq.recSuspendTicks, 0);
      wake_up(&card->seq.dataAvail);
    }
  } else {
#ifndef SAM_IGNORE_REC_OVERFLOW
    SAM_ATOMIC_SET(&card->seq.recSuspendTicks, 0);
    card->seq.recOverflow=1;
    wake_up(&card->seq.dataAvail);
#endif
  }
}

static int retrieveRecEventFS(SamCard *card, unsigned char *buf)
{
  unsigned flags;
  unsigned char *event;
  int size;

  SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
  if(card->seq.rec.usedCount) {
    event=card->seq.rec.ringBuffer+card->seq.rec.usedIdx*SAM_SEQ_EVENT_SIZE;
    size=*event&0x80 ? 8 : 4;
    if(SAM_MEMCPY_TOFS(buf, event, size)) {
      SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
      return -EFAULT;
    }
    card->seq.rec.usedIdx=(card->seq.rec.usedIdx+1)%SAM_STORED_MIDI_EVENTS;
    card->seq.rec.usedCount--;
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    return size;
  }
  SAM_END_CRITICAL(&card->midi.recSpinLock, flags);

  return 0;
}

static void flushBuffers(SamCard *card, SamTmpMidiBuffer *buffers)
{
  int i;

  for(i=0; i<SamMidiPortSentinel; i++) {
    if(buffers[i].nMsgs>0) {
      if(samTalk(card,
		 SamSendCtrl, 1, card->firmwareInfo->midiSelCtrls[i],
		 SamSendMidiP, buffers[i].nMsgs, buffers[i].msgs,
		 SamEndOfScript)<0)
	printk(KERN_ERR "sam9407[#%d:%s]: error writing midi data\n",
	       card->cardIdx, card->hardwareInfo->name);
      buffers[i].nMsgs=0;
    }
  }
}

static void appendBuffer(SamCard *card, SamTmpMidiBuffer *buffers, int bufferIdx, int nMsgs, ...)
{
  va_list ap;
  SamTmpMidiBuffer *buffer;
  int i;

  if(bufferIdx>=SamMidiPortSentinel)
    return;

  buffer=buffers+bufferIdx;
  if(buffer->nMsgs+nMsgs>SAM_NUMBER_OF(buffers->msgs))
    flushBuffers(card, buffers);

  va_start(ap, nMsgs);
  for(i=0; i<nMsgs; i++)
    buffer->msgs[buffer->nMsgs++]=va_arg(ap, int);
  va_end(ap);
}

static void resetSeqInput(SamCard *card)
{
  unsigned flags;

  timerStop(&card->seq.rec);
  SAM_ATOMIC_SET(&card->seq.recSuspendTicks, 0);
  SAM_ATOMIC_SET(&card->seq.rec.timerTicks, 0);
  card->seq.rec.timerOverflow=0;

  card->seq.lastRecTimer=0;

  SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
  card->seq.rec.usedIdx=card->seq.rec.usedCount=0;
#ifndef SAM_IGNORE_REC_OVERFLOW
  card->seq.recOverflow=0;
#endif
  card->seq.followupRecEvent=0;

  SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
}

static int resetSeqOutput(SamCard *card)
{
  int error=0, tmpError, i;

  playTimerStop(card);

  SAM_ATOMIC_SET(&card->seq.play.timerTicks, 0);
  card->seq.play.timerOverflow=0;

  card->seq.playing=0;
  card->seq.sleeping=0;

  card->seq.lastWaitTimerTicks=0;
  card->seq.lastWaitTimerDrift=0;
  card->seq.timeBase=SAM_DEFAULT_TIMEBASE;
  card->seq.tempo=SAM_DEFAULT_TEMPO;

  card->seq.pendingWriteBufFilled=0;
  card->seq.play.usedIdx=card->seq.play.usedCount=0;

  for(i=0; i<SamMidiPortSentinel; i++)
    if((tmpError=samSendMidiReset(card, i))<0 && !error)
      error=tmpError;

  return error;
}

/* process a single 8 byte wide event */
static void processEvent(SamCard *card, SamTmpMidiBuffer *buffers, unsigned char *event)
{
  int i;
  unsigned flags, v, vl, vh, base;

  switch(event[0]) {
  case SEQ_MIDIPUTC:
    appendBuffer(card, buffers, event[2], 1, event[1]);
    break;
  case EV_TIMING:
    flushBuffers(card, buffers);
    switch(event[1]) {
    case TMR_START:
      playTimerStart(card, 1);
      break;
    case TMR_STOP:
      playTimerStop(card);
      break;
    case TMR_CONTINUE:
      playTimerStart(card, 0);
      break;
    case TMR_WAIT_ABS:
      card->seq.lastWaitTimerTicks=0;
      card->seq.lastWaitTimerDrift=0;
      /* flow into next case */
    case TMR_WAIT_REL:
      flushBuffers(card, buffers);
      samLLMul32(&vl, &vh, *(unsigned *)(event+4), 60*SAM_MIDI_TICKER_FREQ);
      samLLAdd64(&vl, &vh, card->seq.lastWaitTimerDrift, 0);
      base=card->seq.timeBase*card->seq.tempo;
      if(vh<base) {
	samLLDivMod24(vl, vh, base,
		      &v, &card->seq.lastWaitTimerDrift);
	card->seq.lastWaitTimerTicks+=v;
	if(card->seq.lastWaitTimerTicks>(unsigned)SAM_ATOMIC_READ(&card->seq.play.timerTicks)) {
	  card->seq.wakeupTicks=card->seq.lastWaitTimerTicks;
	  card->seq.sleeping=1;
	}
      } else
	if(!card->seq.play.timerOverflow) {
	  card->seq.play.timerOverflow=1;
	  printk(KERN_WARNING "sam9407[#%d:%s]: sequencer playback timer overflow\n",
		 card->cardIdx, card->hardwareInfo->name);
	}
      break;
    case TMR_ECHO:
      SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
      if(card->seq.rec.ringBuffer)
	appendRecEvent(card, event, 0);
      SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
      break;
    case TMR_TEMPO:
      v=*(unsigned *)(event+4);
      if(v<SAM_MIN_TEMPO)
	v=SAM_MIN_TEMPO;
      if(v>SAM_MAX_TEMPO)
	v=SAM_MAX_TEMPO;
      /* readjust timer drift */
      card->seq.lastWaitTimerDrift=card->seq.lastWaitTimerDrift*v/card->seq.tempo;
      card->seq.tempo=v;
      break;
    }
    break;
  case EV_CHN_COMMON:
    switch(event[2]) {
    case MIDI_PGM_CHANGE:
      appendBuffer(card, buffers, event[1], 2, 0xC0|(event[3]&0x0F), event[4]);
      break;
    case MIDI_CTL_CHANGE:
      appendBuffer(card, buffers, event[1], 3, 0xB0|(event[3]&0x0F), event[4], event[6]&0x7F);
      break;
    case MIDI_PITCH_BEND:
      appendBuffer(card, buffers, event[1], 3, 0xE0|(event[3]&0x0F), event[6]&0x7F, (event[7]>>7)&0x7F);
      break;
    }
    break;
  case EV_CHN_VOICE:
    switch(event[2]) {
    case MIDI_NOTEON:
      appendBuffer(card, buffers, event[1], 3, 0x90|(event[3]&0x0F), event[4], event[5]);
      break;
    case MIDI_NOTEOFF:
      appendBuffer(card, buffers, event[1], 3, 0x80|(event[3]&0x0F), event[4], event[5]);
      break;
    case MIDI_KEY_PRESSURE:
      appendBuffer(card, buffers, event[1], 2, 0xD0|(event[3]&0x0F), event[5]);
      break;
    }
    break;
  case EV_SYSEX:
    for(i=0; i<6 && event[i+2]!=0xFF; i++);
    appendBuffer(card, buffers, event[1], i, event[2], event[3], event[4], event[5], event[6], event[7]);
    break;
  }
}

/* asynchronous playback of
 * sequencer events stored at card->seq.play.ringBuffer
 */
void samCheckPlaybackSeq(SamCard *card)
{
  int i;
  unsigned char *event;
  SamTmpMidiBuffer buffers[SamMidiPortSentinel];

  down(&card->midi.accessLock);
  if(card->seq.syncGroup>=0 && !card->seq.playing) {
    if(!card->seq.play.usedCount && !card->seq.syncStartTimer) {
      up(&card->midi.accessLock);
      return;
    }
    if(!card->seq.syncStarted) {
      samSyncStart(card->seq.syncGroup);
      card->seq.syncStarted=1;
    }
    if(!samSyncReady(card->seq.syncGroup)) {
      up(&card->midi.accessLock);
      return;
    }
    if(card->seq.syncStartTimer) {
      timerStart(&card->seq.play, 1);
      card->seq.lastWaitTimerTicks=0;
      card->seq.lastWaitTimerDrift=0;
    }
  }

  card->seq.playing=1;

  if(!card->seq.play.ringBuffer) {
    up(&card->midi.accessLock);
    return;
  }

  if(card->seq.sleeping) {
    if((unsigned)SAM_ATOMIC_READ(&card->seq.play.timerTicks)<card->seq.wakeupTicks) {
      up(&card->midi.accessLock);
      return;
    }
    card->seq.sleeping=0;
  }

  if(card->seq.play.usedCount) {
    for(i=0; i<SamMidiPortSentinel; i++)
      buffers[i].nMsgs=0;
    while(!card->seq.sleeping && card->seq.play.usedCount) {
      event=card->seq.play.ringBuffer+card->seq.play.usedIdx*SAM_SEQ_EVENT_SIZE;
      /* we've got one event, process it */
      processEvent(card, buffers, event);
      card->seq.play.usedIdx=(card->seq.play.usedIdx+1)%SAM_STORED_MIDI_EVENTS;
      card->seq.play.usedCount--;
      wake_up(&card->seq.moreSpace);
    }
    flushBuffers(card, buffers);
  }
  up(&card->midi.accessLock);
}

/* handle external midi events */
void samMidiInputSeq(SamCard *card, unsigned v)
{
  unsigned flags, vl, vh, newRecTimer, newRecRem;
  unsigned char event[8];

  SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
  if(!card->seq.rec.ringBuffer) {
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    return;
  }

  if(!card->seq.followupRecEvent) {
    memset(event, 0, sizeof(event));
    event[0]=EV_TIMING;
    event[1]=TMR_START;
    appendRecEvent(card, event, 1);
    card->seq.followupRecEvent=1;
  }

  samLLMul32(&vl, &vh, (unsigned)SAM_ATOMIC_READ(&card->seq.rec.timerTicks), SAM_DEFAULT_TEMPO*SAM_DEFAULT_TIMEBASE);
  if(vh<60*SAM_MIDI_TICKER_FREQ) {
    samLLDivMod24(vl, vh, 60*SAM_MIDI_TICKER_FREQ,
		  &newRecTimer, &newRecRem);
    if(newRecTimer>card->seq.lastRecTimer && !card->seq.rec.timerOverflow) {
      memset(event, 0, sizeof(event));
      event[0]=EV_TIMING;
      event[1]=TMR_WAIT_ABS;
      *(unsigned *)(event+4)=newRecTimer;
      appendRecEvent(card, event, 1);
      card->seq.lastRecTimer=newRecTimer;
    }
  } else
    if(!card->seq.rec.timerOverflow) {
      card->seq.rec.timerOverflow=1;
      printk(KERN_WARNING "sam9407[#%d:%s]: sequencer record timer overflow\n",
	     card->cardIdx, card->hardwareInfo->name);
    }

  memset(event, 0, sizeof(event));
  event[0]=SEQ_MIDIPUTC;
  event[1]=v;
  event[2]=SamMidiPortExternal;
  appendRecEvent(card, event, 1);

  SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
}

int samOpenSeq(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  unsigned flags;
  int error;

  if(!card->firmwareInfo->haveMidi)
    return -ENOPKG;

  down(&card->midi.accessLock);
  if((file->f_mode & SAM_MODE_READ_MASK) &&
     (card->midi.ports[SamMidiPortExternal].ownerRead!=SamMidiPortOwnerNone ||
      card->midi.ports[SamMidiPortInternal].ownerRead!=SamMidiPortOwnerNone)) {
    up(&card->midi.accessLock);
    return -EBUSY;
  }
  if((file->f_mode & SAM_MODE_WRITE_MASK) &&
     (card->midi.ports[SamMidiPortExternal].ownerWrite!=SamMidiPortOwnerNone ||
      card->midi.ports[SamMidiPortInternal].ownerWrite!=SamMidiPortOwnerNone)) {
    up(&card->midi.accessLock);
    return -EBUSY;
  }

  if(file->f_mode & SAM_MODE_READ_MASK) {
    card->midi.ports[SamMidiPortExternal].ownerRead=SamMidiPortOwnerSeq;
    card->midi.ports[SamMidiPortInternal].ownerRead=SamMidiPortOwnerSeq;
  }
  if(file->f_mode & SAM_MODE_WRITE_MASK) {
    card->midi.ports[SamMidiPortExternal].ownerWrite=SamMidiPortOwnerSeq;
    card->midi.ports[SamMidiPortInternal].ownerWrite=SamMidiPortOwnerSeq;
  }

  error=0;

  if(file->f_mode & SAM_MODE_READ_MASK) {
    resetSeqInput(card);
    card->seq.rec.ringBuffer=(unsigned char *)kmalloc(SAM_STORED_MIDI_EVENTS*SAM_SEQ_EVENT_SIZE, GFP_KERNEL);
    if(!card->seq.rec.ringBuffer)
      error=-ENOMEM;
  }

  if(error>=0 && (file->f_mode & SAM_MODE_WRITE_MASK)) {
    card->seq.play.ringBuffer=(unsigned char *)kmalloc(SAM_STORED_MIDI_EVENTS*SAM_SEQ_EVENT_SIZE, GFP_KERNEL);
    if(card->seq.play.ringBuffer)
      error=resetSeqOutput(card);
    else
      error=-ENOMEM;
  }

  if(error<0) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->seq.rec.ringBuffer) {
      kfree(card->seq.rec.ringBuffer);
      card->seq.rec.ringBuffer=NULL;
    }
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->seq.play.ringBuffer) {
      kfree(card->seq.play.ringBuffer);
      card->seq.play.ringBuffer=NULL;
    }
    if(file->f_mode & SAM_MODE_READ_MASK) {
      card->midi.ports[SamMidiPortExternal].ownerRead=SamMidiPortOwnerNone;
      card->midi.ports[SamMidiPortInternal].ownerRead=SamMidiPortOwnerNone;
    }
    if(file->f_mode & SAM_MODE_WRITE_MASK) {
      card->midi.ports[SamMidiPortExternal].ownerWrite=SamMidiPortOwnerNone;
      card->midi.ports[SamMidiPortInternal].ownerWrite=SamMidiPortOwnerNone;
    }
    up(&card->midi.accessLock);
    return error;
  }

  if(file->f_mode & SAM_MODE_READ_MASK)
    timerStart(&card->seq.rec, 1);

  up(&card->midi.accessLock);

  atomic_inc(&card->fastPollRequests);

  return 0;
}

void samReleaseSeq(struct inode *inode, struct file *file, SamCard *card, mode_t mode, char *closure)
{
  SamWaitQueue wait;
  unsigned flags;

  down(&card->midi.accessLock);

  if(file->f_mode & SAM_MODE_WRITE_MASK) {
    while(card->seq.play.usedCount &&
	  (!card->seq.sleeping || card->seq.play.timerRunning ||
	   (card->seq.syncGroup>=0 && !card->seq.playing))) {
      samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->seq.moreSpace, &wait);
      up(&card->midi.accessLock);
      samSleepOn(&card->seq.moreSpace, &wait);
#if LINUX_VERSION_CODE>=0x20200
      if(signal_pending(current))
	break;
#else /* Linux 2.0 */
      if(current->signal & ~current->blocked)
	break;
#endif /* Linux 2.0 */
      down(&card->midi.accessLock);
    }
  }

  atomic_dec(&card->fastPollRequests);

  syncLeave(card);

  if(file->f_mode & SAM_MODE_READ_MASK) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    if(card->seq.rec.ringBuffer) {
      kfree(card->seq.rec.ringBuffer);
      card->seq.rec.ringBuffer=NULL;
    }
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);

    resetSeqInput(card);
  }

  if(file->f_mode & SAM_MODE_WRITE_MASK) {
    if(card->seq.play.ringBuffer) {
      kfree(card->seq.play.ringBuffer);
      card->seq.play.ringBuffer=NULL;
    }

    if(resetSeqOutput(card)<0)
      printk(KERN_ERR "sam9407[#%d:%s]: couldn't reset midi channel\n",
	     card->cardIdx, card->hardwareInfo->name);
  }

  if(file->f_mode & SAM_MODE_READ_MASK) {
    card->midi.ports[SamMidiPortExternal].ownerRead=SamMidiPortOwnerNone;
    card->midi.ports[SamMidiPortInternal].ownerRead=SamMidiPortOwnerNone;
  }
  if(file->f_mode & SAM_MODE_WRITE_MASK) {
    card->midi.ports[SamMidiPortExternal].ownerWrite=SamMidiPortOwnerNone;
    card->midi.ports[SamMidiPortInternal].ownerWrite=SamMidiPortOwnerNone;
  }

  up(&card->midi.accessLock);
}

int samReadSeq(struct inode *inode, struct file *file, char *buf, int count, SamCard *card, char *closure)
{
  SamWaitQueue wait;
  unsigned flags;
  int error, n, size;
  unsigned char *cp;

  if(count<0 || (count>0 && count<8))
    return -EINVAL;

  if((error=verify_area(VERIFY_WRITE, buf, count))<0)
    return error;

  cp=(unsigned char *)buf;
  n=count;

  down(&card->midi.accessLock);

  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     !card->seq.recOverflow &&
#endif
     (!card->seq.rec.usedCount || SAM_ATOMIC_READ(&card->seq.recSuspendTicks)>0) &&
     (file->f_flags & O_NONBLOCK)) {
    up(&card->midi.accessLock);
    return -EAGAIN;
  }

  /* wait for incoming data */
  for(;;) {
    samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->seq.dataAvail, &wait);
    if(
#ifndef SAM_IGNORE_REC_OVERFLOW
       card->seq.recOverflow ||
#endif
       (card->seq.rec.usedCount && SAM_ATOMIC_READ(&card->seq.recSuspendTicks)<=0)) {
      samCancelSleepOn(&card->seq.dataAvail, &wait);
      break;
    }
    up(&card->midi.accessLock);
    samSleepOn(&card->seq.dataAvail, &wait);
#if LINUX_VERSION_CODE>=0x20200
    if(signal_pending(current))
      return -ERESTARTSYS;
#else /* Linux 2.0 */
    if(current->signal & ~current->blocked)
      return -ERESTARTSYS;
#endif /* Linux 2.0 */
    down(&card->midi.accessLock);
  }

#ifndef SAM_IGNORE_REC_OVERFLOW
  if(card->seq.recOverflow) {
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    card->seq.recOverflow=0;
    card->seq.rec.usedIdx=card->seq.rec.usedCount=0;
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    up(&card->midi.accessLock);
    return -EIO;
  }
#endif

  while(n>=8) {
    if((size=retrieveRecEventFS(card, cp))<=0) {
      if(size<0) { /* error */
	up(&card->midi.accessLock);
	return size;
      }
      break;
    }
    cp+=size;
    n-=size;
  }

  up(&card->midi.accessLock);

  return cp-(unsigned char *)buf;
}

int samWriteSeq(struct inode *inode, struct file *file, const char *buf, int count, SamCard *card, char *closure)
{
  SamWaitQueue wait;
  int error, sigPending, i, n, size;
  unsigned char *event, *cp;

  if(count<0 || (count&3))
    return -EINVAL;

  if((error=verify_area(VERIFY_READ, buf, count))<0)
    return error;

  cp=(unsigned char *)buf;
  n=count>>2;

  down(&card->midi.accessLock);

  while(n>0) {
    if(card->seq.play.usedCount+SAM_STORED_MIDI_EVENTS/2>SAM_STORED_MIDI_EVENTS &&
       (file->f_flags & O_NONBLOCK)) {
      error=-EAGAIN;
      break;
    }

    /* wait until at least half SAM_STORED_MIDI_EVENTS
     * buffer is free
     * to avoid writing small chunks only
     */
    while(card->seq.play.usedCount+SAM_STORED_MIDI_EVENTS/2>SAM_STORED_MIDI_EVENTS) {
      card->seq.checkPlayback=1;
      samFeedThreadInfo.haveJobs=1;
      wake_up(&samFeedThreadInfo.feedSam);
      samPrepareSleepOn(TASK_INTERRUPTIBLE, &card->seq.moreSpace, &wait);
      up(&card->midi.accessLock);
      samSleepOn(&card->seq.moreSpace, &wait);
#if LINUX_VERSION_CODE>=0x20200
      sigPending=signal_pending(current);
#else /* Linux 2.0 */
      sigPending=current->signal & ~current->blocked;
#endif /* Linux 2.0 */
      down(&card->midi.accessLock);
      if(sigPending) {
	error=-ERESTARTSYS;
	break;
      }
    }
    if(error<0)
      break;

    /* take care of half finished pending event first */
    if(card->seq.pendingWriteBufFilled && n>0 && card->seq.play.usedCount<SAM_STORED_MIDI_EVENTS) {
      i=(card->seq.play.usedIdx+card->seq.play.usedCount)%SAM_STORED_MIDI_EVENTS;
      event=card->seq.play.ringBuffer+i*SAM_SEQ_EVENT_SIZE;

      memcpy(event, card->seq.pendingWriteBuf, 4);
      if(SAM_MEMCPY_FROMFS(event+4, cp, 4)) {
	error=-EFAULT;
	break;
      }
      card->seq.play.usedCount++;
      card->seq.pendingWriteBufFilled=0;
      cp+=4;
      n--;
    }

    while(n>0 && card->seq.play.usedCount<SAM_STORED_MIDI_EVENTS) {
      i=(card->seq.play.usedIdx+card->seq.play.usedCount)%SAM_STORED_MIDI_EVENTS;
      event=card->seq.play.ringBuffer+i*SAM_SEQ_EVENT_SIZE;

      if(SAM_GET_USER(size, cp)) {
	error=-EFAULT;
	break;
      }
      size=size&0x80 ? 2 : 1;

      if(n>=size) {
	if(SAM_MEMCPY_FROMFS(event, cp, size<<2)) {
	  error=-EFAULT;
	  break;
	}
	card->seq.play.usedCount++;

	cp+=size<<2;
	n-=size;
      } else {
	if(SAM_MEMCPY_FROMFS(card->seq.pendingWriteBuf, cp, 4)) {
	  error=-EFAULT;
	  break;
	}
	card->seq.pendingWriteBufFilled=1;
	cp+=4;
	n--;
      }
    }
    if(error<0)
      break;
  }

  up(&card->midi.accessLock);
  card->seq.checkPlayback=1;
  samFeedThreadInfo.haveJobs=1;
  wake_up(&samFeedThreadInfo.feedSam);

  if(error>=0 ||
     ((error==-EAGAIN || error==-ERESTARTSYS) && cp>(unsigned char *)buf))
    return cp-(unsigned char *)buf;
  else
    return error;
}

#if LINUX_VERSION_CODE>=0x20200
unsigned samPollSeq(struct inode *inode, struct file *file, poll_table *wait, SamCard *card, mode_t mode, char *closure)
{
  unsigned mask, flags;

  down(&card->midi.accessLock);
  SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);

  mask=0;
  if(
#ifndef SAM_IGNORE_REC_OVERFLOW
     card->seq.recOverflow ||
#endif
     (card->seq.rec.usedCount && SAM_ATOMIC_READ(&card->seq.recSuspendTicks)<=0))
    mask|= POLLIN | POLLRDNORM;

  if(card->seq.play.usedCount+SAM_STORED_MIDI_EVENTS/2<=SAM_STORED_MIDI_EVENTS)
    mask|= POLLOUT | POLLWRNORM;

  poll_wait(file, &card->seq.dataAvail, wait);
  poll_wait(file, &card->seq.moreSpace, wait);

  SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
  up(&card->midi.accessLock);

  return mask;
}
#else /* Linux 2.0 */
int samSelectSeq(struct inode *inode, struct file *file, int type, select_table *wait, SamCard *card, char *closure)
{
  unsigned flags;
  int avail=0;

  switch(type) {
  case SEL_IN:
    SAM_BEGIN_CRITICAL(&card->midi.recSpinLock, flags);
    avail=
#ifndef SAM_IGNORE_REC_OVERFLOW
      card->seq.recOverflow ||
#endif
      (card->seq.rec.usedCount && SAM_ATOMIC_READ(&card->seq.recSuspendTicks)<=0);
    if(!avail)
      select_wait(&card->seq.dataAvail, wait);
    SAM_END_CRITICAL(&card->midi.recSpinLock, flags);
    break;
  case SEL_OUT:
    down(&card->midi.accessLock);
    avail=(card->seq.play.usedCount+SAM_STORED_MIDI_EVENTS/2<=SAM_STORED_MIDI_EVENTS);
    if(!avail)
      select_wait(&card->seq.moreSpace, wait);
    up(&card->midi.accessLock);
    break;
  }
  return avail;
}
#endif /* Linux 2.0 */

static int syncJoin(SamCard *card, int *syncGroupP)
{
  int error, syncGroup;

  if((error=verify_area(VERIFY_WRITE, syncGroupP, sizeof(int)))<0)
    return error;
  if(SAM_GET_USER(syncGroup, syncGroupP))
    return -EFAULT;

  if(card->seq.playing)
    return -EBUSY;

  syncLeave(card);
  if((error=samSyncJoin(&syncGroup, card->cardIdx, SamSyncDeviceSeq))>=0) {
    card->seq.syncGroup=syncGroup;
    card->seq.syncStarted=0;
    card->seq.syncStartTimer=0;
    if(SAM_PUT_USER(syncGroup, syncGroupP))
      error=-EFAULT;
  }

  return error;
}

static int synthInfo(struct synth_info *infoP)
{
  int error, device;
  char *name;

  if((error=verify_area(VERIFY_WRITE, infoP, sizeof(struct synth_info)))<0)
    return error;

  if(SAM_GET_USER(device, &infoP->device))
    return -EFAULT;

  switch(device) {
  case SamMidiPortInternal:
    name="sam9407-synth-internal";
    break;
  case SamMidiPortExternal:
    name="sam9407-synth-external";
    break;
  default:
    return -EINVAL;
  }

  if(SAM_MEMCPY_TOFS(&infoP->name, name, strlen(name)+1) ||
     SAM_PUT_USER(SYNTH_TYPE_MIDI, &infoP->synth_type) ||
     SAM_PUT_USER(0x9407, &infoP->synth_subtype) ||
     SAM_PUT_USER(32, &infoP->nr_voices))
    return -EFAULT;

  if(SAM_PUT_USER(device==SamMidiPortExternal ? SYNTH_CAP_INPUT : 0, &infoP->capabilities))
    return -EFAULT;

  return 0;
}

static int midiInfo(struct midi_info *infoP)
{
  int error, device;
  char *name;

  if((error=verify_area(VERIFY_WRITE, infoP, sizeof(struct midi_info)))<0)
    return error;

  if(SAM_GET_USER(device, &infoP->device))
    return -EFAULT;

  switch(device) {
  case SamMidiPortInternal:
    name="sam9407-midi-internal";
    break;
  case SamMidiPortExternal:
    name="sam9407-midi-external";
    break;
  default:
    return -EINVAL;
  }

  if(SAM_MEMCPY_TOFS(&infoP->name, name, strlen(name)+1) ||
     SAM_PUT_USER(0, &infoP->capabilities) ||
     SAM_PUT_USER(0, &infoP->dev_type))
    return -EFAULT;

  return 0;
}

static int processOutOfBand(SamCard *card, unsigned char *eventP)
{
  int error, i;
  SamTmpMidiBuffer buffers[SamMidiPortSentinel];
  unsigned char event[8];

  if((error=verify_area(VERIFY_READ, eventP, 8))<0)
    return error;

  for(i=0; i<SamMidiPortSentinel; i++)
    buffers[i].nMsgs=0;

  if(SAM_MEMCPY_FROMFS(event, eventP, 8))
    return -EFAULT;

  down(&card->midi.accessLock);
  processEvent(card, buffers, event);
  flushBuffers(card, buffers);
  up(&card->midi.accessLock);

  return 0;
}

int samIoctlSeq(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg, SamCard *card, mode_t mode, char *closure, int callNr)
{
  int error, v;

  error=0;
  switch(cmd) {
  case SAM_IOC_API_INFO:
    error=samApiInfo(card, (SamApiInfo *)arg, SAM_SEQ_API_VERSION);
    break;
  case SAM_IOC_SYNC_JOIN:
    down(&card->midi.accessLock);
    error=syncJoin(card, (int *)arg);
    up(&card->midi.accessLock);
    break;
  case SAM_IOC_SYNC_LEAVE:
    down(&card->midi.accessLock);
    syncLeave(card);
    up(&card->midi.accessLock);
    break;
  case SAM_IOC_SYNC_INFO:
    down(&card->midi.accessLock);
    error=putInt(arg, card->seq.syncGroup);
    up(&card->midi.accessLock);
    break;
  case SNDCTL_SEQ_NRSYNTHS:
    return putInt(arg, SamMidiPortSentinel);
  case SNDCTL_SYNTH_INFO:
    return synthInfo((struct synth_info *)arg);
  case SNDCTL_SEQ_NRMIDIS:
    return putInt(arg, SamMidiPortSentinel);
  case SNDCTL_MIDI_INFO:
    return midiInfo((struct midi_info *)arg);
  case SNDCTL_SEQ_CTRLRATE:
    return putInt(arg, SAM_MIDI_TICKER_FREQ);
  case SNDCTL_SEQ_RESET:
    down(&card->midi.accessLock);
    if(file->f_mode & SAM_MODE_READ_MASK) {
      resetSeqInput(card);
      timerStart(&card->seq.rec, 1);
    }
    if(file->f_mode & SAM_MODE_WRITE_MASK)
      error=resetSeqOutput(card);
    up(&card->midi.accessLock);
    break;
  case SNDCTL_TMR_START:
    down(&card->midi.accessLock);
    playTimerStart(card, 1);
    up(&card->midi.accessLock);
    break;
  case SNDCTL_TMR_STOP:
    down(&card->midi.accessLock);
    playTimerStop(card);
    up(&card->midi.accessLock);
    break;
  case SNDCTL_TMR_CONTINUE:
    down(&card->midi.accessLock);
    playTimerStart(card, 0);
    up(&card->midi.accessLock);
    break;
  case SNDCTL_TMR_TIMEBASE:
    if((error=verify_area(VERIFY_WRITE, (void *)arg, sizeof(int)))<0)
      return error;
    if(SAM_GET_USER(v, (int *)arg))
      return -EFAULT;
    if(v<SAM_MIN_TIMEBASE)
      v=SAM_MIN_TIMEBASE;
    if(v>SAM_MAX_TIMEBASE)
      v=SAM_MAX_TIMEBASE;
    if(SAM_PUT_USER(v, (int *)arg))
      return -EFAULT;
    down(&card->midi.accessLock);
    /* readjust timer drift */
    card->seq.lastWaitTimerDrift=card->seq.lastWaitTimerDrift*v/card->seq.timeBase;
    card->seq.timeBase=v;
    up(&card->midi.accessLock);
    break;
  case SNDCTL_TMR_TEMPO:
    if((error=verify_area(VERIFY_WRITE, (void *)arg, sizeof(int)))<0)
      return error;
    if(SAM_GET_USER(v, (int *)arg))
      return -EFAULT;
    if(v<SAM_MIN_TEMPO)
      v=SAM_MIN_TEMPO;
    if(v>SAM_MAX_TEMPO)
      v=SAM_MAX_TEMPO;
    if(SAM_PUT_USER(v, (int *)arg))
      return -EFAULT;
    down(&card->midi.accessLock);
    /* readjust timer drift */
    card->seq.lastWaitTimerDrift=card->seq.lastWaitTimerDrift*v/card->seq.tempo;
    card->seq.tempo=v;
    up(&card->midi.accessLock);
    break;
  case SNDCTL_SEQ_OUTOFBAND:
    return processOutOfBand(card, (unsigned char *)arg);
  default:
    return -ENOSYS;
  }

  return error;
}

void samInitializeSeq(void)
{
#ifdef SAM_ENABLE_RTC
  samRTCRegisterCallback(&rtcCallbackInfo);
#endif
}
