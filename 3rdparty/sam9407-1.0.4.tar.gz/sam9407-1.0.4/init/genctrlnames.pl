# -*-perl-*-

while(<>) {
    if(/^\s*SAM_API_CLASS_(\w+)/) {
	$classes[$#classes+1]=$1 if($1 ne "NONE");
    }
    if(/^\s*(SAM_MIXER_(\w+_)?ID_(\w+))/) {
	$class=$2; chop($class);
	$class="VANILLA" if (!$class);
	$name=$3;
	$value=$1;
	if($name ne "FIRST" && $name ne "LAST" && $name ne "SENTINEL") {
	    $mixer{$class}.=$; . $name;
	    $mixer_value{$class,$name}=$value;
	    if(/\/\*.*RESET/) {
		$doesReset{$class,$name}="1";
	    } else {
		$doesReset{$class,$name}="0";
	    }
	    if(/\#(\d+)/) {
		$mixerAddrLimit{$class,$name}=$1;
	    } else {
		$mixerAddrLimit{$class,$name}="0";
	    }
	    $mixerAddr{$class,$name}=$mixerControls{$class}+0;
	    $mixerControls{$class}+=$mixerAddrLimit{$class,$name}+1;
	}
    }
    if(/^\s*(SAM_AUDIO_(\w+_)?ID_(\w+))/) {
	$class=$2; chop($class);
	$class="VANILLA" if (!$class);
	$name=$3;
	$value=$1;
	if($name ne "LAST" && $name ne "SENTINEL") {
	    $audio{$class}.=$; . $name;
	    $audio_value{$class,$name}=$value;
	    if(/\/\*.*PLAY/) {
		$restrictPlayMode{$class,$name}="1";
	    } else {
		$restrictPlayMode{$class,$name}="0";
	    }
	    if(/\/\*.*RECORD/) {
		$restrictRecordMode{$class,$name}="1";
	    } else {
		$restrictRecordMode{$class,$name}="0";
	    }
	    if(/\#(\d+)/) {
		$audioAddrLimit{$class,$name}=$1;
	    } else {
		$audioAddrLimit{$class,$name}="0";
	    }
	    $audioAddr{$class,$name}=$audioControls{$class}+0;
	    $audioControls{$class}+=$audioAddrLimit{$class,$name}+1;
	}
    }
}

$maxMixerControls=0;
$maxAudioControls=0;
foreach $class (@classes) {
    $maxMixerControls=$mixerControls{$class} if($mixerControls{$class}>$maxMixerControls);
    $maxAudioControls=$audioControls{$class} if($audioControls{$class}>$maxAudioControls);
}
$maxMixerControls+=$mixerControls{HW};

print "\#define SAM_MIXER_CONTROLS $maxMixerControls\n";
print "\#define SAM_AUDIO_CONTROLS $maxAudioControls\n";
print "
typedef struct SamCtrlNameAssoc {
  char *name;
  unsigned char id;
  char doesReset;
  char restrictPlayMode, restrictRecordMode;
  unsigned short addrLimit;
  unsigned short addr;
} SamCtrlNameAssoc;

typedef struct SamApiAssoc {
  char *name;
  unsigned char apiClass;
  SamCtrlNameAssoc *mixer;
  SamCtrlNameAssoc *audio;
} SamApiAssoc;
";

print "\nstatic SamCtrlNameAssoc samMixerAssocHW[]={\n";
foreach $name (split($;, $mixer{HW})) {
    if($name) {
	print "  { \"$name\", $mixer_value{HW,$name}, $doesReset{HW,$name}, 0, 0,";
	print " $mixerAddrLimit{HW,$name}, $mixerAddr{HW,$name} },\n";
    }
}
print "  { NULL }\n";
print "};\n";

foreach $class (@classes) {
    print "\nstatic SamCtrlNameAssoc samMixerAssoc_${class}[]={\n";
    foreach $name (split($;, $mixer{$class})) {
	if($name) {
	    print "  { \"$name\", $mixer_value{$class,$name}, $doesReset{$class,$name}, 0, 0,";
	    print " $mixerAddrLimit{$class,$name}, $mixerAddr{$class,$name} },\n";
	}
    }
    print "  { NULL }\n";
    print "};\n";
    print "\nstatic SamCtrlNameAssoc samAudioAssoc_${class}[]={\n";
    foreach $name (split($;, $audio{$class})) {
	if($name) {
	    print "  { \"$name\", $audio_value{$class,$name}, 0,";
	    print " $restrictPlayMode{$class,$name}, $restrictRecordMode{$class,$name},";
	    print " $audioAddrLimit{$class,$name}, $audioAddr{$class,$name} },\n";
	}
    }
    print "  { NULL }\n";
    print "};\n";
}

print "\nstatic SamApiAssoc samApiAssocs[]={\n";
foreach $class (@classes) {
    print "  { \"$class\", SAM_API_CLASS_$class, samMixerAssoc_$class, samAudioAssoc_$class },\n";
}
print "  { NULL }\n";
print "};\n";
