/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "init.h"

#ifndef MAP_FAILED
#define MAP_FAILED ((void *)-1)
#endif

char *prgName;
char cardId[32];
int mixerFd=-1;

Options options;

void complain(int priority, char *format, ...)
{
  va_list ap;
  char *errMsg, *newFormat, *src, *dst;
  int size, errMsgSize;

  if(options.syslog) {
    va_start(ap, format);
    vsyslog(priority, format, ap);
    va_end(ap);
  }
  if(!options.syslog || options.verbose) {
    /* replace occurrences of %m with the error message
     * string of errno.
     */
    errMsg=strerror(errno);
    errMsgSize=strlen(errMsg);
    size=0;
    for(src=format; *src; src++) {
      if(*src=='%' && src[1]) {
	if(*++src=='m')
	  size+=errMsgSize;
	else
	  size+=2;
      } else
	size++;
    }
    size++;
    if(!(newFormat=alloca(size))) {
      fprintf(stderr, "%s: %s.\n", prgName, _("virtual memory exhausted"));
      exit(1);
    }
    dst=newFormat;
    for(src=format; *src; src++) {
      if(*src=='%' && src[1]) {
	if(*++src=='m') {
	  memcpy(dst, errMsg, errMsgSize);
	  dst+=errMsgSize;
	} else {
	  *dst++='%';
	  *dst++=*src;
	}
      } else
	*dst++=*src;
    }
    *dst=0;
    fprintf(stderr, "%s[%s]: ", prgName, cardId);
    va_start(ap, format);
    vfprintf(stderr, newFormat, ap);
    va_end(ap);
    fprintf(stderr, "\n");
  }
}

void *xmalloc(int size)
{
  void *result=malloc(size);
  if(!result) {
    fprintf(stderr, "%s: %s.\n", prgName, _("virtual memory exhausted"));
    exit(1);
  }
  return result;
}

void *xrealloc(void *ptr, int size)
{
  void *result=realloc(ptr, size);
  if(!result) {
    fprintf(stderr, "%s: %s.\n", prgName, _("virtual memory exhausted"));
    exit(1);
  }
  return result;
}

char *xstrdup(char *str)
{
  char *result=strdup(str);
  if(!result) {
    fprintf(stderr, "%s: %s.\n", prgName, _("virtual memory exhausted"));
    exit(1);
  }
  return result;
}

static int openMixer(int cardNr)
{
  static char devName[256];

  if(mixerFd>=0) {
    close(mixerFd);
    mixerFd=-1;
  }

  if(options.device) {
    if((mixerFd=open(options.device, O_RDWR))>=0)
      return 1;
  } else {
    sprintf(devName, "/dev/sam9407/card%d/mixer", cardNr);
    options.device=devName;
    if((mixerFd=open(options.device, O_RDWR))>=0)
      return 1;
    sprintf(devName, "/dev/sam%d_mixer", cardNr);
    options.device=devName;
    if((mixerFd=open(options.device, O_RDWR))>=0)
      return 1;
    if(cardNr==0) {
      options.device="/dev/mixer";
      if((mixerFd=open(options.device, O_RDWR))>=0)
	return 1;
    }
  }

  return 0;
}

static int setHardwareHints(void)
{
  SamHardwareHints hints;
  int changed;
  unsigned cardMem;

  if(ioctl(mixerFd, SAM_IOC_HW_HINTS_GET, &hints)<0) {
    complain(LOG_ERR, "%s: %m", _("can't query hardware hints"));
    return 0;
  }

  changed=0;

  if(options.cardMem && *options.cardMem) {
    cardMem=strtol(options.cardMem, NULL, 0);
    switch(options.cardMem[strlen(options.cardMem)-1]) {
    case 'k':
    case 'K':
      cardMem<<=10;
    case 'M':
      cardMem<<=20;
      break;
    }
    cardMem>>=1;
    if(cardMem!=hints.cardMem) {
      hints.cardMem=cardMem;
      changed=1;
    }
  }

  if(!changed)
    return 1;

  if(ioctl(mixerFd, SAM_IOC_HW_HINTS_SET, &hints)<0) {
    complain(LOG_ERR, "%s: %m", _("can't set hardware hints"));
    return 0;
  }

  return 1;
}

static int loadFirmware(void)
{
  int success, fd;
  struct stat st;
  SamFirmware firmware;

  memset(&firmware, 0, sizeof(firmware));
  if(options.verbose)
    fprintf(stderr, "%s[%s]: %s: %s\n", prgName, cardId, _("initializing firmware from"), options.firmware);
  if((fd=open(options.firmware, O_RDONLY))<0) {
    complain(LOG_ERR, "%s: %s: %m", _("can't open firmware"), options.firmware);
    return 0;
  }
  if(fstat(fd, &st)<0) {
    complain(LOG_ERR, "%s: %s: %m", _("can't stat firmware"), options.firmware);
    close(fd);
    return 0;
  }
  if((firmware.data=(unsigned short *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    complain(LOG_ERR, "%s: %s: %m", _("can't mmap firmware"), options.firmware);
    close(fd);
    return 0;
  }
  success=1;
  firmware.size=st.st_size>>1;
  if(ioctl(mixerFd, SAM_IOC_FIRMWARE_LOAD, &firmware)<0) {
    complain(LOG_ERR, "%s: %s: %m", _("can't load firmware"), options.firmware);
    success=0;
  }
  munmap((void *)firmware.data, st.st_size);
  close(fd);
  return success;
}

static int loadSoundBanks(void)
{
  int success, fd, bank, i;
  struct stat st;
  SamSoundBank soundBank;
  SamSoundBankInfo infos[SAM_NROF_SBANKS];
  char sbankName[SAM_SBANK_NAME_LEN+1], *cp;

  if(ioctl(mixerFd, SAM_IOC_BANK_INFO, infos)<0) {
    complain(LOG_ERR, "%s: %m", _("can't retrieve soundbank information"));
    return 0;
  }

  for(bank=0; bank<SAM_NROF_SBANKS; bank++) {
    if(!options.soundbanks[bank])
      continue;

    if((cp=strrchr(options.soundbanks[bank], '/')))
      cp++;
    else
      cp=options.soundbanks[bank];
    for(i=0; i<SAM_SBANK_NAME_LEN && *cp && *cp!='.'; i++, cp++)
      sbankName[i]=toupper(*cp);
    sbankName[i]=0;
    if(strcmp(sbankName, infos[bank].name)==0) {
      if(options.verbose)
	fprintf(stderr, "%s[%s]: %s %s %s #%d\n", prgName, cardId, _("soundbank"), sbankName, _("already loaded at"), bank);
      continue;
    }

    if(*options.soundbanks[bank]) {
      if(options.verbose)
	fprintf(stderr, "%s[%s]: %s #%d: %s\n", prgName, cardId, _("loading soundbank"), bank, options.soundbanks[bank]);

      if((fd=open(options.soundbanks[bank], O_RDONLY))<0) {
	complain(LOG_ERR, "%s: %s: %m", _("can't open soundbank"), options.soundbanks[bank]);
	return 0;
      }
      if(fstat(fd, &st)<0) {
	complain(LOG_ERR, "%s: %s: %m", _("can't stat soundbank"), options.soundbanks[bank]);
	close(fd);
	return 0;
      }
      if((soundBank.data=(char *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
	complain(LOG_ERR, "%s: %s: %m", _("can't mmap soundbank"), options.soundbanks[bank]);
	close(fd);
	return 0;
      }
      success=1;
      soundBank.id=bank;
      soundBank.size=st.st_size;
      if(ioctl(mixerFd, SAM_IOC_BANK_LOAD, &soundBank)<0) {
	complain(LOG_ERR, "%s: %s: %m", _("can't load soundbank"), options.soundbanks[bank]);
	success=0;
      }
      munmap(soundBank.data, st.st_size);
      close(fd);
      if(!success)
	return 0;
    } else {
      if(options.verbose)
	fprintf(stderr, "%s[%s]: %s #%d\n", prgName, cardId, _("unloading soundbank"), bank);
      if(ioctl(mixerFd, SAM_IOC_BANK_UNLOAD, &bank)<0) {
	complain(LOG_ERR, "%s #%d: %m", _("can't unload soundbank"), bank);
	return 0;
      }
    }
  }
  return 1;
}

static void usage(void)
{
  fprintf(stderr,"%s: %s %s\n", _("usage"), prgName, _("[-s] [-v] [-n cardNr] [-i] [-d <mixer_device>] [-f <firmware>] [-b <id>:<soundbank>]"));
  exit(1);
}

int main(int argc, char **argv)
{
  FILE *configFile;
  int optionSyslog, optionVerbose;
  int cardNr, expectedCardNr, cardsHandledOk;
  int success, c, bank;
  char *cp;
  SamApiInfo apiInfo;
  SamDriverInfo driverInfo;

  prgName=argv[0];

#ifdef SAM_ENABLE_NLS
  setlocale(LC_ALL, "");
  bindtextdomain("sam9407", "/usr/share/locale");
  textdomain("sam9407");
#endif

  initAtoms();

  configFile=fopen(SAM_CONFIG_FILE, "r");

  optionSyslog=0;
  optionVerbose=0;
  cardsHandledOk=0;
  for(expectedCardNr=cardNr=0;;cardNr++) {
    sprintf(cardId, "#%d", cardNr);
    memset(&options, 0, sizeof(options));
    options.syslog=optionSyslog;
    options.verbose=optionVerbose;

    if(configFile)
      /* parse config file and get string options */
      if(!parseConfigFile(configFile, cardNr, SAM_API_CLASS_NONE, 0))
	continue;

    while(cardNr==expectedCardNr && (c=getopt(argc, argv, "b:d:f:in:sv"))!=EOF) {
      switch(c) {
      case 'b':
	cp=NULL; /* make compiler happy */
	if((bank=strtol(optarg, NULL, 0))<0 || bank>=SAM_NROF_SBANKS ||
	   !(cp=strchr(optarg, ':')))
	  complain(LOG_ERR, "%s: %s", _("invalid soundbank parameter"), optarg);
	else
	  options.soundbanks[bank]=cp+1;
	break;
      case 'd':
	options.device=optarg;
	break;
      case 'f':
	options.firmware=optarg;
	break;
      case 'i':
	options.initialize=1;
	break;
      case 'n':
	expectedCardNr=strtol(optarg, NULL, 0);
	break;
      case 's':
	if(!optionSyslog) {
	  options.syslog=optionSyslog=1;
	  openlog("sam9407", 0, LOG_USER);
	}
	break;
      case 'v':
	options.verbose=optionVerbose=1;
	break;
      default:
	usage();
      }
    }

    if(!openMixer(cardNr))
      break;

    success=1;

    if(ioctl(mixerFd, SAM_IOC_API_INFO, &apiInfo)<0) {
      complain(LOG_ERR, "%s: %m", _("can't query SAM9407 API information"));
      continue;
    }

    if(apiInfo.version!=SAM_MIXER_API_VERSION) {
      complain(LOG_ERR, "%s", _("incompatible API versions, please recompile"));
      break;
    }

    if(ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
      complain(LOG_ERR, "%s: %m", _("can't query SAM9407 driver"));
      continue;
    }
    sprintf(cardId, "#%d:%s", cardNr, driverInfo.hardware);

    if(options.verbose) {
      if(*driverInfo.firmware)
	fprintf(stderr, "%s[%s]: %s: %s\n", prgName, cardId, _("currently using firmware"), driverInfo.firmware);
      else
	fprintf(stderr, "%s[%s]: %s\n", prgName, cardId, _("no firmware loaded so far"));
    }
    
    /* set hardware hints */
    if(!setHardwareHints())
      success=0;

    if(options.initialize || !*driverInfo.firmware) {
      if(!options.firmware) {
	complain(LOG_ERR, "%s", _("no firmware file specified"));
	continue;
      }
      
      if(!loadFirmware())
	continue;

      if(ioctl(mixerFd, SAM_IOC_API_INFO, &apiInfo)<0) {
	complain(LOG_ERR, "%s: %m", _("can't query SAM9407 API information"));
	continue;
      }

      if(ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
	complain(LOG_ERR, "%s: %m", _("can't query SAM9407 driver"));
	continue;
      }
    }

    if(configFile)
      /* parse config file to adjust mixer controls */
      if(!parseConfigFile(configFile, cardNr, apiInfo.apiClass, driverInfo.playChannelsTotal))
	continue;

    if(driverInfo.haveMidi &&
       !loadSoundBanks())
      success=0;

    if(success)
      cardsHandledOk++;
  }

  if(mixerFd>=0) {
    close(mixerFd);
    mixerFd=-1;
  }

  if(configFile)
    fclose(configFile);

  if(options.verbose) {
    fprintf(stderr, "%s: %d %s", prgName, cardNr, _("cards handled"));
    if(cardNr!=cardsHandledOk)
      fprintf(stderr, ", %d %s", cardNr-cardsHandledOk, _("with errors"));
    fprintf(stderr, "\n");
  }

  return cardNr==cardsHandledOk ? 0 : 1;
}
