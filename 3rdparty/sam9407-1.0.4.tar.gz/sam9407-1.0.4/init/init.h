#ifndef _INIT_H
#define _INIT_H

#include <stdio.h>
#include <sam9407.h>

#include "config.h"

#ifdef SAM_ENABLE_NLS
#include <libintl.h>
#define _(str) gettext(str)
#else
#define _(str) str
#endif

#define NumberOf(vec) (sizeof(vec)/sizeof(*(vec)))

typedef struct {
  int syslog, verbose, initialize;
  char *device, *cardMem, *firmware, *soundbanks[SAM_NROF_SBANKS];
} Options;

extern char *prgName;
extern char cardId[];
extern int mixerFd;

extern Options options;

void complain(int perr, char *format, ...);
void *xmalloc(int size);
void *xrealloc(void *ptr, int size);
char *xstrdup(char *str);

void initAtoms(void);
int parseConfigFile(FILE *configFile, int expectedCard, SamApiClass expectedClass, int playbackChannels);

#endif /* _INIT_H */
