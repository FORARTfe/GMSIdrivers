/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#include <sam9407.h>

#include "ctrlnames.h"
#include "init.h"

#define NR_OF_ATOMS		256
#define HASH_BUCKETS		211

typedef struct HashEntry {
  int atom;
  struct HashEntry *next;
} HashEntry;

typedef struct {
  SamCtrlNameAssoc *mixerHW;
  SamCtrlNameAssoc *mixer[NumberOf(samApiAssocs)];
  SamCtrlNameAssoc *audio[NumberOf(samApiAssocs)];
  char *name;
} AtomData;

typedef struct {
  int alloc, n;
  AtomData *data;
  HashEntry *bucket[HASH_BUCKETS];
} Atoms;

static Atoms atoms;

static int apiAtoms[NumberOf(samApiAssocs)];

/* command line options that can be specified in config
 * file as well
 */
static struct {
  char *name;
  char **destP;
  int atom;
} stringOptions[]={
  { "device",		&options.device },
  { "mem",		&options.cardMem },
  { "firmware", 	&options.firmware },
  { "soundbank",	&options.soundbanks[0] },
  { "soundbank0",	&options.soundbanks[0] },
  { "soundbank1",	&options.soundbanks[1] },
  { "soundbank2",	&options.soundbanks[2] },
  { "soundbank3",	&options.soundbanks[3] },
  { "soundbank4",	&options.soundbanks[4] },
  { "soundbank5",	&options.soundbanks[5] },
  { "soundbank6",	&options.soundbanks[6] },
  { "soundbank7",	&options.soundbanks[7] },
};

static int hash(char *str)
{
  char *p;
  unsigned h=0,g;
  for(p=str;*p;p++){
    h=(h<<4)+*p;
    if((g=h&0xf0000000)!=0){
      h^=g>>24;
      h^=g;
    }
  }
  return h%HASH_BUCKETS;
}

static int intern(char *name, int create)
{
  HashEntry *entry;
  int h=hash(name), alloc;
  for(entry=atoms.bucket[h]; entry; entry=entry->next) {
    if(strcmp(atoms.data[entry->atom].name, name)==0)
      return entry->atom;
  }
  if(!create)
    return -1;
  entry=(HashEntry *)xmalloc(sizeof(HashEntry));
  entry->atom=atoms.n++;
  entry->next=atoms.bucket[h];
  atoms.bucket[h]=entry;
  if(entry->atom>=atoms.alloc) {
    alloc=entry->atom*3/2;
    if(alloc<NR_OF_ATOMS)
      alloc=NR_OF_ATOMS;
    if(atoms.data)
      atoms.data=(AtomData *)xrealloc(atoms.data, alloc*sizeof(AtomData));
    else
      atoms.data=(AtomData *)xmalloc(alloc*sizeof(AtomData));
    memset(atoms.data+atoms.alloc, 0, (alloc-atoms.alloc)*sizeof(AtomData));
    atoms.alloc=alloc;
  }
  atoms.data[entry->atom].name=xstrdup(name);
  return entry->atom;
}

AtomData *externAtom(int atom)
{
  return atoms.data+atom;
}

void initAtoms(void)
{
  int i, j, atom;
  SamCtrlNameAssoc *mixer, *audio;

  for(j=0; samMixerAssocHW[j].name; j++) {
    atom=intern(samMixerAssocHW[j].name, 1);
    externAtom(atom)->mixerHW=samMixerAssocHW+j;
  }
  for(i=0; samApiAssocs[i].name; i++) {
    apiAtoms[i]=intern(samApiAssocs[i].name, 1);
    mixer=samApiAssocs[i].mixer;
    for(j=0; mixer[j].name; j++) {
      atom=intern(mixer[j].name, 1);
      externAtom(atom)->mixer[i]=mixer+j;
    }
    audio=samApiAssocs[i].audio;
    for(j=0; audio[j].name; j++) {
      atom=intern(audio[j].name, 1);
      externAtom(atom)->audio[i]=audio+j;
    }
  }

  for(i=0; i<NumberOf(stringOptions); i++)
    stringOptions[i].atom=intern(stringOptions[i].name, 1);
}

int sendMixerControls(int classIdx, int doesReset, SamControl *mixerControls, int nMixerControls)
{
  SamCtrlNameAssoc *mixerAssocList[2], *mixerAssoc;
  SamControl oldControls[SAM_MIXER_CONTROLS+1];
  int success, n, i, addr;

  if(doesReset) {
    /* check if the value really changed */
    memcpy(oldControls, mixerControls, (nMixerControls+1)*sizeof(SamControl));
    if(ioctl(mixerFd, SAM_IOC_MIXER_GET, oldControls)<0) {
      complain(LOG_ERR, "%s: %m", _("can't retrieve mixer values"));
      return 0;
    }
    for(i=0; i<nMixerControls; i++)
      if(mixerControls[i].value!=oldControls[i].value)
	break;
    if(i>=nMixerControls)
      /* none changed */
      return 1;

    /* backup non-reset controls */
    memset(oldControls, 0, sizeof(oldControls));
    n=0;
    mixerAssocList[0]=samMixerAssocHW;
    mixerAssocList[1]=samApiAssocs[classIdx].mixer;
    for(i=0; i<NumberOf(mixerAssocList); i++) {
      for(mixerAssoc=mixerAssocList[i]; mixerAssoc->name; mixerAssoc++) {
	if(!mixerAssoc->doesReset) {
	  for(addr=0; addr<=mixerAssoc->addrLimit; addr++) {
	    oldControls[n].id=mixerAssoc->id;
	    oldControls[n].addr=addr;
	    n++;
	  }
	}
      }
    }
    oldControls[n].id=SAM_MIXER_ID_SENTINEL;

    if(ioctl(mixerFd, SAM_IOC_MIXER_GET, oldControls)<0) {
      complain(LOG_ERR, "%s: %m", _("can't retrieve mixer values"));
      return 0;
    }
  }

  success=1;
  if(ioctl(mixerFd, SAM_IOC_MIXER_SET, mixerControls)<0) {
    complain(LOG_ERR, "%s: %m", _("can't set mixer values"));
    success=0;
  }

  /* restore non-reset controls */
  if(doesReset && ioctl(mixerFd, SAM_IOC_MIXER_SET, oldControls)<0) {
    complain(LOG_ERR, "%s: %m", _("can't set mixer values"));
    success=0;
  }

  return success;
}

int sendAudioControls(int channel, SamControl *audioControls, int nAudioControls)
{
  SamRedirectedAudioControl redir;

  redir.channel=channel;
  redir.controls=audioControls;

  if(ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_SET, &redir)<0) {
    complain(LOG_ERR, "%s: %m", _("can't set audio values"));
    return 0;
  }

  return 1;
}

int parseConfigFile(FILE *configFile, int expectedCard, SamApiClass expectedClass, int playbackChannels)
{
  int success;
  char buf[256], *cp, *name, *value;
  int atomCard, atomClass, atomMixer, atomAudioPlay, atomAudioRecord, atom, addr;
  AtomData *atomData;
  int currentCard, currentClassIdx, expectedClassIdx, i;
  int currentChannel;
  int pass, nControls;
  SamControl controls[SAM_MIXER_CONTROLS+1], *controlP;
  SamCtrlNameAssoc *mixerAssoc;

  atomCard=intern("card", 1);
  atomClass=intern("class", 1);
  atomMixer=intern("mixer", 1);
  atomAudioPlay=intern("audio_play", 1);
  atomAudioRecord=intern("audio_record", 1);

  expectedClassIdx=-1;
  for(i=0; samApiAssocs[i].name; i++) {
    if(samApiAssocs[i].apiClass==expectedClass) {
      expectedClassIdx=i;
      break;
    }
  }

  /* send reset controls in first pass
   * non-reset controls in second
   */
  for(pass=0; pass<2; pass++) {
    currentCard=0;
    currentClassIdx=0;
    currentChannel=-1;
    nControls=0;

    rewind(configFile);

    while(fgets(buf, sizeof(buf), configFile)) {
      cp=buf;
      while(isspace(*cp)) cp++;
      if(!*cp || *cp=='#')
	continue;
      name=cp;
      while(*cp && !isspace(*cp)) cp++;
      if(*cp)
	*cp++=0;
      if((atom=intern(name, 0))<0)
	continue;
      /* skip spaces at the beginning of addr/value */
      while(isspace(*cp)) cp++;
      /* check for an optional address */
      addr=0;
      if(*cp=='[') {
	cp++;
	while(isspace(*cp)) cp++;
	while(*cp>='0' && *cp<='9')
	  addr=addr*10+*cp++-'0';
	while(isspace(*cp)) cp++;
	if(*cp!=']') /* syntax error */
	  continue;
	cp++;
      }
      /* skip spaces at the beginning of value */
      while(isspace(*cp)) cp++;
      value=cp;
      /* find the end of value */
      while(*cp && !isspace(*cp)) cp++;
      *cp=0;
    
      if(atom==atomCard || atom==atomMixer || atom==atomAudioPlay || atom==atomAudioRecord) {
	/* switch to a new channel
	 * we need to flush pending mixer control
	 * values
	 */
	if(nControls>0) {
	  controls[nControls].id=SAM_MIXER_ID_SENTINEL;
	  if(currentChannel>=0)
	    success=sendAudioControls(currentChannel, controls, nControls);
	  else
	    success=sendMixerControls(expectedClassIdx, pass==0, controls, nControls);
	  if(!success)
	    return 0;
	  nControls=0;
	}
      }

      if(atom==atomCard) {
	currentCard=strtol(value, NULL, 0);
	currentClassIdx=0;
	currentChannel=-1;
	continue;
      }

      if(atom==atomClass) {
	for(cp=value; *cp; cp++)
	  *cp=toupper(*cp);
	currentClassIdx=-1;
	if((atom=intern(value, 0))>=0) {
	  for(i=0; i<NumberOf(apiAtoms); i++) {
	    if(atom==apiAtoms[i]) {
	      currentClassIdx=i;
	      break;
	    }
	  }
	}
	continue;
      }

      if(atom==atomMixer) {
	currentChannel=-1;
	continue;
      }

      if(atom==atomAudioPlay) {
	currentChannel=strtol(value, NULL, 0);
	continue;
      }

      if(atom==atomAudioRecord) {
	currentChannel=playbackChannels+strtol(value, NULL, 0);
	continue;
      }

      if(currentCard!=expectedCard)
	continue;

      atomData=externAtom(atom);

      if(isupper(*name)) {
	if(currentClassIdx>=0 && currentClassIdx==expectedClassIdx) {
	  if(nControls>=SAM_MIXER_CONTROLS) {
	    /* mixerControls buffer full, we need to flush it */
	    controls[nControls].id=SAM_MIXER_ID_SENTINEL;
	    if(currentChannel>=0)
	      success=sendAudioControls(currentChannel, controls, nControls);
	    else
	      success=sendMixerControls(expectedClassIdx, pass==0, controls, nControls);
	    if(!success)
	      return 0;
	    nControls=0;
	  }
	  if(currentChannel>=0 && atomData->audio[expectedClassIdx] &&
	     pass==1) {
	    controlP=controls+nControls;
	    controlP->id=atomData->audio[expectedClassIdx]->id;
	    controlP->addr=addr;
	    controlP->value=strtol(value, NULL, 0);
	    nControls++;
	  }
	  if(currentChannel<0) {
	    mixerAssoc=atomData->mixer[expectedClassIdx];
	    if(!mixerAssoc)
	      mixerAssoc=atomData->mixerHW;
	    if(mixerAssoc && pass==!mixerAssoc->doesReset) {
	      /* mixer adjustment */
	      controlP=controls+nControls;
	      controlP->id=mixerAssoc->id;
	      controlP->addr=addr;
	      controlP->value=strtol(value, NULL, 0);
	      nControls++;
	    }
	  }
	}
      } else {
	/* search for string option */
	for(i=0; i<NumberOf(stringOptions); i++)
	  if(stringOptions[i].atom==atom)
	    *stringOptions[i].destP=xstrdup(value);
      }
    }

    if(nControls>0) {
      controls[nControls].id=SAM_MIXER_ID_SENTINEL;
      if(currentChannel>=0)
	success=sendAudioControls(currentChannel, controls, nControls);
      else
	success=sendMixerControls(expectedClassIdx, pass==0, controls, nControls);
      if(!success)
	return 0;
    }
  }
  return 1;
}
