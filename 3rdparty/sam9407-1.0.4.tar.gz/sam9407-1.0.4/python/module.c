/*
  Copyright (C) 1999, 2000 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include <Python.h>

#include <sys/soundcard.h>
#include <sam9407.h>

#include "ctrlnames.h"

#ifndef MAP_FAILED
#define MAP_FAILED		((void *)-1)
#endif

#ifndef Py_TPFLAGS_DEFAULT
#define Py_TPFLAGS_DEFAULT	0
#endif

#define NumberOf(vec)		(sizeof(vec)/sizeof(*(vec)))

typedef enum {
  AudioModePlay,
  AudioModeRecord
} AudioMode;

typedef struct {
  PyObject_HEAD
  SamCtrlNameAssoc *ref;
} CtrlRefObject;

typedef struct {
  PyObject_HEAD
  char *name;
  SamApiClass apiClass;
  PyObject *mixerHWById, *mixerHWByName;
  PyObject *mixerFWById, *mixerFWByName;
  PyObject *audioById, *audioByName;
} ApiInfoObject;

typedef struct {
  PyObject_HEAD
  char *devName;
  int fd;
  ApiInfoObject *apiInfo;
} MixerObject;

typedef struct {
  PyObject_HEAD
  AudioMode mode;
  char *devName;
  int fd, nonBlocking;
  ApiInfoObject *apiInfo;
} AudioObject;

static ApiInfoObject *buildApiInfo(SamApiClass apiClass);
static void ctrlRefRelease(PyObject *self);
static void apiInfoRelease(PyObject *self);

static PyObject *mixerOpen(PyObject *self, PyObject *args);
static void mixerRelease(PyObject *self);
static int mixerPrint(PyObject *self, FILE *fp, int flags);
static PyObject *mixerGetAttr(PyObject *self, char *name);
static PyObject *mixer_fileno(PyObject *self, PyObject *args);
static PyObject *mixer_devname(PyObject *self, PyObject *args);
static PyObject *mixer_events(PyObject *self, PyObject *args);
static PyObject *mixer_api_info(PyObject *self, PyObject *args);
static PyObject *mixer_sync_join(PyObject *self, PyObject *args);
static PyObject *mixer_sync_leave(PyObject *self, PyObject *args);
static PyObject *mixer_sync_info(PyObject *self, PyObject *args);
static PyObject *mixer_driver_info(PyObject *self, PyObject *args);
static PyObject *mixer_hw_hints_get(PyObject *self, PyObject *args);
static PyObject *mixer_hw_hints_set(PyObject *self, PyObject *args, PyObject *keywds);
static PyObject *mixer_firmware_load(PyObject *self, PyObject *args);
static PyObject *mixer_known(PyObject *self, PyObject *args);
static PyObject *mixer_get(PyObject *self, PyObject *args);
static PyObject *mixer_set(PyObject *self, PyObject *args);
static PyObject *mixer_get_info(PyObject *self, PyObject *args);
static PyObject *mixer_audio_known(PyObject *self, PyObject *args);
static PyObject *mixer_audio_get(PyObject *self, PyObject *args);
static PyObject *mixer_audio_set(PyObject *self, PyObject *args);
static PyObject *mixer_audio_info(PyObject *self, PyObject *args);
static PyObject *mixer_channel_owner_info(PyObject *self, PyObject *args);
static PyObject *mixer_bank_load(PyObject *self, PyObject *args);
static PyObject *mixer_bank_unload(PyObject *self, PyObject *args);
static PyObject *mixer_bank_prio_chg(PyObject *self, PyObject *args);
static PyObject *mixer_bank_info(PyObject *self, PyObject *args);
static PyObject *mixer_peak_meter_info(PyObject *self, PyObject *args);

static PyObject *audioOpen(AudioMode mode, PyObject *args);
static void audioRelease(PyObject *self);
static int audioPrint(PyObject *self, FILE *fp, int flags);
static PyObject *playOpen(PyObject *self, PyObject *args);
static PyObject *recordOpen(PyObject *self, PyObject *args);
static PyObject *audioGetAttr(PyObject *self, char *name);
static PyObject *audio_fileno(PyObject *self, PyObject *args);
static PyObject *audio_devname(PyObject *self, PyObject *args);
static PyObject *audio_read(PyObject *self, PyObject *args);
static PyObject *audio_write(PyObject *self, PyObject *args);
static PyObject *audio_sync_join(PyObject *self, PyObject *args);
static PyObject *audio_sync_leave(PyObject *self, PyObject *args);
static PyObject *audio_sync_info(PyObject *self, PyObject *args);
static PyObject *audio_channel_info(PyObject *self, PyObject *args);
static PyObject *audio_channel_redirect(PyObject *self, PyObject *args);
static PyObject *audio_known(PyObject *self, PyObject *args);
static PyObject *audio_get(PyObject *self, PyObject *args);
static PyObject *audio_set(PyObject *self, PyObject *args);
static PyObject *audio_info(PyObject *self, PyObject *args);
/* OSS ioctls */
static PyObject *audio_reset(PyObject *self, PyObject *args);
static PyObject *audio_post(PyObject *self, PyObject *args);
static PyObject *audio_speed(PyObject *self, PyObject *args);
static PyObject *audio_channels(PyObject *self, PyObject *args);
static PyObject *audio_setfragment(PyObject *self, PyObject *args);
static PyObject *audio_setfmt(PyObject *self, PyObject *args);
static PyObject *audio_getspace(PyObject *self, PyObject *args);
static PyObject *audio_getptr(PyObject *self, PyObject *args);

static PyTypeObject ctrlRefType={
  PyObject_HEAD_INIT(NULL)
  0,						/* ob_size */
  "ctrl_ref",					/* tp_name */
  sizeof(CtrlRefObject),			/* tp_basicsize */
  0,						/* tp_itemsize */
  /* methods */
  ctrlRefRelease,				/* tp_dealloc */
  0,						/* tp_print */
  0,						/* tp_getattr */
  0,						/* tp_setattr */
  0,						/* tp_compare */
  0,						/* tp_repr */
  0,						/* tp_as_number */
  0,						/* tp_as_sequence */
  0,						/* tp_as_mapping */
  0,						/* tp_hash */
  0,						/* tp_call */
  0,						/* tp_str */
  0,						/* tp_getattro */
  0,						/* tp_setattro */
  0,						/* tp_as_buffer */
  Py_TPFLAGS_DEFAULT,				/* tp_flags */
  0,						/* tp_doc */
};

static PyTypeObject apiInfoType={
  PyObject_HEAD_INIT(NULL)
  0,						/* ob_size */
  "api_info",					/* tp_name */
  sizeof(ApiInfoObject),			/* tp_basicsize */
  0,						/* tp_itemsize */
  /* methods */
  apiInfoRelease,				/* tp_dealloc */
  0,						/* tp_print */
  0,						/* tp_getattr */
  0,						/* tp_setattr */
  0,						/* tp_compare */
  0,						/* tp_repr */
  0,						/* tp_as_number */
  0,						/* tp_as_sequence */
  0,						/* tp_as_mapping */
  0,						/* tp_hash */
  0,						/* tp_call */
  0,						/* tp_str */
  0,						/* tp_getattro */
  0,						/* tp_setattro */
  0,						/* tp_as_buffer */
  Py_TPFLAGS_DEFAULT,				/* tp_flags */
  0,						/* tp_doc */
};

static PyTypeObject mixerType={
  PyObject_HEAD_INIT(NULL)
  0,						/* ob_size */
  "mixer",					/* tp_name */
  sizeof(MixerObject),				/* tp_basicsize */
  0,						/* tp_itemsize */
  /* methods */
  mixerRelease,					/* tp_dealloc */
  mixerPrint,					/* tp_print */
  mixerGetAttr,					/* tp_getattr */
  0,						/* tp_setattr */
  0,						/* tp_compare */
  0,						/* tp_repr */
  0,						/* tp_as_number */
  0,						/* tp_as_sequence */
  0,						/* tp_as_mapping */
  0,						/* tp_hash */
  0,						/* tp_call */
  0,						/* tp_str */
  0,						/* tp_getattro */
  0,						/* tp_setattro */
  0,						/* tp_as_buffer */
  Py_TPFLAGS_DEFAULT,				/* tp_flags */
  0,						/* tp_doc */
};

static PyTypeObject audioType={
  PyObject_HEAD_INIT(NULL)
  0,						/* ob_size */
  "audio",					/* tp_name */
  sizeof(AudioObject),				/* tp_basicsize */
  0,						/* tp_itemsize */
  /* methods */
  audioRelease,					/* tp_dealloc */
  audioPrint,					/* tp_print */
  audioGetAttr,					/* tp_getattr */
  0,						/* tp_setattr */
  0,						/* tp_compare */
  0,						/* tp_repr */
  0,						/* tp_as_number */
  0,						/* tp_as_sequence */
  0,						/* tp_as_mapping */
  0,						/* tp_hash */
  0,						/* tp_call */
  0,						/* tp_str */
  0,						/* tp_getattro */
  0,						/* tp_setattro */
  0,						/* tp_as_buffer */
  Py_TPFLAGS_DEFAULT,				/* tp_flags */
  0,						/* tp_doc */
};

static PyMethodDef mixerMethods[]={
  { "fileno",		mixer_fileno,				METH_VARARGS },
  { "devname",		mixer_devname,				METH_VARARGS },
  { "events",		mixer_events,				METH_VARARGS },
  { "api_info",		mixer_api_info,				METH_VARARGS },
  { "sync_join",	mixer_sync_join,			METH_VARARGS },
  { "sync_leave",	mixer_sync_leave,			METH_VARARGS },
  { "sync_info",	mixer_sync_info,			METH_VARARGS },
  { "driver_info",	mixer_driver_info,			METH_VARARGS },
  { "hw_hints_get",	mixer_hw_hints_get,			METH_VARARGS },
  { "hw_hints_set",	(PyCFunction)mixer_hw_hints_set,	METH_VARARGS|METH_KEYWORDS },
  { "firmware_load",	mixer_firmware_load,			METH_VARARGS },
  { "mixer_known",	mixer_known,				METH_VARARGS },
  { "mixer_get",	mixer_get,				METH_VARARGS },
  { "mixer_set",	mixer_set,				METH_VARARGS },
  { "mixer_info",	mixer_get_info,				METH_VARARGS },
  { "audio_known",	mixer_audio_known,			METH_VARARGS },
  { "audio_get",	mixer_audio_get,			METH_VARARGS },
  { "audio_set",	mixer_audio_set,			METH_VARARGS },
  { "audio_info",	mixer_audio_info,			METH_VARARGS },
  { "channel_owner_info",	mixer_channel_owner_info,	METH_VARARGS },
  { "bank_load",	mixer_bank_load,			METH_VARARGS },
  { "bank_unload",	mixer_bank_unload,			METH_VARARGS },
  { "bank_prio_chg",	mixer_bank_prio_chg,			METH_VARARGS },
  { "bank_info",	mixer_bank_info,			METH_VARARGS },
  { "peak_meter_info",	mixer_peak_meter_info,			METH_VARARGS },
  { NULL }							/* sentinel */
};

static PyMethodDef audioMethods[]={
  { "fileno",		audio_fileno,				METH_VARARGS },
  { "devname",		audio_devname,				METH_VARARGS },
  { "read",		audio_read,				METH_VARARGS },
  { "write",		audio_write,				METH_VARARGS },
  { "sync_join",	audio_sync_join,			METH_VARARGS },
  { "sync_leave",	audio_sync_leave,			METH_VARARGS },
  { "sync_info",	audio_sync_info,			METH_VARARGS },
  { "channel_info",	audio_channel_info,			METH_VARARGS },
  { "channel_redirect",	audio_channel_redirect,			METH_VARARGS },
  { "audio_known",	audio_known,				METH_VARARGS },
  { "audio_get",	audio_get,				METH_VARARGS },
  { "audio_set",	audio_set,				METH_VARARGS },
  { "audio_info",	audio_info,				METH_VARARGS },
  { "reset",		audio_reset,				METH_VARARGS },
  { "post",		audio_post,				METH_VARARGS },
  { "speed",		audio_speed,				METH_VARARGS },
  { "channels",		audio_channels,				METH_VARARGS },
  { "setfragment",	audio_setfragment,			METH_VARARGS },
  { "setfmt",		audio_setfmt,				METH_VARARGS },
  { "getspace",		audio_getspace,				METH_VARARGS },
  { "getptr",		audio_getptr,				METH_VARARGS },
  { NULL }							/* sentinel */
};

static PyMethodDef methods[]={
  {"mixer",		mixerOpen,				METH_VARARGS},
  {"play",		playOpen,				METH_VARARGS},
  {"record",		recordOpen,				METH_VARARGS},
  { NULL }							/* sentinel */
};

static PyObject *UnsupportedAPIVersionError;
static PyObject *UnsupportedFirmwareError;
static PyObject *InvalidArgumentError;
static PyObject *InvalidModeError;
static PyObject *IOError;
static PyObject *EAGAINError;

static void raiseIOError(char *fileName, char *sysCall, char *arg)
{
  int savedErrno=errno;
  PyObject *v;

  v=Py_BuildValue("(sisss)", fileName, savedErrno, strerror(savedErrno), sysCall, arg);
  if(v) {
    PyErr_SetObject(IOError, v);
    Py_DECREF(v);
  }
}

static int safeListAppend(PyObject *dest, PyObject *item)
{
  int error;

  if(!item)
    return 0;

  error=PyList_Append(dest, item);
  Py_DECREF(item);

  return error>=0;
}

static ApiInfoObject *buildApiInfo(SamApiClass apiClass)
{
  SamApiAssoc *apiAssoc;
  SamCtrlNameAssoc *ctrlNameAssoc;
  ApiInfoObject *apiInfo;
  CtrlRefObject *ctrlRef;
  int nMixerHWControls, nMixerFWControls, nAudioControls;

  for(apiAssoc=samApiAssocs; apiAssoc->name && apiAssoc->apiClass!=apiClass; apiAssoc++);
  if(!apiAssoc) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }
  if(!(apiInfo=PyObject_NEW(ApiInfoObject, &apiInfoType)))
    return NULL;

  nMixerHWControls=0;
  for(ctrlNameAssoc=samMixerAssocHW; ctrlNameAssoc->name; ctrlNameAssoc++)
    if(ctrlNameAssoc->id>=nMixerHWControls)
      nMixerHWControls=ctrlNameAssoc->id+1;
  nMixerFWControls=0;
  for(ctrlNameAssoc=apiAssoc->mixer; ctrlNameAssoc->name; ctrlNameAssoc++)
    if(ctrlNameAssoc->id>=nMixerFWControls)
      nMixerFWControls=ctrlNameAssoc->id+1;
  nAudioControls=0;
  for(ctrlNameAssoc=apiAssoc->audio; ctrlNameAssoc->name; ctrlNameAssoc++)
    if(ctrlNameAssoc->id>=nAudioControls)
      nAudioControls=ctrlNameAssoc->id+1;

  apiInfo->apiClass=apiClass;
  apiInfo->name=apiAssoc->name;
  apiInfo->mixerHWById=apiInfo->mixerHWByName=NULL;
  apiInfo->mixerFWById=apiInfo->mixerFWByName=NULL;
  apiInfo->audioById=apiInfo->audioByName=NULL;
  if(!(apiInfo->mixerHWById=PyList_New(nMixerHWControls)) ||
     !(apiInfo->mixerHWByName=PyDict_New()) ||
     !(apiInfo->mixerFWById=PyList_New(nMixerFWControls)) ||
     !(apiInfo->mixerFWByName=PyDict_New()) ||
     !(apiInfo->audioById=PyList_New(nAudioControls)) ||
     !(apiInfo->audioByName=PyDict_New())) {
    Py_DECREF(apiInfo);
    return NULL;
  }

  for(ctrlNameAssoc=samMixerAssocHW; ctrlNameAssoc->name; ctrlNameAssoc++) {
    if(!(ctrlRef=PyObject_NEW(CtrlRefObject, &ctrlRefType))) {
      Py_DECREF(apiInfo);
      return NULL;
    }
    ctrlRef->ref=ctrlNameAssoc;
    if(PyDict_SetItemString(apiInfo->mixerHWByName, ctrlNameAssoc->name, (PyObject *)ctrlRef)<0 ||
       (Py_INCREF(ctrlRef), PyList_SetItem(apiInfo->mixerHWById, ctrlNameAssoc->id-SAM_MIXER_HW_ID_FIRST, (PyObject *)ctrlRef)<0)) {
      Py_DECREF(ctrlRef);
      Py_DECREF(apiInfo);
      return NULL;
    }
  }

  for(ctrlNameAssoc=apiAssoc->mixer; ctrlNameAssoc->name; ctrlNameAssoc++) {
    if(!(ctrlRef=PyObject_NEW(CtrlRefObject, &ctrlRefType))) {
      Py_DECREF(apiInfo);
      return NULL;
    }
    ctrlRef->ref=ctrlNameAssoc;
    if(PyDict_SetItemString(apiInfo->mixerFWByName, ctrlNameAssoc->name, (PyObject *)ctrlRef)<0 ||
       (Py_INCREF(ctrlRef), PyList_SetItem(apiInfo->mixerFWById, ctrlNameAssoc->id, (PyObject *)ctrlRef)<0)) {
      Py_DECREF(ctrlRef);
      Py_DECREF(apiInfo);
      return NULL;
    }
  }

  for(ctrlNameAssoc=apiAssoc->audio; ctrlNameAssoc->name; ctrlNameAssoc++) {
    if(!(ctrlRef=PyObject_NEW(CtrlRefObject, &ctrlRefType))) {
      Py_DECREF(apiInfo);
      return NULL;
    }
    ctrlRef->ref=ctrlNameAssoc;
    if(PyDict_SetItemString(apiInfo->audioByName, ctrlNameAssoc->name, (PyObject *)ctrlRef)<0 ||
       (Py_INCREF(ctrlRef), PyList_SetItem(apiInfo->audioById, ctrlNameAssoc->id, (PyObject *)ctrlRef)<0)) {
      Py_DECREF(ctrlRef);
      Py_DECREF(apiInfo);
      return NULL;
    }
  }

  return apiInfo;
}

static void ctrlRefRelease(PyObject *self)
{
}

static void apiInfoRelease(PyObject *self)
{
  ApiInfoObject *apiInfo=(ApiInfoObject *)self;

  if(apiInfo->mixerHWById) {
    Py_DECREF(apiInfo->mixerHWById);
  }
  if(apiInfo->mixerHWByName) {
    Py_DECREF(apiInfo->mixerHWByName);
  }
  if(apiInfo->mixerFWById) {
    Py_DECREF(apiInfo->mixerFWById);
  }
  if(apiInfo->mixerFWByName) {
    Py_DECREF(apiInfo->mixerFWByName);
  }
  if(apiInfo->audioById) {
    Py_DECREF(apiInfo->audioById);
  }
  if(apiInfo->audioByName) {
    Py_DECREF(apiInfo->audioByName);
  }
}

static int dumpKnown(PyObject *result, PyObject *ctrlRefById)
{
  CtrlRefObject *ctrlRef;
  int n, i;

  n=PyList_Size(ctrlRefById);
  for(i=0; i<n; i++) {
    if((ctrlRef=(CtrlRefObject *)PyList_GetItem(ctrlRefById, i)) &&
       !safeListAppend(result, PyString_FromString(ctrlRef->ref->name)))
      return 0;
  }

  return 1;
}

static int parseControls(PyObject *ctrlRefByNameFirst, PyObject *ctrlRefByNameSecond,
			 SamControl *dest, PyObject *source)
{
  int n, i, isSeq;
  PyObject *elem, *arg;
  CtrlRefObject *ctrlRef;
  char *name;
  unsigned addr, value;

  n=PySequence_Length(source);
  for(i=0; i<n; i++) {
    if(!(elem=PySequence_GetItem(source, i)))
      return 0;
    isSeq=PySequence_Check(elem) && !PyString_Check(elem);
    if(isSeq && PySequence_Length(elem)<1) {
      Py_DECREF(elem);
      PyErr_SetString(InvalidArgumentError, "control name is missing");
      return 0;
    }
    if(isSeq) {
      if(!(arg=PySequence_GetItem(elem, 0))) {
	Py_DECREF(elem);
	return 0;
      }
    } else {
      Py_INCREF(elem);
      arg=elem;
    }

    if(!PyString_Check(arg)) {
      Py_DECREF(arg);
      Py_DECREF(elem);
      PyErr_SetString(InvalidArgumentError, "control name must be of type string");
      return 0;
    }
    name=PyString_AsString(arg);
    Py_DECREF(arg);
    if(!name) {
      Py_DECREF(elem);
      PyErr_SetString(InvalidArgumentError, "control name is missing");
      return 0;
    }

    if(isSeq && PySequence_Length(elem)>1) {
      if(!(arg=PySequence_GetItem(elem, 1))) {
	Py_DECREF(elem);
	return 0;
      }
      if(!PyInt_Check(arg)) {
	Py_DECREF(arg);
	Py_DECREF(elem);
	PyErr_SetString(InvalidArgumentError, "control address must be of type int");
	return 0;
      }
      addr=PyInt_AsLong(arg);
      Py_DECREF(arg);
    } else
      addr=0;

    if(isSeq && PySequence_Length(elem)>2) {
      if(!(arg=PySequence_GetItem(elem, 2))) {
	Py_DECREF(elem);
	return 0;
      }
      if(!PyInt_Check(arg)) {
	Py_DECREF(arg);
	Py_DECREF(elem);
	PyErr_SetString(InvalidArgumentError, "value must be of type int");
	return 0;
      }
      value=PyInt_AsLong(arg);
      Py_DECREF(arg);
    } else
      value=0;

    ctrlRef=(CtrlRefObject *)PyDict_GetItemString(ctrlRefByNameFirst, name);
    if(!ctrlRef && ctrlRefByNameSecond)
      ctrlRef=(CtrlRefObject *)PyDict_GetItemString(ctrlRefByNameSecond, name);
    if(!ctrlRef) {
      Py_DECREF(elem);
      PyErr_SetString(InvalidArgumentError, "invalid control name");
      return 0;
    }
    dest[i].id=ctrlRef->ref->id;
    dest[i].addr=addr;
    dest[i].value=value;
    Py_DECREF(ctrlRef);
    Py_DECREF(elem);
  }
  dest[n].id=SAM_MIXER_ID_SENTINEL;

  return 1;
}

static int dumpControls(PyObject *ctrlRefByIdFirst,
			PyObject *ctrlRefByIdSecond, int offsetSecond,
			PyObject *dest, SamControl *source, int getFormat)
{
  PyObject *elem;
  CtrlRefObject *ctrlRef;
  int i;

  for(i=0; source[i].id!=SAM_MIXER_ID_SENTINEL; i++) {
    if(ctrlRefByIdSecond && source[i].id>=offsetSecond)
      ctrlRef=(CtrlRefObject *)PyList_GetItem(ctrlRefByIdSecond, source[i].id-offsetSecond);
    else
      ctrlRef=(CtrlRefObject *)PyList_GetItem(ctrlRefByIdFirst, source[i].id);
    if(!ctrlRef)
      return 0;
    if(getFormat)
      elem=Py_BuildValue("(siii)", ctrlRef->ref->name, source[i].addr, source[i].isConfigured, source[i].value);
    else
      elem=Py_BuildValue("(si)", ctrlRef->ref->name, source[i].value);
    if(!elem ||
       PyList_SetItem(dest, i, elem)<0)
      return 0;
  }

  return 1;
}

static PyObject *mixerOpen(PyObject *self, PyObject *args)
{
  MixerObject *mixer;
  PyObject *arg;
  char buf[256], *devName, *cp;
  int cardNr, fd;
  SamApiInfo apiInfo;

  arg=NULL;
  if (!PyArg_ParseTuple(args, "|O", &arg))
    return NULL;

  if(arg) {
    if(PyInt_Check(arg)) {
      if(!PyArg_Parse(arg, "i", &cardNr))
	return NULL;
      sprintf(buf, "/dev/sam9407/card%d/mixer", cardNr);
      devName=buf;
      fd=open(devName, O_RDWR);
      if(fd<0) {
	sprintf(buf, "/dev/sam%d_mixer", cardNr);
	devName=buf;
	fd=open(devName, O_RDWR);
      }
      if(fd<0 && cardNr==0) {
	devName="/dev/mixer";
	fd=open(devName, O_RDWR);
      }
    } else if(PyString_Check(arg)) {
      if(!PyArg_Parse(arg, "s", &devName))
	return NULL;
      fd=open(devName, O_RDWR);
    } else {
      PyErr_SetString(InvalidArgumentError, "argument must be of type integer or string");
      return NULL;
    }
  } else {
    devName="/dev/sam9407/card0/mixer";
    fd=open(devName, O_RDWR);
    if(fd<0) {
      devName="/dev/sam0_mixer";
      fd=open(devName, O_RDWR);
    }
    if(fd<0) {
      devName="/dev/mixer";
      fd=open(devName, O_RDWR);
    }
  }

  if(fd<0) {
    raiseIOError(devName, "open", NULL);
    return NULL;
  }

  if(ioctl(fd, SAM_IOC_API_INFO, &apiInfo)<0) {
    raiseIOError(devName, "ioctl", "SAM_IOC_API_INFO");
    close(fd);
    return NULL;
  }

  if(apiInfo.version!=SAM_MIXER_API_VERSION) {
    PyErr_SetNone(UnsupportedAPIVersionError);
    close(fd);
    return NULL;
  }

  if(!(cp=PyMem_Malloc(strlen(devName)+1))) {
    close(fd);
    return NULL;
  }
  strcpy(cp, devName);
  devName=cp;

  if(!(mixer=PyObject_NEW(MixerObject, &mixerType))) {
    PyMem_Free(devName);
    close(fd);
    return NULL;
  }

  mixer->devName=devName;
  mixer->fd=fd;
  if(apiInfo.apiClass!=SAM_API_CLASS_NONE) {
    if(!(mixer->apiInfo=buildApiInfo(apiInfo.apiClass)))
      PyErr_Clear();
  } else
    mixer->apiInfo=NULL;

  return (PyObject *)mixer;
}

static void mixerRelease(PyObject *self)
{
  MixerObject *mixer=(MixerObject *)self;

  if(mixer->apiInfo) {
    Py_DECREF(mixer->apiInfo);
  }
  PyMem_Free(mixer->devName);
  close(mixer->fd);
}

static int mixerPrint(PyObject *self, FILE *fp, int flags)
{
  MixerObject *mixer=(MixerObject *)self;

  fprintf(fp, "<sam9407.mixer using %s at %p>", mixer->devName, mixer);

  return 0;
}

static PyObject *mixerGetAttr(PyObject *self, char *name)
{
  return Py_FindMethod(mixerMethods, self, name);
}

static PyObject *mixer_fileno(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  return Py_BuildValue("i", mixer->fd);
}

static PyObject *mixer_devname(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  return Py_BuildValue("s", mixer->devName);
}

static PyObject *mixer_events(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  SamEvent eventBuf[256], *events, *event;
  int n, i;
  PyObject *result, *elem;
  CtrlRefObject *ctrlRef;

  events=NULL;
  if (!PyArg_ParseTuple(args, "|s#", &events, &n))
    return NULL;

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  if(!events) {
    if((n=read(mixer->fd, eventBuf, sizeof(eventBuf)))<0) {
      raiseIOError(mixer->devName, "read", NULL);
      return NULL;
    }
    events=eventBuf;
    n/=sizeof(SamEvent);
  } else {
    if(n%sizeof(SamEvent)) {
      PyErr_SetString(InvalidArgumentError, "argument is not a valid sam9407 event buffer");
      return NULL;
    }
    n/=sizeof(SamEvent);
  }

  if(!(result=PyList_New(n)))
    return NULL;

  for(i=0; i<n; i++) {
    event=events+i;

    elem=NULL;
    if(event->type>=0) {
      /* audio event */
      if((ctrlRef=(CtrlRefObject *)PyList_GetItem(mixer->apiInfo->audioById, event->id)))
	elem=Py_BuildValue("(sisi)", "audio", event->type, ctrlRef->ref->name, event->addr);
    } else {
      switch(event->type) {
      case SAM_EVENT_TYPE_MIXER:
	if(event->id>=SAM_MIXER_HW_ID_FIRST)
	  ctrlRef=(CtrlRefObject *)PyList_GetItem(mixer->apiInfo->mixerHWById, event->id-SAM_MIXER_HW_ID_FIRST);
	else
	  ctrlRef=(CtrlRefObject *)PyList_GetItem(mixer->apiInfo->mixerFWById, event->id);
	if(ctrlRef)
	  elem=Py_BuildValue("(ssi)", "mixer", ctrlRef->ref->name, event->addr);
	break;
      case SAM_EVENT_TYPE_NOCTRL:
	switch(event->id) {
	case SAM_EVENT_FIRMWARE_CHANGED:
	  elem=Py_BuildValue("(s)", "firmware");
	  break;
	case SAM_EVENT_SBANK_CHANGED:
	  elem=Py_BuildValue("(s)", "sbank");
	  break;
	case SAM_EVENT_CHANNEL_OWNER_CHANGED:
	  elem=Py_BuildValue("(s)", "channel_owner");
	  break;
	default:
	  elem=Py_BuildValue("(s)", NULL);
	}
	break;
      default:
	elem=Py_BuildValue("(s)", NULL);
      }
    }
    if(!elem ||
       PyList_SetItem(result, i, elem)<0) {
      Py_DECREF(result);
      return NULL;
    }
  }

  return result;
}

static PyObject *mixer_api_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  SamApiInfo apiInfo;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_API_INFO, &apiInfo)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_API_INFO");
    return NULL;
  }

  if(apiInfo.version!=SAM_MIXER_API_VERSION) {
    PyErr_SetNone(UnsupportedAPIVersionError);
    return NULL;
  }

  if((apiInfo.apiClass==SAM_API_CLASS_NONE && mixer->apiInfo ) ||
     (apiInfo.apiClass!=SAM_API_CLASS_NONE &&
      (!mixer->apiInfo || apiInfo.apiClass!=mixer->apiInfo->apiClass))) {
    if(mixer->apiInfo) {
      Py_DECREF(mixer->apiInfo);
      mixer->apiInfo=NULL;
    }
    if(apiInfo.apiClass!=SAM_API_CLASS_NONE &&
       !(mixer->apiInfo=buildApiInfo(apiInfo.apiClass)))
      return NULL;
  }

  return Py_BuildValue("{siss}",
		       "version", SAM_MIXER_API_VERSION,
		       "apiClass", mixer->apiInfo ? mixer->apiInfo->name : "NONE");
}

static PyObject *mixer_sync_join(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  int syncGroup;

  syncGroup=-1;
  if (!PyArg_ParseTuple(args, "|i", &syncGroup))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_SYNC_JOIN, &syncGroup)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_SYNC_JOIN");
    return NULL;
  }

  return Py_BuildValue("i", syncGroup);
}

static PyObject *mixer_sync_leave(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_SYNC_LEAVE)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_SYNC_LEAVE");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_sync_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  int syncGroup;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_SYNC_INFO, &syncGroup)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_SYNC_INFO");
    return NULL;
  }

  return Py_BuildValue("i", syncGroup);
}

static PyObject *mixer_driver_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  SamDriverInfo driverInfo;
  char version[256];

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_DRIVER_INFO");
    return NULL;
  }

  sprintf(version, "%d.%d.%d",
	  driverInfo.driverVersion.major,
	  driverInfo.driverVersion.minor,
	  driverInfo.driverVersion.tiny);
  return Py_BuildValue("{sssssssisisisisisisisisisisisisi}",
		       "version", version,
		       "hardware", driverInfo.hardware,
		       "firmware", driverInfo.firmware,
		       "haveAudio", driverInfo.haveAudio,
		       "haveMidi", driverInfo.haveMidi,
		       "haveMod", driverInfo.haveMod,
		       "memTotal", driverInfo.memTotal,
		       "memFree", driverInfo.memFree,
		       "memSBanks", driverInfo.memSBanks,
		       "memMod", driverInfo.memMod,
		       "memAudio", driverInfo.memAudio,
		       "playChannelsUsed", driverInfo.playChannelsUsed,
		       "playChannelsTotal", driverInfo.playChannelsTotal,
		       "recordChannelsUsed", driverInfo.recordChannelsUsed,
		       "recordChannelsTotal", driverInfo.recordChannelsTotal,
		       "peakMeterValues", driverInfo.peakMeterValues);
}

static PyObject *mixer_hw_hints_get(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  SamHardwareHints hardwareHints;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_HW_HINTS_GET, &hardwareHints)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_HW_HINTS_GET");
    return NULL;
  }

  return Py_BuildValue("{si}",
		       "cardMem", hardwareHints.cardMem);
}

static PyObject *mixer_hw_hints_set(PyObject *self, PyObject *args, PyObject *keywds)
{
  static char *kwlist[]={
    "cardMem", NULL
  };
  MixerObject *mixer=(MixerObject *)self;
  int cardMem;
  SamHardwareHints hardwareHints;

  cardMem=-1;
  if (!PyArg_ParseTupleAndKeywords(args, keywds, "|i", kwlist, &cardMem))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_HW_HINTS_GET, &hardwareHints)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_HW_HINTS_GET");
    return NULL;
  }

  if(cardMem>=0)
    hardwareHints.cardMem=cardMem;
  
  if(ioctl(mixer->fd, SAM_IOC_HW_HINTS_SET, &hardwareHints)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_HW_HINTS_SET");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_firmware_load(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  char *fileName;
  int fd;
  struct stat st;
  SamFirmware firmware;

  if (!PyArg_ParseTuple(args, "s", &fileName))
    return NULL;

  memset(&firmware, 0, sizeof(SamFirmware));
  if((fd=open(fileName, O_RDONLY))<0) {
    raiseIOError(fileName, "open", NULL);
    return NULL;
  }

  if(fstat(fd, &st)<0) {
    raiseIOError(fileName, "fstat", NULL);
    close(fd);
    return NULL;
  }

  if((firmware.data=(unsigned short *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    raiseIOError(fileName, "mmap", NULL);
    close(fd);
    return NULL;
  }

  firmware.size=st.st_size>>1;
  if(ioctl(mixer->fd, SAM_IOC_FIRMWARE_LOAD, &firmware)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_FIRMWARE_LOAD");
    munmap((void *)firmware.data, st.st_size);
    close(fd);
    return NULL;
  }

  munmap((void *)firmware.data, st.st_size);
  close(fd);

  return Py_BuildValue("");
}

static PyObject *mixer_known(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *result;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(!mixer->apiInfo)
    return Py_BuildValue("[]");

  if(!(result=PyList_New(0)))
    return NULL;

  if(!dumpKnown(result, mixer->apiInfo->mixerHWById) ||
     !dumpKnown(result, mixer->apiInfo->mixerFWById)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_get(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg, *result;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->mixerFWByName, mixer->apiInfo->mixerHWByName,
		    controls, arg))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_MIXER_GET, controls)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_GET");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(mixer->apiInfo->mixerFWById, mixer->apiInfo->mixerHWById, SAM_MIXER_HW_ID_FIRST,
		   result, controls, 1)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_set(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->mixerFWByName, mixer->apiInfo->mixerHWByName,
		    controls, arg))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_MIXER_SET, controls)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_SET");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_get_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg, *result;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->mixerFWByName, mixer->apiInfo->mixerHWByName,
		    controls, arg))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_MIXER_INFO, controls)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_INFO");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(mixer->apiInfo->mixerFWById, mixer->apiInfo->mixerHWById, SAM_MIXER_HW_ID_FIRST,
		   result, controls, 0)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_audio_known(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *result;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(!mixer->apiInfo)
    return Py_BuildValue("[]");

  if(!(result=PyList_New(0)))
    return NULL;

  if(!dumpKnown(result, mixer->apiInfo->audioById)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_audio_get(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg, *result;
  SamRedirectedAudioControl redirAudioControl;
  SamControl *controls;
  int channel, n;

  if(!PyArg_ParseTuple(args, "iO", &channel, &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "second argument is neither list nor typle");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  redirAudioControl.channel=channel;
  redirAudioControl.controls=controls;
  if(ioctl(mixer->fd, SAM_IOC_MIXER_AUDIO_GET, &redirAudioControl)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_AUDIO_GET");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(mixer->apiInfo->audioById, NULL, 0, result, controls, 1)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_audio_set(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg;
  SamRedirectedAudioControl redirAudioControl;
  SamControl *controls;
  int channel, n;

  if(!PyArg_ParseTuple(args, "iO", &channel, &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "second argument is neither a list nor tuple");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  redirAudioControl.channel=channel;
  redirAudioControl.controls=controls;
  if(ioctl(mixer->fd, SAM_IOC_MIXER_AUDIO_SET, &redirAudioControl)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_AUDIO_SET");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_audio_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *arg, *result;
  SamRedirectedAudioControl redirAudioControl;
  SamControl *controls;
  int channel, n;

  if(!PyArg_ParseTuple(args, "iO", &channel, &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "second argument is neither a list nor tuple");
    return NULL;
  }

  if(!mixer->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(mixer->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  redirAudioControl.channel=channel;
  redirAudioControl.controls=controls;
  if(ioctl(mixer->fd, SAM_IOC_MIXER_AUDIO_INFO, &redirAudioControl)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_MIXER_AUDIO_INFO");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(mixer->apiInfo->audioById, NULL, 0, result, controls, 0)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *mixer_channel_owner_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *result, *v;
  int pids[256], i;
  SamChannelOwnerInfo channelOwnerInfo;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  channelOwnerInfo.pids=pids;
  channelOwnerInfo.size=NumberOf(pids);
  if(ioctl(mixer->fd, SAM_IOC_CHANNEL_OWNER_INFO, &channelOwnerInfo)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_CHANNEL_OWNER_INFO");
    return NULL;
  }

  if(!(result=PyList_New(channelOwnerInfo.size)))
    return NULL;

  for(i=0; i<channelOwnerInfo.size; i++) {
    if(!(v=Py_BuildValue("i", pids[i])) ||
       PyList_SetItem(result, i, v)<0) {
      Py_DECREF(result);
      return NULL;
    }
  }

  return result;
}

static PyObject *mixer_bank_load(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  int id, fd;
  char *fileName;
  struct stat st;
  SamSoundBank soundBank;

  if (!PyArg_ParseTuple(args, "is", &id, &fileName))
    return NULL;

  if((fd=open(fileName, O_RDONLY))<0) {
    raiseIOError(fileName, "open", NULL);
    return NULL;
  }

  if(fstat(fd, &st)<0) {
    raiseIOError(fileName, "fstat", NULL);
    close(fd);
    return NULL;
  }

  if((soundBank.data=(char *)mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    raiseIOError(fileName, "mmap", NULL);
    close(fd);
    return NULL;
  }

  soundBank.size=st.st_size;
  if(ioctl(mixer->fd, SAM_IOC_BANK_LOAD, &soundBank)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_BANK_LOAD");
    munmap((void *)soundBank.data, st.st_size);
    close(fd);
    return NULL;
  }

  munmap((void *)soundBank.data, st.st_size);
  close(fd);

  return Py_BuildValue("");
}

static PyObject *mixer_bank_unload(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  int v;
  unsigned char id;

  if (!PyArg_ParseTuple(args, "i", &v))
    return NULL;

  id=v;
  if(ioctl(mixer->fd, SAM_IOC_BANK_UNLOAD, &id)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_BANK_UNLOAD");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_bank_prio_chg(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  int id, priority;
  SamSoundBankPrio soundBankPrio;

  if (!PyArg_ParseTuple(args, "ii", &id, &priority))
    return NULL;

  soundBankPrio.id=id;
  soundBankPrio.priority=priority;
  if(ioctl(mixer->fd, SAM_IOC_BANK_PRIO_CHG, &soundBankPrio)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_BANK_PRIO_CHG");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *mixer_bank_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *result, *v;
  int i;
  SamSoundBankInfo soundBankInfo[SAM_NROF_SBANKS];

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(mixer->fd, SAM_IOC_BANK_INFO, soundBankInfo)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_BANK_INFO");
    return NULL;
  }

  if(!(result=PyList_New(SAM_NROF_SBANKS)))
    return NULL;

  for(i=0; i<SAM_NROF_SBANKS; i++) {
    if(!(v=Py_BuildValue("si", soundBankInfo[i].name, soundBankInfo[i].priority)) ||
       PyList_SetItem(result, i, v)<0) {
      Py_DECREF(result);
      return NULL;
    }
  }

  return result;
}

static PyObject *mixer_peak_meter_info(PyObject *self, PyObject *args)
{
  MixerObject *mixer=(MixerObject *)self;
  PyObject *result, *v;
  int i;
  unsigned short peakMeter[256];
  SamPeakMeterInfo peakMeterInfo;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  peakMeterInfo.data=peakMeter;
  peakMeterInfo.size=NumberOf(peakMeter);
  if(ioctl(mixer->fd, SAM_IOC_PEAK_METER_INFO, &peakMeterInfo)<0) {
    raiseIOError(mixer->devName, "ioctl", "SAM_IOC_PEAK_METER_INFO");
    return NULL;
  }

  if(!(result=PyList_New(peakMeterInfo.size)))
    return NULL;

  for(i=0; i<peakMeterInfo.size; i++) {
    if(!(v=Py_BuildValue("i", peakMeter[i])) ||
       PyList_SetItem(result, i, v)<0) {
      Py_DECREF(result);
      return NULL;
    }
  }

  return result;
}

static PyObject *audioOpen(AudioMode mode, PyObject *args)
{
  AudioObject *audio;
  PyObject *arg;
  char buf[256], *devName, *cp;
  int cardNr, flags, fd, nonBlocking;
  SamApiInfo apiInfo;

  arg=NULL;
  nonBlocking=0;
  if (!PyArg_ParseTuple(args, "|Oi", &arg, &nonBlocking))
    return NULL;

  if(mode==AudioModeRecord)
    flags=O_RDONLY;
  else
    flags=O_WRONLY;
  if(nonBlocking)
    flags|=O_NONBLOCK;

  if(arg) {
    if(PyInt_Check(arg)) {
      if(!PyArg_Parse(arg, "i", &cardNr))
	return NULL;
      sprintf(buf, "/dev/sam9407/card%d/dsp", cardNr);
      devName=buf;
      fd=open(devName, flags);
      if(fd<0) {
	sprintf(buf, "/dev/sam%d_dsp", cardNr);
	devName=buf;
	fd=open(devName, flags);
      }
      if(fd<0 && cardNr==0) {
	devName="/dev/dsp";
	fd=open(devName, flags);
      }
    } else if(PyString_Check(arg)) {
      if(!PyArg_Parse(arg, "s", &devName))
	return NULL;
      fd=open(devName, flags);
    } else {
      PyErr_SetString(InvalidArgumentError, "argument must be of type integer or string");
      return NULL;
    }
  } else {
    devName="/dev/sam9407/card0/dsp";
    fd=open(devName, flags);
    if(fd<0) {
      devName="/dev/sam0_dsp";
      fd=open(devName, flags);
    }
    if(fd<0) {
      devName="/dev/dsp";
      fd=open(devName, flags);
    }
  }

  if(fd<0) {
    raiseIOError(devName, "open", NULL);
    return NULL;
  }

  if(ioctl(fd, SAM_IOC_API_INFO, &apiInfo)<0) {
    raiseIOError(devName, "ioctl", "SAM_IOC_API_INFO");
    close(fd);
    return NULL;
  }

  if(apiInfo.version!=SAM_AUDIO_API_VERSION) {
    PyErr_SetNone(UnsupportedAPIVersionError);
    close(fd);
    return NULL;
  }

  if(!(cp=PyMem_Malloc(strlen(devName)+1))) {
    close(fd);
    return NULL;
  }
  strcpy(cp, devName);
  devName=cp;

  if(!(audio=PyObject_NEW(AudioObject, &audioType))) {
    PyMem_Free(devName);
    close(fd);
    return NULL;
  }

  audio->mode=mode;
  audio->devName=devName;
  audio->fd=fd;
  audio->nonBlocking=nonBlocking;
  if(apiInfo.apiClass!=SAM_API_CLASS_NONE) {
    if(!(audio->apiInfo=buildApiInfo(apiInfo.apiClass)))
      PyErr_Clear();
  } else
    audio->apiInfo=NULL;

  return (PyObject *)audio;
}

static void audioRelease(PyObject *self)
{
  AudioObject *audio=(AudioObject *)self;

  if(audio->apiInfo) {
    Py_DECREF(audio->apiInfo);
  }
  PyMem_Free(audio->devName);
  close(audio->fd);
}

static int audioPrint(PyObject *self, FILE *fp, int flags)
{
  AudioObject *audio=(AudioObject *)self;

  fprintf(fp, "<sam9407.%s using %s in %s mode at %p>",
	  audio->mode==AudioModeRecord ? "record" : "play",
	  audio->devName,
	  audio->nonBlocking ? "nonblocking" : "blocking",
	  audio);

  return 0;
}

static PyObject *playOpen(PyObject *self, PyObject *args)
{
  return audioOpen(AudioModePlay, args);
}

static PyObject *recordOpen(PyObject *self, PyObject *args)
{
  return audioOpen(AudioModeRecord, args);
}

static PyObject *audioGetAttr(PyObject *self, char *name)
{
  return Py_FindMethod(audioMethods, self, name);
}

static PyObject *audio_fileno(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  return Py_BuildValue("i", audio->fd);
}

static PyObject *audio_devname(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  return Py_BuildValue("s", audio->devName);
}

static PyObject *audio_read(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  char buf[65536];
  int n;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(audio->mode!=AudioModeRecord) {
    PyErr_SetNone(InvalidModeError);
    return NULL;
  }

  if((n=read(audio->fd, buf, sizeof(buf)))<0) {
    if(errno==EAGAIN)
      PyErr_SetNone(EAGAINError);
    else
      raiseIOError(audio->devName, "read", NULL);
    return NULL;
  }

  return Py_BuildValue("s#", buf, n);
}

static PyObject *audio_write(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  char *cp;
  int n, i;

  if (!PyArg_ParseTuple(args, "s#", &cp, &n))
    return NULL;

  if(audio->mode!=AudioModePlay) {
    PyErr_SetNone(InvalidModeError);
    return NULL;
  }

  while(n>0) {
    if((i=write(audio->fd, cp, n))<0) {
      if(errno==EAGAIN)
	PyErr_SetNone(EAGAINError);
      else
	raiseIOError(audio->devName, "write", NULL);
      return NULL;
    }
    cp+=i;
    n-=i;
    if(audio->nonBlocking)
      break;
  }

  return Py_BuildValue("s#", cp, n);
}

static PyObject *audio_sync_join(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int syncGroup;

  syncGroup=-1;
  if (!PyArg_ParseTuple(args, "|i", &syncGroup))
    return NULL;

  if(audio->mode!=AudioModePlay) {
    PyErr_SetNone(InvalidModeError);
    return NULL;
  }

  if(ioctl(audio->fd, SAM_IOC_SYNC_JOIN, &syncGroup)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_SYNC_JOIN");
    return NULL;
  }

  return Py_BuildValue("i", syncGroup);
}

static PyObject *audio_sync_leave(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(audio->mode!=AudioModePlay) {
    PyErr_SetNone(InvalidModeError);
    return NULL;
  }

  if(ioctl(audio->fd, SAM_IOC_SYNC_LEAVE)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_SYNC_LEAVE");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *audio_sync_info(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int syncGroup;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(audio->mode!=AudioModePlay) {
    PyErr_SetNone(InvalidModeError);
    return NULL;
  }

  if(ioctl(audio->fd, SAM_IOC_SYNC_INFO, &syncGroup)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_SYNC_INFO");
    return NULL;
  }

  return Py_BuildValue("i", syncGroup);
}

static PyObject *audio_channel_info(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  SamChannelNumbers channelNumbers;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(audio->fd, SAM_IOC_CHANNEL_INFO, &channelNumbers)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_CHANNEL_INFO");
    return NULL;
  }

  return Py_BuildValue("i", audio->mode==AudioModeRecord ? channelNumbers.record : channelNumbers.play);
}

static PyObject *audio_channel_redirect(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int channel;
  SamChannelNumbers channelNumbers;

  if (!PyArg_ParseTuple(args, "i", &channel))
    return NULL;

  if(audio->mode==AudioModeRecord) {
    channelNumbers.play=-1;
    channelNumbers.record=channel;
  } else {
    channelNumbers.play=channel;
    channelNumbers.record=-1;
  }
  if(ioctl(audio->fd, SAM_IOC_CHANNEL_REDIRECT, &channelNumbers)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_CHANNEL_REDIRECT");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *audio_known(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  PyObject *result;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(!audio->apiInfo)
    return Py_BuildValue("[]");

  if(!(result=PyList_New(0)))
    return NULL;

  if(!dumpKnown(result, audio->apiInfo->audioById)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *audio_get(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  PyObject *arg, *result;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!audio->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(audio->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  if(ioctl(audio->fd, SAM_IOC_AUDIO_GET, controls)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_AUDIO_GET");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(audio->apiInfo->audioById, NULL, 0, result, controls, 1)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *audio_set(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  PyObject *arg;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!audio->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(audio->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  if(ioctl(audio->fd, SAM_IOC_AUDIO_SET, controls)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_AUDIO_SET");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *audio_info(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  PyObject *arg, *result;
  SamControl *controls;
  int n;

  if(!PyArg_ParseTuple(args, "O", &arg))
    return NULL;

  if(!PySequence_Check(arg) || PyString_Check(arg)) {
    PyErr_SetString(InvalidArgumentError, "argument is neither a list nor tuple");
    return NULL;
  }

  if(!audio->apiInfo) {
    PyErr_SetNone(UnsupportedFirmwareError);
    return NULL;
  }

  n=PySequence_Length(arg);
  controls=(SamControl *)alloca((n+1)*sizeof(SamControl));
  if(!controls) {
    PyErr_NoMemory();
    return NULL;
  }
  memset(controls, 0, (n+1)*sizeof(SamControl));

  if(!parseControls(audio->apiInfo->audioByName, NULL, controls, arg))
    return NULL;

  if(ioctl(audio->fd, SAM_IOC_AUDIO_INFO, controls)<0) {
    raiseIOError(audio->devName, "ioctl", "SAM_IOC_AUDIO_INFO");
    return NULL;
  }

  if(!(result=PyList_New(n)))
    return NULL;

  if(!dumpControls(audio->apiInfo->audioById, NULL, 0, result, controls, 0)) {
    Py_DECREF(result);
    return NULL;
  }

  return result;
}

static PyObject *audio_reset(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(audio->fd, SNDCTL_DSP_RESET)<0) {
    raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_RESET");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *audio_post(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(ioctl(audio->fd, SNDCTL_DSP_POST)<0) {
    raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_POST");
    return NULL;
  }

  return Py_BuildValue("");
}

static PyObject *audio_speed(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int speed;

  if (!PyArg_ParseTuple(args, "i", &speed))
    return NULL;

  if(ioctl(audio->fd, SNDCTL_DSP_SPEED, &speed)<0) {
    raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_SPEED");
    return NULL;
  }

  return Py_BuildValue("i", speed);
}

static PyObject *audio_channels(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int channels;

  if (!PyArg_ParseTuple(args, "i", &channels))
    return NULL;

  if(ioctl(audio->fd, SOUND_PCM_WRITE_CHANNELS, &channels)<0) {
    raiseIOError(audio->devName, "ioctl", "SOUND_PCM_WRITE_CHANNELS");
    return NULL;
  }

  return Py_BuildValue("i", channels);
}

static PyObject *audio_setfragment(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  int size, count;
  unsigned v;

  if (!PyArg_ParseTuple(args, "ii", &size, &count))
    return NULL;

  v=(size&0xFFFF)|((count&0x7FFF)<<16);

  if(ioctl(audio->fd, SNDCTL_DSP_SETFRAGMENT, &v)<0) {
    raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_SETFRAGMENT");
    return NULL;
  }

  return Py_BuildValue("(ii)", v&0xFFFF, (v>>16)&0x7FFF);
}

static PyObject *audio_setfmt(PyObject *self, PyObject *args)
{
  struct Format {
    char *name;
    int value;
  } formats[]={
    { "MU_LAW", AFMT_MU_LAW },
    { "A_LAW", AFMT_A_LAW },
    { "U8", AFMT_U8 },
    { "S16_LE", AFMT_S16_LE },
    { "S16_BE", AFMT_S16_BE },
    { "S8", AFMT_S8 },
    { "U16_LE", AFMT_U16_LE },
    { "U16_BE", AFMT_U16_BE },
    { NULL }		/* sentinel */
  };

  AudioObject *audio=(AudioObject *)self;
  struct Format *format;
  char *name;
  int value;

  if (!PyArg_ParseTuple(args, "s", &name))
    return NULL;

  for(format=formats; format->name; format++)
    if(strcmp(name, format->name)==0)
      break;
  if(!format->name) {
    PyErr_SetString(InvalidArgumentError, "invalid format name specified");
    return NULL;
  }

  value=format->value;
  if(ioctl(audio->fd, SNDCTL_DSP_SETFMT, &value)<0) {
    raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_SETFMT");
    return NULL;
  }

  if(value!=format->value) {
    for(format=formats; format->name; format++)
      if(strcmp(name, format->name)==0)
	break;
  }

  if(format->name)
    name=format->name;
  else
    name="UNKNOWN";

  return Py_BuildValue("s", name);
}

static PyObject *audio_getspace(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  audio_buf_info info;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(audio->mode==AudioModeRecord) {
    if(ioctl(audio->fd, SNDCTL_DSP_GETISPACE, &info)<0) {
      raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_GETISPACE");
      return NULL;
    }
  } else {
    if(ioctl(audio->fd, SNDCTL_DSP_GETOSPACE, &info)<0) {
      raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_GETOSPACE");
      return NULL;
    }
  }

  return Py_BuildValue("{sisisisi}",
		       "fragments", info.fragments,
		       "fragstotal", info.fragstotal,
		       "fragsize", info.fragsize,
		       "bytes", info.bytes);
}

static PyObject *audio_getptr(PyObject *self, PyObject *args)
{
  AudioObject *audio=(AudioObject *)self;
  count_info info;

  if (!PyArg_ParseTuple(args, ""))
    return NULL;

  if(audio->mode==AudioModeRecord) {
    if(ioctl(audio->fd, SNDCTL_DSP_GETIPTR, &info)<0) {
      raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_GETIPTR");
      return NULL;
    }
  } else {
    if(ioctl(audio->fd, SNDCTL_DSP_GETOPTR, &info)<0) {
      raiseIOError(audio->devName, "ioctl", "SNDCTL_DSP_GETOPTR");
      return NULL;
    }
  }

  return Py_BuildValue("{sisisi}",
		       "ptr", info.ptr,
		       "bytes", info.bytes,
		       "blocks", info.blocks);
}

void initsam9407(void)
{
  PyObject *m, *d;

  m=Py_InitModule("sam9407", methods);
  d=PyModule_GetDict(m);

  UnsupportedAPIVersionError=PyErr_NewException("sam9407.UnsupportedAPIVersionError", NULL, NULL);
  PyDict_SetItemString(d, "UnsupportedAPIVersionError", UnsupportedAPIVersionError);
  UnsupportedFirmwareError=PyErr_NewException("sam9407.UnsupportedFirmwareError", NULL, NULL);
  PyDict_SetItemString(d, "UnsupportedFirmwareError", UnsupportedFirmwareError);
  InvalidArgumentError=PyErr_NewException("sam9407.InvalidArgumentError", NULL, NULL);
  PyDict_SetItemString(d, "InvalidArgumentError", InvalidArgumentError);
  InvalidModeError=PyErr_NewException("sam9407.InvalidModeError", NULL, NULL);
  PyDict_SetItemString(d, "InvalidModeError", InvalidModeError);
  IOError=PyErr_NewException("sam9407.IOError", NULL, NULL);
  PyDict_SetItemString(d, "IOError", IOError);
  EAGAINError=PyErr_NewException("sam9407.EAGAINError", NULL, NULL);
  PyDict_SetItemString(d, "EAGAINError", EAGAINError);
}
