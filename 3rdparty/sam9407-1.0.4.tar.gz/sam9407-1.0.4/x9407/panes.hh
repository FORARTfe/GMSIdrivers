#ifndef _PANES_HH
#define _PANESx_HH

#include <X11/Intrinsic.h>

#include "controls.hh"

class DevicePane;
class SoundBankPane;

class DevicePaneEvent : public Event {
public:
  DevicePaneEvent(DevicePane *aDevicePane, Type aType) : Event(aType) { devicePane=aDevicePane; }
  virtual void triggerDeviceClosed(int cardNr);
  virtual void triggerDevicesRescanned(DeviceInfo *devices, int count);
  virtual void triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName);
private:
  DevicePane *devicePane;
};

class DevicePane : public Pane {
public:
  DevicePane(Group *aGroup, char *aName, int aTabPosition);
  virtual ~DevicePane();
  virtual void build(Widget parent);
  void disposeDevices();
  void displayList();
  void devicesRescanned(Event::DeviceInfo *devices, int count);
  void selectCardNr(int aCardNr);
  void fwChanged(int aCardNr, char *fwName);
  void loadFirmware();
private:
  static void rescanDevicesCallback(Widget w, XtPointer closure, XtPointer callData);
  static void useDeviceCallback(Widget w, XtPointer closure, XtPointer callData);
  static void releaseDeviceCallback(Widget w, XtPointer closure, XtPointer callData);
  static void loadFirmwareCallback(Widget w, XtPointer closure, XtPointer callData);
  
  DevicePaneEvent devicesRescannedEvent;
  DevicePaneEvent fwChangedEvent;
  DevicePaneEvent devClosedEvent;
  Widget wLblInUse, wInUse, wTitle, wList;
  Widget wRescan, wUse, wRelease, wFirmLoad;
  int cardNr;
  Event::DeviceInfo *devices;
  int nDevices;
  String *list;
  String fsFirmwarePath;
};

class HardwarePane : public Pane {
public:
  HardwarePane(Group *aGroup, char *aName, int aTabPosition, Boolean aWithSampleRate);
};

class AnaOutPane : public Pane {
public:
  AnaOutPane(Group *aGroup, char *aName, int aTabPosition);
};

class BoxesPane : public Pane {
public:
  BoxesPane(Group *aGroup, char *aName, int aTabPosition);
};

class SoundBankPaneEvent : public Event {
public:
  SoundBankPaneEvent(SoundBankPane *aSoundBankPane) : Event(Event::SBankChanged) { soundBankPane=aSoundBankPane; }
  virtual void triggerSBankChanged(SoundbankInfo *sbanks, int count, int memSBank, int memFree);
private:
  SoundBankPane *soundBankPane;
};

class SoundBankPane : public Pane {
public:
  SoundBankPane(Group *aGroup, char *aName, int aTabPosition);
  virtual ~SoundBankPane();
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void sbankChanged(Event::SoundbankInfo *sbanks, int count, int memSBank, int memFree);
  void elemSelected(int index);
  void loadSBank();
  void unloadSBank();
  void changePrio();
private:
  static void elemSelectedCallback(Widget w, XtPointer closure, XtPointer callData);
  static void loadCallback(Widget w, XtPointer closure, XtPointer callData);
  static void unloadCallback(Widget w, XtPointer closure, XtPointer callData);
  static void ackTextAction(Widget w, XEvent *event, String *params, Cardinal *numParams);

  static XContext thisPtrContext;

  SoundBankPaneEvent soundBankChangedEvent;
  Widget wTitle, wList, wLblMemSBank, wMemSBank, wLblMemFree, wMemFree;
  Widget wLoad, wUnload, wLblPrio, wPrio;
  String *list;
  String fsSBankPath;
};

#endif /* _PANES_HH */
