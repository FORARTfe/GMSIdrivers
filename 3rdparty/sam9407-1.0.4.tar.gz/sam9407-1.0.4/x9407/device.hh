#ifndef _DEVICE_HH
#define _DEVICE_HH

#include <map>

#include <X11/Intrinsic.h>

using namespace std;

class Application;
class Device;
struct SamControl;
struct SamEvent;
struct SamCtrlNameAssoc;

class Event {
  friend class Device;
public:
  enum Type {
    DevicesRescanned,
    DeviceClosed,
    FirmwareChanged,
    SBankChanged,
    MixerValue,
    AudioValue,
    PeakMeterChanged,
    ChannelOwnerChanged,
  };
  struct DeviceInfo {
    char *hwName;
    char *fwName;
  };
  struct SoundbankInfo {
    char *name;
    unsigned priority;
  };

  Event(Type aType, unsigned char aId=0, unsigned char aAddr=0, unsigned char aChannel=0) {
    type=aType;
    id=aId;
    addr=aAddr;
    channel=aChannel;
    device=NULL;
    prevP=NULL;
    next=NULL;
  }
  virtual ~Event();

  void subscribe(Device *aDevice);
  void unsubscribe();

  virtual void triggerDevicesRescanned(DeviceInfo *devices, int count);
  virtual void triggerDeviceClosed(int cardNr);
  virtual void triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName);
  virtual void triggerSBankChanged(SoundbankInfo *sbanks, int count, int memSBank, int memFree);
  /* value will be <0 if control is not supported */
  virtual void triggerMixerValue(int value);
  virtual void triggerAudioValue(int value);
  virtual void triggerPeakMeter(unsigned short *tbl);
  virtual void triggerChannelOwner(int *pids);

private:
  Type type;
  unsigned char id, addr, channel;
  Device *device;

  Event **prevP, *next;
};

class Device {
  friend class Event;
public:
  /* recording channels are marked in the highest bit
   * so their address remains independent of the number
   * of playback channels supported by this particular firmware
   */
  static const int RecordChannelMask=0x80;

  Device(Application *aAppl);
  void rescan();
  void open(int aCardNr);
  void close();
  int isOpen() { return mixerFd>=0; }
  int isUsable();
  int getCardNr() { return cardNr; }
  int getPlaybackChannels() { return playbackChannels; }
  void setApiSupported(int apiClass);
  void adjust(int id, int addr, int channel, int value);
  void poll(int id, int addr, int channel);
  void loadSettings(int complain, char *fileName);
  void saveSettings(int complain, char *fileName);
  void loadFirmware(char *fileName);
  void loadSBank(int slot, char *fileName);
  void unloadSBank(int slot);
  void changeSBankPrio(int slot, int prio);
  void startPollPeakMeter();
  void stopPollPeakMeter();

private:
  struct HashBucket {
    unsigned idx;
    Event *events;
    HashBucket *next;
  };

  static const int MaxCards=8;
  static const int HashBucketSize=211;
  static const int EventChunkSize=256;

  static void mixerEvent(XtPointer closure, int *source, XtInputId *inputId);
  static void pollPeakMeter(XtPointer closure, XtIntervalId *id);
  static void verifyChannelOwner(XtPointer closure, XtIntervalId *id);

  void sendMixerControls(int complain, SamCtrlNameAssoc *mixerAssoc, int doesReset, SamControl *mixerControls);
  void sendAudioControls(int complain, int channel, SamControl *audioControls);
  Event **findEventPInBuckets(HashBucket **buckets, unsigned idx);
  void triggerFirmwareChanged(int aApiClass);
  void triggerSBankChanged();
  void triggerPeakMeter();
  void triggerChannelOwner();
  void triggerValues(int checkSupported, int channel, SamControl *controls);
  void triggerAllValues(int apiClass, int audioChannels);
  void handleEvents(SamEvent *events, int nEvents);

  Application *appl;
  int cardNr, mixerFd, apiClass, playbackChannels;
  XtInputId inputId;
  XtIntervalId pollPeakMeterId;
  XtIntervalId verifyChannelOwnerId;
  Event *devRescannnedEvents;
  Event *devCloseEvents;
  Event *firmwareChangedEvents;
  Event *sbankChangedEvents;
  HashBucket *mixerChangedEvents[HashBucketSize];
  HashBucket *audioChangedEvents[HashBucketSize];
  Event *peakMeterEvents;
  Event *channelOwnerEvents;
  map<int, int, less<int> > supportedApis;
  map<XrmQuark, SamCtrlNameAssoc *, less<XrmQuark> > mixerHWCtrlsByName;
  map<int, SamCtrlNameAssoc *, less<int> > mixerHWCtrlsById;
  map<int, map<XrmQuark, SamCtrlNameAssoc *, less<XrmQuark> >, less<int> > allMixerCtrlsByName, allAudioCtrlsByName;
  map<int, map<int, SamCtrlNameAssoc *, less<int> >, less<int> > allMixerCtrlsById;
};

#endif /* _DEVICE_HH */
