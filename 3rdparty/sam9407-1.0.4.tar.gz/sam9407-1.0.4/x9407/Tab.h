/***************************************************************
 * Tab widget
 ***************************************************************/

/* RESOURCES:
   Name			Class			RepType		Default Value
   ----			-----			-------		-------------
   foreground		Foreground		Pixel		Black
   shadowThickness	ShadowThickness		Dimension	1
   topShadowColor	TopShadowColor		Pixel		gray80
   bottomShadowColor	BottomShadowColor	Pixel		gray60
   */

#ifndef _TAB_H
#define _TAB_H

/* New Fields */
#define XtNisTab "isTab"
#define XtNtabPosition "tabPosition"
#define XtNrelatedPane "relatedPane"
#define XtNuserSelectable "userSelectable"
#define XtNtabVisible "tabVisible"
#define XtNselectedTab "selectedTab"
#define XtNtabTranslations "tabTranslations"
#define XtNtabGapWidth "tabGapWidth"
#define XtNshadowThickness "shadowThickness"
#define XtNtopShadowColor "topShadowColor"
#define XtNbottomShadowColor "bottomShadowColor"
#define XtNmarginWidth "marginWidth"

#define XtCIsTab "IsTab"
#define XtCTabPosition "TabPosition"
#define XtCRelatedPane "RelatedPane"
#define XtCUserSelectable "UserSelectable"
#define XtCTabVisible "TabVisible"
#define XtCSelectedTab "SelectedTab"
#define XtCTabTranslations "TabTranslations"
#define XtCTabGapWidth "TabGapWidth"
#define XtCShadowThickness "ShadowThickness"
#define XtCTopShadowColor "TopShadowColor"
#define XtCBottomShadowColor "BottomShadowColor"
#define XtCMarginWidth "MarginWidth"

extern WidgetClass tabWidgetClass;
typedef struct _TabClassRec *TabWidgetClass;
typedef struct _TabRec *TabWidget;

#endif /* _TAB_H */
