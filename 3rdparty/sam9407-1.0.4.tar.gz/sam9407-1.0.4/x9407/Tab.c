/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include "TabP.h"

#ifndef XtX
#define XtX(w)	   ((w)->core.x)
#endif

#ifndef XtY
#define XtY(w)	   ((w)->core.y)
#endif

#ifndef XtWidth
#define XtWidth(w) ((w)->core.width)
#endif

#ifndef XtHeight
#define XtHeight(w) ((w)->core.height)
#endif

#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

static void ClassInitialize();
static void Initialize();
static void ConstraintInitialize();
static void Release();
static void ChangeManaged();
static XtGeometryResult GeometryManager();
static void Resize();
static void Redisplay();
static Boolean SetValues();
static XtGeometryResult PreferredGeometry();
static Boolean ConstraintSetValues();
static void SelectTab();
static Boolean Layout();
static void ClearDecoration();
static void DrawDecoration();

static void SelectTabAction();

static XtActionsRec actions[]={
  {"SelectTab", SelectTabAction},
};

static char translations[]="\
";

static char tabTranslations[]="\
<Btn1Up>: SelectTab()\n\
";

static XtResource resources[]= {
  {
    XtNforeground, XtCForeground,
    XtRPixel, sizeof(Pixel),
    XtOffset(TabWidget, tab.foreground),
    XtRString, (XtPointer)"Black"
  },
  {
    XtNshadowThickness, XtCShadowThickness,
    XtRDimension, sizeof(Dimension),
    XtOffset(TabWidget, tab.shadowThickness),
    XtRImmediate, (XtPointer)2
  },
  {
    XtNtopShadowColor, XtCTopShadowColor,
    XtRPixel, sizeof(Pixel),
    XtOffset(TabWidget, tab.topShadowColor),
    XtRString, (XtPointer)"gray80"
  },
  {
    XtNbottomShadowColor, XtCBottomShadowColor,
    XtRPixel, sizeof(Pixel),
    XtOffset(TabWidget, tab.bottomShadowColor),
    XtRString, (XtPointer)"gray60"
  },
  {
    XtNmarginWidth, XtCMarginWidth,
    XtRDimension, sizeof(Dimension),
    XtOffset(TabWidget, tab.marginWidth),
    XtRImmediate, (XtPointer)2
  },
  {
    XtNtabGapWidth, XtCTabGapWidth,
    XtRDimension, sizeof(Dimension),
    XtOffset(TabWidget, tab.tabGapWidth),
    XtRImmediate, (XtPointer)4
  },
  {
    XtNselectedTab, XtCSelectedTab,
    XtRWidget, sizeof(Widget),
    XtOffset(TabWidget, tab.selectedTab),
    XtRImmediate, (XtPointer)NULL
  },
  {
    XtNuserSelectable, XtCUserSelectable, 
    XtRBoolean, sizeof(Boolean),
    XtOffset(TabWidget, tab.userSelectable),
    XtRImmediate, (XtPointer)True
  },
  {
    XtNtabVisible, XtCTabVisible, 
    XtRBoolean, sizeof(Boolean),
    XtOffset(TabWidget, tab.tabVisible),
    XtRImmediate, (XtPointer)True
  },
  {
    XtNtabTranslations, XtCTabTranslations,
    XtRTranslationTable, sizeof(XtTranslations),
    XtOffset(TabWidget, tab.tabTranslations),
    XtRString, (XtPointer)tabTranslations
  },
};

static XtResource tabConstraintResources[] = {
  {
    XtNisTab, XtCIsTab, 
    XtRBoolean, sizeof(Boolean),
    XtOffset(TabConstraints,tab.isTab),
    XtRImmediate, (XtPointer)True
  },
  {
    XtNtabPosition, XtCTabPosition, 
    XtRInt, sizeof(int),
    XtOffset(TabConstraints,tab.tabPosition),
    XtRImmediate, (XtPointer)-1
  },
  {
    XtNrelatedPane, XtCRelatedPane, 
    XtRWidget, sizeof(Widget),
    XtOffset(TabConstraints,tab.relatedPane),
    XtRImmediate, (XtPointer)NULL
  },
};


TabClassRec tabClassRec = {
  {/* core_class members */
    (WidgetClass) &constraintClassRec,		/* superclass */
    "Tab",					/* class_name */
    sizeof(TabRec),				/* widget_size */
    ClassInitialize,				/* class_initialize */
    NULL,					/* class_part_init */
    FALSE,					/* class_inited */
    Initialize,					/* initialize */
    NULL,					/* initialize_hook */
    XtInheritRealize,				/* realize */
    actions,					/* actions */
    XtNumber(actions),				/* num_actions */
    resources,					/* resources */
    XtNumber(resources),			/* num_resources */
    NULLQUARK,					/* xrm_class */
    TRUE,					/* compress_motion */
    TRUE,					/* compress_exposure */
    TRUE,					/* compress_enterleave */
    FALSE,					/* visible_interest */
    Release,					/* destroy */
    Resize,					/* resize */
    Redisplay,					/* expose */
    SetValues,					/* set_values */
    NULL,					/* set_values_hook */
    XtInheritSetValuesAlmost,			/* set_values_almost */
    NULL,					/* get_values_hook */
    NULL,					/* accept_focus */
    XtVersion,					/* version */
    NULL,					/* callback_private */
    translations,				/* tm_table */
    PreferredGeometry,				/* query_geometry */
    XtInheritDisplayAccelerator,		/* display_accelerator */
    NULL					/* extension */
  },
  { /* composite_class members */
    GeometryManager,				/* geometry_manager */
    ChangeManaged,				/* change_managed */
    XtInheritInsertChild,			/* insert_child */
    XtInheritDeleteChild,			/* delete_child */
    NULL					/* extension */
  },
  { /* constraint_class fields */
    tabConstraintResources,			/* subresourses */
    XtNumber(tabConstraintResources),		/* subresource_count */
    sizeof(TabConstraintsRec),			/* constraint_size */
    ConstraintInitialize,			/* initialize */   
    NULL,					/* destroy */
    ConstraintSetValues,			/* set_values */
    NULL					/* extension */
  },
  { /* tab_class members */
    NULL,                           		/* extension */
  }
};

WidgetClass tabWidgetClass=(WidgetClass)&tabClassRec;

/* select the specified tab
 * if this one is invalid or NULL
 * select the first tab
 */
static void SelectTab(tw,aSelection,repaint)
     TabWidget tw;
     Widget aSelection;
     Boolean repaint;
{
  TabConstraints tab;
  Widget selection=aSelection;
  /* check if selection is valid */
  if(selection &&
     (XtParent(selection)!=(Widget)tw ||
      (tw->tab.tabVisible && !XtIsManaged(selection))))
    selection=NULL;
  if(selection){
    tab=(TabConstraints)selection->core.constraints;
    if(!tab->tab.isTab ||
       tab->tab.tabPosition<0)
      selection=NULL;
  }
  /* if no selection has been made, or selection is invalid
   * select the first tab
   */
  if(!selection){
    WidgetList childP;
    int numChildren=tw->composite.num_children,i;
    Widget child;
    for(childP=tw->composite.children,i=0;
	i<numChildren;
	childP++,i++) {
      child=*childP;
      tab = (TabConstraints)child->core.constraints;
	    
      if(tab->tab.isTab &&
	 tab->tab.tabPosition>=0 &&
	 (!tw->tab.tabVisible || XtIsManaged(child))) {
	/* found one, we're done */
	selection=child;
	break;
      }
    }
  }
  /* if new one is the same as the old one, we're done */
  if(selection==tw->tab.selectedTab)
    return;

  ClearDecoration(tw);

  /* deselect old tab, if provided */
  if(tw->tab.selectedTab) {
    tab=(TabConstraints)tw->tab.selectedTab->core.constraints;
    /* unmanage the related pane */
    if(tab->tab.relatedPane && XtIsManaged(tab->tab.relatedPane)){
      tw->tab.dontLayout++;
      XtUnmanageChild(tab->tab.relatedPane);
      tw->tab.dontLayout--;
    }
  }
  /* set the new selection, as we don't need the old one anymore */
  tw->tab.selectedTab=selection;

  DrawDecoration(tw);

  /* if we don't have a new tab to select,
   * we're done
   */
  if(!selection)
    return;

  /* select new tab & related pane */
  tab=(TabConstraints)selection->core.constraints;
  if(tab->tab.relatedPane && !XtIsManaged(tab->tab.relatedPane)) {
    tw->tab.dontLayout++;
    XtManageChild(tab->tab.relatedPane);
    tw->tab.dontLayout--;
  }
}

/* Relayout our tabs
 * If dontLayout is requested, it'll always return False, otherwise
 * if we do have enough space to satisfy the request it will return True
 */
static Boolean Layout(tw,queryOnly)
     TabWidget tw;
     Boolean queryOnly;
{
  Boolean success=False; /* result value */
  TabConstraints tab;
  WidgetList childP;
  int numChildren=tw->composite.num_children,i;
  Widget child;
  Dimension shadowThickness;

  if(tw->tab.dontLayout)
    return False;

  tw->tab.maxTabPosition=-1;
  tw->tab.tabWidth=tw->tab.tabHeight=tw->tab.tabBorderWidth=0;
  tw->tab.paneWidth=tw->tab.paneHeight=tw->tab.paneBorderWidth=0;

  /* first check out our required size */
  for(childP=tw->composite.children,i=0;
      i<numChildren;
      childP++,i++) {
    child=*childP;
    tab = (TabConstraints)child->core.constraints;

    if(tab->tab.isTab) {
      /* dismiss all tabs that don't belong here */
      if(XtIsManaged(child) &&
	 (!tw->tab.tabVisible || tab->tab.tabPosition<0))
	XtUnmanageChild(child);

      if(tw->tab.tabVisible) {
	/* figure out highest tabPosition to determine our required size */
	if(tab->tab.tabPosition>tw->tab.maxTabPosition)
	  tw->tab.maxTabPosition=tab->tab.tabPosition;

	/* also determine the largest tab */
	if(tab->tab.preferredWidth>tw->tab.tabWidth)
	  tw->tab.tabWidth=tab->tab.preferredWidth;
	if(tab->tab.preferredHeight>tw->tab.tabHeight)
	  tw->tab.tabHeight=tab->tab.preferredHeight;
	if(tab->tab.preferredBorderWidth>tw->tab.tabBorderWidth)
	  tw->tab.tabBorderWidth=tab->tab.preferredBorderWidth;
      }
    } else { /* pane */
      /* find out maximal pane size as well */
      if(tab->tab.preferredWidth>tw->tab.paneWidth)
	tw->tab.paneWidth=tab->tab.preferredWidth;
      if(tab->tab.preferredHeight>tw->tab.paneHeight)
	tw->tab.paneHeight=tab->tab.preferredHeight;
      if(tab->tab.preferredBorderWidth>tw->tab.paneBorderWidth)
	tw->tab.paneBorderWidth=tab->tab.preferredBorderWidth;
    }
  }

  /* calculate required size, compare it with the preferred ones
   * and try to resize if they are different
   */

  shadowThickness=tw->tab.shadowThickness;

  /* first take care of the tabs */
  if(tw->tab.tabVisible) {
    tw->tab.requiredWidth=(tw->tab.maxTabPosition+1)*(tw->tab.tabWidth+(tw->tab.tabBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1));
    if(tw->tab.maxTabPosition>0)
      tw->tab.requiredWidth+=tw->tab.maxTabPosition*tw->tab.tabGapWidth;
    tw->tab.tabRequiredHeight=tw->tab.tabHeight+(tw->tab.tabBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1);
  } else {
    tw->tab.requiredWidth=0;
    tw->tab.requiredHeight=0;
    tw->tab.tabRequiredHeight=0;
  }
  tw->tab.requiredHeight=tw->tab.tabRequiredHeight+tw->tab.paneHeight+(tw->tab.paneBorderWidth<<1)+shadowThickness+(tw->tab.marginWidth<<1);
  /* check if the pane would extend the tabs */
  if(tw->tab.paneWidth+(tw->tab.paneBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1)>tw->tab.requiredWidth)
    tw->tab.requiredWidth=tw->tab.paneWidth+(tw->tab.paneBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1);

  tw->tab.cellWidth=tw->tab.tabWidth+(tw->tab.tabBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1)+tw->tab.tabGapWidth;

  tw->tab.actualWidth=MAX(XtWidth(tw),tw->tab.requiredWidth);
  tw->tab.actualHeight=MAX(XtHeight(tw),tw->tab.requiredHeight);

  /* if in query mode and we do have enough space,
   * don't do any more parental requests but return True
   */
  if(XtWidth(tw)>=tw->tab.requiredWidth &&
     XtHeight(tw)>=tw->tab.requiredHeight){
    if(queryOnly)
      return True;
    success=True;
  }

  /* make the geometry request */
  if(tw->tab.requiredWidth!=tw->tab.preferredWidth ||
     tw->tab.requiredHeight!=tw->tab.preferredHeight) {
    XtGeometryResult result;
    XtWidgetGeometry request, return_request;
    tw->tab.preferredWidth=tw->tab.requiredWidth;
    tw->tab.preferredHeight=tw->tab.requiredHeight;

    if(XtWidth(tw)!=tw->tab.requiredWidth ||
       XtHeight(tw)!=tw->tab.requiredHeight ) {
      request.width=tw->tab.requiredWidth;
      request.height=tw->tab.requiredHeight;
      request.request_mode=CWWidth | CWHeight;
      if(queryOnly)
	request.request_mode|=XtCWQueryOnly;
      result = XtMakeGeometryRequest((Widget)tw, &request, &return_request);
      if(result==XtGeometryYes){
	if(queryOnly)
	  return True;
	success=True;
      }
      if(result==XtGeometryAlmost) {
	request=return_request;
	(void) XtMakeGeometryRequest((Widget)tw, &request, &return_request);
      }
    }
  }

  /* check the available space once again
   */
  if(XtWidth(tw)>=tw->tab.requiredWidth &&
     XtHeight(tw)>=tw->tab.requiredHeight){
    success=True;
  }
  tw->tab.actualWidth=MAX(XtWidth(tw),tw->tab.requiredWidth);
  tw->tab.actualHeight=MAX(XtHeight(tw),tw->tab.requiredHeight);

  /* panes always should fill up the whole available window space */
  if(tw->tab.paneWidth+(tw->tab.paneBorderWidth<<1)+(shadowThickness<<1)+(tw->tab.marginWidth<<1)<tw->tab.actualWidth)
    tw->tab.paneWidth=tw->tab.actualWidth-(tw->tab.paneBorderWidth<<1)-(shadowThickness<<1)-(tw->tab.marginWidth<<1);
  if(tw->tab.paneHeight+(tw->tab.paneBorderWidth<<1)+shadowThickness+(tw->tab.marginWidth<<1)<tw->tab.actualHeight-tw->tab.tabRequiredHeight)
    tw->tab.paneHeight=tw->tab.actualHeight-tw->tab.tabRequiredHeight-(tw->tab.paneBorderWidth<<1)-shadowThickness-(tw->tab.marginWidth<<1);

  /* we don't need to relayout in query mode */
  if(queryOnly)
    return success;

  ClearDecoration(tw);

  SelectTab(tw,tw->tab.selectedTab,False);

  /* now forcedly resize & position our tabs */
  for(childP=tw->composite.children,i=0;
      i<numChildren;
      childP++,i++) {
    child=*childP;
    tab = (TabConstraints)child->core.constraints;
    if(tab->tab.isTab){
      if(XtIsManaged(child))
	XtConfigureWidget(child,
			  tab->tab.tabPosition*tw->tab.cellWidth+shadowThickness+tw->tab.marginWidth,
			  shadowThickness+tw->tab.marginWidth,
			  tw->tab.tabWidth,
			  tw->tab.tabHeight,
			  tw->tab.tabBorderWidth);
    } else { /* pane */
      /* hide pane if it isn't selected */
      if(XtIsManaged(child) &&
	 ( !tw->tab.selectedTab ||
	   ((TabConstraints)tw->tab.selectedTab->core.constraints)->tab.relatedPane!=child))
	XtUnmanageChild(child);
      XtConfigureWidget(child,
			shadowThickness+tw->tab.marginWidth,
			tw->tab.tabRequiredHeight+tw->tab.marginWidth,
			tw->tab.paneWidth,
			tw->tab.paneHeight,
			tw->tab.paneBorderWidth);
    }
  }
  DrawDecoration(tw);
  return success;
}

static void ClearDecoration(tw)
     TabWidget tw;
{
  if(!XtIsRealized((Widget)tw))
    return;
  XClearWindow(XtDisplay(tw),XtWindow(tw));
}

static void DrawDecoration(tw)
     TabWidget tw;
{
  Dimension cornerRadius,shadowThickness;
  XPoint points[32];
  int nPoints,activeTabPosition;
  WidgetList childP;
  int numChildren=tw->composite.num_children,i;
  Widget child;
  TabConstraints tab;

  if(!tw->tab.tabVisible ||
     !XtIsRealized((Widget)tw))
    return;

  shadowThickness=tw->tab.shadowThickness;
  cornerRadius=shadowThickness<tw->tab.marginWidth?shadowThickness:tw->tab.marginWidth;

  /* left pane line */
  XFillRectangle(XtDisplay(tw),XtWindow(tw),tw->tab.topGC,0,tw->tab.tabRequiredHeight-shadowThickness,shadowThickness,tw->tab.actualHeight-tw->tab.tabRequiredHeight+shadowThickness);
  /* right pane line */
  XFillRectangle(XtDisplay(tw),XtWindow(tw),tw->tab.bottomGC,tw->tab.actualWidth-shadowThickness,tw->tab.tabRequiredHeight-shadowThickness,shadowThickness,tw->tab.actualHeight-tw->tab.tabRequiredHeight+shadowThickness);

  /* bottom pane line */
  nPoints=0;
  points[nPoints].x=0;points[nPoints].y=tw->tab.actualHeight;nPoints++;
  points[nPoints].x=shadowThickness;points[nPoints].y=-shadowThickness;nPoints++;
  points[nPoints].x=tw->tab.actualWidth-shadowThickness;points[nPoints].y=0;nPoints++;
  points[nPoints].x=0;points[nPoints].y=shadowThickness;nPoints++;
  XFillPolygon(XtDisplay(tw),XtWindow(tw),tw->tab.bottomGC,points,nPoints,Convex,CoordModePrevious);

  /* draw all managed tab decorations here,
   * don't bother about triangle capstyles as
   * the straight line below those will draw over it anyhow
   */
    
  for(childP=tw->composite.children,i=0;
      i<numChildren;
      childP++,i++) {
    child=*childP;
    tab = (TabConstraints)child->core.constraints;

    if(tab->tab.isTab && tab->tab.tabPosition>=0 && XtIsManaged(child)) {
      /* draw tab decoration
       * starting from bottom left moving to top right and back again
       */
	    
      nPoints=0;
      points[nPoints].x=tw->tab.cellWidth*tab->tab.tabPosition;points[nPoints].y=tw->tab.tabRequiredHeight-shadowThickness;nPoints++;
      points[nPoints].x=shadowThickness;points[nPoints].y=0;nPoints++;
      points[nPoints].x=0;points[nPoints].y=-(tw->tab.tabRequiredHeight-(shadowThickness<<1)-cornerRadius);nPoints++;
      points[nPoints].x=cornerRadius;points[nPoints].y=-cornerRadius;nPoints++;
      points[nPoints].x=tw->tab.tabWidth+(tw->tab.tabBorderWidth<<1)+(tw->tab.marginWidth<<1)-(cornerRadius<<1);points[nPoints].y=0;nPoints++;
      points[nPoints].x=0;points[nPoints].y=-shadowThickness;nPoints++;
      points[nPoints].x=-(tw->tab.tabWidth+(tw->tab.tabBorderWidth<<1)+(tw->tab.marginWidth<<1)-(cornerRadius<<1)+shadowThickness);points[nPoints].y=0;nPoints++;
      points[nPoints].x=-cornerRadius;points[nPoints].y=cornerRadius;nPoints++;
      XFillPolygon(XtDisplay(tw),XtWindow(tw),tw->tab.topGC,points,nPoints,Convex,CoordModePrevious);
	    
      /* now start drawing from the bottom right, left then towards
       * the top and back again
       */
      nPoints=0;
      points[nPoints].x=tw->tab.cellWidth*(tab->tab.tabPosition+1)-tw->tab.tabGapWidth;points[nPoints].y=tw->tab.tabRequiredHeight-(tw->tab.selectedTab!=child?shadowThickness:0);nPoints++;
      points[nPoints].x=-shadowThickness;points[nPoints].y=0;nPoints++;
      points[nPoints].x=0;points[nPoints].y=-(tw->tab.tabRequiredHeight-(shadowThickness<<1)-cornerRadius+(tw->tab.selectedTab==child?shadowThickness:0));nPoints++;
      points[nPoints].x=-cornerRadius;points[nPoints].y=-cornerRadius;nPoints++;
      points[nPoints].x=0;points[nPoints].y=-shadowThickness;nPoints++;
      points[nPoints].x=shadowThickness;points[nPoints].y=0;nPoints++;
      points[nPoints].x=cornerRadius;points[nPoints].y=cornerRadius;nPoints++;
      XFillPolygon(XtDisplay(tw),XtWindow(tw),tw->tab.bottomGC,points,nPoints,Convex,CoordModePrevious);
    }
  }
	    
  activeTabPosition=-1;
  if(tw->tab.selectedTab && XtIsManaged(tw->tab.selectedTab)) {
    TabConstraints tab=(TabConstraints)tw->tab.selectedTab->core.constraints;
    if(tab->tab.isTab)
      activeTabPosition=tab->tab.tabPosition;
  }
  /* top separator between pane & tabs */
  /* if we have an active tab, draw a line from the very left to the selected tab */
  if(activeTabPosition>0){
    XFillRectangle(XtDisplay(tw),XtWindow(tw),tw->tab.topGC,
		   0,tw->tab.tabRequiredHeight-shadowThickness,activeTabPosition*tw->tab.cellWidth+shadowThickness,shadowThickness);
  }
  /* draw the line located right to the selected tab */
  /* there won't be a right part if the selected tab is
   * the very right one and the pane has just the same width
   * as all the tabs
   */
  if(activeTabPosition<0 ||
     activeTabPosition!=tw->tab.maxTabPosition ||
     (tw->tab.maxTabPosition+1)*tw->tab.cellWidth-tw->tab.tabGapWidth!=tw->tab.actualWidth) {
    nPoints=0;
    if(activeTabPosition>=0) {
      points[nPoints].x=(activeTabPosition+1)*tw->tab.cellWidth-tw->tab.tabGapWidth;
      points[nPoints].y=tw->tab.tabRequiredHeight-shadowThickness;nPoints++;
      points[nPoints].x=-shadowThickness;points[nPoints].y=shadowThickness;nPoints++;
    } else {
      points[nPoints].x=0;points[nPoints].y=tw->tab.tabRequiredHeight-shadowThickness;nPoints++;
      points[nPoints].x=0;points[nPoints].y=shadowThickness;nPoints++;
    }
    /* if all the tabs determine the largest size,
     * draw the bottom shadow straight through
     */
    if(tw->tab.maxTabPosition>=0 && (tw->tab.maxTabPosition+1)*tw->tab.cellWidth-tw->tab.tabGapWidth==tw->tab.actualWidth) {
      points[nPoints].x=tw->tab.actualWidth-(activeTabPosition+1)*tw->tab.cellWidth+tw->tab.tabGapWidth;points[nPoints].y=0;nPoints++;
      points[nPoints].x=0;points[nPoints].y=-shadowThickness;nPoints++;
    } else {
      points[nPoints].x=tw->tab.actualWidth-(activeTabPosition+1)*tw->tab.cellWidth+tw->tab.tabGapWidth;points[nPoints].y=0;nPoints++;
      points[nPoints].x=shadowThickness;points[nPoints].y=-shadowThickness;nPoints++;
    }
    XFillPolygon(XtDisplay(tw),XtWindow(tw),tw->tab.topGC,points,nPoints,Convex,CoordModePrevious);
  }
}

static void SelectTabAction(w,event,params,num_params)
     Widget w;
     XEvent *event;
     String *params;
     Cardinal *num_params;
{
  Widget tab=w, parent;
  TabWidget tw;

  while((parent=XtParent(tab))!=NULL){
    if(XtIsSubclass(parent,tabWidgetClass)){
      tw=(TabWidget)parent;
      if(tw->tab.userSelectable)
	SelectTab(tw, tab, True);
      break;
    }
    tab=parent;
  }
}

static void GetGCs(tw)
     TabWidget tw;
{
  XtGCMask valuemask;
  XGCValues values;

  values.foreground=tw->tab.topShadowColor;
  values.background=tw->core.background_pixel;
  valuemask=GCForeground|GCBackground;
  tw->tab.topGC=XtGetGC((Widget)tw,valuemask,&values);

  values.foreground=tw->tab.bottomShadowColor;
  values.background=tw->core.background_pixel;
  valuemask=GCForeground|GCBackground;
  tw->tab.bottomGC=XtGetGC((Widget)tw,valuemask,&values);
}

static void ReleaseGCs(tw)
     TabWidget tw;
{
  XtReleaseGC( (Widget)tw, tw->tab.topGC );
  XtReleaseGC( (Widget)tw, tw->tab.bottomGC );
}

static void
ClassInitialize()
{
}

static void Initialize(req, new, args, num_args)
     Widget req, new;
     ArgList args;
     Cardinal *num_args;
{
  TabWidget tw=(TabWidget)new;

  if (XtWidth(req) <= 0) 
    XtWidth(new) = 16;
    
  if (XtHeight(req) <= 0) 
    XtHeight(new) = 16;

  GetGCs(tw);

  tw->tab.dontLayout=0;
  tw->tab.preferredWidth=tw->tab.preferredHeight=0;
}

static void 
Release(w)
     Widget w;
{
  TabWidget tw=(TabWidget)w;
  ReleaseGCs(tw);
}

/* populate a translation table
 * recursively down to all children
 */
static void PopulateTranslations(w,translations)
     Widget w;
     XtTranslations translations;
{
  XtOverrideTranslations(w,translations);
  if(XtIsComposite(w)){
    CompositeWidget cw=(CompositeWidget)w;
    WidgetList childP;
    int numChildren=cw->composite.num_children,i;
    for(childP=cw->composite.children,i=0;
	i<numChildren;
	childP++,i++)
      PopulateTranslations(*childP,translations);
  }
}

static void ChangeManaged(w)
     Widget w;
{
  TabWidget tw = (TabWidget)w;
  TabConstraints tab;
  WidgetList childP;
  int numChildren=tw->composite.num_children,i;
  Widget child;

  for(childP=tw->composite.children,i=0;
      i<numChildren;
      childP++,i++) {
    child=*childP;
    tab = (TabConstraints)child->core.constraints;

    /* set preferred size for new children */
    if(!tab->tab.preferredWidth)
      tab->tab.preferredWidth=XtWidth(child);
    if(!tab->tab.preferredHeight)
      tab->tab.preferredHeight=XtHeight(child);
    if(!tab->tab.preferredBorderWidth)
      tab->tab.preferredBorderWidth=child->core.border_width;

    /* for all tabs, override translation table with
     * tabTranslations */
    if(tab->tab.isTab && !tab->tab.hasTranslations){
      PopulateTranslations(child,tw->tab.tabTranslations);
      tab->tab.hasTranslations=True;
    }
  }

  Layout(tw,False);
}

static XtGeometryResult GeometryManager(w, request, reply)
     Widget w;
     XtWidgetGeometry *request, *reply;
{
  TabConstraints tab=(TabConstraints)w->core.constraints;
  TabWidget tw=(TabWidget)XtParent(w);
  Dimension oldWidth=tab->tab.preferredWidth, oldHeight=tab->tab.preferredHeight,
    oldBorderWidth=tab->tab.preferredBorderWidth;
  Boolean relayout;
  XtGeometryResult result;

  relayout=False;
  if(request->request_mode & CWWidth){
    tab->tab.preferredWidth=request->width;
    relayout=True;
  }
  if(request->request_mode & CWHeight){
    tab->tab.preferredHeight=request->height;
    relayout=True;
  }
  if(request->request_mode & CWBorderWidth){
    tab->tab.preferredBorderWidth=request->border_width;
    relayout=True;
  }

  if(relayout) {
    result=Layout(tw,request->request_mode & XtCWQueryOnly)?XtGeometryYes:XtGeometryNo;
    if(result!=XtGeometryYes ||
       (request->request_mode & XtCWQueryOnly)){
      tab->tab.preferredWidth=oldWidth;
      tab->tab.preferredHeight=oldHeight;
      tab->tab.preferredBorderWidth=oldBorderWidth;
      if(!(request->request_mode & XtCWQueryOnly))
	Layout(tw,False);
    }
  } else
    result=XtGeometryNo;
  return result;
}

static void Resize(w)
     Widget w;
{
  TabWidget tw=(TabWidget)w;

  Layout(tw,False);
}

static void
Redisplay(w, event, region)
     Widget w;
     XEvent *event;
     Region region;
{
  DrawDecoration((TabWidget)w);
}

static Boolean SetValues(old,request,new,args,num_args)
     Widget old,request,new;
     ArgList args;
     Cardinal *num_args;
{
  TabWidget old_tw=(TabWidget)old;
  TabWidget new_tw=(TabWidget)new;
  Boolean redisplay=False;
  Widget selectedTab;
  TabConstraints tab;
  if(old_tw->tab.foreground!=new_tw->tab.foreground ||
     old_tw->tab.topShadowColor!=new_tw->tab.topShadowColor ||
     old_tw->tab.bottomShadowColor!=new_tw->tab.bottomShadowColor){
    ReleaseGCs(old_tw);
    GetGCs(new_tw);
    redisplay=True;
  }
  if(old_tw->tab.shadowThickness!=new_tw->tab.shadowThickness){
    Layout(new_tw,False);
    redisplay=False;
  }
  if(old_tw->tab.marginWidth != new_tw->tab.marginWidth ||
     old_tw->tab.tabGapWidth != new_tw->tab.tabGapWidth) {
    Layout(new_tw,False);
    redisplay=False;
  }
  if(old_tw->tab.selectedTab != new_tw->tab.selectedTab) {
    selectedTab=new_tw->tab.selectedTab;
    new_tw->tab.selectedTab=old_tw->tab.selectedTab;
    tab=(TabConstraints)selectedTab->core.constraints;
    SelectTab(new_tw,selectedTab,True);
    if(tab->tab.preferredWidth && tab->tab.preferredHeight)
      Layout(new_tw,False);
    redisplay=False;
  }
  return redisplay;
}
    
static XtGeometryResult PreferredGeometry(w, constraints, reply)
     Widget w;
     XtWidgetGeometry *constraints, *reply;
{
  TabWidget tw=(TabWidget)w;

  if((constraints->request_mode & CWWidth) &&
     constraints->width<tw->tab.preferredWidth)
    reply->width=constraints->width;
  else
    reply->width=tw->tab.preferredWidth;

  if((constraints->request_mode & CWHeight) &&
     constraints->height<tw->tab.preferredHeight)
    reply->height=constraints->height;
  else
    reply->height=tw->tab.preferredHeight;

  reply->request_mode=CWWidth | CWHeight;

  return XtGeometryYes;
}

static int CheckRelatedPane(w,failSafeW)
     Widget w;
     Widget failSafeW;
{
  TabConstraints tab=(TabConstraints)w->core.constraints;
    
  if(tab->tab.relatedPane) {
    TabConstraints paneTab=(TabConstraints)tab->tab.relatedPane->core.constraints;
    if(XtParent(tab->tab.relatedPane)!=XtParent(w) ||
       paneTab->tab.isTab) {
      /* wrong pane specified, reset it */
      tab->tab.relatedPane=failSafeW;
      XtAppWarning(XtWidgetToApplicationContext(w),
		   "Invalid relatedPane resource specified.");
      return 0;
    }
  }
  return 1;
}

static void ConstraintInitialize(request, new, args, num_args)
     Widget request, new;
     ArgList args;
     Cardinal *num_args;
{
  TabConstraints tab=(TabConstraints)new->core.constraints;

  tab->tab.preferredWidth=tab->tab.preferredHeight=0;
  tab->tab.preferredBorderWidth=0;
  tab->tab.hasTranslations=False;

  /* do some resource checking */
  CheckRelatedPane(new,NULL);
}

static Boolean ConstraintSetValues(current, request, new, args, num_args)
     Widget current, request, new;
     ArgList args;
     Cardinal *num_args;
{
  TabConstraints ctc = (TabConstraints) current->core.constraints;
  TabConstraints ntc = (TabConstraints) new->core.constraints;
  TabWidget tw=(TabWidget)new->core.parent;

  if(ctc->tab.isTab != ntc->tab.isTab) {
    ntc->tab.isTab=ctc->tab.isTab;
    XtAppWarning(XtWidgetToApplicationContext(new),
		 "No dynamic change of isTab resource permitted.");
  }

  if(ntc->tab.isTab &&
     ctc->tab.tabPosition != ntc->tab.tabPosition ) {
    Layout(XtParent(new),False);
  }

  if(ctc->tab.relatedPane != ntc->tab.relatedPane) {
    if(CheckRelatedPane(new,ctc->tab.relatedPane)){
      tw->tab.dontLayout++;
      if(ctc->tab.relatedPane)
	XtUnmanageChild(ctc->tab.relatedPane);
      if(ntc->tab.relatedPane)
	XtManageChild(ntc->tab.relatedPane);
      tw->tab.dontLayout--;
    }
  }
    
  return False;
}
