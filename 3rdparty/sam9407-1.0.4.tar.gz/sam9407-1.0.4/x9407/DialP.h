#ifndef _DIALP_h
#define _DIALP_h

#include "Dial.h"
#include <X11/CoreP.h>

typedef struct {
  XtPointer	    extension;		/* pointer to extension record      */
} DialClassPart;

typedef struct _DialClassRec {
  CoreClassPart	core_class;
  DialClassPart	dial_class;
} DialClassRec;

extern DialClassRec dialClassRec;

typedef enum {
  DialGrabNone,
  DialGrabPointer,
} DialGrabKind;

typedef struct {
  /* resources */
  Dimension marginWidth;
  Pixel foregroundPixel;
  XFontStruct *titleFont, *labelFont;
  char *title;
  float value, minimum, maximum, step;
  XtCallbackList callbacks;
  Boolean duplexMode;

  /* user data */
  GC fgGC, bgGC, titleGC;
  GC grayGC, grayTitleGC;
  Pixmap stipple;
  DialGrabKind grab;
  unsigned whichButton;
} DialPart;

typedef struct _DialRec {
  CorePart core;
  DialPart dial;
} DialRec;

#endif /* _DIALP_H */
