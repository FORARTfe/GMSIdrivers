#ifndef _X9407_HH
#define _X9407_HH

#include <string>
#include <X11/Intrinsic.h>
#include "utils.hh"
#include "device.hh"

using namespace std;

class Application;

extern "C" char *XsraSelFile(Widget toplevel, char *prompt, char *init_path, char **saved_path, int hide_flag, int (*show_entry)());

class ApplicationEvent : public Event {
public:
  ApplicationEvent::ApplicationEvent(Application *aAppl, Type aType);
  virtual void triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName);
  virtual void triggerDeviceClosed(int cardNr);
private:
  Application *appl;
};

class Application {
  friend class ApplicationEvent;
public:
  struct Resources {
    int card, adjustRelatedButton, errorMsgTimeout, syncWriteDelay;
    int pollValueInterval, pollPeakMeterInterval, verifyChannelOwnerDelay;
    String syncWithFile;
    String applTitle, fsLoadTitle, fsSaveTitle, fsFirmTitle, fsSBankTitle;
    String cardNone, noFirmware, noOwner;
    /* several error messages */
    String errIncompatibleApi, errNoCardSelected, errDeviceNotUsable;
    String errQueryApi, errQueryDriver, errQuerySBank, errQueryMixer, errSetMixer;
    String errReadMixer, errQueryPeakMeter, errQueryChannelOwner;
    String errOpenInputFile, errOpenOutputFile, errOpenDev;
    String errOpenFirm, errLoadFirm;
    String errOpenSBank, errLoadSBank;
    String errUnloadSBank, errSBankPrioChg;
  };

  Application(int aArgc, char **aArgv);
  ~Application();
  void build();
  void mainLoop();
  void fatal(int perr, ...);
  void error(int perr, ...);
  void triggerDelayedSaveSyncFile(void);

  Resources resources;
  Device device;

  XtAppContext appContext;
  Widget top, classes, visiblePane;

private:
  static void quitAction(Widget w, XEvent *event, String *params, Cardinal *numParams);
  static void dismissAction(Widget w, XEvent *event, String *params, Cardinal *numParams);
  static void copyrightCallback(Widget w, XtPointer closure, XtPointer callData);
  static void quitCallback(Widget w, XtPointer closure, XtPointer callData);
  static void dismissCallback(Widget w, XtPointer closure, XtPointer callData);
  static void loadCallback(Widget w, XtPointer closure, XtPointer callData);
  static void saveCallback(Widget w, XtPointer closure, XtPointer callData);
  static void eraseMessage(XtPointer closure, XtIntervalId *id);
  static void syncFileSaveCB(XtPointer closure, XtIntervalId *id);

  void getLoadSaveDefaultFileName(string &dest);
  void getSyncFileName(string &dest);
  void loadSyncFile();
  void saveSyncFileIfModified();

  static XContext thisPtrContext;
  static Menu fileMenu[];
  static Menu mainMenu[];
  static XrmOptionDescRec x9407Options[];
  static XtResource x9407Resources[];
  static XtActionsRec x9407Actions[];
  static String fallbackResources[];

  int argc;
  char **argv;
  Boolean quitMainLoopRequested;

  Widget msg, copyright;
  Pixmap iconPixmap, iconMask;
  XtIntervalId msgTimeoutId, syncWriteDelayId;
  String fsConfigPath;
  Boolean mixerValuesNotSaved;
  string title;

  ApplicationEvent fwChangedEvent;
  ApplicationEvent devClosedEvent;
};

#endif /* _X9407_HH */
