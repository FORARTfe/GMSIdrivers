/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Xmu/Xmu.h>

#include "PeakMeterP.h"

#ifndef XtX
#define XtX(w)	   ((w)->core.x)
#endif

#ifndef XtY
#define XtY(w)	   ((w)->core.y)
#endif

#ifndef XtWidth
#define XtWidth(w) ((w)->core.width)
#endif

#ifndef XtHeight
#define XtHeight(w) ((w)->core.height)
#endif

#ifndef XtDepth
#define XtDepth(w) ((w)->core.depth)
#endif

#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

static void Initialize();
static void Release();
static void Redisplay();
static Boolean SetValues();
static XtGeometryResult QueryGeometry();

static XtResource resources[] = {
  {
    XtNforeground, XtCForeground,
    XtRPixel, sizeof(Pixel),
    XtOffset(PeakMeterWidget, peakMeter.foregroundPixel),
    XtRString, (XtPointer)"Black"
  },
  {
    XtNmarginWidth, XtCMarginWidth,
    XtRDimension, sizeof(Dimension),
    XtOffset(PeakMeterWidget, peakMeter.marginWidth),
    XtRImmediate, (XtPointer)2
  },
  {
    XtNmeterWidth, XtCMeterWidth,
    XtRDimension, sizeof(Dimension),
    XtOffset(PeakMeterWidget, peakMeter.meterWidth),
    XtRImmediate, (XtPointer)5
  },
  {
    XtNmeterColor, XtCMeterColor,
    XtRPixel, sizeof(Pixel),
    XtOffset(PeakMeterWidget, peakMeter.meterPixel),
    XtRString, (XtPointer)"Black"
  },
  {
    XtNtroughColor, XtCTroughColor,
    XtRPixel, sizeof(Pixel),
    XtOffset(PeakMeterWidget, peakMeter.troughPixel),
    XtRString, (XtPointer)XtDefaultBackground
  },
  {
    XtNfont, XtCFont,
    XtRFontStruct, sizeof(XFontStruct *),
    XtOffset(PeakMeterWidget, peakMeter.font),
    XtRString, XtDefaultFont
  },
  {
    XtNlabel, XtCLabel,
    XtRString, sizeof(String),
    XtOffset(PeakMeterWidget, peakMeter.label),
    XtRString, NULL
  },
  {
    XtNpercentage, XtCPercentage,
    XtRInt, sizeof(int),
    XtOffset(PeakMeterWidget, peakMeter.percentage),
    XtRImmediate, (XtPointer)0
  },
};

static XtActionsRec actions[] =
{
};

static char translations[] ="\
";

PeakMeterClassRec peakMeterClassRec = {
  { /* core fields */
    /* superclass		*/	(WidgetClass) &widgetClassRec,
    /* class_name		*/	"PeakMeter",
    /* widget_size		*/	sizeof(PeakMeterRec),
    /* class_initialize		*/	NULL,
    /* class_part_initialize	*/	NULL,
    /* class_inited		*/	FALSE,
    /* initialize		*/	Initialize,
    /* initialize_hook		*/	NULL,
    /* realize			*/	XtInheritRealize,
    /* actions			*/	actions,
    /* num_actions		*/	XtNumber(actions),
    /* resources		*/	resources,
    /* num_resources		*/	XtNumber(resources),
    /* xrm_class		*/	NULLQUARK,
    /* compress_motion		*/	TRUE,
    /* compress_exposure	*/	TRUE,
    /* compress_enterleave	*/	TRUE,
    /* visible_interest		*/	FALSE,
    /* destroy			*/	Release,
    /* resize			*/	NULL,
    /* expose			*/	Redisplay,
    /* set_values		*/	SetValues,
    /* set_values_hook		*/	NULL,
    /* set_values_almost	*/	XtInheritSetValuesAlmost,
    /* get_values_hook		*/	NULL,
    /* accept_focus		*/	NULL,
    /* version			*/	XtVersion,
    /* callback_private		*/	NULL,
    /* tm_table			*/	translations,
    /* query_geometry		*/	QueryGeometry,
    /* display_accelerator	*/	XtInheritDisplayAccelerator,
    /* extension		*/	NULL
  },
  { /* peakMeter fields */
    /* extension		*/	NULL
  }
};

WidgetClass peakMeterWidgetClass = (WidgetClass)&peakMeterClassRec;

static void Redraw(dw, withLabel)
     PeakMeterWidget dw;
     int withLabel;
{
  Display *dpy;
  Window win;
  int x, y, separation;
  int width, height, labelWidth, labelHeight, lines, len;
  char *cp, *cp2, savedChar=0;

  if(!XtIsRealized((Widget)dw))
    return;

  lines=0;
  for(cp=dw->peakMeter.label; cp;) {
    lines++;
    if((cp=strchr(cp, '\n')))
      cp++;
  }

  dpy=XtDisplay((Widget)dw);
  win=XtWindow((Widget)dw);

  labelHeight=dw->peakMeter.font->max_bounds.ascent+dw->peakMeter.font->max_bounds.descent;
  width=dw->peakMeter.meterWidth;
  x=(XtWidth(dw)-width)/2;
  height=XtHeight(dw)-3*dw->peakMeter.marginWidth-labelHeight*lines;
  separation=height-height*dw->peakMeter.percentage/100;

  XFillRectangle(dpy, win, dw->peakMeter.troughGC,
		 x, dw->peakMeter.marginWidth,
		 width, separation);

  XFillRectangle(dpy, win, dw->peakMeter.meterGC,
		 x, dw->peakMeter.marginWidth+separation,
		 width, height-separation);

  if(withLabel && dw->peakMeter.label) {
    y=XtHeight(dw)-dw->peakMeter.marginWidth-(lines-1)*labelHeight;
    for(cp=dw->peakMeter.label; cp;) {
      if((cp2=strchr(cp, '\n'))) {
	savedChar=*cp2;
	*cp2=0;
	len=cp2-cp;
      } else
	len=strlen(cp);
      labelWidth=XTextWidth(dw->peakMeter.font, cp, len);
      XDrawString(dpy, win, dw->peakMeter.labelGC,
		  (XtWidth(dw)-labelWidth)/2,
		  y-dw->peakMeter.font->max_bounds.descent,
		  cp, len);
      if(cp2)
	*cp2++=savedChar;
      cp=cp2;
      y+=labelHeight;
    }
  }
}

static void GetGCs(dw)
     PeakMeterWidget dw;
{
  XtGCMask valuemask;
  XGCValues values;

  values.foreground=dw->peakMeter.meterPixel;
  values.background=dw->core.background_pixel;
  valuemask=GCForeground|GCBackground;
  dw->peakMeter.meterGC=XtGetGC((Widget)dw, valuemask, &values);

  values.foreground=dw->peakMeter.troughPixel;
  dw->peakMeter.troughGC=XtGetGC((Widget)dw, valuemask, &values);

  values.foreground=dw->peakMeter.foregroundPixel;
  values.font=dw->peakMeter.font->fid;
  valuemask|=GCFont;
  dw->peakMeter.labelGC=XtGetGC((Widget)dw, valuemask, &values);
}

static void ReleaseGCs(dw)
     PeakMeterWidget dw;
{
  XtReleaseGC((Widget)dw, dw->peakMeter.labelGC);
  XtReleaseGC((Widget)dw, dw->peakMeter.meterGC);
  XtReleaseGC((Widget)dw, dw->peakMeter.troughGC);
}

static void Initialize(req, new, args, num_args)
     Widget req, new;
     ArgList args;
     Cardinal *num_args;
{
  PeakMeterWidget dw=(PeakMeterWidget)new;

  if(XtWidth(req)<=0) 
    XtWidth(new)=16;
  
  if(XtHeight(req)<=0) 
    XtHeight(new)=16;

  GetGCs(dw);
}

static void Release(w)
     Widget w;
{
  PeakMeterWidget dw=(PeakMeterWidget)w;

  ReleaseGCs(dw);
}

static void Redisplay(w, event, region)
     Widget w;
     XEvent *event;
     Region region;
{
  PeakMeterWidget dw=(PeakMeterWidget)w;
  XRectangle rect;

  if(XtIsRealized(w)) {
    XClipBox(region, &rect);
    XClearArea(XtDisplay(w), XtWindow(w), rect.x, rect.y, rect.width, rect.height, False);
    Redraw(dw, 1);
  }
}

static Boolean SetValues(old,request,new,args,num_args)
     Widget old,request,new;
     ArgList args;
     Cardinal *num_args;
{
  PeakMeterWidget old_dw=(PeakMeterWidget)old;
  PeakMeterWidget new_dw=(PeakMeterWidget)new;
  Boolean redisplay=False;

  if(old_dw->peakMeter.foregroundPixel!=new_dw->peakMeter.foregroundPixel ||
     old_dw->peakMeter.meterPixel!=new_dw->peakMeter.meterPixel ||
     old_dw->peakMeter.troughPixel!=new_dw->peakMeter.troughPixel ||
     old_dw->core.background_pixel!=new_dw->core.background_pixel ||
     old_dw->peakMeter.font!=new_dw->peakMeter.font) {
    ReleaseGCs(old_dw);
    GetGCs(new_dw);
    redisplay=True;
  }

  if(old_dw->core.sensitive!=new_dw->core.sensitive ||
     old_dw->peakMeter.marginWidth!=new_dw->peakMeter.marginWidth ||
     old_dw->peakMeter.meterWidth!=new_dw->peakMeter.meterWidth ||
     old_dw->peakMeter.label!=new_dw->peakMeter.label) {
    redisplay=True;
  }

  /* if value changed, redraw without erasing */
  if(old_dw->peakMeter.percentage!=new_dw->peakMeter.percentage)
    Redraw(new_dw, 0);

  return redisplay;
}

static XtGeometryResult QueryGeometry(w, intended, preferred)
     Widget w;
     XtWidgetGeometry *intended, *preferred; 
{
  PeakMeterWidget dw=(PeakMeterWidget)w;
  int maxLabelWidth, labelHeight, lines;
  char *cp, *cp2, savedChar=0;

  lines=0;
  maxLabelWidth=0;
  for(cp=dw->peakMeter.label; cp;) {
    lines++;
    if((cp2=strchr(cp, '\n'))) {
      savedChar=*cp2;
      *cp2=0;
    }
    maxLabelWidth=MAX(maxLabelWidth, XTextWidth(dw->peakMeter.font, cp, strlen(cp)));
    if(cp2)
      *cp2++=savedChar;
    cp=cp2;
  }

  labelHeight=dw->peakMeter.font->max_bounds.ascent+dw->peakMeter.font->max_bounds.descent;

  preferred->request_mode=CWWidth|CWHeight;
  preferred->width=MAX(dw->peakMeter.meterWidth, maxLabelWidth)+2*dw->peakMeter.marginWidth;
  preferred->height=4*dw->peakMeter.meterWidth+3*dw->peakMeter.marginWidth+lines*labelHeight;

  if(((intended->request_mode& (CWWidth|CWHeight)) == (CWWidth|CWHeight)) &&
     intended->width == preferred->width &&
     intended->height == preferred->height)
    return XtGeometryYes;
  
  if(preferred->width==dw->core.width &&
     preferred->height==dw->core.height)
    return XtGeometryNo;
  
  return XtGeometryAlmost;
}
