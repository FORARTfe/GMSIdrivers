#ifndef _CONTROLS_HH
#define _CONTROLS_HH

#include <string>
#include <map>

#include <X11/Intrinsic.h>

#include "device.hh"

using namespace std;

class Api;
class ReadOnly;
class Dial;
class Toggle;
class PeakMeter;
class ChannelOwner;
class RadioBox;
struct _DialCallbackInfo;

class Control {
public:
  Control(Control *aParent, char *aName);
  virtual ~Control();
  virtual void build(Widget w);
  virtual void setSensitive(Boolean enable);
  virtual void poll();
  virtual Boolean needsPollValue();
  virtual Boolean needsPollPeakMeter();
protected:
  Control *parent;
  char *name;
  Control *next;
  Control *children;
  Application *appl;
};

class ApiEvent : public Event {
public:
  ApiEvent(Api *aApi, Type aType) : Event(aType) { api=aApi; }
  virtual void triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName);
  virtual void triggerDeviceClosed(int cardNr);
private:
  Api *api;
};

class Api : public Control {
public:
  Api(Application *aAppl, char *aName, int aApiClass);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void fwChanged(int currentApiClass);

private:
  int apiClass;
  ApiEvent fwChangedEvent;
  ApiEvent devClosedEvent;
  Widget wTab, wPane;
};

class Group : public Control {
public:
  Group(Api *aApi, char *aName, int aTabPosition);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
private:
  int tabPosition;
  Widget wTab, wPane;
};

class Pane : public Control {
public:
  Pane(Group *aGroup, char *aName, int aTabPosition);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  virtual void changedVisibility(Boolean visible);
private:
  static void paneVisibleAction(Widget w, XEvent *event, String *params, Cardinal *numParams);
  static XContext thisPtrContext;

  int tabPosition;
protected:
  Widget wTab, wPane;
private:
  static void pollValues(XtPointer closure, XtIntervalId *id);
  XtIntervalId pollValueId;
};

class Label : public Control {
public:
  Label(Pane *aPane, char *aName);
  virtual void build(Widget parent);
private:
  Widget wLabel;
};

class ReadOnlyEvent : public Event {
public:
  ReadOnlyEvent(ReadOnly *aReadOnly, Type aType, int aId, int aAddr, int aChannel)
    : Event(aType, aId, aAddr, aChannel) { readOnly=aReadOnly; }
  virtual void triggerMixerValue(int value);
  virtual void triggerAudioValue(int value);
private:
  ReadOnly *readOnly;
};

class ReadOnly : public Control {
public:
  ReadOnly(Pane *aPane, char *aName, int aId, int aAddr, int aChannel, Boolean aNeedsPolling);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  virtual void poll();
  virtual Boolean needsPollValue();
  void translate(int value, char *resourceName);
  void eventSetDisplay(int aValue);
private:
  Widget wLabel;
  int id, addr, channel;
  Boolean needsPolling, supported;
  map<int, string, less<int> > valueResourceMapping;
  ReadOnlyEvent event;
};

class DialEvent : public Event {
public:
  DialEvent(Dial *aDial, Type aType, int aId, int aAddr, int aChannel)
    : Event(aType, aId, aAddr, aChannel) { dial=aDial; }
  virtual void triggerMixerValue(int value);
  virtual void triggerAudioValue(int value);
private:
  Dial *dial;
};

class Dial : public Control {
public:
  Dial(Pane *aPane, char *aName, Dial *aRelated,
       int aId, int aAddr, int aChannel,
       float aMin, float aMax, float aStep=1, float aMultiply=1, float aAdd=0);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void adjusted(int checkRelated, _DialCallbackInfo *info);
  void eventSetDisplay(int aValue);
private:
  static void adjustedCallback(Widget w, XtPointer closure, XtPointer callData);
  Dial *related;
  Widget wDial;
  int id, addr, channel;
  float min, max, step, multiply, add;
  DialEvent event;
};

class ToggleEvent : public Event {
public:
  ToggleEvent(Toggle *aToggle, Type aType, int aId, int aAddr, int aChannel)
    : Event(aType, aId, aAddr, aChannel) { toggle=aToggle; }
  virtual void triggerMixerValue(int value);
  virtual void triggerAudioValue(int value);
private:
  Toggle *toggle;
};

class Toggle : public Control {
public:
  Toggle(Pane *aPane, char *aName,
	 int aId, int aAddr, int aChannel,
	 int aOnValue, int aOffValue);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void toggled(Boolean on);
  void eventSetDisplay(int aValue);
private:
  static void toggledCallback(Widget w, XtPointer closure, XtPointer callData);
  Widget wToggle;
  int id, addr, channel;
  int onValue, offValue;
  ToggleEvent event;
};

class PeakMeterEvent : public Event {
public:
  PeakMeterEvent(PeakMeter *aPeakMeter)
    : Event(PeakMeterChanged) { peakMeter=aPeakMeter; }
  virtual void triggerPeakMeter(unsigned short *tbl);
private:
  PeakMeter *peakMeter;
};

class PeakMeter : public Control {
public:
  PeakMeter(Pane *aPane, char *aName,
	    int aOfs, int aMax=0xFFFF);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  virtual Boolean needsPollPeakMeter();
  void eventSetDisplay(unsigned short *tbl);
private:
  Widget wPeakMeter;
  int ofs, max;
  PeakMeterEvent event;
};

class ChannelOwnerEvent : public Event {
public:
  ChannelOwnerEvent(ChannelOwner *aChannelOwner)
    : Event(ChannelOwnerChanged) { channelOwner=aChannelOwner; }
  virtual void triggerChannelOwner(int *pids);
private:
  ChannelOwner *channelOwner;
};

class ChannelOwner : public Control {
public:
  ChannelOwner(Pane *aPane, char *aName,
	       int aChannel);
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void eventSetDisplay(int *pids);
private:
  Widget wOwner;
  int channel;
  ChannelOwnerEvent event;
};

class RadioBoxEvent : public Event {
public:
  RadioBoxEvent(RadioBox *aRadioBox, Type aType, int aId, int aAddr, int aChannel)
    : Event(aType, aId, aAddr, aChannel) { radioBox=aRadioBox; }
  virtual void triggerMixerValue(int value);
  virtual void triggerAudioValue(int value);
private:
  RadioBox *radioBox;
};

class RadioBox : public Control {
public:
  RadioBox(Pane *aPane, char *aName,
	      int aId, int aAddr, int aChannel,
	      int aRows, int aValueStart);
  virtual ~RadioBox();
  virtual void build(Widget parent);
  virtual void setSensitive(Boolean enable);
  void toggled(int row);
  void eventSetDisplay(int aValue);
private:
  static void toggledCallback(Widget w, XtPointer closure, XtPointer callData);
  Widget wBox, wTitle, *wToggles;
  int id, addr, channel;
  int rows, valueStart, currentRow;
  RadioBoxEvent event;
};

#endif /* _CONTROLS_HH */
