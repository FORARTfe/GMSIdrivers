/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "Tab.h"
#include "Layout.h"
#include "Dial.h"
#include "PeakMeter.h"

#include "../kernel/sam9407.h"
#include "x9407.hh"
#include "controls.hh"

#include XAW_HEADER(Label.h)
#include XAW_HEADER(Command.h)
#include XAW_HEADER(Toggle.h)
#include XAW_HEADER(List.h)
#include XAW_HEADER(AsciiText.h)

Control::Control(Control *aParent, char *aName)
{
  parent=aParent;
  name=aName;
  if(parent) {
    appl=parent->appl;
    next=parent->children;
    parent->children=this;
  } else {
    appl=NULL;
    next=NULL;
  }
  children=NULL;
}

Control::~Control()
{
}

void Control::build(Widget w)
{
  Control *child;

  for(child=children; child; child=child->next)
    child->build(w);
}

void Control::setSensitive(Boolean enable)
{
  Control *child;

  for(child=children; child; child=child->next)
    child->setSensitive(enable);
}

void Control::poll()
{
  Control *child;

  for(child=children; child; child=child->next)
    child->poll();
}

Boolean Control::needsPollValue()
{
  Control *child;

  for(child=children; child; child=child->next)
    if(child->needsPollValue())
      return True;

  return False;
}

Boolean Control::needsPollPeakMeter()
{
  Control *child;

  for(child=children; child; child=child->next)
    if(child->needsPollPeakMeter())
      return True;

  return False;
}

void ApiEvent::triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName)
{
  api->fwChanged(apiClass);
}

void ApiEvent::triggerDeviceClosed(int cardNr)
{
  api->fwChanged(SAM_API_CLASS_NONE);
}

Api::Api(Application *aAppl, char *aName, int aApiClass)
  : Control(NULL, aName),
    fwChangedEvent(this, Event::FirmwareChanged),
    devClosedEvent(this, Event::DeviceClosed)
{
  apiClass=aApiClass;
  wTab=wPane=NULL;
  appl=aAppl;

  appl->device.setApiSupported(apiClass);

  fwChangedEvent.subscribe(&appl->device);
  devClosedEvent.subscribe(&appl->device);
}

void Api::build(Widget parent)
{
  static int tabPosition;
  char buf[256];

  if(wPane)
    return;

  wPane=XtVaCreateWidget(name, tabWidgetClass, parent,
			 XtNisTab, False,
			 NULL);
  sprintf(buf, "lbl_%s", name);
  wTab=XtVaCreateWidget(buf, labelWidgetClass, parent,
			XtNisTab, True,
			XtNrelatedPane, wPane,
			XtNtabPosition, tabPosition++,
			XtNlabel, name,
			NULL);

  Control::build(wPane);

  if(XtIsRealized(appl->top)) {
    XtRealizeWidget(wPane);
    XtRealizeWidget(wTab);
  }
}

void Api::setSensitive(Boolean enable)
{
  if(enable)
    XtVaSetValues(appl->classes,
		  XtNselectedTab, wTab,
		  NULL);

  Control::setSensitive(enable);
}

void Api::fwChanged(int currentApiClass)
{
  if(currentApiClass==apiClass) {
    build(appl->classes);
    setSensitive(True);
  } else
    setSensitive(False);
}

Group::Group(Api *aApi, char *aName, int aTabPosition)
  : Control(aApi, aName)
{
  tabPosition=aTabPosition;
  wTab=wPane=NULL;
}

void Group::build(Widget parent)
{
  char buf[256];

  if(wPane)
    return;

  sprintf(buf, "pane_%s", name);
  wPane=XtVaCreateWidget(buf, tabWidgetClass, parent,
			 XtNisTab, False,
			 NULL);
  sprintf(buf, "tab_%s", name);
  wTab=XtVaCreateManagedWidget(buf, labelWidgetClass, parent,
			       XtNisTab, True,
			       XtNrelatedPane, wPane,
			       XtNtabPosition, tabPosition,
			       NULL);

  Control::build(wPane);
}

void Group::setSensitive(Boolean enable)
{
  if(wTab && tabPosition==0)
    XtVaSetValues(XtParent(wTab),
		  XtNselectedTab, wTab,
		  NULL);

  Control::setSensitive(enable);
}

XContext Pane::thisPtrContext;

Pane::Pane(Group *aGroup, char *aName, int aTabPosition)
  : Control(aGroup, aName)
{
  tabPosition=aTabPosition;
  wTab=wPane=NULL;
  pollValueId=0;
}

void Pane::build(Widget parent)
{
  static int classInitialized;
  static XtActionsRec actions[]=
  {
    { "paneVisible", paneVisibleAction },
  };
  static char paneTranslations[]="\
<VisibilityNotify>:	paneVisible()\n\
";

  char buf[256];

  if(wPane)
    return;

  if(!classInitialized) {
    XtAppAddActions(appl->appContext, actions, XtNumber(actions));
    classInitialized=1;
  }

  sprintf(buf, "pane_%s", name);
  wPane=XtVaCreateWidget(buf, layoutWidgetClass, parent,
			 XtNisTab, False,
			 NULL);
  Utils::saveAttachment(wPane, thisPtrContext, (XPointer)this);
  XtOverrideTranslations(wPane,
			 XtParseTranslationTable(paneTranslations));
  sprintf(buf, "tab_%s", name);
  wTab=XtVaCreateManagedWidget(buf, labelWidgetClass, parent,
			       XtNisTab, True,
			       XtNrelatedPane, wPane,
			       XtNtabPosition, tabPosition,
			       NULL);

  Control::build(wPane);
}

void Pane::setSensitive(Boolean enable)
{
  if(wTab && tabPosition==0)
    XtVaSetValues(XtParent(wTab),
		  XtNselectedTab, wTab,
		  NULL);

  Control::setSensitive(enable);
}

void Pane::pollValues(XtPointer closure, XtIntervalId *id)
{
  Pane *pane=(Pane *)closure;

  pane->pollValueId=0;
  pane->poll();

  if(!pane->pollValueId)
    pane->pollValueId=XtAppAddTimeOut(pane->appl->appContext, pane->appl->resources.pollValueInterval, pollValues, pane);
}

void Pane::changedVisibility(Boolean visible)
{
  if(visible) {
    if(!pollValueId && needsPollValue()) {
      poll();
      pollValueId=XtAppAddTimeOut(appl->appContext, appl->resources.pollValueInterval, pollValues, this);
    }
    if(needsPollPeakMeter())
      appl->device.startPollPeakMeter();
  } else {
    if(pollValueId) {
      XtRemoveTimeOut(pollValueId);
      pollValueId=0;
    }
    appl->device.stopPollPeakMeter();
  }
}

void Pane::paneVisibleAction(Widget w, XEvent *event, String *params, Cardinal *numParams)
{
  Pane *pane=(Pane *)Utils::findAttachment(w, thisPtrContext);
  Pane *oldPane;

  if(pane) {
    if(pane->appl->visiblePane==w)
      return;

    if(pane->appl->visiblePane) {
      oldPane=(Pane *)Utils::findAttachment(pane->appl->visiblePane, thisPtrContext);
      if(oldPane)
	oldPane->changedVisibility(False);
    }
    pane->changedVisibility(True);
    pane->appl->visiblePane=w;
  }
}

Label::Label(Pane *aPane, char *aName)
  : Control(aPane, aName)
{
  wLabel=NULL;
}

void Label::build(Widget parent)
{
  if(wLabel)
    return;

  wLabel=XtVaCreateManagedWidget(name, labelWidgetClass, parent,
				 NULL);

  Control::build(parent);
}

void ReadOnlyEvent::triggerMixerValue(int value)
{
  readOnly->eventSetDisplay(value);
}

void ReadOnlyEvent::triggerAudioValue(int value)
{
  readOnly->eventSetDisplay(value);
}

ReadOnly::ReadOnly(Pane *aPane, char *aName,
		   int aId, int aAddr, int aChannel, Boolean aNeedsPolling)
  : Control(aPane, aName),
    event(this, aChannel>=0 ? Event::AudioValue : Event::MixerValue,
	  aId, aAddr, aChannel)
{
  wLabel=NULL;
  id=aId;
  addr=aAddr;
  channel=aChannel;
  needsPolling=aNeedsPolling;
  supported=False;
}

void ReadOnly::build(Widget parent)
{
  if(wLabel)
    return;

  wLabel=XtVaCreateManagedWidget(name, labelWidgetClass, parent,
				 NULL);

  Control::build(parent);
}

void ReadOnly::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

void ReadOnly::poll()
{
  if(supported)
    appl->device.poll(id, addr, channel);
}

Boolean ReadOnly::needsPollValue()
{
  return needsPolling && supported;
}

void ReadOnly::translate(int value, char *resourceName)
{
  string *strP;

  strP=&valueResourceMapping[value];
  *strP=resourceName;
}

void ReadOnly::eventSetDisplay(int aValue)
{
  char *resourceName, *label;

  supported=aValue>=0;
  if(supported && valueResourceMapping.count(aValue))
    resourceName=(char *)valueResourceMapping[aValue].c_str();
  else
    resourceName="unknown";
  label=Utils::getStringSubResource(wLabel, resourceName, "Value");
  if(!label)
    label="";
  XtVaSetValues(wLabel,
		XtNsensitive, supported,
		XtNlabel, label,
		NULL);
}

void DialEvent::triggerMixerValue(int value)
{
  dial->eventSetDisplay(value);
}

void DialEvent::triggerAudioValue(int value)
{
  dial->eventSetDisplay(value);
}

Dial::Dial(Pane *aPane, char *aName, Dial *aRelated,
	   int aId, int aAddr, int aChannel,
	   float aMin, float aMax, float aStep, float aMultiply, float aAdd)
  : Control(aPane, aName),
    event(this, aChannel>=0 ? Event::AudioValue : Event::MixerValue,
	  aId, aAddr, aChannel)
{
  related=aRelated;
  if(related)
    related->related=this;
  id=aId;
  addr=aAddr;
  channel=aChannel;
  min=aMin;
  max=aMax;
  step=aStep;
  multiply=aMultiply;
  add=aAdd;
  wDial=NULL;
}

void Dial::adjustedCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Dial *dial=(Dial *)closure;

  dial->adjusted(1, (DialCallbackInfo *)callData);
}

void Dial::adjusted(int checkRelated, DialCallbackInfo *info)
{
  int value;

  value=(int)(info->value*multiply+add);
  appl->device.adjust(id, addr, channel, value);
  if(checkRelated && related && info->button==(unsigned)appl->resources.adjustRelatedButton)
    related->adjusted(0, info);
}

void Dial::build(Widget parent)
{
  if(wDial)
    return;

  wDial=XtVaCreateManagedWidget(name, dialWidgetClass, parent,
				XtNduplexMode, True,
				XtNminimum, *(unsigned *)&min,
				XtNmaximum, *(unsigned *)&max,
				XtNstep, *(unsigned *)&step,
				NULL);
  XtAddCallback(wDial, XtNcallback, adjustedCallback, this);

  Control::build(parent);
}

void Dial::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

void Dial::eventSetDisplay(int aValue)
{
  float value;

  if(aValue>=0) {
    value=((double)aValue-add)/multiply;
    XtVaSetValues(wDial,
		  XtNsensitive, True,
		  XtNvalue, *(unsigned *)&value,
		  NULL);
  } else
    XtVaSetValues(wDial,
		  XtNsensitive, False,
		  XtNvalue, 0,
		  NULL);
}

void ToggleEvent::triggerMixerValue(int value)
{
  toggle->eventSetDisplay(value);
}

void ToggleEvent::triggerAudioValue(int value)
{
  toggle->eventSetDisplay(value);
}

Toggle::Toggle(Pane *aPane, char *aName,
	       int aId, int aAddr, int aChannel,
	       int aOnValue, int aOffValue)
  : Control(aPane, aName),
    event(this, aChannel>=0 ? Event::AudioValue : Event::MixerValue,
	  aId, aAddr, aChannel)
{
  id=aId;
  addr=aAddr;
  channel=aChannel;
  onValue=aOnValue;
  offValue=aOffValue;
  wToggle=NULL;
}

void Toggle::toggledCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Toggle *toggle=(Toggle *)closure;

  /* value changes are reported from device
   * so switch back toggle state
   */
  XtVaSetValues(toggle->wToggle,
		XtNstate, !callData,
		NULL);

  toggle->toggled((Boolean)callData);
}

void Toggle::toggled(Boolean on)
{
  int value;

  if(on)
    value=onValue;
  else
    value=offValue;

  if(value>=0)
    appl->device.adjust(id, addr, channel, value);
}

void Toggle::build(Widget parent)
{
  if(wToggle)
    return;

  wToggle=XtVaCreateManagedWidget(name, toggleWidgetClass, parent,
				  NULL);
  XtAddCallback(wToggle, XtNcallback, toggledCallback, this);

  Control::build(parent);
}

void Toggle::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

void Toggle::eventSetDisplay(int aValue)
{
  if(aValue>=0) {
    XtVaSetValues(wToggle,
		  XtNsensitive, True,
		  XtNstate, aValue==onValue,
		  NULL);
  } else
    XtVaSetValues(wToggle,
		  XtNsensitive, False,
		  XtNstate, 0,
		  NULL);
}

void PeakMeterEvent::triggerPeakMeter(unsigned short *tbl)
{
  peakMeter->eventSetDisplay(tbl);
}

PeakMeter::PeakMeter(Pane *aPane, char *aName,
		     int aOfs, int aMax)
  : Control(aPane, aName),
    event(this)
{
  ofs=aOfs;
  max=aMax;
  wPeakMeter=NULL;
}

void PeakMeter::build(Widget parent)
{
  if(wPeakMeter)
    return;

  wPeakMeter=XtVaCreateManagedWidget(name, peakMeterWidgetClass, parent,
				     NULL);

  Control::build(parent);
}

void PeakMeter::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

Boolean PeakMeter::needsPollPeakMeter()
{
  return True;
}

void PeakMeter::eventSetDisplay(unsigned short *tbl)
{
  XtVaSetValues(wPeakMeter,
		XtNpercentage, 100*tbl[ofs]/max,
		NULL);
}

void ChannelOwnerEvent::triggerChannelOwner(int *pids)
{
  channelOwner->eventSetDisplay(pids);
}

ChannelOwner::ChannelOwner(Pane *aPane, char *aName,
		     int aChannel)
  : Control(aPane, aName),
    event(this)
{
  channel=aChannel;
  wOwner=NULL;
}

void ChannelOwner::build(Widget parent)
{
  if(wOwner)
    return;

  wOwner=XtVaCreateManagedWidget(name, labelWidgetClass, parent,
				 XtNlabel, "",
				 NULL);

  Control::build(parent);
}

void ChannelOwner::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

void ChannelOwner::eventSetDisplay(int *pids)
{
  char buf[256];
  int fd, n;
  string str;

  if(!pids[channel]) {
    XtVaSetValues(wOwner,
		  XtNlabel, appl->resources.noOwner,
		  NULL);
    return;
  }

  sprintf(buf, "/proc/%d/cmdline", pids[channel]);
  if((fd=open(buf, O_RDONLY))>=0) {
    if((n=read(fd, buf, sizeof(buf)-1))>=0) {
      buf[n]=0;
      str+=buf;
      str+=' ';
    }
    close(fd);
  }
  sprintf(buf, "[%d]", pids[channel]);
  str+=buf;

  XtVaSetValues(wOwner,
		XtNlabel, str.c_str(),
		NULL);
}

void RadioBoxEvent::triggerMixerValue(int value)
{
  radioBox->eventSetDisplay(value);
}

void RadioBoxEvent::triggerAudioValue(int value)
{
  radioBox->eventSetDisplay(value);
}

RadioBox::RadioBox(Pane *aPane, char *aName,
			 int aId, int aAddr, int aChannel,
			 int aRows, int aValueStart)
  : Control(aPane, aName),
    event(this, aChannel>=0 ? Event::AudioValue : Event::MixerValue,
	  aId, aAddr, aChannel)
{
  id=aId;
  addr=aAddr;
  channel=aChannel;
  rows=aRows;
  valueStart=aValueStart;
  wBox=NULL;
  wToggles=NULL;
}

RadioBox::~RadioBox()
{
  if(wToggles)
    XtFree((char *)wToggles);
}

void RadioBox::toggledCallback(Widget w, XtPointer closure, XtPointer callData)
{
  RadioBox *radioBox=(RadioBox *)closure;
  XtPointer radioData;

  /* value changes are reported from device
   * so switch back toggle state
   */
  XtVaSetValues(w,
		XtNstate, !callData,
		NULL);

  XtVaGetValues(w,
		XtNradioData, &radioData,
		NULL);

  radioBox->toggled((int)radioData);
}

void RadioBox::toggled(int row)
{
  appl->device.adjust(id, addr, channel, row+valueStart);
}

void RadioBox::build(Widget parent)
{
  int row;
  char buf[256];

  if(wBox)
    return;

  wBox=XtVaCreateManagedWidget(name, layoutWidgetClass, parent,
			       NULL);
  wTitle=XtVaCreateManagedWidget("title", labelWidgetClass, wBox,
				 NULL);
  wToggles=(Widget *)XtMalloc(rows*sizeof(Widget));
  for(row=0; row<rows; row++) {
    sprintf(buf, "row%d", row); 
    wToggles[row]=XtVaCreateManagedWidget(buf, toggleWidgetClass, wBox,
					  XtNradioData, (XtPointer)row,
					  NULL);
    XtAddCallback(wToggles[row], XtNcallback, toggledCallback, this);
  }

  Control::build(parent);
}

void RadioBox::setSensitive(Boolean enable)
{
  if(enable)
    event.subscribe(&appl->device);
  else
    event.unsubscribe();

  Control::setSensitive(enable);
}

void RadioBox::eventSetDisplay(int aValue)
{
  int row;

  for(row=0; row<rows; row++)
    XtVaSetValues(wToggles[row],
		  XtNsensitive, aValue>=0,
		  XtNstate, row==aValue-valueStart,
		  NULL);
}
