#ifndef _DIAL_H
#define _DIAL_H

/****************************************************************
 *
 * Dial widget
 *
 ****************************************************************/

/* Resources:

   Name			Class			RepType		Default Value
   ----			-----			-------		-------------
   foreground		Foreground		Pixel		Black

*/

#define XtNtitleFont	"titleFont"
#define XtNlabelFont	"labelFont"
#define XtNtitle	"title"
#define XtNminimum	"minimum"
#define XtNmaximum	"maximum"
#define XtNstep		"step"
#define XtNduplexMode	"duplexMode"
#ifndef XtNmarginWidth
#define XtNmarginWidth	"marginWidth"
#endif

#define XtCTitle	"Title"
#define XtCMinimum	"Minimum"
#define XtCMaximum	"Maximum"
#define XtCStep		"Step"
#define XtCDuplexMode	"DuplexMode"
#ifndef XtCMarginWidth
#define XtCMarginWidth	"MarginWidth"
#endif

typedef struct _DialCallbackInfo {
  unsigned button;
  float value;
} DialCallbackInfo;

typedef struct _DialClassRec *DialWidgetClass;
typedef struct _DialRec *DialWidget;

extern WidgetClass dialWidgetClass;

#endif /* _Dial_h */
