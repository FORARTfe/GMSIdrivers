#ifndef _PEAKMETERP_h
#define _PEAKMETERP_h

#include "PeakMeter.h"
#include <X11/CoreP.h>

typedef struct {
  XtPointer	    	extension;		/* pointer to extension record      */
} PeakMeterClassPart;

typedef struct _PeakMeterClassRec {
  CoreClassPart		core_class;
  PeakMeterClassPart	peakMeter_class;
} PeakMeterClassRec;

extern PeakMeterClassRec peakMeterClassRec;

typedef struct {
  /* resources */
  Dimension marginWidth, meterWidth;
  Pixel foregroundPixel, meterPixel, troughPixel;
  XFontStruct *font;
  char *label;
  int percentage;

  /* user data */
  GC meterGC, troughGC, labelGC;
} PeakMeterPart;

typedef struct _PeakMeterRec {
  CorePart core;
  PeakMeterPart peakMeter;
} PeakMeterRec;

#endif /* _PEAKMETERP_H */
