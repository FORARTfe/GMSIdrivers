/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifdef SUPPORT_HOMSTDR

#include <stdio.h>

#include "../kernel/sam9407.h"
#include "controls.hh"
#include "panes.hh"
#include "api_homstdr.hh"

ApiHomstdr::ApiHomstdr(Application *aAppl)
  : Api(aAppl, "homstdr", SAM_API_CLASS_HOMSTDR)
{
  Pane *pane;

  initialized=0;

  groupConfig=new Group(		this, "config", 0);
  pane=new DevicePane(			groupConfig, "devices", 0);
}

void ApiHomstdr::build(Widget parent)
{
  Group *group;
  Pane *pane;
  Dial *dial;
  Toggle *toggle;
  Label *label;
  ChannelOwner *channelOwner;
  PeakMeter *peakMeter;
  int channel;
  char *paneName;

  if(!initialized) {
    group=groupConfig;
    pane=new HardwarePane(		group, "hardware", 1, False);
    pane=new AnaOutPane(		group, "anaout", 2);
    pane=new BoxesPane(			group, "boxes", 3);

    group=new Group(			this, "general", 1);
    pane=new Pane(			group, "main", 0);
    dial=new Dial(			pane, "volume", NULL,
					SAM_MIXER_HOMSTDR_ID_MASTER_VOL, 0, -1,
					0, 255);

    pane=new Pane(			group, "recording", 1);
    dial=new Dial(			pane, "rec_vol", NULL,
					SAM_AUDIO_HOMSTDR_ID_REC_VOL, 0, Device::RecordChannelMask|0,
					0, 255);
    label=new Label(			pane, "lbl_rec_mode");
    toggle=new Toggle(			pane, "rec_mode_in0",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0, -1);
    toggle=new Toggle(			pane, "rec_mode_in01",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					1, -1);
    toggle=new Toggle(			pane, "rec_mode_in0123",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					3, -1);
    toggle=new Toggle(			pane, "rec_mode_front",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x7F, -1);
    toggle=new Toggle(			pane, "rec_mode_rear",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x7E, -1);
    toggle=new Toggle(			pane, "rec_mode_4ch",
					SAM_AUDIO_HOMSTDR_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x40, -1);

    group=new Group(			this, "source", 2);
    for(channel=0; channel<4; channel++) {
      paneName=XtMalloc(9);
      sprintf(paneName, "channel%d", channel);
      
      pane=new Pane(group, paneName, channel);
    
      label=new Label(			pane, "lbl_left");
      label=new Label(			pane, "lbl_right");
      label=new Label(			pane, "lbl_front");
      dial=new Dial(			pane, "voll_frontl", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTL, 0, channel,
					0, 255);
      dial=new Dial(			pane, "voll_frontr", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTR, 0, channel,
					0, 255);
      dial=new Dial(			pane, "volr_frontl", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTL, 1, channel,
					0, 255);
      dial=new Dial(			pane, "volr_frontr", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_FRONTR, 1, channel,
					0, 255);
      label=new Label(			pane, "lbl_rear");
      dial=new Dial(			pane, "voll_rearl", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARL, 0, channel,
					0, 255);
      dial=new Dial(			pane, "voll_rearr", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARR, 0, channel,
					0, 255);
      dial=new Dial(			pane, "volr_rearl", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARL, 1, channel,
					0, 255);
      dial=new Dial(			pane, "volr_rearr", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REARR, 1, channel,
					0, 255);
      label=new Label(			pane, "lbl_reverb");
      dial=new Dial(			pane, "voll_rev", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REV, 0, channel,
					0, 255);
      dial=new Dial(			pane, "volr_rev", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_REV, 1, channel,
					0, 255);
      label=new Label(			pane, "lbl_chorus");
      dial=new Dial(			pane, "voll_chr", NULL,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_CHR, 0, channel,
					0, 255);
      dial=new Dial(			pane, "volr_chr", dial,
					SAM_AUDIO_HOMSTDR_ID_SRC_VOL_CHR, 1, channel,
					0, 255);
      label=new Label(			pane, "lbl_dinrec_vol");
      dial=new Dial(			pane, "dinrecl_vol", NULL,
					SAM_AUDIO_HOMSTDR_ID_DINREC_VOL, 0, channel,
					0, 255);
      dial=new Dial(			pane, "dinrecr_vol", dial,
					SAM_AUDIO_HOMSTDR_ID_DINREC_VOL, 1, channel,
					0, 255);
      toggle=new Toggle(		pane, "wave_mode",
					SAM_AUDIO_HOMSTDR_ID_SRC_CFG, 0, channel,
					1, 0);
      toggle=new Toggle(		pane, "filter_on",
					SAM_AUDIO_HOMSTDR_ID_FILTER_ON, 0, channel,
					1, 0);
    }

    group=new Group(			this, "equalizer", 3);
    for(channel=0; channel<4; channel++) {
      paneName=XtMalloc(9);
      sprintf(paneName, "channel%d", channel);

      pane=new Pane(group, paneName, channel);
      label=new Label(			pane, "lbl_left");
      label=new Label(			pane, "lbl_right");
      label=new Label(			pane, "lbl_type");
      toggle=new Toggle(		pane, "equl_type_off",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 0, channel,
					0, -1);
      toggle=new Toggle(		pane, "equr_type_off",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 1, channel,
					0, -1);
      toggle=new Toggle(		pane, "equl_type_2b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 0, channel,
					1, -1);
      toggle=new Toggle(		pane, "equr_type_2b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 1, channel,
					1, -1);
      toggle=new Toggle(		pane, "equl_type_4b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 0, channel,
					2, -1);
      toggle=new Toggle(		pane, "equr_type_4b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 1, channel,
					2, -1);
      toggle=new Toggle(		pane, "equl_type_6b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 0, channel,
					3, -1);
      toggle=new Toggle(		pane, "equr_type_6b",
					SAM_AUDIO_HOMSTDR_ID_EQ_CFG, 1, channel,
					3, -1);
      dial=new Dial(			pane, "levl_lb", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_LB, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_lb", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_LB, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levl_mb1", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB1, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_mb1", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB1, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levl_mb2", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB2, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_mb2", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB2, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levl_mb3", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB3, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_mb3", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB3, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levl_mb4", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB4, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_mb4", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_MB4, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levl_hb", NULL,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_HB, 0, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
      dial=new Dial(			pane, "levr_hb", dial,
					SAM_AUDIO_HOMSTDR_ID_EQ_LEV_HB, 1, channel,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    }

    group=new Group(			this, "reverb", 4);
    for(channel=0; channel<4; channel++) {
      paneName=XtMalloc(9);
      sprintf(paneName, "channel%d", channel);

      pane=new Pane(group, paneName, channel);

      toggle=new Toggle(		pane, "enable",
					SAM_AUDIO_HOMSTDR_ID_EFF_CFG, 0, channel,
					1, 0);
      label=new Label(			pane, "lbl_type");
      toggle=new Toggle(		pane, "type_room1",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					0, -1);
      toggle=new Toggle(		pane, "type_room2",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					1, -1);
      toggle=new Toggle(		pane, "type_room3",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					2, -1);
      toggle=new Toggle(		pane, "type_hall1",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					3, -1);
      toggle=new Toggle(		pane, "type_hall2",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					4, -1);
      toggle=new Toggle(		pane, "type_plate",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					5, -1);
      toggle=new Toggle(		pane, "type_theatre",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					6, -1);
      toggle=new Toggle(		pane, "type_cathedral",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					7, -1);
      toggle=new Toggle(		pane, "type_space1",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					8, -1);
      toggle=new Toggle(		pane, "type_space2",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					9, -1);
      toggle=new Toggle(		pane, "type_single_echo",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					10, -1);
      toggle=new Toggle(		pane, "type_stereo_echo",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					11, -1);
      toggle=new Toggle(		pane, "type_3xecho",
					SAM_AUDIO_HOMSTDR_ID_REV_TYPE, 0, channel,
					12, -1);
      dial=new Dial(			pane, "time", NULL,
					SAM_AUDIO_HOMSTDR_ID_REV_TIME, 0, channel,
					0, 127);
      dial=new Dial(			pane, "feed", NULL,
					SAM_AUDIO_HOMSTDR_ID_REV_FEED, 0, channel,
					0, 127);
      dial=new Dial(			pane, "volf", NULL,
					SAM_AUDIO_HOMSTDR_ID_REV_VOLF, 0, channel,
					0, 127);
      dial=new Dial(			pane, "volr", NULL,
					SAM_AUDIO_HOMSTDR_ID_REV_VOLR, 0, channel,
					0, 127);
    }

    group=new Group(			this, "chorus", 5);
    for(channel=0; channel<4; channel++) {
      paneName=XtMalloc(9);
      sprintf(paneName, "channel%d", channel);

      pane=new Pane(group, paneName, channel);
    
      toggle=new Toggle(		pane, "enable",
					SAM_AUDIO_HOMSTDR_ID_EFF_CFG, 1, channel,
					1, 0);
      label=new Label(			pane, "lbl_type");
      toggle=new Toggle(		pane, "type_chorus1",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					0, -1);
      toggle=new Toggle(		pane, "type_chorus2",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					1, -1);
      toggle=new Toggle(		pane, "type_chorus3",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					2, -1);
      toggle=new Toggle(		pane, "type_chorus4",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					3, -1);
      toggle=new Toggle(		pane, "type_fbchorus",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					4, -1);
      toggle=new Toggle(		pane, "type_flanger",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					5, -1);
      toggle=new Toggle(		pane, "type_shortdel",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					6, -1);
      toggle=new Toggle(		pane, "type_shortfbdel",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					7, -1);
      toggle=new Toggle(		pane, "type_les_slow",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					8, -1);
      toggle=new Toggle(		pane, "type_les_fast",
					SAM_AUDIO_HOMSTDR_ID_CHR_TYPE, 0, channel,
					9, -1);
      dial=new Dial(			pane, "delay", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_DEL, 0, channel,
					0, 127);
      dial=new Dial(			pane, "feed", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_FEED, 0, channel,
					0, 127);
      dial=new Dial(			pane, "rate", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_RATE, 0, channel,
					0, 127);
      dial=new Dial(			pane, "depth", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_DEPTH, 0, channel,
					0, 127);
      dial=new Dial(			pane, "volf", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_VOLF, 0, channel,
					0, 127);
      dial=new Dial(			pane, "volr", NULL,
					SAM_AUDIO_HOMSTDR_ID_CHR_VOLR, 0, channel,
					0, 127);
    }

    group=new Group(			this, "monitor", 6);
    pane=new Pane(			group, "common", 0);
    peakMeter=new PeakMeter(		pane, "peak_fl", 0);
    peakMeter=new PeakMeter(		pane, "peak_fr", 10);
    peakMeter=new PeakMeter(		pane, "peak_rl", 1);
    peakMeter=new PeakMeter(		pane, "peak_rr", 11);
    label=new Label(			pane, "lbl_owner");
    label=new Label(			pane, "lbl_owner_0");
    channelOwner=new ChannelOwner(	pane, "owner_0", 0);
    label=new Label(			pane, "lbl_owner_1");
    channelOwner=new ChannelOwner(	pane, "owner_1", 1);
    label=new Label(			pane, "lbl_owner_2");
    channelOwner=new ChannelOwner(	pane, "owner_2", 2);
    label=new Label(			pane, "lbl_owner_3");
    channelOwner=new ChannelOwner(	pane, "owner_3", 3);

    for(channel=0; channel<4; channel++) {
      paneName=XtMalloc(9);
      sprintf(paneName, "channel%d", channel);

      pane=new Pane(group, paneName, channel+1);

      peakMeter=new PeakMeter(		pane, "audinl", channel+2);
      peakMeter=new PeakMeter(		pane, "audinr", channel+12);
      peakMeter=new PeakMeter(		pane, "recordl", channel+6);
      peakMeter=new PeakMeter(		pane, "recordr", channel+16);
      label=new Label(			pane, "lbl_equ");
      peakMeter=new PeakMeter(		pane, "equl_lb", channel*12+20);
      peakMeter=new PeakMeter(		pane, "equr_lb", channel*12+26);
      peakMeter=new PeakMeter(		pane, "equl_mb1", channel*12+21);
      peakMeter=new PeakMeter(		pane, "equr_mb1", channel*12+27);
      peakMeter=new PeakMeter(		pane, "equl_mb2", channel*12+22);
      peakMeter=new PeakMeter(		pane, "equr_mb2", channel*12+28);
      peakMeter=new PeakMeter(		pane, "equl_mb3", channel*12+23);
      peakMeter=new PeakMeter(		pane, "equr_mb3", channel*12+29);
      peakMeter=new PeakMeter(		pane, "equl_mb4", channel*12+24);
      peakMeter=new PeakMeter(		pane, "equr_mb4", channel*12+30);
      peakMeter=new PeakMeter(		pane, "equl_hb", channel*12+25);
      peakMeter=new PeakMeter(		pane, "equr_hb", channel*12+31);
    }

    initialized=1;
  }
  Api::build(parent);
}

#endif /* SUPPORT_HOMSTDR */
