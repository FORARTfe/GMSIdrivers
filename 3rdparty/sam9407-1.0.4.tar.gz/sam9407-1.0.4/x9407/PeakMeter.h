#ifndef _PEAKMETER_H
#define _PEAKMETER_H

/****************************************************************
 *
 * PeakMeter widget
 *
 ****************************************************************/

/* Resources:

   Name			Class			RepType		Default Value
   ----			-----			-------		-------------
*/

#define XtNmeterWidth	"meterWidth"
#define XtNmeterColor	"meterColor"
#define XtNtroughColor	"troughColor"
#define XtNpercentage	"percentage"
#ifndef XtNmarginWidth
#define XtNmarginWidth	"marginWidth"
#endif

#define XtCMeterWidth	"MeterWidth"
#define XtCMeterColor	"MeterColor"
#define XtCTroughColor	"TroughColor"
#define XtCPercentage	"Percentage"
#ifndef XtCMarginWidth
#define XtCMarginWidth	"MarginWidth"
#endif

typedef struct _PeakMeterClassRec *PeakMeterWidgetClass;
typedef struct _PeakMeterRec *PeakMeterWidget;

extern WidgetClass peakMeterWidgetClass;

#endif /* _PEAKMETER_H */
