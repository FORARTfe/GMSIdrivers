/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifdef SUPPORT_VANILLA

#include <stdio.h>

#include "../kernel/sam9407.h"
#include "controls.hh"
#include "panes.hh"
#include "api_vanilla.hh"

ApiVanilla::ApiVanilla(Application *aAppl)
  : Api(aAppl, "vanilla", SAM_API_CLASS_VANILLA)
{
  Pane *pane;

  initialized=0;

  groupConfig=new Group(		this, "config", 0);
  pane=new DevicePane(			groupConfig, "devices", 0);
}

void ApiVanilla::build(Widget parent)
{
  Group *group;
  Pane *pane;
  Dial *dial;
  Toggle *toggle;
  Label *label;

  if(!initialized) {
    group=groupConfig;
    pane=new HardwarePane(		group, "hardware", 1, True);
    pane=new AnaOutPane(		group, "anaout", 2);
    pane=new BoxesPane(			group, "boxes", 3);
    pane=new SoundBankPane(		group, "soundbank", 4);

    group=new Group(			this, "general", 1);
    pane=new Pane(			group, "main", 0);
    label=new Label(			pane, "lbl_post");
    dial=new Dial(			pane, "volume", NULL,
					SAM_MIXER_ID_MASTER_VOL, 0, -1,
					0, 255);
    toggle=new Toggle(			pane, "gm_post",
					SAM_MIXER_ID_GM_POST, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "wave_post",
					SAM_MIXER_ID_WAVE_POST, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "mod_post",
					SAM_MIXER_ID_MOD_POST, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "audech_post",
					SAM_MIXER_ID_AUDECH_POST, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "master_mute",
					SAM_MIXER_ID_MASTER_MUTE, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "minus_6db",
					SAM_MIXER_ID_MINUS_6DB, 0, -1,
					1, 0);

    pane=new Pane(			group, "config", 1);
    label=new Label(			pane, "equ_lbl");
    toggle=new Toggle(			pane, "rec_cfg",
					SAM_MIXER_ID_REC_CFG, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "aud_onoff",
					SAM_MIXER_ID_AUD_ONOFF, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "ech_onoff",
					SAM_MIXER_ID_ECH_ONOFF, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "rev_onoff",
					SAM_MIXER_ID_REV_ONOFF, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "chr_onoff",
					SAM_MIXER_ID_CHR_ONOFF, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "sur_onoff",
					SAM_MIXER_ID_SUR_ONOFF, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "wave_ass",
					SAM_MIXER_ID_WAVE_ASS, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "mod_ass",
					SAM_MIXER_ID_MOD_ASS, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "equ_type_4b",
					SAM_MIXER_ID_EQU_TYPE, 0, -1,
					0, -1);
    toggle=new Toggle(			pane, "equ_type_2b",
					SAM_MIXER_ID_EQU_TYPE, 0, -1,
					1, -1);
    toggle=new Toggle(			pane, "equ_type_none",
					SAM_MIXER_ID_EQU_TYPE, 0, -1,
					2, -1);

    pane=new Pane(			group, "midi", 2);
    dial=new Dial(			pane, "gm_vol", NULL,
					SAM_MIXER_ID_GM_VOL, 0, -1,
					0, 255);
    dial=new Dial(			pane, "gm_pan", NULL,
					SAM_MIXER_ID_GM_PAN, 0, -1,
					-64, 63, 1, 1, 64);

    pane=new Pane(			group, "recording", 3);
    dial=new Dial(			pane, "rec_vol", NULL,
					SAM_AUDIO_ID_REC_VOL, 0, Device::RecordChannelMask|0,
					0, 255);
    label=new Label(			pane, "lbl_rec_mode");
    toggle=new Toggle(			pane, "rec_mode_audin",
					SAM_AUDIO_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0, -1);
    toggle=new Toggle(			pane, "rec_mode_main",
					SAM_AUDIO_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x7F, -1);
    toggle=new Toggle(			pane, "rec_mode_sur",
					SAM_AUDIO_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x7E, -1);
    toggle=new Toggle(			pane, "rec_mode_mainsur",
					SAM_AUDIO_ID_REC_MODE, 0, Device::RecordChannelMask|0,
					0x40, -1);

    pane=new Pane(			group, "audio_in", 4);
    label=new Label(			pane, "aud_gain_lbl");
    dial=new Dial(			pane, "aud_gainl", NULL,
					SAM_MIXER_ID_AUD_GAINL, 0, -1,
					0, 127);
    dial=new Dial(			pane, "aud_gainr", dial,
					SAM_MIXER_ID_AUD_GAINR, 0, -1,
					0, 127);
    label=new Label(			pane, "aud_vol_lbl");
    dial=new Dial(			pane, "audl_vol", NULL,
					SAM_MIXER_ID_AUDL_VOL, 0, -1,
					0, 255);
    dial=new Dial(			pane, "audr_vol", dial,
					SAM_MIXER_ID_AUDR_VOL, 0, -1,
					0, 255);
    label=new Label(			pane, "aud_pan_lbl");
    dial=new Dial(			pane, "audl_pan", NULL,
					SAM_MIXER_ID_AUDL_PAN, 0, -1,
					0, 127);
    dial=new Dial(			pane, "audr_pan", dial,
					SAM_MIXER_ID_AUDR_PAN, 0, -1,
					0, 127);
    toggle=new Toggle(			pane, "aud_sel",
					SAM_MIXER_ID_AUD_SEL, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "audchr_send",
					SAM_MIXER_ID_AUDCHR_SEND, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "audrev_send",
					SAM_MIXER_ID_AUDREV_SEND, 0, -1,
					1, 0);

    group=new Group(			this, "effects", 2);
    pane=new Pane(			group, "echo", 0);
    dial=new Dial(			pane, "ech_lev", NULL,
					SAM_MIXER_ID_ECH_LEV, 0, -1,
					0, 127);
    dial=new Dial(			pane, "ech_tim", NULL,
					SAM_MIXER_ID_ECH_TIM, 0, -1,
					0, 127);
    dial=new Dial(			pane, "ech_feed", NULL,
					SAM_MIXER_ID_ECH_FEED, 0, -1,
					0, 127);

    pane=new Pane(			group, "reverb", 1);
    label=new Label(			pane, "type_lbl");
    toggle=new Toggle(			pane, "rev_type_room1",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					0, -1);
    toggle=new Toggle(			pane, "rev_type_room2",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					1, -1);
    toggle=new Toggle(			pane, "rev_type_room3",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					2, -1);
    toggle=new Toggle(			pane, "rev_type_hall1",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					3, -1);
    toggle=new Toggle(			pane, "rev_type_hall2",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					4, -1);
    toggle=new Toggle(			pane, "rev_type_plate",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					5, -1);
    toggle=new Toggle(			pane, "rev_type_delay",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					6, -1);
    toggle=new Toggle(			pane, "rev_type_pandelay",
					SAM_MIXER_ID_REV_TYPE, 0, -1,
					7, -1);
    dial=new Dial(			pane, "rev_vol", NULL,
					SAM_MIXER_ID_REV_VOL, 0, -1,
					0, 255);
    dial=new Dial(			pane, "rev_time", NULL,
					SAM_MIXER_ID_REV_TIME, 0, -1,
					0, 127);
    dial=new Dial(			pane, "rev_feed", NULL,
					SAM_MIXER_ID_REV_FEED, 0, -1,
					0, 127);
    dial=new Dial(			pane, "gmrev_send", NULL,
					SAM_MIXER_ID_GMREV_SEND, 0, -1,
					0, 255);

    pane=new Pane(			group, "chorus", 2);
    label=new Label(			pane, "type_lbl");
    toggle=new Toggle(			pane, "chr_type_chorus1",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					0, -1);
    toggle=new Toggle(			pane, "chr_type_chorus2",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					1, -1);
    toggle=new Toggle(			pane, "chr_type_chorus3",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					2, -1);
    toggle=new Toggle(			pane, "chr_type_chorus4",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					3, -1);
    toggle=new Toggle(			pane, "chr_type_fbchorus",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					4, -1);
    toggle=new Toggle(			pane, "chr_type_flanger",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					5, -1);
    toggle=new Toggle(			pane, "chr_type_shortdel",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					6, -1);
    toggle=new Toggle(			pane, "chr_type_fbdel",
					SAM_MIXER_ID_CHR_TYPE, 0, -1,
					7, -1);
    dial=new Dial(			pane, "chr_vol", NULL,
					SAM_MIXER_ID_CHR_VOL, 0, -1,
					0, 255);
    dial=new Dial(			pane, "chr_del", NULL,
					SAM_MIXER_ID_CHR_DEL, 0, -1,
					0, 127);
    dial=new Dial(			pane, "chr_feed", NULL,
					SAM_MIXER_ID_CHR_FEED, 0, -1,
					0, 127);
    dial=new Dial(			pane, "chr_rate", NULL,
					SAM_MIXER_ID_CHR_RATE, 0, -1,
					0, 127);
    dial=new Dial(			pane, "chr_depth", NULL,
					SAM_MIXER_ID_CHR_DEPTH, 0, -1,
					0, 127);
    dial=new Dial(			pane, "gmchr_send", NULL,
					SAM_MIXER_ID_GMCHR_SEND, 0, -1,
					0, 255);

    group=new Group(			this, "post", 3);
    pane=new Pane(			group, "equ_low", 0);
    dial=new Dial(			pane, "eq_lbl", NULL,
					SAM_MIXER_ID_EQ_LBL, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eq_lbr", dial,
					SAM_MIXER_ID_EQ_LBR, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eqf_lb", NULL,
					SAM_MIXER_ID_EQF_LB, 0, -1,
					0, 4.7, 0.1,				/* min, max, step */
					127./4.7, 0				/* multiply, add */
					);

    pane=new Pane(			group, "equ_medlow", 1);
    dial=new Dial(			pane, "eq_mlbl", NULL,
					SAM_MIXER_ID_EQ_MLBL, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eq_mlbr", dial,
					SAM_MIXER_ID_EQ_MLBR, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eqf_mlb", NULL,
					SAM_MIXER_ID_EQF_MLB, 0, -1,
					0, 4.2, 0.1,				/* min, max, step */
					127./4.2, 0				/* multiply, add */
					);

    pane=new Pane(			group, "equ_medhigh", 2);
    dial=new Dial(			pane, "eq_mhbl", NULL,
					SAM_MIXER_ID_EQ_MHBL, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eq_mhbr", dial,
					SAM_MIXER_ID_EQ_MHBR, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eqf_mhb", NULL,
					SAM_MIXER_ID_EQF_MHB, 0, -1,
					0, 4.2, 0.1,				/* min, max, step */
					127./4.2, 0				/* multiply, add */
					);

    pane=new Pane(			group, "equ_high", 3);
    dial=new Dial(			pane, "eq_hbl", NULL,
					SAM_MIXER_ID_EQ_HBL, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eq_hbr", dial,
					SAM_MIXER_ID_EQ_HBR, 0, -1,
					-12, 12, 0.1,				/* min, max, step */
					128./24., 64.				/* multiply, add */
					);
    dial=new Dial(			pane, "eqf_hb", NULL,
					SAM_MIXER_ID_EQF_HB, 0, -1,
					0, 18.75, 0.1,				/* min, max, step */
					127./18.75, 0				/* multiply, add */
					);

    pane=new Pane(			group, "surround", 4);
    dial=new Dial(			pane, "sur_vol", NULL,
					SAM_MIXER_ID_SUR_VOL, 0, -1,
					0, 255);
    dial=new Dial(			pane, "sur_del", NULL,
					SAM_MIXER_ID_SUR_DEL, 0, -1,
					0, 127);
    toggle=new Toggle(			pane, "sur_inp",
					SAM_MIXER_ID_SUR_INP, 0, -1,
					1, 0);
    toggle=new Toggle(			pane, "sur_24",
					SAM_MIXER_ID_SUR_24, 0, -1,
					1, 0);
    initialized=1;
  }

  Api::build(parent);
}

#endif /* SUPPORT_VANILLA */
