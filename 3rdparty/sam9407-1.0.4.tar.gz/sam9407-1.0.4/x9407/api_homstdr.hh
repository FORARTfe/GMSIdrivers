#ifndef _API_HOMSTDR_HH
#define _API_HOMSTDR_HH

#include "controls.hh"

class Application;

class ApiHomstdr : public Api {
public:
  ApiHomstdr(Application *aAppl);
  virtual void build(Widget parent);
private:
  int initialized;
  Group *groupConfig;
};

#endif /* _API_HOMSTDR_HH */
