#ifndef _API_VANILLA_HH
#define _API_VANILLA_HH

#include "controls.hh"

class Application;

class ApiVanilla : public Api {
public:
  ApiVanilla(Application *aAppl);
  virtual void build(Widget parent);
private:
  int initialized;
  Group *groupConfig;
};

#endif /* _API_VANILLA_HH */
