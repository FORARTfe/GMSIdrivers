# -*-perl-*-

die "usage: $0 <msgfile> <resfile>\n" unless $#ARGV>=$[+1;

die "can't open $ARGV[$[]: $!\n" unless open MSG, $ARGV[$[];
MSG: while(<MSG>) {
    $pending.=$_;
    chomp;
    next MSG if /\\$/;
    split /:/, $pending;
    $pending="";
    next MSG if $#_<=0;
    $key=shift @_;
    $value=join ":", @_;
    chomp $value;
    $trans{$key}=$value;
}
close MSG;

die "can't open $ARGV[$[+1]: $!\n" unless open AD, $ARGV[$[+1];
$pending="";
AD: while(<AD>) {
    $pending.=$_;
    chomp;
    next AD if /\\$/;
    split /:/, $pending;
    $key=shift @_;
    if(exists $trans{$key}) {
	print "$key:$trans{$key}\n";
    } else {
	print $pending;
    }
    $pending="";
}
close AD;
