/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../kernel/sam9407.h"
#include "controls.hh"
#include "panes.hh"
#include "api_none.hh"

ApiNone::ApiNone(Application *aAppl)
  : Api(aAppl, "none", SAM_API_CLASS_NONE)
{
  Group *group;
  Pane *pane;

  group=new Group(this, "config", 0);
  pane=new DevicePane(group, "devices", 0);
}
