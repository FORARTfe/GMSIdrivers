/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Xmu/Xmu.h>

#include "DialP.h"

#define TIP_ANGLE		(M_PI/10)
#define POINTER_ORIGIN_RADIUS	2

#ifndef XtX
#define XtX(w)	   ((w)->core.x)
#endif

#ifndef XtY
#define XtY(w)	   ((w)->core.y)
#endif

#ifndef XtWidth
#define XtWidth(w) ((w)->core.width)
#endif

#ifndef XtHeight
#define XtHeight(w) ((w)->core.height)
#endif

#ifndef XtDepth
#define XtDepth(w) ((w)->core.depth)
#endif

#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

typedef enum {
  RedrawDrawAll,
  RedrawErasePointer,
  RedrawDrawPointer,
} RedrawMode;

typedef struct {
  int width, height, titleHeight, labelHeight, arcRadius;
  int centerX, centerY;
} DialExtents;

static void Initialize();
static void Release();
static void Redisplay();
static Boolean SetValues();
static XtGeometryResult QueryGeometry();

static void GrabAction();
static void AdjustAction();
static void ReleaseAction();

static float floatZero=0;
static float floatOne=1;
static float floatHundret=100;

static XtResource resources[] = {
  {
    XtNforeground, XtCForeground,
    XtRPixel, sizeof(Pixel),
    XtOffset(DialWidget, dial.foregroundPixel),
    XtRString, (XtPointer)"Black"
  },
  {
    XtNmarginWidth, XtCMarginWidth,
    XtRDimension, sizeof(Dimension),
    XtOffset(DialWidget, dial.marginWidth),
    XtRImmediate, (XtPointer)2
  },
  {
    XtNtitleFont, XtCFont,
    XtRFontStruct, sizeof(XFontStruct *),
    XtOffset(DialWidget, dial.titleFont),
    XtRString, XtDefaultFont
  },
  {
    XtNlabelFont, XtCFont,
    XtRFontStruct, sizeof(XFontStruct *),
    XtOffset(DialWidget, dial.labelFont),
    XtRString, XtDefaultFont
  },
  {
    XtNtitle, XtCTitle,
    XtRString, sizeof(String),
    XtOffset(DialWidget, dial.title),
    XtRString, NULL
  },
  {
    XtNvalue, XtCValue,
    XtRFloat, sizeof(float),
    XtOffset(DialWidget, dial.value),
    XtRFloat, &floatZero
  },
  {
    XtNminimum, XtCMinimum,
    XtRFloat, sizeof(float),
    XtOffset(DialWidget, dial.minimum),
    XtRFloat, &floatZero
  },
  {
    XtNmaximum, XtCMaximum,
    XtRFloat, sizeof(float),
    XtOffset(DialWidget, dial.maximum),
    XtRFloat, &floatHundret
  },
  {
    XtNstep, XtCStep,
    XtRFloat, sizeof(float),
    XtOffset(DialWidget, dial.step),
    XtRFloat, &floatOne
  },
  {
    XtNcallback, XtCCallback,
    XtRCallback, sizeof(XtPointer),
    XtOffset(DialWidget, dial.callbacks),
    XtRCallback, (XtPointer)NULL
  },
  {
    XtNduplexMode, XtCDuplexMode,
    XtRBoolean, sizeof(Boolean),
    XtOffset(DialWidget, dial.duplexMode),
    XtRImmediate, (XtPointer)0
  },
};

static XtActionsRec actions[] =
{
  { "grab",	GrabAction },
  { "adjust",	AdjustAction },
  { "release",	ReleaseAction },
};

static char translations[] ="\
<BtnDown>:	grab() adjust()\n\
<BtnMotion>:	adjust()\n\
<BtnUp>:	release()\
";

DialClassRec dialClassRec = {
  { /* core fields */
    /* superclass		*/	(WidgetClass) &widgetClassRec,
    /* class_name		*/	"Dial",
    /* widget_size		*/	sizeof(DialRec),
    /* class_initialize		*/	NULL,
    /* class_part_initialize	*/	NULL,
    /* class_inited		*/	FALSE,
    /* initialize		*/	Initialize,
    /* initialize_hook		*/	NULL,
    /* realize			*/	XtInheritRealize,
    /* actions			*/	actions,
    /* num_actions		*/	XtNumber(actions),
    /* resources		*/	resources,
    /* num_resources		*/	XtNumber(resources),
    /* xrm_class		*/	NULLQUARK,
    /* compress_motion		*/	TRUE,
    /* compress_exposure	*/	TRUE,
    /* compress_enterleave	*/	TRUE,
    /* visible_interest		*/	FALSE,
    /* destroy			*/	Release,
    /* resize			*/	NULL,
    /* expose			*/	Redisplay,
    /* set_values		*/	SetValues,
    /* set_values_hook		*/	NULL,
    /* set_values_almost	*/	XtInheritSetValuesAlmost,
    /* get_values_hook		*/	NULL,
    /* accept_focus		*/	NULL,
    /* version			*/	XtVersion,
    /* callback_private		*/	NULL,
    /* tm_table			*/	translations,
    /* query_geometry		*/	QueryGeometry,
    /* display_accelerator	*/	XtInheritDisplayAccelerator,
    /* extension		*/	NULL
  },
  { /* dial fields */
    /* extension		*/	NULL
  }
};

WidgetClass dialWidgetClass = (WidgetClass)&dialClassRec;

static double CheckValue(dw, value)
     DialWidget dw;
     double value;
{
  double result;
  result=floor((value-dw->dial.minimum)/dw->dial.step+0.5)*dw->dial.step+dw->dial.minimum;
  /* check for precision error */
  if(result>=-dw->dial.step/10 &&
     result<=dw->dial.step/10)
    result=0;
  if(result<dw->dial.minimum)
    result=dw->dial.minimum;
  if(result>dw->dial.maximum)
    result=dw->dial.maximum;
  return result;
}

static void GetExtents(dw, extents)
     DialWidget dw;
     DialExtents *extents;
{
  extents->width=XtWidth(dw)-2*dw->dial.marginWidth;
  extents->height=XtHeight(dw)-2*dw->dial.marginWidth;

  extents->titleHeight=dw->dial.titleFont->max_bounds.ascent+dw->dial.titleFont->max_bounds.descent;
  extents->labelHeight=dw->dial.labelFont->max_bounds.ascent+dw->dial.labelFont->max_bounds.descent;
  extents->arcRadius=MIN(extents->width/2, extents->height-extents->titleHeight-extents->labelHeight-2*dw->dial.marginWidth);

  extents->centerX=XtWidth(dw)/2;
  extents->centerY=(XtHeight(dw)+extents->arcRadius+extents->titleHeight-extents->labelHeight)/2;
}

static void Redraw(dw, mode, rect)
     DialWidget dw;
     RedrawMode mode;
     XRectangle *rect;
{
  Display *dpy;
  Window win;
  GC gc;
  int x, y;
  DialExtents extents;
  double divisor, angle, angle2;
  XPoint tip[3];
  char buf[256];

  if(!XtIsRealized((Widget)dw))
    return;
  dpy=XtDisplay((Widget)dw);
  win=XtWindow((Widget)dw);
  if(mode!=RedrawErasePointer) {
    if(dw->core.sensitive)
      gc=dw->dial.fgGC;
    else
      gc=dw->dial.grayGC;
  } else
    gc=dw->dial.bgGC;

  GetExtents(dw, &extents);

  if(mode==RedrawDrawAll) {
    if(rect)
      XClearArea(dpy, win, rect->x, rect->y, rect->width, rect->height, False);
    else
      XClearWindow(dpy, win);

    /* Draw the title, if specified */
    if(dw->dial.title)
      XDrawString(dpy, win, dw->core.sensitive ? dw->dial.titleGC : dw->dial.grayTitleGC,
		  extents.centerX-XTextWidth(dw->dial.titleFont, dw->dial.title, strlen(dw->dial.title))/2,
		  extents.centerY-extents.arcRadius-dw->dial.marginWidth-dw->dial.titleFont->max_bounds.descent,
		  dw->dial.title, strlen(dw->dial.title));
  }

  if(mode!=RedrawErasePointer) {
    /* draw the outer arc */
    XDrawArc(dpy, win, gc,
	     extents.centerX-extents.arcRadius, extents.centerY-extents.arcRadius,
	     2*extents.arcRadius, 2*extents.arcRadius,
	     0, 180*64);
    XDrawLine(dpy, win, gc,
	      extents.centerX-extents.arcRadius, extents.centerY,
	      extents.centerX+extents.arcRadius, extents.centerY);

    /* the center arc */
    XFillArc(dpy, win, gc,
	     extents.centerX-POINTER_ORIGIN_RADIUS, extents.centerY-POINTER_ORIGIN_RADIUS,
	     POINTER_ORIGIN_RADIUS*2, POINTER_ORIGIN_RADIUS*2, 0, 360*64);
  }

  /* draw the label */
  sprintf(buf, "%g", dw->dial.value);
  XDrawString(dpy, win, gc,
	      extents.centerX-XTextWidth(dw->dial.labelFont, buf, strlen(buf))/2,
	      extents.centerY+dw->dial.marginWidth+dw->dial.labelFont->max_bounds.ascent,
	      buf, strlen(buf));

  /* draw the pointer */
  divisor=dw->dial.maximum-dw->dial.minimum;
  if(divisor<=0)
    divisor=1;
  angle=M_PI*(dw->dial.value-dw->dial.minimum)/divisor;
  x=cos(angle)*extents.arcRadius;
  y=sin(angle)*extents.arcRadius;

  XDrawLine(dpy, win, gc,
	    extents.centerX, extents.centerY,
	    extents.centerX-x, extents.centerY-y);

  /* draw the tip of the pointer */
  tip[0].x=extents.centerX-x;
  tip[0].y=extents.centerY-y;

  angle2=angle+TIP_ANGLE;
  tip[1].x=tip[0].x+cos(angle2)*extents.arcRadius/5;
  tip[1].y=tip[0].y+sin(angle2)*extents.arcRadius/5;

  angle2=angle-TIP_ANGLE;
  tip[2].x=tip[0].x+cos(angle2)*extents.arcRadius/5;
  tip[2].y=tip[0].y+sin(angle2)*extents.arcRadius/5;

  XFillPolygon(dpy, win, gc,
	       tip, 3, Convex, CoordModeOrigin);
}

static void GetGCs(dw)
     DialWidget dw;
{
  XtGCMask valuemask;
  XGCValues values;

  values.foreground=values.background=dw->core.background_pixel;
  values.font=dw->dial.labelFont->fid;
  valuemask=GCForeground|GCBackground|GCFont;
  dw->dial.bgGC=XtGetGC((Widget)dw, valuemask, &values);

  values.foreground=dw->dial.foregroundPixel;
  dw->dial.fgGC=XtGetGC((Widget)dw, valuemask, &values);

  values.font=dw->dial.titleFont->fid;
  dw->dial.titleGC=XtGetGC((Widget)dw, valuemask, &values);

  /* get gray GC's */
  values.font=dw->dial.labelFont->fid;
  values.fill_style=FillTiled;
  values.tile=XmuCreateStippledPixmap(XtScreen((Widget)dw),
				      values.foreground, 
				      values.background,
				      dw->core.depth);
  dw->dial.stipple=values.tile;
  valuemask=GCForeground|GCBackground|GCFont|GCTile|GCFillStyle;
  dw->dial.grayGC=XtGetGC((Widget)dw, valuemask, &values);

  values.font=dw->dial.titleFont->fid;
  dw->dial.grayTitleGC=XtGetGC((Widget)dw, valuemask, &values);
}

static void ReleaseGCs(dw)
     DialWidget dw;
{
  XtReleaseGC((Widget)dw, dw->dial.bgGC);
  XtReleaseGC((Widget)dw, dw->dial.fgGC);
  XtReleaseGC((Widget)dw, dw->dial.titleGC);
  XtReleaseGC((Widget)dw, dw->dial.grayGC);
  XtReleaseGC((Widget)dw, dw->dial.grayTitleGC);
  XmuReleaseStippledPixmap(XtScreen((Widget)dw), dw->dial.stipple);
}

static void Initialize(req, new, args, num_args)
     Widget req, new;
     ArgList args;
     Cardinal *num_args;
{
  DialWidget dw=(DialWidget)new;

  if(XtWidth(req)<=0) 
    XtWidth(new)=16;
  
  if(XtHeight(req)<=0) 
    XtHeight(new)=16;

  GetGCs(dw);
  dw->dial.grab=DialGrabNone;

  if(dw->dial.title)
    dw->dial.title=XtNewString(dw->dial.title);
}

static void Release(w)
     Widget w;
{
  DialWidget dw=(DialWidget)w;

  if(dw->dial.title)
    XtFree(dw->dial.title);

  ReleaseGCs(dw);
}

static void Redisplay(w, event, region)
     Widget w;
     XEvent *event;
     Region region;
{
  DialWidget dw=(DialWidget)w;
  XRectangle rect;

  XClipBox(region, &rect);
  Redraw(dw, RedrawDrawAll, &rect);
}

static Boolean SetValues(old,request,new,args,num_args)
     Widget old,request,new;
     ArgList args;
     Cardinal *num_args;
{
  DialWidget old_dw=(DialWidget)old;
  DialWidget new_dw=(DialWidget)new;
  Boolean redisplay=False;
  int v;

  if(old_dw->dial.foregroundPixel!=new_dw->dial.foregroundPixel ||
     old_dw->core.background_pixel!=new_dw->core.background_pixel ||
     old_dw->dial.titleFont!=new_dw->dial.titleFont ||
     old_dw->dial.labelFont!=new_dw->dial.labelFont) {
    ReleaseGCs(old_dw);
    GetGCs(new_dw);
    redisplay=True;
  }

  if(old_dw->dial.title!=new_dw->dial.title) {
    if(old_dw->dial.title)
      XtFree(old_dw->dial.title);
    if(new_dw->dial.title)
      new_dw->dial.title=XtNewString(new_dw->dial.title);
    redisplay=True;
  }

  if(old_dw->core.sensitive!=new_dw->core.sensitive ||
     old_dw->dial.marginWidth!=new_dw->dial.marginWidth) {
    redisplay=True;
  }

  if(old_dw->dial.minimum!=new_dw->dial.minimum ||
     old_dw->dial.maximum!=new_dw->dial.maximum) {
    if(new_dw->dial.minimum>new_dw->dial.maximum) {
      v=new_dw->dial.minimum;
      new_dw->dial.minimum=new_dw->dial.maximum;
      new_dw->dial.maximum=v;
    }
    redisplay=True;
  }

  if(old_dw->dial.step!=new_dw->dial.step) {
    if(new_dw->dial.step<=0) {
      new_dw->dial.step=old_dw->dial.step;
      XtAppWarning(XtWidgetToApplicationContext(new), "Step value must be >0");
    } else
      redisplay=True;
  }

  /* sanity checks */
  new_dw->dial.value=CheckValue(new_dw, new_dw->dial.value);

  /* if value changed, we redraw just the pointer */
  if(old_dw->dial.value!=new_dw->dial.value) {
    Redraw(old_dw, RedrawErasePointer, NULL);
    Redraw(new_dw, RedrawDrawPointer, NULL);
  }

  return redisplay;
}

static XtGeometryResult QueryGeometry(w, intended, preferred)
     Widget w;
     XtWidgetGeometry *intended, *preferred; 
{
  DialWidget dw=(DialWidget)w;
  int titleHeight, labelHeight, titleWidth, labelWidth;

  if(dw->dial.title)
    titleWidth=XTextWidth(dw->dial.titleFont, dw->dial.title, strlen(dw->dial.title));
  else
    titleWidth=0;

  labelWidth=XTextWidth(dw->dial.labelFont, "99999.9999", 10);

  titleHeight=dw->dial.titleFont->max_bounds.ascent+dw->dial.titleFont->max_bounds.descent;
  labelHeight=dw->dial.labelFont->max_bounds.ascent+dw->dial.labelFont->max_bounds.descent;

  preferred->request_mode=CWWidth|CWHeight;
  preferred->width=MAX(titleWidth, labelWidth)+2*dw->dial.marginWidth;
  preferred->height=preferred->width/2+titleHeight+labelHeight+4*dw->dial.marginWidth;

 if(((intended->request_mode& (CWWidth|CWHeight)) == (CWWidth|CWHeight)) &&
    intended->width == preferred->width &&
    intended->height == preferred->height)
   return XtGeometryYes;

 if(preferred->width==dw->core.width &&
    preferred->height==dw->core.height)
   return XtGeometryNo;

  return XtGeometryAlmost;
}

static void GrabAction(w, event, params, num_params)
     Widget w;
     XEvent *event; 
     String *params;
     Cardinal *num_params;
{
  DialWidget dw=(DialWidget)w;
  DialExtents extents;
  int x, y;
  unsigned whichButton;

  switch(event->type) {
  case ButtonPress:
  case ButtonRelease:
    x=event->xbutton.x;
    y=event->xbutton.y;
    whichButton=event->xbutton.button;
    break;
  default:
    return;
  }

  GetExtents(dw, &extents);

  dw->dial.grab=DialGrabPointer;
  dw->dial.whichButton=whichButton;
}

static void AdjustAction(w, event, params, num_params)
     Widget w;
     XEvent *event; 
     String *params;
     Cardinal *num_params;
{
  DialWidget dw=(DialWidget)w;
  DialExtents extents;
  int x, y, dx, dy, angle;
  float range;
  DialCallbackInfo info;

  if(dw->dial.grab!=DialGrabPointer)
    return;

  switch(event->type) {
  case ButtonPress:
  case ButtonRelease:
    x=event->xbutton.x;
    y=event->xbutton.y;
    break;
  case MotionNotify:
    x=event->xmotion.x;
    y=event->xmotion.y;
    break;
  default:
    return;
  }

  GetExtents(dw, &extents);
  dx=x-extents.centerX;
  dy=extents.centerY-y;
  if(dy<0)
    dy=0;

  if(dx!=0) {
    angle=180.*atan((dy+0.0)/(dx+0.0))/M_PI;
    if(dx<0)
      angle+=180;
  } else
    angle=90;

  range=dw->dial.maximum-dw->dial.minimum;
  if(range<=0)
    range=1;

  info.value=CheckValue(dw, dw->dial.minimum+range*(180-angle)/180);
  info.button=dw->dial.whichButton;

  if(info.value!=dw->dial.value) {
    if(!dw->dial.duplexMode) {
      Redraw(dw, RedrawErasePointer, NULL);
      dw->dial.value=info.value;
      Redraw(dw, RedrawDrawPointer, NULL);
    }
    XtCallCallbackList(w, dw->dial.callbacks, (XtPointer)&info);
  }
}

static void ReleaseAction(w, event, params, num_params)
     Widget w;
     XEvent *event; 
     String *params;
     Cardinal *num_params;
{
  DialWidget dw=(DialWidget)w;

  dw->dial.grab=DialGrabNone;
}
