/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "../kernel/sam9407.h"

#include "x9407.hh"
#include "panes.hh"

#include XAW_HEADER(Label.h)
#include XAW_HEADER(Command.h)
#include XAW_HEADER(Toggle.h)
#include XAW_HEADER(List.h)
#include XAW_HEADER(AsciiText.h)

void DevicePaneEvent::triggerDeviceClosed(int cardNr)
{
  devicePane->selectCardNr(-1);
}

void DevicePaneEvent::triggerDevicesRescanned(Event::DeviceInfo *devices, int count)
{
  devicePane->devicesRescanned(devices, count);
}

void DevicePaneEvent::triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName)
{
  devicePane->fwChanged(cardNr, fwName);
}

DevicePane::DevicePane(Group *aGroup, char *aName, int aTabPosition)
  : Pane(aGroup, aName, aTabPosition),
    devicesRescannedEvent(this, Event::DevicesRescanned),
    fwChangedEvent(this, Event::FirmwareChanged),
    devClosedEvent(this, Event::DeviceClosed)
{
  wLblInUse=wInUse=wTitle=wList=NULL;
  wRescan=wUse=wRelease=wFirmLoad=NULL;
  cardNr=-1;
  devices=NULL;
  nDevices=0;
  list=NULL;
  fsFirmwarePath=NULL;

  devicesRescannedEvent.subscribe(&appl->device);
  fwChangedEvent.subscribe(&appl->device);
  devClosedEvent.subscribe(&appl->device);
}

DevicePane::~DevicePane()
{
  if(list)
    XtFree((char *)list);
  if(devices)
    disposeDevices();
  if(fsFirmwarePath)
    XtFree(fsFirmwarePath);
}

void DevicePane::build(Widget parent)
{
  char cardNrBuf[32];

  if(wList)
    return;

  Pane::build(parent);

  sprintf(cardNrBuf, "%d", cardNr);

  wLblInUse=XtVaCreateManagedWidget("inuse_lbl", labelWidgetClass, wPane,
				    NULL);
  wInUse=XtVaCreateManagedWidget("inuse", labelWidgetClass, wPane,
				 XtNlabel, cardNr>=0 ? cardNrBuf : appl->resources.cardNone,
				 NULL);
  wTitle=XtVaCreateManagedWidget("title", labelWidgetClass, wPane,
				 NULL);
  wList=XtVaCreateManagedWidget("list", listWidgetClass, wPane,
				XtNforceColumns, True,
				XtNdefaultColumns, 1,
				NULL);
  wRescan=XtVaCreateManagedWidget("rescan", commandWidgetClass, wPane,
				  NULL);
  XtAddCallback(wRescan, XtNcallback, rescanDevicesCallback, this);
  wUse=XtVaCreateManagedWidget("use", commandWidgetClass, wPane,
			       NULL);
  XtAddCallback(wUse, XtNcallback, useDeviceCallback, this);
  wRelease=XtVaCreateManagedWidget("release", commandWidgetClass, wPane,
				   NULL); 
  XtAddCallback(wRelease, XtNcallback, releaseDeviceCallback, this);
  wFirmLoad=XtVaCreateManagedWidget("firmload", commandWidgetClass, wPane,
				    NULL);
  XtAddCallback(wFirmLoad, XtNcallback, loadFirmwareCallback, this);

  displayList();
}

void DevicePane::disposeDevices()
{
  int i;

  for(i=0; i<nDevices; i++) {
    XtFree((char *)devices[i].hwName);
    XtFree((char *)devices[i].fwName);
  }
  XtFree((char *)devices);
  devices=NULL;
}

void DevicePane::displayList()
{
  int size, elemSize, i;
  char *fwName, *cp;

  if(!wList)
    return;

  size=(nDevices+1)*sizeof(String);
  for(i=0; i<nDevices; i++) {
    fwName=devices[i].fwName;
    if(!*fwName)
      fwName=appl->resources.noFirmware;
    elemSize=strlen(devices[i].hwName)+strlen(fwName)+8;
    if(elemSize<32)
      elemSize=32;
    size+=elemSize;
  }
  if(list)
    XtFree((char *)list);
  list=(String *)XtMalloc(size);

  cp=(char *)(list+nDevices+1);
  for(i=0; i<nDevices; i++) {
    list[i]=cp;
    fwName=devices[i].fwName;
    if(!*fwName)
      fwName=appl->resources.noFirmware;
    cp+=sprintf(cp, "%d %-15s %s", i, devices[i].hwName, fwName)+1;
  }
  list[nDevices]=NULL;

  XtVaSetValues(wList,
		XtNlist, list,
		XtNnumberStrings, 0,
		NULL);
}

void DevicePane::devicesRescanned(Event::DeviceInfo *aDevices, int count)
{
  int i;

  /* draw a copy of the devices parameter */
  if(devices)
    disposeDevices();
  devices=(Event::DeviceInfo *)XtMalloc(count*sizeof(Event::DeviceInfo));

  for(i=0; i<count; i++) {
    devices[i].hwName=(char *)XtNewString(aDevices[i].hwName);
    devices[i].fwName=(char *)XtNewString(aDevices[i].fwName);
  }
  nDevices=count;

  displayList();
}

void DevicePane::selectCardNr(int aCardNr)
{
  char cardNrBuf[32];

  cardNr=aCardNr;
  if(wInUse) {
    sprintf(cardNrBuf, "%d", cardNr);
    XtVaSetValues(wInUse,
		  XtNlabel, cardNr>=0 ? cardNrBuf : appl->resources.cardNone,
		  NULL);
    if(cardNr>=0 && cardNr<nDevices)
      XawListHighlight(wList, cardNr);
    else
      XawListUnhighlight(wList);
  }
}

void DevicePane::fwChanged(int aCardNr, char *fwName)
{
  if(aCardNr<nDevices) {
    XtFree((char *)devices[aCardNr].fwName);
    devices[aCardNr].fwName=(char *)XtNewString(fwName);

    displayList();
    selectCardNr(aCardNr);
  }
}

void DevicePane::loadFirmware()
{
  char *fileName;

  if(!appl->device.isOpen()) {
    appl->error(0, appl->resources.errNoCardSelected, NULL);
    return;
  }

  if((fileName=XsraSelFile(appl->top, appl->resources.fsFirmTitle, NULL, &fsFirmwarePath, 1, NULL))) {
    appl->device.loadFirmware(fileName);
    XtFree(fileName);
  }
}

void DevicePane::rescanDevicesCallback(Widget w, XtPointer closure, XtPointer callData)
{
  DevicePane *devicePane=(DevicePane *)closure;

  devicePane->appl->device.rescan();
}

void DevicePane::useDeviceCallback(Widget w, XtPointer closure, XtPointer callData)
{
  DevicePane *devicePane=(DevicePane *)closure;
  XawListReturnStruct *current;

  current=XawListShowCurrent(devicePane->wList);
  if(current->list_index>=0)
    devicePane->appl->device.open(current->list_index);
}

void DevicePane::releaseDeviceCallback(Widget w, XtPointer closure, XtPointer callData)
{
  DevicePane *devicePane=(DevicePane *)closure;

  devicePane->appl->device.close();
}

void DevicePane::loadFirmwareCallback(Widget w, XtPointer closure, XtPointer callData)
{
  DevicePane *devicePane=(DevicePane *)closure;

  devicePane->loadFirmware();
}

HardwarePane::HardwarePane(Group *aGroup, char *aName, int aTabPosition, Boolean aWithSampleRate)
  : Pane(aGroup, aName, aTabPosition)
{
  Toggle *toggle;
  Label *label;
  ReadOnly *readOnly;

  if(aWithSampleRate) {
    label=new Label(			this, "lbl_sr");
    toggle=new Toggle(			this, "sr_32khz",
					SAM_MIXER_ID_SAMPLE_RATE, 0, -1,
					32000, -1);
    toggle=new Toggle(			this, "sr_44khz",
					SAM_MIXER_ID_SAMPLE_RATE, 0, -1,
					44100, -1);
    toggle=new Toggle(			this, "sr_48khz",
					SAM_MIXER_ID_SAMPLE_RATE, 0, -1,
					48000, -1);
    toggle=new Toggle(			this, "sr_sync",
					SAM_MIXER_HW_ID_EXTERNAL_CLOCK, 0, -1,
					1, 0);
  }
  label=new Label(			this, "lbl_ain");
  toggle=new Toggle(			this, "ain_digital",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_DIGITAL, -1);
  toggle=new Toggle(			this, "ain_codec",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_CODEC, -1);
  toggle=new Toggle(			this, "ain_mic",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_MIC, -1);
  toggle=new  Toggle(			this, "ain_line1",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_LINE1, -1);
  toggle=new Toggle(			this, "ain_line2",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_LINE2, -1);
  toggle=new Toggle(			this, "ain_slavedsp",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_SLAVE_DSP, -1);
  toggle=new Toggle(			this, "ain_masterbus",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_MASTER_BUS, -1);
  toggle=new Toggle(			this, "ain_slavebus",
					SAM_MIXER_HW_ID_AUDIO_INPUT, 0, -1,
					SAM_MIXER_AUDIO_INPUT_SLAVE_BUS, -1);
  label=new Label(			this, "lbl_aout");
  toggle=new Toggle(			this, "aout_ext",
					SAM_MIXER_HW_ID_AUDIO_OUTPUT, 0, -1,
					SAM_MIXER_AUDIO_OUTPUT_EXTERNAL, -1);
  toggle=new Toggle(			this, "aout_dsp",
					SAM_MIXER_HW_ID_AUDIO_OUTPUT, 0, -1,
					SAM_MIXER_AUDIO_OUTPUT_MASTER_DSP, -1);
  label=new Label(			this, "lbl_mroute");
  toggle=new Toggle(			this, "mroute_dream",
					SAM_MIXER_HW_ID_MIDI_ROUTE, 0, -1,
					SAM_MIXER_MIDI_ROUTE_DREAM, -1);
  toggle=new Toggle(			this, "mroute_codec",
					SAM_MIXER_HW_ID_MIDI_ROUTE, 0, -1,
					SAM_MIXER_MIDI_ROUTE_CODEC, -1);
  label=new Label(			this, "lbl_di");
  toggle=new	Toggle(			this, "di_optical",
					SAM_MIXER_HW_ID_DIGITAL_INPUT, 0, -1,
					SAM_MIXER_DIGITAL_INPUT_OPTICAL, -1);
  toggle=new Toggle(			this, "di_coaxial",
					SAM_MIXER_HW_ID_DIGITAL_INPUT, 0, -1,
					SAM_MIXER_DIGITAL_INPUT_COAX, -1);
  label=new Label(			this, "lbl_dir");
  readOnly=new ReadOnly(		this, "dir",
					SAM_MIXER_HW_ID_DIGITAL_IN_RATE, 0, -1, True);
  readOnly->translate(SAM_MIXER_DIR_48K_4PERCENT, "48k_4p");
  readOnly->translate(SAM_MIXER_DIR_44K_4PERCENT, "44k_4p");
  readOnly->translate(SAM_MIXER_DIR_32K_4PERCENT, "32k_4p");
  readOnly->translate(SAM_MIXER_DIR_48K_400PPM, "48k");
  readOnly->translate(SAM_MIXER_DIR_44_1K_400PPM, "44k");
  readOnly->translate(SAM_MIXER_DIR_44_056K_400PPM, "44_056k");
  readOnly->translate(SAM_MIXER_DIR_32K_400PPM, "32k");
}

AnaOutPane::AnaOutPane(Group *aGroup, char *aName, int aTabPosition)
  : Pane(aGroup, aName, aTabPosition)
{
  Dial *dial;

  dial=new Dial(			this, "ana_out1l", NULL,
					SAM_MIXER_HW_ID_ANALOG_OUT_VOL, 0, -1,
					-94, 20, 1, 1, 94);
  dial=new Dial(			this, "ana_out1r", dial,
					SAM_MIXER_HW_ID_ANALOG_OUT_VOL, 1, -1,
					-94, 20, 1, 1, 94);
  dial=new Dial(			this, "ana_out2l", NULL,
					SAM_MIXER_HW_ID_ANALOG_OUT_VOL, 2, -1,
					-94, 20, 1, 1, 94);
  dial=new Dial(			this, "ana_out2r", dial,
					SAM_MIXER_HW_ID_ANALOG_OUT_VOL, 3, -1,
					-94, 20, 1, 1, 94);
}

BoxesPane::BoxesPane(Group *aGroup, char *aName, int aTabPosition)
  : Pane(aGroup, aName, aTabPosition)
{
  RadioBox *radioBox;
  int channel;
  char *channelName;

  radioBox=new RadioBox(		this, "midiin", SAM_MIXER_HW_ID_BOX_MIDI_IN, 0, -1,
					9, 0);
  for(channel=0; channel<4; channel++) {
    channelName=XtMalloc(4);
    sprintf(channelName, "ch%d", channel);
    radioBox=new RadioBox(		this, channelName, SAM_MIXER_HW_ID_BOX_CHANNEL, channel, -1,
					9, 0);
  }
}

void SoundBankPaneEvent::triggerSBankChanged(SoundbankInfo *sbanks, int count, int memSBank, int memFree)
{
  soundBankPane->sbankChanged(sbanks, count, memSBank, memFree);
}

XContext SoundBankPane::thisPtrContext;

SoundBankPane::SoundBankPane(Group *aGroup, char *aName, int aTabPosition)
  : Pane(aGroup, aName, aTabPosition),
    soundBankChangedEvent(this)
{
  wTitle=wList=wLblMemSBank=wMemSBank=wLblMemFree=wMemFree=NULL;
  wLoad=wUnload=wLblPrio=wPrio=NULL;
  list=NULL;
  fsSBankPath=NULL;
}

SoundBankPane::~SoundBankPane()
{
  if(list)
    XtFree((char *)list);
  if(fsSBankPath)
    XtFree(fsSBankPath);
}

void SoundBankPane::build(Widget parent)
{
  static int classInitialized;
  static XtActionsRec actions[]=
  {
    { "ackSBankText", ackTextAction },
  };
  static char textTranslations[]="\
<Key>Return:	ackSBankText()\n\
<Key>Linefeed:	ackSBankText()\n\
:<Key>KP_Enter:	ackSBankText()\
";

  if(wList)
    return;

  Pane::build(parent);

  if(!classInitialized) {
    XtAppAddActions(appl->appContext, actions, XtNumber(actions));
    classInitialized=1;
  }

  wTitle=XtVaCreateManagedWidget("title", labelWidgetClass, wPane,
				 NULL);
  wList=XtVaCreateManagedWidget("list", listWidgetClass, wPane,
				XtNforceColumns, True,
				XtNdefaultColumns, 1,
				NULL);
  XtAddCallback(wList, XtNcallback, elemSelectedCallback, this);
  wLblMemSBank=XtVaCreateManagedWidget("memsbank_lbl", labelWidgetClass, wPane,
				       NULL);
  wMemSBank=XtVaCreateManagedWidget("memsbank", labelWidgetClass, wPane,
				    NULL);
  wLblMemFree=XtVaCreateManagedWidget("memfree_lbl", labelWidgetClass, wPane,
				      NULL);
  wMemFree=XtVaCreateManagedWidget("memfree", labelWidgetClass, wPane,
				   NULL);
  wLoad=XtVaCreateManagedWidget("load", commandWidgetClass, wPane,
				NULL);
  XtAddCallback(wLoad, XtNcallback, loadCallback, this);
  wUnload=XtVaCreateManagedWidget("unload", commandWidgetClass, wPane,
				  NULL);
  XtAddCallback(wUnload, XtNcallback, unloadCallback, this);
  wLblPrio=XtVaCreateManagedWidget("prio_lbl", labelWidgetClass, wPane,
				   NULL);
  wPrio=XtVaCreateManagedWidget("prio", asciiTextWidgetClass, wPane,
				XtNeditType, XawtextEdit,
				NULL);
  Utils::saveAttachment(wPrio, thisPtrContext, (XPointer)this);
  XtOverrideTranslations(wPrio,
			 XtParseTranslationTable(textTranslations));
}

void SoundBankPane::setSensitive(Boolean enable)
{
  if(enable)
    soundBankChangedEvent.subscribe(&appl->device);
  else
    soundBankChangedEvent.unsubscribe();

  Pane::setSensitive(enable);
}

void SoundBankPane::sbankChanged(Event::SoundbankInfo *sbanks, int count, int memSBank, int memFree)
{
  int size, elemSize, i;
  char buf[32], *cp;
  XawListReturnStruct *current;

  size=(count+1)*sizeof(String);
  for(i=0; i<count; i++) {
    elemSize=strlen(sbanks[i].name)+8;
    if(elemSize<16)
      elemSize=16;
    size+=elemSize;
  }
  if(list)
    XtFree((char *)list);
  list=(String *)XtMalloc(size);
  cp=(char *)(list+count+1);
  for(i=0; i<count; i++) {
    list[i]=cp;
    if(*sbanks[i].name)
      cp+=sprintf(cp, "%d %-8s %d", i, sbanks[i].name, sbanks[i].priority)+1;
    else
      cp+=sprintf(cp, "%d", i)+1;
  }
  list[count]=NULL;

  XtVaSetValues(wList,
		XtNlist, list,
		XtNnumberStrings, 0,
		NULL);

  sprintf(buf, "%dk", memSBank>>9);
  XtVaSetValues(wMemSBank,
		XtNlabel, buf,
		NULL);

  sprintf(buf, "%dk", memFree>>9);
  XtVaSetValues(wMemFree,
		XtNlabel, buf,
		NULL);

  current=XawListShowCurrent(wList);
  elemSelected(current->list_index);
}

void SoundBankPane::elemSelected(int index)
{
  int prio;
  char buf[32];

  if(index>=0 && sscanf(list[index], "%*d %*s %d", &prio)==1) {
    sprintf(buf, "%d", prio);
    XtVaSetValues(wPrio,
		  XtNstring, buf,
		  NULL);
  } else
    XtVaSetValues(wPrio,
		  XtNstring, "",
		  NULL);
}

void SoundBankPane::loadSBank()
{
  char *fileName;
  XawListReturnStruct *current;

  current=XawListShowCurrent(wList);
  if(current->list_index>=0) {
    if((fileName=XsraSelFile(appl->top, appl->resources.fsSBankTitle, NULL, &fsSBankPath, 1, NULL))) {
      appl->device.loadSBank(current->list_index, fileName);
      XtFree(fileName);
    }
  }
}

void SoundBankPane::unloadSBank()
{
  XawListReturnStruct *current;

  current=XawListShowCurrent(wList);
  if(current->list_index>=0)
    appl->device.unloadSBank(current->list_index);
}

void SoundBankPane::changePrio()
{
  XawListReturnStruct *current;
  String str;

  current=XawListShowCurrent(wList);
  if(current->list_index>=0) {
    XtVaGetValues(wPrio, XtNstring, &str, NULL);
    appl->device.changeSBankPrio(current->list_index, atoi(str));
  }
}

void SoundBankPane::elemSelectedCallback(Widget w, XtPointer closure, XtPointer callData)
{
  SoundBankPane *sbankPane=(SoundBankPane *)closure;
  XawListReturnStruct *elem=(XawListReturnStruct *)callData;

  sbankPane->elemSelected(elem->list_index);
}

void SoundBankPane::loadCallback(Widget w, XtPointer closure, XtPointer callData)
{
  SoundBankPane *sbankPane=(SoundBankPane *)closure;

  sbankPane->loadSBank();
}

void SoundBankPane::unloadCallback(Widget w, XtPointer closure, XtPointer callData)
{
  SoundBankPane *sbankPane=(SoundBankPane *)closure;

  sbankPane->unloadSBank();
}

void SoundBankPane::ackTextAction(Widget w, XEvent *event, String *params, Cardinal *numParams)
{
  SoundBankPane *sbankPane=(SoundBankPane *)Utils::findAttachment(w, thisPtrContext);

  if(sbankPane)
    sbankPane->changePrio();
}
