#ifndef _UTILS_HH
#define _UTILS_HH

/* a collection of utlity functions */

#include <X11/Intrinsic.h>

#ifdef USE_XAW3D_HEADERS
#define XAW_HEADER(file) <X11/Xaw3d/file>
#else
#define XAW_HEADER(file) <X11/Xaw/file>
#endif

struct Menu {
  char *name;
  XtCallbackProc callback;
  struct Menu *subMenu;
};

class Utils {
public:
  static void buildMenu(Widget top, Menu *aMenu);
  static void saveAttachment(Widget w, XContext &context, XPointer data);
  static XPointer findAttachment(Widget w, XContext context);
  static char *getStringSubResource(Widget w, char *resName, char *resClass);
};

#endif /* _UTILS_HH */
