#ifndef _API_NONE_HH
#define _API_NONE_HH

#include "controls.hh"

class Application;

class ApiNone : public Api {
public:
  ApiNone(Application *aAppl);
};

#endif /* _API_NONE_HH */
