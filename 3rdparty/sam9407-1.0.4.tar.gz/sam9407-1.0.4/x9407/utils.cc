/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "utils.hh"

#include XAW_HEADER(MenuButton.h)
#include XAW_HEADER(SimpleMenu.h)
#include XAW_HEADER(SmeBSB.h)

void Utils::buildMenu(Widget top, Menu *aMenu)
{
  Menu *menu;
  Widget w;
  char buf[256];
  for(menu=aMenu; menu->name; menu++) {
    if(menu->subMenu) {
      sprintf(buf, "%s_menu", menu->name);
      w=XtVaCreatePopupShell(buf, simpleMenuWidgetClass, top,
			     NULL);
      buildMenu(w, menu->subMenu);
      w=XtVaCreateManagedWidget(menu->name, menuButtonWidgetClass, top,
				XtNmenuName, XtNewString(buf),
				NULL);
    } else
      w=XtVaCreateManagedWidget(menu->name, smeBSBObjectClass, top,
				NULL);
    if(menu->callback)
      XtAddCallback(w, XtNcallback, menu->callback, NULL);
  }
}

void Utils::saveAttachment(Widget w, XContext &context, XPointer data)
{
  if(!context)
    context=XUniqueContext();

  XSaveContext(XtDisplay(w), (XID)w, context, data);
}

XPointer Utils::findAttachment(Widget w, XContext context)
{
  Display *dpy;
  Widget search;
  XPointer result;

  for(search=w; search && !XtIsWidget(search); search=XtParent(search));
  if(!search)
    return NULL;

  dpy=XtDisplay(search);
  
  while(search) {
    if(XFindContext(dpy, (XID)search, context, &result)==0)
      return result;
    search=XtParent(search);
  }
  return NULL;
}

char *Utils::getStringSubResource(Widget w, char *resName, char *resClass)
{
  XtResource resource;
  struct StringResource {
    String str;
  } value;

  resource.resource_name=resName;
  resource.resource_class=resClass;
  resource.resource_type=XtRString;
  resource.resource_size=sizeof(String);
  resource.resource_offset=XtOffsetOf(StringResource, str);
  resource.default_type=XtRString;
  resource.default_addr=NULL;

  value.str=NULL;
  XtVaGetSubresources(w, &value, "sub", "Sub", &resource, 1, NULL);
  return value.str;
}
