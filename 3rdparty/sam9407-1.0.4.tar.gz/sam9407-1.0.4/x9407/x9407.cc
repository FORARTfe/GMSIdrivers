/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdarg.h>
#include <errno.h>
#include <pwd.h>
#include <string>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>

#include <X11/xpm.h>

#include "Tab.h"
#include "Layout.h"

#include "controls.hh"
#include "x9407.hh"

#include "resources.hh"
#include "x9407.xpm"

#include XAW_HEADER(Command.h)

#include "api_none.hh"
#ifdef SUPPORT_VANILLA
#include "api_vanilla.hh"
#endif
#ifdef SUPPORT_HOMSTDR
#include "api_homstdr.hh"
#endif

XContext Application::thisPtrContext;
Menu Application::fileMenu[]={
  {
    "load",
    loadCallback
  },
  {
    "save",
    saveCallback
  },
  {
    "copyright",
    copyrightCallback
  },
  {
    "quit",
    quitCallback
  },
  {
    NULL		/* sentinel */
  }
};

Menu Application::mainMenu[]={
  {
    "file",
    NULL,
    fileMenu
  },
  {
    NULL		/* sentinel */
  }
};

XrmOptionDescRec Application::x9407Options[] = {
  {"-card", "card", XrmoptionSepArg, NULL},
  {"-syncWithFile", "syncWithFile", XrmoptionSepArg, NULL},
};

XtResource Application::x9407Resources[] = {
  {
    "card", "Card",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, card),
    XtRImmediate, (XtPointer)0
  },
  {
    "adjustRelatedButton", "AdjustRelatedButton",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, adjustRelatedButton),
    XtRImmediate, (XtPointer)2
  },
  {
    "errorMsgTimeout", "ErrorMsgTimeout",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, errorMsgTimeout),
    XtRImmediate, (XtPointer)2000
  },
  {
    "syncWriteDelay", "SyncWriteDelay",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, syncWriteDelay),
    XtRImmediate, (XtPointer)10000
  },
  {
    "pollValueInterval", "PollValueInterval",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, pollValueInterval),
    XtRImmediate, (XtPointer)2000
  },
  {
    "pollPeakMeterInterval", "PollPeakMeterInterval",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, pollPeakMeterInterval),
    XtRImmediate, (XtPointer)250
  },
  {
    "verifyChannelOwnerDelay", "VerifyChannelOwnerDelay",
    XtRInt, sizeof(int),
    XtOffsetOf(Resources, verifyChannelOwnerDelay),
    XtRImmediate, (XtPointer)500
  },
  {
    "syncWithFile", "SyncWithFile",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, syncWithFile),
    XtRString, NULL
  },
  {
    "applTitle", "ApplTitle",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, applTitle),
    XtRString, (XtPointer)"x9407"
  },
  {
    "fsLoadTitle", "FSLoadTitle",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, fsLoadTitle),
    XtRString, (XtPointer)"Load Settings"
  },
  {
    "fsSaveTitle", "FSSaveTitle",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, fsSaveTitle),
    XtRString, (XtPointer)"Save Settings"
  },
  {
    "fsFirmTitle", "FSFirmTitle",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, fsFirmTitle),
    XtRString, (XtPointer)"Load Firmware"
  },
  {
    "fsSBankTitle", "FSSBankTitle",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, fsSBankTitle),
    XtRString, (XtPointer)"Load Soundbank"
  },
  {
    "cardNone", "CardNone",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, cardNone),
    XtRString, (XtPointer)"None"
  },
  {
    "noFirmware", "NoFirmware",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, noFirmware),
    XtRString, (XtPointer)"N/A"
  },
  {
    "noOwner", "NoOwner",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, noOwner),
    XtRString, (XtPointer)"None"
  },
  {
    "errIncompatibleApi", "ErrIncompatibleApi",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errIncompatibleApi),
    XtRString, (XtPointer)"Incompatible API versions, please recompile"
  },
  {
    "errNoCardSelected", "ErrNoCardSelected",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errNoCardSelected),
    XtRString, (XtPointer)"No card selected"
  },
  {
    "errDeviceNotUsable", "ErrDeviceNotUsable",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errDeviceNotUsable),
    XtRString, (XtPointer)"Please select a usable device first"
  },
  {
    "errQueryApi", "ErrQueryApi",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQueryApi),
    XtRString, (XtPointer)"Can't query API info"
  },
  {
    "errQueryDriver", "ErrQueryDriver",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQueryDriver),
    XtRString, (XtPointer)"Can't query driver info"
  },
  {
    "errQuerySBank", "ErrQuerySBank",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQuerySBank),
    XtRString, (XtPointer)"Can't query soundbank info"
  },
  {
    "errQueryMixer", "ErrQueryMixer",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQueryMixer),
    XtRString, (XtPointer)"Can't query mixer info"
  },
  {
    "errSetMixer", "ErrSetMixer",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errSetMixer),
    XtRString, (XtPointer)"Can't set mixer values"
  },
  {
    "errReadMixer", "ErrReadMixer",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errReadMixer),
    XtRString, (XtPointer)"Error while reading from mixer device"
  },
  {
    "errQueryPeakMeter", "ErrQueryPeakMeter",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQueryPeakMeter),
    XtRString, (XtPointer)"Can't query peak meter values"
  },
  {
    "errQueryChannelOwner", "ErrQueryChannelOwner",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errQueryChannelOwner),
    XtRString, (XtPointer)"Can't query channel owner"
  },
  {
    "errOpenInputFile", "ErrOpenInputFile",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errOpenInputFile),
    XtRString, (XtPointer)"Can't open input file"
  },
  {
    "errOpenOutputFile", "ErrOpenOutputFile",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errOpenOutputFile),
    XtRString, (XtPointer)"Can't open output file"
  },
  {
    "errOpenDev", "ErrOpenDev",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errOpenDev),
    XtRString, (XtPointer)"Can't open device"
  },
  {
    "errOpenFirm", "ErrOpenFirm",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errOpenFirm),
    XtRString, (XtPointer)"Can't open firmware"
  },
  {
    "errLoadFirm", "ErrLoadFirm",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errLoadFirm),
    XtRString, (XtPointer)"Can't load firmware"
  },
  {
    "errOpenSBank", "ErrOpenSBank",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errOpenSBank),
    XtRString, (XtPointer)"Can't open soundbank"
  },
  {
    "errLoadSBank", "ErrLoadSBank",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errLoadSBank),
    XtRString, (XtPointer)"Can't load soundbank"
  },
  {
    "errUnloadSBank", "ErrUnloadSBank",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errUnloadSBank),
    XtRString, (XtPointer)"Can't unload soundbank"
  },
  {
    "errSBankPrioChg", "ErrSBankPrioChg",
    XtRString, sizeof(String),
    XtOffsetOf(Resources, errSBankPrioChg),
    XtRString, (XtPointer)"Can't change soundbank priority"
  },
};

XtActionsRec Application::x9407Actions[] = {
  { "quit", Application::quitAction },
  { "dismiss", Application::dismissAction },
};

ApplicationEvent::ApplicationEvent(Application *aAppl, Type aType)
  : Event(aType)
{
  appl=aAppl;
  subscribe(&appl->device);
}

void ApplicationEvent::triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName)
{
  char buf[16];

  if(appl->device.isUsable())
    appl->loadSyncFile();

  appl->title=appl->resources.applTitle;
  if(*hwName) {
    appl->title+=" (";
    sprintf(buf, "#%d:", cardNr);
    appl->title+=buf;
    appl->title+=hwName;
    appl->title+=")";
  }
  XtVaSetValues(appl->top,
		XtNtitle, appl->title.c_str(),
		XtNiconName, appl->title.c_str(),
		NULL);
}

void ApplicationEvent::triggerDeviceClosed(int cardNr)
{
  appl->saveSyncFileIfModified();

  if(appl->fsConfigPath) {
    XtFree(appl->fsConfigPath);
    appl->fsConfigPath=NULL;
  }

  XtVaSetValues(appl->top,
		XtNtitle, appl->resources.applTitle,
		XtNiconName, appl->resources.applTitle,
		NULL);
}

void Application::quitAction(Widget w, XEvent *event, String *params, Cardinal *numParams)
{
  Application *appl=(Application *)Utils::findAttachment(w, thisPtrContext);

  if(appl)
    appl->quitMainLoopRequested=1;
}

void Application::dismissAction(Widget w, XEvent *event, String *params, Cardinal *numParams)
{
  XtUnmapWidget(w);
}

void Application::copyrightCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Application *appl=(Application *)Utils::findAttachment(w, thisPtrContext);
  Widget layout, dismiss;
  Atom wmDeleteWindow;

  if(!appl)
    return;

  if(!appl->copyright) {
    appl->copyright=XtVaAppCreateShell("copyright", "Copyright",
				       transientShellWidgetClass, XtDisplay(appl->top),
				       XtNtransientFor, appl->top,
				       NULL);
    layout=XtVaCreateManagedWidget("layout", layoutWidgetClass, appl->copyright,
				   NULL);
    XtVaCreateManagedWidget("msg", labelWidgetClass, layout,
			    NULL);
    dismiss=XtVaCreateManagedWidget("dismiss", commandWidgetClass, layout,
				    NULL);
    XtAddCallback(dismiss, XtNcallback, dismissCallback, NULL);
    XtOverrideTranslations(appl->copyright, XtParseTranslationTable ("<Message>WM_PROTOCOLS: dismiss()"));
    XtRealizeWidget(appl->copyright);

    wmDeleteWindow=XInternAtom(XtDisplay(appl->copyright), "WM_DELETE_WINDOW", False);
    XSetWMProtocols(XtDisplay(appl->copyright), XtWindow(appl->copyright), &wmDeleteWindow, 1);
  }

  XtMapWidget(appl->copyright);
}

void Application::quitCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Application *appl=(Application *)Utils::findAttachment(w, thisPtrContext);

  if(appl)
    appl->quitMainLoopRequested=1;
}

void Application::dismissCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Widget shell;

  for(shell=w; !XtIsShell(shell); shell=XtParent(shell));
  XtUnmapWidget(shell);
}

void Application::getLoadSaveDefaultFileName(string &dest)
{
  char *home;
  struct passwd *pwd;
  char buf[32];

  dest="";
  if(!(home=getenv("HOME"))) {
    if((pwd=getpwuid(getuid()))) {
      dest+=pwd->pw_dir;
    }
  } else
    dest+=home;
  if(dest.length())
    dest+="/";
  dest+=".sam9407_";
  sprintf(buf, "%d", device.getCardNr());
  dest+=buf;
}

void Application::getSyncFileName(string &dest)
{
  char *cp;
  char buf[32];

  dest="";
  for(cp=resources.syncWithFile; *cp;) {
    if(*cp=='%') {
      switch(*++cp) {
      case 'c':
	sprintf(buf, "%d", device.getCardNr());
	dest+=buf;
	cp++;
	break;
      case 0:
	/* EOS in specifier */
	break;
      default:
	dest+=*cp++;
      }
    } else
      dest+=*cp++;
  }
}

void Application::loadCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Application *appl=(Application *)Utils::findAttachment(w, thisPtrContext);
  string defPath;
  char *fileName;

  if(!appl)
    return;

  if(!appl->device.isUsable()) {
    appl->error(0, appl->resources.errDeviceNotUsable, NULL);
    return;
  }

  appl->getLoadSaveDefaultFileName(defPath);

  if((fileName=XsraSelFile(appl->top, appl->resources.fsLoadTitle, (char *)defPath.c_str(), &appl->fsConfigPath, 0, NULL))) {
    appl->device.loadSettings(1, fileName);
    XtFree(fileName);
  }
}

void Application::saveCallback(Widget w, XtPointer closure, XtPointer callData)
{
  Application *appl=(Application *)Utils::findAttachment(w, thisPtrContext);
  string defPath;
  char *fileName;

  if(!appl->device.isUsable()) {
    appl->error(0, appl->resources.errDeviceNotUsable, NULL);
    return;
  }

  appl->getLoadSaveDefaultFileName(defPath);

  if((fileName=XsraSelFile(appl->top, appl->resources.fsSaveTitle, (char *)defPath.c_str(), &appl->fsConfigPath, 0, NULL))) {
    appl->device.saveSettings(1, fileName);
    XtFree(fileName);
  }
}

void Application::eraseMessage(XtPointer closure, XtIntervalId *id)
{
  Application *appl=(Application *)closure;
  XtVaSetValues(appl->msg, XtNlabel, "", NULL);
}

void Application::fatal(int perr, ...)
{
  int savedErrno=errno;
  char *cp;
  va_list ap;

  fprintf(stderr, "%s: ", argv[0]);
  va_start(ap, perr);
  while((cp=va_arg(ap, char *))) {
    fprintf(stderr, "%s", cp);
  }
  va_end(ap);

  if(perr)
    fprintf(stderr, ": %s", strerror(savedErrno));

  fprintf(stderr, "\n");

  exit(1);
}

void Application::error(int perr, ...)
{
  int savedErrno=errno;
  string str;
  char *cp;
  va_list ap;

  if(!msg)
    return;

  if(msgTimeoutId) {
    XtRemoveTimeOut(msgTimeoutId);
    msgTimeoutId=0;
  }

  va_start(ap, perr);
  while((cp=va_arg(ap, char *)))
    str+=cp;
  va_end(ap);

  if(perr) {
    str+=": ";
    str+=strerror(savedErrno);
  }

  XtVaSetValues(msg, XtNlabel, str.c_str(), NULL);

  msgTimeoutId=XtAppAddTimeOut(appContext, resources.errorMsgTimeout, eraseMessage, this);
}

void Application::loadSyncFile()
{
  string fileName;

  if(!resources.syncWithFile)
    return;

  getSyncFileName(fileName);
  device.loadSettings(0, (char *)fileName.c_str());
}

void Application::saveSyncFileIfModified()
{
  string fileName;

  if(!resources.syncWithFile ||
     !mixerValuesNotSaved)
    return;

  getSyncFileName(fileName);
  device.saveSettings(0, (char *)fileName.c_str());
  mixerValuesNotSaved=0;
}

void Application::syncFileSaveCB(XtPointer closure, XtIntervalId *id)
{
  Application *appl=(Application *)closure;

  appl->saveSyncFileIfModified();
  appl->syncWriteDelayId=0;
}

void Application::triggerDelayedSaveSyncFile(void)
{
  if(!resources.syncWithFile)
    return;

  mixerValuesNotSaved=1;

  if(syncWriteDelayId) {
    XtRemoveTimeOut(syncWriteDelayId);
    syncWriteDelayId=0;
  }

  syncWriteDelayId=XtAppAddTimeOut(appContext, resources.syncWriteDelay, syncFileSaveCB, this);
}

Application::Application(int aArgc, char **aArgv)
  : device(this),
    fwChangedEvent(this, Event::FirmwareChanged),
    devClosedEvent(this, Event::DeviceClosed)
{
  argc=aArgc;
  argv=aArgv;
  quitMainLoopRequested=False;
  appContext=NULL;
  top=msg=classes=copyright=visiblePane=NULL;
  iconPixmap=iconMask=None;
  msgTimeoutId=0;
  syncWriteDelayId=0;
  fsConfigPath=NULL;
  mixerValuesNotSaved=False;
}

Application::~Application()
{
  if(fsConfigPath)
    XtFree(fsConfigPath);
}

void Application::build()
{
  Widget main;
  Pixmap iconPixmap, iconMask;

  if(top)
    return;

  top=XtVaAppInitialize(&appContext, "X9407", x9407Options, XtNumber(x9407Options), &argc, argv, fallbackResources,
			NULL);
  Utils::saveAttachment(top, thisPtrContext, (XPointer)this);

  XtVaGetValues(top, XtNiconPixmap, &iconPixmap, NULL);
  if(!iconPixmap) {
    if(XpmCreatePixmapFromData(XtDisplay(top),
			       RootWindowOfScreen(XtScreen(top)),
			       x9407_xpm, &iconPixmap, &iconMask, NULL)==XpmSuccess)
      XtVaSetValues(top,
		    XtNiconPixmap, iconPixmap,
		    XtNiconMask, iconMask,
		    NULL);
  }

  XtVaGetApplicationResources(top, &resources,
			      x9407Resources, XtNumber(x9407Resources),
			      NULL);

  XtAppAddActions(appContext, x9407Actions, XtNumber(x9407Actions));
 
  main=XtVaCreateManagedWidget("main", layoutWidgetClass, top,
			       NULL);

  /* create menu bar */
  Utils::buildMenu(main, mainMenu);

  classes=XtVaCreateManagedWidget("classes", tabWidgetClass, main,
				  XtNuserSelectable, False,
				  XtNtabVisible, False,
				  XtNmarginWidth, 0,
				  XtNshadowThickness, 0,
				  NULL);

  msg=XtVaCreateManagedWidget("msg", labelWidgetClass, main,
			      XtNlabel, "",
			      NULL);

  XtOverrideTranslations(top, XtParseTranslationTable ("<Message>WM_PROTOCOLS: quit()"));
}

void Application::mainLoop()
{
  Atom wmDeleteWindow;
  XEvent event;

  if(!XtIsRealized(top)) {
    XtRealizeWidget(top);
    wmDeleteWindow=XInternAtom(XtDisplay(top), "WM_DELETE_WINDOW", False);
    XSetWMProtocols(XtDisplay(top), XtWindow(top), &wmDeleteWindow, 1);
  }

  quitMainLoopRequested=False;
  while(!quitMainLoopRequested) {
    XtAppNextEvent(appContext, &event);
    XtDispatchEvent(&event);
  }
}

Application *x9407;

int main(int argc, char **argv)
{
  Api *api;
  Application x9407(argc, argv);

  api=new ApiNone(&x9407);
#ifdef SUPPORT_VANILLA
  api=new ApiVanilla(&x9407);
#endif
#ifdef SUPPORT_HOMSTDR
  api=new ApiHomstdr(&x9407);
#endif

  x9407.build();

  x9407.device.rescan();
  x9407.device.open(x9407.resources.card);

  x9407.mainLoop();

  return 0;
}
