/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "../kernel/sam9407.h"
#include "x9407.hh"
#include "device.hh"

#include "ctrlnames.h"

#ifndef MAP_FAILED
#define MAP_FAILED ((void *)-1)
#endif

#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

Event::~Event()
{
  if(device)
    unsubscribe();
}

void Event::subscribe(Device *aDevice)
{
  Event **headP=NULL;

  if(device)
    return;

  device=aDevice;

  switch(type) {
  case DevicesRescanned:
    headP=&device->devRescannnedEvents;
    break;
  case DeviceClosed:
    headP=&device->devCloseEvents;
    break;
  case FirmwareChanged:
    headP=&device->firmwareChangedEvents;
    break;
  case SBankChanged:
    headP=&device->sbankChangedEvents;
    break;
  case MixerValue:
    headP=device->findEventPInBuckets(device->mixerChangedEvents, (id<<8)|addr);
    break;
  case AudioValue:
    headP=device->findEventPInBuckets(device->audioChangedEvents, (channel<<16)|(id<<8)|addr);
    break;
  case PeakMeterChanged:
    headP=&device->peakMeterEvents;
    break;
  case ChannelOwnerChanged:
    headP=&device->channelOwnerEvents;
    break;
  }

  prevP=headP;
  if(*headP)
    (*headP)->prevP=&next;
  next=*headP;
  *headP=this;
}

void Event::unsubscribe()
{
  if(!device)
    return;

  if(next)
    next->prevP=prevP;
  *prevP=next;
  device=NULL;
}

void Event::triggerDevicesRescanned(DeviceInfo *devices, int count)
{
}

void Event::triggerDeviceClosed(int cardNr)
{
}

void Event::triggerFirmwareChanged(int cardNr, int apiClass, char *hwName, char *fwName)
{
}

void Event::triggerSBankChanged(SoundbankInfo *sbanks, int count, int memSBank, int memFree)
{
}

void Event::triggerMixerValue(int value)
{
}

void Event::triggerAudioValue(int value)
{
}

void Event::triggerPeakMeter(unsigned short *tbl)
{
}

void Event::triggerChannelOwner(int *pids)
{
}

void Device::mixerEvent(XtPointer closure, int *source, XtInputId *inputId)
{
  Device *device=(Device *)closure;
  SamEvent events[EventChunkSize];
  int n;

  if((n=read(device->mixerFd, events, sizeof(events)))<0) {
    device->appl->error(1, device->appl->resources.errReadMixer, NULL);
    return;
  }

  device->handleEvents(events, n/sizeof(SamEvent));
}

void Device::pollPeakMeter(XtPointer closure, XtIntervalId *id)
{
  Device *device=(Device *)closure;

  device->pollPeakMeterId=0;

  if(device->mixerFd>=0)
    device->triggerPeakMeter();

  device->startPollPeakMeter();
}

void Device::verifyChannelOwner(XtPointer closure, XtIntervalId *id)
{
  Device *device=(Device *)closure;

  device->verifyChannelOwnerId=0;
  device->triggerChannelOwner();
}

Device::Device(Application *aAppl)
{
  SamCtrlNameAssoc *assoc;
  map<XrmQuark, SamCtrlNameAssoc *, less<XrmQuark> > *ctrlsByName;
  map<int, SamCtrlNameAssoc *, less<int> > *ctrlsById;
  int apiIdx;

  appl=aAppl;
  cardNr=0;
  mixerFd=-1;
  apiClass=SAM_API_CLASS_NONE;
  playbackChannels=0;
  inputId=0;
  pollPeakMeterId=0;
  verifyChannelOwnerId=0;
  devRescannnedEvents=devCloseEvents=firmwareChangedEvents=NULL;
  sbankChangedEvents=peakMeterEvents=channelOwnerEvents=NULL;
  memset(mixerChangedEvents, 0, sizeof(mixerChangedEvents));
  memset(audioChangedEvents, 0, sizeof(audioChangedEvents));

  /* construct SamCtrlNameAssoc mappings */
  for(assoc=samMixerAssocHW; assoc->name; assoc++) {
    mixerHWCtrlsById[assoc->id]=assoc;
    mixerHWCtrlsByName[XrmStringToQuark(assoc->name)]=assoc;
  }
  for(apiIdx=0; samApiAssocs[apiIdx].name; apiIdx++) {
    ctrlsByName=&allMixerCtrlsByName[samApiAssocs[apiIdx].apiClass];
    ctrlsById=&allMixerCtrlsById[samApiAssocs[apiIdx].apiClass];
    for(assoc=samApiAssocs[apiIdx].mixer; assoc->name; assoc++) {
      (*ctrlsById)[assoc->id]=assoc;
      (*ctrlsByName)[XrmStringToQuark(assoc->name)]=assoc;
    }

    ctrlsByName=&allAudioCtrlsByName[samApiAssocs[apiIdx].apiClass];
    for(assoc=samApiAssocs[apiIdx].audio; assoc->name; assoc++)
      (*ctrlsByName)[XrmStringToQuark(assoc->name)]=assoc;
  }
}

void Device::rescan()
{
  int card, fd;
  char devName[256];
  SamApiInfo apiInfo;
  SamDriverInfo driverInfo[MaxCards];
  Event::DeviceInfo deviceInfo[MaxCards];
  Event *event;

  for(card=0; card<MaxCards; card++) {
    sprintf(devName, "/dev/sam9407/card%d/mixer", card);
    fd=::open(devName, O_RDWR);
    if(fd<0) {
      sprintf(devName, "/dev/sam%d_mixer", card);
      fd=::open(devName, O_RDWR);
    }
    if(fd<0 && card==0)
      fd=::open("/dev/mixer", O_RDWR);
    if(fd<0)
      break;
    if(::ioctl(fd, SAM_IOC_API_INFO, &apiInfo)<0 ||
       apiInfo.version!=SAM_MIXER_API_VERSION ||
       ::ioctl(fd, SAM_IOC_DRIVER_INFO, driverInfo+card)<0) {
      ::close(fd);
      break;
    }
    ::close(fd);
    deviceInfo[card].hwName=driverInfo[card].hardware;
    deviceInfo[card].fwName=driverInfo[card].firmware;
  }

  for(event=devRescannnedEvents; event; event=event->next)
    event->triggerDevicesRescanned(deviceInfo, card);
}

void Device::open(int aCardNr)
{
  char devName[256];
  SamApiInfo apiInfo;

  if(mixerFd>=0)
    close();

  if(aCardNr<0)
    return;

  sprintf(devName, "/dev/sam9407/card%d/mixer", aCardNr);
  mixerFd=::open(devName, O_RDWR);
  if(mixerFd<0) {
    sprintf(devName, "/dev/sam%d_mixer", aCardNr);
    mixerFd=::open(devName, O_RDWR);
  }
  if(mixerFd<0 && aCardNr==0)
    mixerFd=::open("/dev/mixer", O_RDWR);

  if(mixerFd>=0 && ::ioctl(mixerFd, SAM_IOC_API_INFO, &apiInfo)<0) {
    appl->error(1, appl->resources.errQueryApi, NULL);
    ::close(mixerFd);
    mixerFd=-1;
  }

  if(mixerFd>=0 && apiInfo.version!=SAM_MIXER_API_VERSION) {
    appl->error(0, appl->resources.errIncompatibleApi, NULL);
    ::close(mixerFd);
    mixerFd=-1;
  }

  if(mixerFd>=0) {
    cardNr=aCardNr;
    inputId=XtAppAddInput(appl->appContext, mixerFd, (XtPointer) XtInputReadMask, mixerEvent, this);
  }

  if(mixerFd>=0)
    triggerFirmwareChanged(apiInfo.apiClass);
  else
    triggerFirmwareChanged(SAM_API_CLASS_NONE);
}

void Device::close()
{
  Event *event;

  if(mixerFd<0)
    return;

  stopPollPeakMeter();

  for(event=devCloseEvents; event; event=event->next)
    event->triggerDeviceClosed(cardNr);

  XtRemoveInput(inputId);
  inputId=0;

  ::close(mixerFd);
  mixerFd=-1;
  cardNr=0;
  apiClass=SAM_API_CLASS_NONE;
}

int Device::isUsable()
{
  return mixerFd>=0 && apiClass!=SAM_API_CLASS_NONE;
}

void Device::setApiSupported(int apiClass)
{
  supportedApis[apiClass]=1;
}

void Device::adjust(int id, int addr, int channel, int value)
{
  SamControl ctrls[2];
  map<int, SamCtrlNameAssoc *, less<int> > *ctrlsById;
  SamCtrlNameAssoc *assoc;
  int handled, i;

  if(mixerFd<0)
    return;

  ctrls[0].id=id;
  ctrls[0].addr=addr;
  ctrls[0].value=value;
  ctrls[1].id=SAM_MIXER_ID_SENTINEL;

  if(channel>=0)
    sendAudioControls(1, channel, ctrls);
  else {
    /* check if a reset-control has been requested */
    handled=0;
    ctrlsById=&allMixerCtrlsById[apiClass];
    if(ctrlsById->count(id))
      assoc=(*ctrlsById)[id];
    else if(mixerHWCtrlsById.count(id))
      assoc=mixerHWCtrlsById[id];
    else
      assoc=NULL;
    if(assoc && assoc->doesReset) {
      for(i=0; samApiAssocs[i].name; i++)
	if(samApiAssocs[i].apiClass==apiClass)
	  break;
      if(samApiAssocs[i].name) {
	/* reset control */
	sendMixerControls(1, samApiAssocs[i].mixer, 1, ctrls);
	handled=1;
      }
    }
    if(!handled) {
      /* non-reset control */
      sendMixerControls(1, NULL, 0, ctrls);
    }
  }

  appl->triggerDelayedSaveSyncFile();
}

void Device::sendMixerControls(int complain, SamCtrlNameAssoc *mixerAssocFW, int doesReset, SamControl *mixerControls)
{
  SamCtrlNameAssoc *mixerAssocList[2], *mixerAssoc;
  SamControl oldControls[SAM_MIXER_CONTROLS+1];
  int error, n, i, addr;

  if(doesReset) {
    memset(oldControls, 0, sizeof(oldControls));
    n=0;
    mixerAssocList[0]=samMixerAssocHW;
    mixerAssocList[1]=mixerAssocFW;
    for(i=0; i<(int)XtNumber(mixerAssocList); i++) {
      for(mixerAssoc=mixerAssocList[i]; mixerAssoc->name; mixerAssoc++) {
	if(!mixerAssoc->doesReset) {
	  for(addr=0; addr<=mixerAssoc->addrLimit; addr++) {
	    oldControls[n].id=mixerAssoc->id;
	    oldControls[n].addr=addr;
	    n++;
	  }
	}
      }
    }
    oldControls[n].id=SAM_MIXER_ID_SENTINEL;

    if(ioctl(mixerFd, SAM_IOC_MIXER_GET, oldControls)<0 && complain)
      appl->error(1, appl->resources.errSetMixer, NULL);
  }

  if((error=ioctl(mixerFd, SAM_IOC_MIXER_SET, mixerControls))<0 && complain)
    appl->error(1, appl->resources.errSetMixer, NULL);
    

  /* restore old values only if the call succeeded
   * or more than one change control has been requested
   */
  if(doesReset &&
     (error>=0 ||
      ( mixerControls[0].id!=SAM_MIXER_ID_SENTINEL &&
	mixerControls[1].id!=SAM_MIXER_ID_SENTINEL))) {
    if(ioctl(mixerFd, SAM_IOC_MIXER_SET, oldControls)<0 && complain)
      appl->error(1, appl->resources.errSetMixer, NULL);
  }
}

void Device::sendAudioControls(int complain, int channel, SamControl *audioControls)
{
  SamRedirectedAudioControl redir;

  if(channel&RecordChannelMask)
    redir.channel=playbackChannels+(channel&~RecordChannelMask);
  else
    redir.channel=channel;
  redir.controls=audioControls;

  if(ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_SET, &redir)<0 && complain)
    appl->error(1, appl->resources.errSetMixer, NULL);
}

void Device::poll(int id, int addr, int channel)
{
  SamEvent event;

  if(channel>=0)
    event.type=channel;
  else
    event.type=SAM_EVENT_TYPE_MIXER;
  event.id=id;
  event.addr=addr;

  handleEvents(&event, 1);
}

void Device::loadSettings(int complain, char *fileName)
{
  SamDriverInfo driverInfo;
  SamCtrlNameAssoc *mixerAssocFW, *mixerAssoc;
  map<XrmQuark, SamCtrlNameAssoc *, less<XrmQuark> > *mixerCtrlsByName, *audioCtrlsByName;
  FILE *fp;
  char buf[256], *apiName, *name, *value, *cp;
  SamControl controls[MAX(SAM_MIXER_CONTROLS, SAM_AUDIO_CONTROLS)+1], *controlP;
  int nControls, pass, audioChannels;
  int cardMatch, classMatch, currentChannel, addr, i;
  XrmQuark quarkCard, quarkClass, quarkMixer, quarkAudioPlay, quarkAudioRecord, quark;

  if(::ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
    if(complain)
      appl->error(1, appl->resources.errQueryDriver, NULL);
    return;
  }
  
  audioChannels=driverInfo.playChannelsTotal+driverInfo.recordChannelsTotal;

  for(i=0; samApiAssocs[i].name; i++)
    if(samApiAssocs[i].apiClass==apiClass)
      break;
  if(!samApiAssocs[i].name)
    return;
  apiName=samApiAssocs[i].name;

  mixerCtrlsByName=&allMixerCtrlsByName[apiClass];
  audioCtrlsByName=&allAudioCtrlsByName[apiClass];

  mixerAssocFW=samApiAssocs[i].mixer;

  if(!(fp=fopen(fileName, "r"))) {
    if(complain)
      appl->error(0, appl->resources.errOpenInputFile, NULL);
    return;
  }

  quarkCard=XrmStringToQuark("card");
  quarkClass=XrmStringToQuark("class");
  quarkMixer=XrmStringToQuark("mixer");
  quarkAudioPlay=XrmStringToQuark("audio_play");
  quarkAudioRecord=XrmStringToQuark("audio_record");

  /* send reset controls in first pass
   * non-reset controls in second
   */
  for(pass=0; pass<2; pass++) {
    cardMatch=cardNr==0;
    classMatch=apiClass==SAM_API_CLASS_VANILLA;
    currentChannel=-1;
    nControls=0;

    rewind(fp);

    while(fgets(buf, sizeof(buf), fp)) {
      cp=buf;
      while(isspace(*cp)) cp++;
      if(!*cp || *cp=='#')
	continue;
      name=cp;
      while(*cp && !isspace(*cp)) cp++;
      if(*cp)
	*cp++=0;
      quark=XrmStringToQuark(name);
      /* skip spaces at the beginning of addr/value */
      while(isspace(*cp)) cp++;
      /* check for an optional address */
      addr=0;
      if(*cp=='[') {
	cp++;
	while(isspace(*cp)) cp++;
	while(*cp>='0' && *cp<='9')
	  addr=addr*10+*cp++-'0';
	while(isspace(*cp)) cp++;
	if(*cp!=']') /* syntax error */
	  continue;
	cp++;
      }
      /* skip spaces at the beginning of value */
      while(isspace(*cp)) cp++;
      value=cp;
      /* find the end of value */
      while(*cp && !isspace(*cp)) cp++;
      *cp=0;
    
      if(quark==quarkCard || quark==quarkMixer || quark==quarkAudioPlay || quark==quarkAudioRecord) {
	/* switch to a new channel
	 * we need to flush pending mixer control
	 * values
	 */
	if(nControls>0) {
	  controls[nControls].id=SAM_MIXER_ID_SENTINEL;
	  if(currentChannel>=0)
	    sendAudioControls(complain, currentChannel, controls);
	  else
	    sendMixerControls(complain, mixerAssocFW, pass==0, controls);
	  nControls=0;
	}
      }

      if(quark==quarkCard) {
	cardMatch=strtol(value, NULL, 0)==cardNr;
	classMatch=apiClass==SAM_API_CLASS_VANILLA;
	currentChannel=-1;
	continue;
      }

      if(quark==quarkClass) {
	for(cp=value; *cp; cp++)
	  *cp=toupper(*cp);
	classMatch=strcmp(value, apiName)==0;
	continue;
      }

      if(quark==quarkMixer) {
	currentChannel=-1;
	continue;
      }

      if(quark==quarkAudioPlay) {
	currentChannel=strtol(value, NULL, 0);
	continue;
      }

      if(quark==quarkAudioRecord) {
	currentChannel=playbackChannels+strtol(value, NULL, 0);
	continue;
      }

      if(!cardMatch || !classMatch ||
	 !isupper(*name))
	continue;

      if(nControls>=(int)XtNumber(controls)-1) {
	/* mixerControls buffer full, we need to flush it */
	controls[nControls].id=SAM_MIXER_ID_SENTINEL;
	if(currentChannel>=0)
	  sendAudioControls(complain, currentChannel, controls);
	else
	  sendMixerControls(complain, mixerAssocFW, pass==0, controls);
	nControls=0;
      }
      if(currentChannel>=0 && audioCtrlsByName->count(quark) &&
	 pass==1) {
	controlP=controls+nControls;
	controlP->id=(*audioCtrlsByName)[quark]->id;
	controlP->addr=addr;
	controlP->value=strtol(value, NULL, 0);
	nControls++;
      }
      if(currentChannel<0) {
	if(mixerCtrlsByName->count(quark))
	  mixerAssoc=(*mixerCtrlsByName)[quark];
	else if(mixerHWCtrlsByName.count(quark))
	  mixerAssoc=mixerHWCtrlsByName[quark];
	else
	  mixerAssoc=NULL;
	if(mixerAssoc && pass==!mixerAssoc->doesReset) {
	  /* mixer adjustment */
	  controlP=controls+nControls;
	  controlP->id=mixerAssoc->id;
	  controlP->addr=addr;
	  controlP->value=strtol(value, NULL, 0);
	  nControls++;
	}
      }
    }

    if(nControls>0) {
      controls[nControls].id=SAM_MIXER_ID_SENTINEL;
      if(currentChannel>=0)
	sendAudioControls(complain, currentChannel, controls);
      else
	sendMixerControls(complain, mixerAssocFW, pass==0, controls);
    }
  }
}

void Device::saveSettings(int complain, char *fileName)
{
  SamDriverInfo driverInfo;
  SamCtrlNameAssoc *mixerAssocList[2];
  SamCtrlNameAssoc *mixerAssoc, *audioAssoc;
  SamRedirectedAudioControl redir;
  SamControl controls[MAX(SAM_MIXER_CONTROLS, SAM_AUDIO_CONTROLS)+1];
  map<int, int, less<int> > supported;
  FILE *fp;
  int error, nControls, pass, audioChannels;
  int channel, addr, addrLimit, i, first;

  if(::ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
    if(complain)
      appl->error(1, appl->resources.errQueryDriver, NULL);
    return;
  }

  audioChannels=driverInfo.playChannelsTotal+driverInfo.recordChannelsTotal;

  for(i=0; samApiAssocs[i].name; i++)
    if(samApiAssocs[i].apiClass==apiClass)
      break;
  if(!samApiAssocs[i].name)
    return;

  mixerAssocList[0]=samMixerAssocHW;
  mixerAssocList[1]=samApiAssocs[i].mixer;
  audioAssoc=samApiAssocs[i].audio;

  if(!(fp=fopen(fileName, "w"))) {
    if(complain)
      appl->error(0, appl->resources.errOpenOutputFile, NULL);
    return;
  }

  fprintf(fp, "%-15s %d\n", "card", cardNr);
  fprintf(fp, "%-15s %s\n", "class", samApiAssocs[i].name);

  /* check if a mixer control is supported
   * in first pass and retrieve the value
   * in the second pass
   */
  addrLimit=0;
  for(pass=0; pass<2; pass++) {
    nControls=0;
    for(i=0; i<(int)XtNumber(mixerAssocList); i++) {
      for(mixerAssoc=mixerAssocList[i]; mixerAssoc->name; mixerAssoc++) {
	if(pass>0) {
	  if(!supported[mixerAssoc->id])
	    continue;
	  addrLimit=mixerAssoc->addrLimit;
	} else
	  addrLimit=0;
	for(addr=0; addr<=addrLimit; addr++) {
	  controls[nControls].id=mixerAssoc->id;
	  controls[nControls].addr=addr;
	  nControls++;
	}
      }
    }
    if(nControls>0) {
      controls[nControls].id=SAM_MIXER_ID_SENTINEL;
      if(pass==0)
	error=ioctl(mixerFd, SAM_IOC_MIXER_INFO, controls);
      else
	error=ioctl(mixerFd, SAM_IOC_MIXER_GET, controls);
      if(error<0) {
	if(complain)
	  appl->error(1, appl->resources.errQueryMixer, NULL);
	fclose(fp);
	return;
      }
      if(pass==0) {
	for(i=0; i<nControls; i++)
	  supported[controls[i].id]=controls[i].value;
      }
    }
  }

  /* dump supported mixer values */
  nControls=0; first=1;
  for(i=0; i<(int)XtNumber(mixerAssocList); i++) {
    for(mixerAssoc=mixerAssocList[i]; mixerAssoc->name; mixerAssoc++) {
      if(!supported[mixerAssoc->id])
	continue;
      addrLimit=mixerAssoc->addrLimit;
      if(first) {
        fprintf(fp, "mixer\n");
	first=0;
      }
      fprintf(fp, "%-15s %d\n", mixerAssoc->name, controls[nControls++].value);
      for(addr=1; addr<=addrLimit; addr++)
	fprintf(fp, "%-12s[%d] %d\n", mixerAssoc->name, addr, controls[nControls++].value);
    }
  }

  if(driverInfo.haveAudio) {
    for(channel=0; channel<audioChannels; channel++) {
      redir.channel=channel;
      redir.controls=controls;
      for(pass=0; pass<2; pass++) {
	nControls=0;
	for(i=0; audioAssoc[i].name; i++) {
	  if(pass>0) {
	    if(!supported[audioAssoc[i].id])
	      continue;
	    addrLimit=audioAssoc[i].addrLimit;
	  } else
	    addrLimit=0;
	  for(addr=0; addr<=addrLimit; addr++) {
	    controls[nControls].id=audioAssoc[i].id;
	    controls[nControls].addr=addr;
	    nControls++;
	  }
	}
	if(nControls>0) {
	  controls[nControls].id=SAM_AUDIO_ID_SENTINEL;
	  if(pass==0)
	    error=ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_INFO, &redir);
	  else
	    error=ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_GET, &redir);
	  if(error<0) {
	    if(complain)
	      appl->error(1, appl->resources.errQueryMixer, NULL);
	    fclose(fp);
	    return;
	  }
	  if(pass==0) {
	    for(i=0; i<nControls; i++)
	      supported[controls[i].id]=controls[i].value;
	  }
	}
      }
      /* dump supported mixer values */
      nControls=0; first=1;
      for(i=0; audioAssoc[i].name; i++) {
	if(!supported[audioAssoc[i].id])
	  continue;
	if(controls[nControls].isConfigured &&
	   ((channel>=playbackChannels && !audioAssoc[i].restrictPlayMode) ||
	    (channel<playbackChannels && !audioAssoc[i].restrictRecordMode))) {
	  if(first) {
	    if(channel>=playbackChannels)
	      fprintf(fp, "%-15s %d\n", "audio_record", channel-playbackChannels);
	    else
	      fprintf(fp, "%-15s %d\n", "audio_play", channel);
	    first=0;
	  }
	  fprintf(fp, "%-15s %d\n", audioAssoc[i].name, controls[nControls++].value);
	  addrLimit=audioAssoc[i].addrLimit;
	  for(addr=1; addr<=addrLimit; addr++)
	    fprintf(fp, "%-12s[%d] %d\n", audioAssoc[i].name, addr, controls[nControls++].value);
	} else
	  nControls+=addrLimit+1;
      }
    }
  }

  fclose(fp);
}

void Device::loadFirmware(char *fileName)
{
  SamFirmware firmware;
  int fd;
  struct stat st;
  
  if((fd=::open(fileName, O_RDONLY))<0 ||
     ::fstat(fd, &st)<0 ||
     (firmware.data=(unsigned short *)::mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    appl->error(1, appl->resources.errOpenFirm, NULL);
    if(fd>=0)
      ::close(fd);
    return;
  }
  firmware.size=st.st_size>>1;
  if(::ioctl(mixerFd, SAM_IOC_FIRMWARE_LOAD, &firmware)<0)
    appl->error(1, appl->resources.errLoadFirm, NULL);

  ::munmap((caddr_t)firmware.data, st.st_size);
  ::close(fd);
}

void Device::loadSBank(int slot, char *fileName)
{
  SamSoundBank sbank;
  int fd;
  struct stat st;
  
  sbank.id=slot;
  if((fd=::open(fileName, O_RDONLY))<0 ||
     ::fstat(fd, &st)<0 ||
     (sbank.data=(char *)::mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0))==MAP_FAILED) {
    appl->error(1, appl->resources.errOpenSBank, NULL);
    if(fd>=0)
      ::close(fd);
    return;
  }
  sbank.size=st.st_size;
  if(::ioctl(mixerFd, SAM_IOC_BANK_LOAD, &sbank)<0)
    appl->error(1, appl->resources.errLoadSBank, NULL);

  ::munmap((caddr_t)sbank.data, st.st_size);
  ::close(fd);
}

void Device::unloadSBank(int slot)
{
  unsigned char id;

  id=slot;
  if(::ioctl(mixerFd, SAM_IOC_BANK_UNLOAD, &id)<0)
    appl->error(1, appl->resources.errUnloadSBank, NULL);
}

void Device::changeSBankPrio(int slot, int prio)
{
  SamSoundBankPrio info;

  info.id=slot;
  info.priority=prio;
  if(::ioctl(mixerFd, SAM_IOC_BANK_PRIO_CHG, &info)<0)
    appl->error(1, appl->resources.errSBankPrioChg, NULL);
}

void Device::startPollPeakMeter()
{
  if(pollPeakMeterId)
    return;

  pollPeakMeterId=XtAppAddTimeOut(appl->appContext, appl->resources.pollPeakMeterInterval, pollPeakMeter, this);
}

void Device::stopPollPeakMeter()
{
  if(!pollPeakMeterId)
    return;

  XtRemoveTimeOut(pollPeakMeterId);
  pollPeakMeterId=0;
}


Event **Device::findEventPInBuckets(HashBucket **buckets, unsigned idx)
{
  int bucketIdx=idx%HashBucketSize;
  HashBucket *hashBucket=buckets[bucketIdx];

  while(hashBucket && hashBucket->idx!=idx)
    hashBucket=hashBucket->next;

  if(!hashBucket) {
    hashBucket=new HashBucket;
    hashBucket->idx=idx;
    hashBucket->events=NULL;
    hashBucket->next=buckets[bucketIdx];
    buckets[bucketIdx]=hashBucket;
  }

  return &hashBucket->events;
}

void Device::triggerFirmwareChanged(int aApiClass)
{
  SamApiInfo apiInfo;
  SamDriverInfo driverInfo;
  int i;
  char *hwName, *fwName;
  Event *event;

  if(aApiClass<0) {
    if(::ioctl(mixerFd, SAM_IOC_API_INFO, &apiInfo)<0) {
      appl->error(1, appl->resources.errQueryApi, NULL);
      apiClass=SAM_API_CLASS_NONE;
    } else
      apiClass=apiInfo.apiClass;
  } else
    apiClass=aApiClass;

  hwName="";
  fwName="";
  playbackChannels=0;
  if(apiClass!=SAM_API_CLASS_NONE) {
    if(::ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)>=0) {
      hwName=driverInfo.hardware;
      fwName=driverInfo.firmware;
      playbackChannels=driverInfo.playChannelsTotal;
    } else {
      appl->error(1, appl->resources.errQueryDriver, NULL);
      apiClass=SAM_API_CLASS_NONE;
    }
  }

  /* check if we do support that class */
  for(i=0; samApiAssocs[i].name; i++)
    if(samApiAssocs[i].apiClass==apiClass)
      break;

  if(!samApiAssocs[i].name)
    apiClass=SAM_API_CLASS_NONE;

  if(!supportedApis.count(apiClass))
    apiClass=SAM_API_CLASS_NONE;

  for(event=firmwareChangedEvents; event; event=event->next)
    event->triggerFirmwareChanged(cardNr, apiClass, hwName, fwName);

  if(apiClass!=SAM_API_CLASS_NONE)
    triggerAllValues(apiClass, driverInfo.playChannelsTotal+driverInfo.recordChannelsTotal);
}

void Device::triggerSBankChanged()
{
  SamDriverInfo driverInfo;
  SamSoundBankInfo sbanks[SAM_NROF_SBANKS];
  Event::SoundbankInfo infos[SAM_NROF_SBANKS];
  Event *event;
  int i;
  
  if(::ioctl(mixerFd, SAM_IOC_DRIVER_INFO, &driverInfo)<0) {
    appl->error(1, appl->resources.errQueryDriver, NULL);
    return;
  }

  if(!driverInfo.haveMidi)
    return;
  
  if(ioctl(mixerFd, SAM_IOC_BANK_INFO, sbanks)>=0) {
    for(i=0; i<SAM_NROF_SBANKS; i++) {
      infos[i].name=sbanks[i].name;
      infos[i].priority=sbanks[i].priority;
    }
    for(event=sbankChangedEvents; event; event=event->next)
      event->triggerSBankChanged(infos, SAM_NROF_SBANKS, driverInfo.memSBanks, driverInfo.memFree);
  } else
    appl->error(1, appl->resources.errQuerySBank, NULL);
}

void Device::triggerPeakMeter()
{
  unsigned short tbl[256];
  SamPeakMeterInfo peakMeterInfo;
  Event *event;

  if(!peakMeterEvents)
    return;

  peakMeterInfo.data=tbl;
  peakMeterInfo.size=XtNumber(tbl);
  if(::ioctl(mixerFd, SAM_IOC_PEAK_METER_INFO, &peakMeterInfo)<0) {
    appl->error(1, appl->resources.errQueryPeakMeter, NULL);
    return;
  }

  if(peakMeterInfo.size==0)
    return;

  for(event=peakMeterEvents; event; event=event->next)
    event->triggerPeakMeter(tbl);
}

void Device::triggerChannelOwner()
{
  int pids[256];
  SamChannelOwnerInfo ownerInfo;
  Event *event;

  if(!channelOwnerEvents)
    return;

  ownerInfo.pids=pids;
  ownerInfo.size=XtNumber(pids);
  if(::ioctl(mixerFd, SAM_IOC_CHANNEL_OWNER_INFO, &ownerInfo)<0) {
    appl->error(1, appl->resources.errQueryChannelOwner, NULL);
    return;
  }

  if(ownerInfo.size==0)
    return;

  for(event=channelOwnerEvents; event; event=event->next)
    event->triggerChannelOwner(pids);
}

void Device::triggerValues(int checkSupported, int channel, SamControl *controls)
{
  SamRedirectedAudioControl redir;
  Event *event;
  int result, i, maskedChannel;

  if(channel>=0) {
    redir.channel=channel;
    redir.controls=controls;
    if(checkSupported)
      result=ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_INFO, &redir);
    else
      result=ioctl(mixerFd, SAM_IOC_MIXER_AUDIO_GET, &redir);
  } else {
    if(checkSupported)
      result=ioctl(mixerFd, SAM_IOC_MIXER_INFO, controls);
    else
      result=ioctl(mixerFd, SAM_IOC_MIXER_GET, controls);
  }

  if(result<0) {
    appl->error(1, appl->resources.errQueryMixer, NULL);
    return;
  }

  if(channel>=0) {
    if(channel>=playbackChannels)
      maskedChannel=(channel-playbackChannels)|RecordChannelMask;
    else
      maskedChannel=channel;
    for(i=0; controls[i].id!=SAM_AUDIO_ID_SENTINEL; i++) {
      event=*findEventPInBuckets(audioChangedEvents,
				 (maskedChannel<<16)|(controls[i].id<<8)|controls[i].addr);
      if(checkSupported) {
	for(; event; event=event->next)
	  if(!controls[i].value)
	    event->triggerAudioValue(-1);
      } else
	for(; event; event=event->next)
	  event->triggerAudioValue(controls[i].value);
    }
  } else {
    for(i=0; controls[i].id!=SAM_MIXER_ID_SENTINEL; i++) {
      event=*findEventPInBuckets(mixerChangedEvents,
				 (controls[i].id<<8)|controls[i].addr);
      if(checkSupported) {
	for(; event; event=event->next)
	  if(!controls[i].value)
	    event->triggerMixerValue(-1);
      } else
	for(; event; event=event->next)
	  event->triggerMixerValue(controls[i].value);
    }
  }
}

void Device::triggerAllValues(int apiClass, int audioChannels)
{
  SamCtrlNameAssoc *mixerAssocList[2];
  SamCtrlNameAssoc *mixerAssoc, *audioAssoc;
  SamControl controls[MAX(SAM_MIXER_CONTROLS, SAM_AUDIO_CONTROLS)+1];
  map <int, int, less<int> > supported;
  int pass, channel, nControls, addr, addrLimit, i;

  for(i=0; samApiAssocs[i].name; i++)
    if(samApiAssocs[i].apiClass==apiClass)
      break;

  if(!samApiAssocs[i].name)
    return;

  mixerAssocList[0]=samMixerAssocHW;
  mixerAssocList[1]=samApiAssocs[i].mixer;
  audioAssoc=samApiAssocs[i].audio;

  /* check if a mixer control is supported
   * in first pass and retrieve the value
   * in the second pass
   */
  for(pass=0; pass<2; pass++) {
    nControls=0;
    for(i=0; i<(int)XtNumber(mixerAssocList); i++) {
      for(mixerAssoc=mixerAssocList[i]; mixerAssoc->name; mixerAssoc++) {
	if(pass>0 && !supported[mixerAssoc->id])
	  continue;
	addrLimit=mixerAssoc->addrLimit;
	for(addr=0; addr<=addrLimit; addr++) {
	  controls[nControls].id=mixerAssoc->id;
	  controls[nControls].addr=addr;
	  nControls++;
	}
      }
    }
    if(nControls>0) {
      controls[nControls].id=SAM_MIXER_ID_SENTINEL;
      triggerValues(pass==0, -1, controls);
      if(pass==0) {
	for(i=0; i<nControls; i++)
	  supported[controls[i].id]=controls[i].value;
      }
    }
  }

  for(channel=0; channel<audioChannels; channel++) {
    for(pass=0; pass<2; pass++) {
      nControls=0;
      for(i=0; audioAssoc[i].name; i++) {
	if(pass>0 && !supported[audioAssoc[i].id])
	  continue;
	addrLimit=audioAssoc[i].addrLimit;
	for(addr=0; addr<=addrLimit; addr++) {
	  controls[nControls].id=audioAssoc[i].id;
	  controls[nControls].addr=addr;
	  nControls++;
	}
      }
      if(nControls>0) {
	controls[nControls].id=SAM_AUDIO_ID_SENTINEL;
	triggerValues(pass==0, channel, controls);
	if(pass==0)
	  for(i=0; i<nControls; i++)
	    supported[controls[i].id]=controls[i].value;
	nControls=0;
      }
    }
  }

  triggerSBankChanged();
  triggerPeakMeter();
  triggerChannelOwner();
}

void Device::handleEvents(SamEvent *events, int nEvents)
{
  SamControl controls[EventChunkSize+1];
  int channel, nControls, i;

  channel=-1;
  nControls=0;
  for(i=0; i<nEvents; i++) {
    if(events[i].type>=0) {
      /* audio event */
      if((nControls>0 && channel!=events[i].type) ||
	 nControls>=EventChunkSize) {
	controls[nControls].id=SAM_AUDIO_ID_SENTINEL;
	triggerValues(0, channel, controls);
	nControls=0;
      }
      channel=events[i].type;
      controls[nControls].id=events[i].id;
      controls[nControls].addr=events[i].addr;
      nControls++;
    } else
      switch(events[i].type) {
      case SAM_EVENT_TYPE_MIXER:
	if((nControls>0 && channel>=0) ||
	   nControls>=EventChunkSize) {
	  controls[nControls].id=SAM_MIXER_ID_SENTINEL;
	  triggerValues(0, channel, controls);
	  nControls=0;
	}
	channel=-1;
	controls[nControls].id=events[i].id;
	controls[nControls].addr=events[i].addr;
	nControls++;
	break;
      case SAM_EVENT_TYPE_NOCTRL:
	switch(events[i].id) {
	case SAM_EVENT_FIRMWARE_CHANGED:
	  triggerFirmwareChanged(-1);
	  return;
	case SAM_EVENT_SBANK_CHANGED:
	  triggerSBankChanged();
	  break;
	case SAM_EVENT_CHANNEL_OWNER_CHANGED:
	  triggerChannelOwner();
	  if(verifyChannelOwnerId)
	    XtRemoveTimeOut(verifyChannelOwnerId);
	  verifyChannelOwnerId=XtAppAddTimeOut(appl->appContext, appl->resources.verifyChannelOwnerDelay, verifyChannelOwner, this);
	  break;
	}
	break;
      }
  }

  if(nControls>0) {
    controls[nControls].id=SAM_MIXER_ID_SENTINEL;
    triggerValues(0, channel, controls);
  }
}
