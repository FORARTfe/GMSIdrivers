#ifndef _TABP_H
#define _TABP_H

#include <X11/Xmu/Converters.h>
#include "Tab.h"

typedef struct _TabClassPart {
  XtPointer	    extension;		/* pointer to extension record      */
} TabClassPart;

/* Class record declaration */
typedef struct _TabClassRec {
  CoreClassPart	core_class;
  CompositeClassPart	composite_class;
  ConstraintClassPart constraint_class;
  TabClassPart	tab_class;
}TabClassRec;

extern TabClassRec tabClassRec;

typedef struct {
  /* resources */
  Dimension shadowThickness;
  Pixel foreground,topShadowColor,bottomShadowColor;
  Dimension marginWidth,tabGapWidth;
  Widget selectedTab;
  Boolean userSelectable, tabVisible;
  XtTranslations tabTranslations;
  /* user data */
  int dontLayout; /* doing layout already */
  Dimension preferredWidth, preferredHeight;
  GC topGC,bottomGC;
  /* keep some redundant variables,
   * for convenience & performance reasons
   * there variables are calculated in Layout()
   */
  Dimension tabWidth, tabHeight, tabBorderWidth, paneWidth, paneHeight, paneBorderWidth, tabRequiredHeight, requiredWidth, requiredHeight, actualWidth, actualHeight, cellWidth;
  int maxTabPosition;
}TabPart;

typedef struct _TabRec {
  CorePart		core;
  CompositePart	composite;
  ConstraintPart	constraint;
  TabPart	tab;
}TabRec;

typedef struct _TabConstraintsPart {
  /* resource part */
  Boolean isTab;   /* true->tab, false->pane */
  int tabPosition; /* position of tab & pane, -1 means invisible */
  Widget relatedPane; /* if this is a tab, relatedPane should point to its pane */

    /* user data  */
  Dimension preferredWidth, preferredHeight,
    preferredBorderWidth; /* what the size of the widget would be,
				 if we wouldn't have forced it */
  Boolean hasTranslations; /* does it have an overridden translation table already */
} TabConstraintsPart;

typedef struct _TabConstraintsRec {
  TabConstraintsPart tab;
} TabConstraintsRec, *TabConstraints;

#endif /* _TABP_H */
