/*
  Copyright (C) 1998-2003 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  dumpmmt can be used to dump the MMT layout of a sam9407 card
  in debugging mode.

  usage: dumpmmt [-n cardNr] [-d <mixer_device>]
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#include <sam9407.h>
#include <firmware.h>

char *prgName;

void fatal(int perr,char *format, ...)
{
  int errn=errno;
  va_list ap;
  va_start(ap, format);
  fprintf(stderr,"%s: ", prgName);
  vfprintf(stderr,format,ap);
  if(perr){
    fprintf(stderr,": ");
    errno=errn;
    perror(NULL);
  }else
    fprintf(stderr,"\n");
  va_end(ap);
  exit(1);
}

void usage(void)
{
  fprintf(stderr, "usage: %s [-n cardNr] [-d <mixer_device>]\n", prgName);
  exit(1);
}

void dumpMMT(int fd)
{
  SamMMTEntry mmt[256];
  SamMMTInfo mmtInfo;
  int slots, i, done;
  char *name;

  mmtInfo.data=(char *)mmt;
  mmtInfo.size=sizeof(mmt);

  if(ioctl(fd, SAM_IOC_DEBUG_MMT_INFO, &mmtInfo)<0)
    fatal(1, "Did you compile the driver with --enable-debug ?\ncan't query MMT info from soundcard");

  slots=mmtInfo.size/sizeof(SamMMTEntry);

  printf("   addr    data rom content\n");
  done=0;
  for(i=0; !done && i<slots; i++) {
    switch(mmt[i].id&SAM_MMT_ID_MASK) {
    case SAM_MMT_ID_MEMSIZE:
      name="memory size";
      break;
    case SAM_MMT_ID_FREE:
      name="free";
      break;
    case SAM_MMT_ID_RESERVED:
      name="system reserved block";
      break;
    case SAM_MMT_ID_MMT:
      name="memory mapping table";
      break;
    case SAM_MMT_ID_MIDI_MT:
      name="midi mapping table";
      break;
    case SAM_MMT_ID_MIDI_MT_EXT:
      name="midi mapping table extension";
      break;
    case SAM_MMT_ID_CTRL_TBL:
      name="control table";
      break;
    case SAM_MMT_ID_MIDI_PAR:
      name="midi sound parameter";
      break;
    case SAM_MMT_ID_MIDI_PCM:
      name="midi sound pcm";
      break;
    case SAM_MMT_ID_STR_WAVE:
      name="streaming wave buffer";
      break;
    case SAM_MMT_ID_STAT_WAVE:
      name="static wave buffer";
      break;
    case SAM_MMT_ID_MMT_COPY:
      name="memory mapping table copy (unofficial)";
      break;
    case SAM_MMT_ID_MIDI_MT_COPY:
      name="midi mapping table copy (unofficial)";
      break;
    case SAM_MMT_ID_SAVED_CTRLS:
      name="control values backup (unofficial)";
      break;
    case SAM_MMT_ID_SAVED_HWCACHE:
      name="hardware cache backup (unofficial)";
      break;
    case SAM_MMT_ID_EOM:
      name="end of memory";
      done=1;
      break;
    default:
      name="** unknown **";
      break;
    }
    printf("0x%08x 0x%02x  %c  %s\n",
	   mmt[i].addr, mmt[i].id>>8,
	   mmt[i].id&SAM_MMT_ROM_MASK ? '*' : ' ',
	   name);
  }
}

int main(int argc, char **argv)
{
  int c, cardNr, fd;
  char buf[256], *devName;

  prgName=argv[0];

  cardNr=0;
  devName=NULL;
  while((c=getopt(argc, argv, "d:n:"))!=EOF) {
    switch(c) {
    case 'd':
      devName=optarg;
      break;
    case 'n':
      cardNr=strtol(optarg, NULL, 0);
      break;
    default:
      usage();
    }
  }

  if(!devName) {
    sprintf(buf, "/dev/sam9407/card%d/mixer", cardNr);
    devName=buf;
    fd=open(devName, O_RDWR);
    if(fd<0) {
      sprintf(buf, "/dev/sam%d_mixer", cardNr);
      devName=buf;
      fd=open(devName, O_RDWR);
    }
    if(fd<0 && cardNr==0) {
      devName="/dev/mixer";
      fd=open(devName, O_RDWR);
    }
  } else
    fd=open(devName, O_RDWR);

  if(fd<0)
    fatal(1, "can't open mixer device");

  dumpMMT(fd);

  return 0;
}
