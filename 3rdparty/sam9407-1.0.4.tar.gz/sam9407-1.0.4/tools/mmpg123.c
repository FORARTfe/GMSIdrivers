/*
  Copyright (C) 2000 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  mmpg123 will use mpg123(1) to play multiple synchronized streams,
  distributed to the available sam9407 output channels.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

#include <sam9407.h>

char *prgName;

void fatal(int perr, char *format, ...)
{
  int errn=errno;
  va_list ap;

  fprintf(stderr, "%s: ", prgName);
  va_start(ap, format);
  vfprintf(stderr, format, ap);
  va_end(ap);
  if(perr)
    fprintf(stderr, ": %s\n", strerror(errn));
  else
    fprintf(stderr, "\n");

  exit(1);
}

void setVolume(int fd, unsigned left, unsigned right, unsigned auxLeft, unsigned auxRight)
{
  SamControl controls[5], *ctrlP;

  ctrlP=controls;

  ctrlP->id=SAM_AUDIO_ID_VOLUME_LEFT;
  ctrlP->addr=0;
  ctrlP->value=left;
  ctrlP++;

  ctrlP->id=SAM_AUDIO_ID_VOLUME_RIGHT;
  ctrlP->addr=0;
  ctrlP->value=right;
  ctrlP++;

  ctrlP->id=SAM_AUDIO_ID_VOLUME_AUX_LEFT;
  ctrlP->addr=0;
  ctrlP->value=auxLeft;
  ctrlP++;

  ctrlP->id=SAM_AUDIO_ID_VOLUME_AUX_RIGHT;
  ctrlP->addr=0;
  ctrlP->value=auxRight;
  ctrlP++;

  ctrlP->id=SAM_AUDIO_ID_SENTINEL;

  if(ioctl(fd, SAM_IOC_AUDIO_SET, controls)<0)
    fatal(1, "can't change output volume");
}

void openStreams(int *streams, int count)
{
  int card, rear, i, fd, syncGroup;
  char buf[256];

  syncGroup=-1;
  card=rear=0;
  i=0;
  while(i<count) {
    sprintf(buf, "/dev/sam9407/card%d/dsp", card);
    fd=open(buf, O_WRONLY);
    if(fd<0) {
      sprintf(buf, "/dev/sam%d_dsp", card);
      fd=open(buf, O_WRONLY);
    }
    if(fd<0 && card==0)
      fd=open("/dev/dsp", O_WRONLY);
    if(fd<0) {
      if(card==0)
	fatal(1, "out of streaming channels");
      card=rear=0;
      continue;
    }

    if(rear)
      setVolume(fd, 0, 0, 65535, 65535);
    else
      setVolume(fd, 65535, 65535, 0, 0);

    if(ioctl(fd, SAM_IOC_SYNC_JOIN, &syncGroup)<0)
      fatal(1, "can't join sync playback group");

    if(++rear>=2) {
      rear=0;
      card++;
    }
    streams[i++]=fd;
  }
  fprintf(stderr, "%s: using sync playback group #%d\n", prgName, syncGroup);
}

void startPlayers(char **fileNames, int *streams, int count)
{
  int i;

  for(i=0; i<count; i++) {
    switch(fork()) {
    case 0:
      if(dup2(streams[i], 1)<0)
	fatal(1, "can't redirect audio stream to stdout");
      close(streams[i]);
      execlp("mpg123", "mpg123", "-s", fileNames[i], NULL);
      fatal(1, "can't exec mpg123");
      break;
    case -1:
      fatal(1, "fork failed");
      break;
    default:
      close(streams[i]);
    }
  }
}

void reapChildren(int count)
{
  int died, status;

  died=0;
  while(died<count) {
    if(wait(&status)>=0)
      died++;
  }
}

int main(int argc, char **argv)
{
  int *streams;

  prgName=argv[0];

  if(!(streams=alloca((argc-1)*sizeof(int))))
    fatal(0, "virtual memory exhausted.");

  openStreams(streams, argc-1);
  startPlayers(argv+1, streams, argc-1);
  reapChildren(argc-1);

  return 0;
}
