/*
  Copyright (C) 2000 Gerd Rausch <gerd@meshed.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define NUMBER_OF(vec)		(sizeof(vec)/sizeof(*(vec)))

typedef struct {
  char *devName, *legacyName;
  int isDefault;
  char **aliases;
} DeviceInfo;

static char *seqAliases[]={
  "music",
  "sequencer2",
  NULL			/* sentinel */
};

static DeviceInfo deviceInfos[]={
  { "mixer",		"mixer",	0 },
  { "sequencer",	"sequencer",	1,	seqAliases },
  { "midi_int",		"midi00",	1 },
  { "midi_ext",		"midi01",	1 },
  { "dsp",		"dsp",		1 },
  { "audio",		"audio",	1 },
  { "status",		"sndstat",	0 },
  { "mod",		"mod",		0 },
};

static DeviceInfo *parse_devname(char *str, int *cardP)
{
  char *cp;
  int i;

  cp=str;
  if(strncmp(cp, "sam9407/card", 12)!=0)
    return NULL;
  cp+=12;
  *cardP=strtol(cp, &cp, 10);
  if(*cp!='/')
    return NULL;
  cp++;

  for(i=0; i<NUMBER_OF(deviceInfos); i++)
    if(strcmp(cp, deviceInfos[i].devName)==0)
      return deviceInfos+i;

  return NULL;
}

int sam_register(int argc, char **argv)
{
  char to[256];
  int card;
  DeviceInfo *devInfo;
  char **aliasP;

  if(argc<3 ||
     !(devInfo=parse_devname(argv[2], &card)))
    return 0;

  sprintf(to, "%s/sam%d_%s", argv[1], card, devInfo->legacyName);
  unlink(to);
  symlink(argv[2], to);

  if(card==0 && devInfo->isDefault) {
    sprintf(to, "%s/%s", argv[1], devInfo->legacyName);
    unlink(to);
    symlink(argv[2], to);

    if(devInfo->aliases) {
      for(aliasP=devInfo->aliases; *aliasP; aliasP++) {
	sprintf(to, "%s/%s", argv[1], *aliasP);
	unlink(to);
	symlink(argv[2], to);
      }
    }
  }

  return 0;
}
