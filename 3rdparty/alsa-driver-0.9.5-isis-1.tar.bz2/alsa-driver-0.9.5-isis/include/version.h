/* include/version.h.  Generated automatically by configure.  */
#define CONFIG_SND_VERSION "0.9.5"
#define CONFIG_SND_DATE ""
