#define __NO_VERSION__
#include "../../alsa-kernel/pci/ice1712/hoontech.c"
