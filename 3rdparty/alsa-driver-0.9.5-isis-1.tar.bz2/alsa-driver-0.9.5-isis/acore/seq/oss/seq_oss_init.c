#define __NO_VERSION__
#include "../../../alsa-kernel/core/seq/oss/seq_oss_init.c"
